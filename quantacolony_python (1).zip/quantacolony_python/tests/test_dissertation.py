"""The dissertation pieces: crowding score, within-state test, robustness statistics, figure house style."""

import numpy as np
import pytest

from quantacolony.core.colony_set import ColonySet
from quantacolony.core import crowding, robustness, within_state


def _colonies(centers, radii):
    n = len(radii)
    return ColonySet(np.arange(n), np.asarray(centers, float), np.asarray(radii, float), (None,) * n,
                     ("circular",) * n, np.full(n, np.nan))


def _disc(shape, x, y, r):
    yy, xx = np.mgrid[:shape[0], :shape[1]]
    return np.hypot(xx - x, yy - y) <= r


def test_crowding_score_counts_only_competitor_growth():
    shape = (300, 300)
    growth = _disc(shape, 50, 50, 10) | _disc(shape, 150, 150, 10) | _disc(shape, 180, 150, 10)
    scores = crowding.colony_scores(growth, _colonies([(50, 50), (150, 150), (180, 150)], [10, 10, 10]))
    assert scores[0] == pytest.approx(0.0)              # alone: its own growth is never a competitor
    assert 0 < scores[1] < 100 and scores[1] == pytest.approx(scores[2], rel=0.05)


def test_crowding_score_rises_as_the_neighbour_comes_closer():
    shape = (240, 240)
    near = crowding.colony_scores(_disc(shape, 100, 100, 10) | _disc(shape, 125, 100, 10),
                                  _colonies([(100, 100), (125, 100)], [10, 10]))[0]
    far = crowding.colony_scores(_disc(shape, 100, 100, 10) | _disc(shape, 140, 100, 10),
                                 _colonies([(100, 100), (140, 100)], [10, 10]))[0]
    assert near > far > 0


def test_within_state_fit_recovers_the_within_state_slope():
    rng = np.random.default_rng(1)
    plates = []
    for s in range(6):
        offset = rng.normal(0, 1)                         # states differ a lot; the test removes it
        for k in range(4):
            count = 10 ** rng.uniform(1.7, 2.6)
            radius = 10 ** (offset + 3 - 0.3 * np.log10(count))
            plates.append(within_state.Plate("P", f"s{s}", f"{s}{k}", hce=count * 10, count=count,
                                             growth=0.1 * k, capture=0.6, median_radius=radius))
    result = within_state.run(plates)
    fit = result["fits"]["Colony count"]
    assert fit.slope == pytest.approx(-0.3, abs=1e-6) and fit.r2 == pytest.approx(1.0, abs=1e-9)


def test_within_state_drops_low_capture_plates_and_single_plate_states():
    keep = [within_state.Plate("P", "a", str(k), 100, 100 + k, 0.1, 0.5, 500) for k in range(2)]
    low = within_state.Plate("P", "a", "low", 100, 50, 0.1, 0.1, 500)
    lone = within_state.Plate("P", "b", "lone", 100, 50, 0.1, 0.9, 500)
    assert within_state.eligible(keep + [low, lone]) == keep


def test_robustness_faded_plates_sit_closer_to_their_own_cell():
    rng = np.random.default_rng(0)
    plates = []
    for c, center in enumerate((200.0, 500.0, 1200.0)):
        for k in range(5):
            medians = np.sort(center * np.exp(rng.normal(0, 0.05, 2)))
            plates.append(robustness.PlateComponents(c * 10 + k, (f"g{c}", "1"), f"g{c}", 100, medians,
                                                     np.array([0.5, 0.5]), k == 0))
    result = robustness.run(plates, permutations=200, seed=0)
    assert result["faded"] == 12 and result["closer"] == 12
    assert result["own_median"] < result["other_median"]


def test_house_style_embeds_only_latin_modern(tmp_path):
    from quantacolony.dissertation import style as S
    with S.house():
        figure = S.new_figure(4.0, 2.5)
        ax = figure.add_axes([0.2, 0.25, 0.7, 0.6])
        ax.plot([1, 2], [1, 2])
        ax.set_xlabel(S.label("cdc13-2 and rif1Δ, 450 µm"))
        ax.set_ylabel(r"Δ log$_{10}$ radius")
        report = S.check(figure)
        path = tmp_path / "f.pdf"
        figure.savefig(path)
    assert report["min_pt"] >= S.MIN_PT and not report["outside"]
    fonts = S.pdf_fonts(path)
    assert fonts and all(embedded and "LMRoman10" in name for name, embedded in fonts)


def test_share_beyond_a_size_counts_either_side_of_any_cutoff():
    from types import SimpleNamespace
    from quantacolony.analyses.builtin.per_plate import ThresholdShare
    values = np.array([100.0, 300.0, 500.0, 700.0, 1200.0, 200.0, 2000.0])
    axes = {"x": type("A", (list,), {"title": "Passage"})(["1"]), "groups": type("A", (list,), {"title": "Genotype"})(["WT"])}
    data = SimpleNamespace(values=values, index_ids=np.array([1, 1, 1, 1, 1, 2, 2]), scheme="raw",
                           axes=axes, value_label="Radius", plate_info={},
                           select=lambda groups, x: np.ones(values.size, bool))
    share = ThresholdShare()
    below = share.compute(data, {"cutoff": "450", "side": "below", "count": "colonies"})
    above = share.compute(data, {"cutoff": "1100", "side": "above", "count": "colonies"})
    assert {c["index_id"]: c["value"] for c in below["cells"][(0, 0)]} == {1: 0.4, 2: 0.5}
    assert {c["index_id"]: c["value"] for c in above["cells"][(0, 0)]} == {1: 0.2, 2: 0.5}
