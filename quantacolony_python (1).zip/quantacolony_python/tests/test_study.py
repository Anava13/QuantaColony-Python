"""User study: the model's rules, and one participant from the form to the results zip on the shipped bundle."""

import json
import sqlite3
import zipfile

import numpy as np
import pytest
from PySide6.QtWidgets import QApplication

from quantacolony.core.colony_set import ColonySet
from quantacolony.study import model as sm
from quantacolony.study.app import BUNDLE
from quantacolony.study.controller import StudyController
from quantacolony.study.views import ConceptsView, FinishView, FormView
from quantacolony.theme import apply_theme


@pytest.fixture(scope="module")
def app():
    return QApplication.instance() or QApplication([])


@pytest.fixture(scope="module")
def bundle():
    return sm.load_bundle(BUNDLE)


# ----- the model ----------------------------------------------------------------------------
def test_participant_and_order():
    person = sm.Participant()
    assert len(person.problems()) == 2 and person.problems()[1].startswith("Still to answer: Science")
    person.name = "  Ana / B. "
    person.answers = {key: choices[0] for key, _, choices in sm.QUESTIONS}
    assert not person.problems() and person.file_stem() == "Ana_B"
    names = [f"study_0{k}" for k in range(1, 7)]
    first, again = sm.presentation_order(names, 7), sm.presentation_order(names, 7)
    assert first == again and sorted(first) == names                   # the seed reproduces the order
    levels = sm.plate_levels(first)
    assert levels[0] == (sm.PRACTICE, "Practice") and levels[1] == (first[0], "Plate 1")


def test_bundle_holds_five_plates_in_order_and_a_target(bundle):
    assert [p.name for p in bundle.scored] == list(bundle.order) == ["study_04", "study_05", "study_03", "study_06"]
    assert bundle.practice.name == sm.PRACTICE and len(bundle.target.colony_ids) == 3
    assert all(bundle.photo_path(p).exists() and p.px_per_mm > 5 for p in bundle.plates)
    assert len(bundle.concepts) == 5 and all((bundle.folder / "concepts" / c.file).exists() for c in bundle.concepts)
    assert set(bundle.marks) == {"triple", "marker", "condensation", "bright", "faint", "snap", "clump"}
    assert bundle.truth_path().exists() and bundle.artifacts_path().exists()


def test_training_score_follows_the_required_rule(bundle):
    import csv
    from PIL import Image
    from quantacolony.study import score as sc
    labels = np.asarray(Image.open(bundle.labels_path())).astype(int)
    kinds = np.asarray(Image.open(bundle.artifacts_path()))
    rows = list(csv.DictReader(open(bundle.truth_path(), encoding="utf-8")))
    required = sc.required_colonies(rows)
    clump = bundle.marks["clump"].colony_ids
    assert not any(required[i] for i in clump) and sum(required.values()) > 0.8 * len(required)
    ids = [i for i, need in required.items() if need]
    centers, radii = member_circles(labels, ids)
    perfect = sc.score_plate(ColonySet.from_columns(centers, radii), labels, kinds, required)
    assert perfect.passed and perfect.found_share == 1 and perfect.correct_share == 1
    marker = bundle.marks["marker"]                                       # plus one outline on the plate number
    extra = ColonySet.from_columns(np.vstack([centers, [marker.center]]), np.append(radii, 8))
    scored = sc.score_plate(extra, labels, kinds, required)
    assert scored.verdicts[-1] == "false:marker" and scored.false_kinds == {"marker": 1}
    whole = sc.score_plate(ColonySet.from_columns(np.vstack([centers, [bundle.marks["clump"].center]]),
                                                  np.append(radii, bundle.marks["clump"].radius)), labels, kinds, required)
    assert whole.verdicts[-1] == "merged"                                 # one outline around the inseparable mass


def test_target_check_follows_the_merged_rule(bundle):
    from PIL import Image
    labels = np.asarray(Image.open(bundle.labels_path())).astype(int)
    target = bundle.target
    centers, radii = member_circles(labels, target.colony_ids)
    assert sm.target_resolved(ColonySet.from_columns(centers, radii), labels, target)
    whole = ColonySet.from_columns(np.array([target.center]), np.array([target.radius]))
    assert not sm.target_resolved(whole, labels, target)                 # one outline around the mass
    assert not sm.target_resolved(ColonySet.from_columns(centers[:2], radii[:2]), labels, target)   # one missed


def test_tutorial_steps_follow_the_recorded_events():
    facts = sm.Facts()
    assert sm.current_step(facts, set()) == 0
    assert sm.current_step(facts, {"plate"}) == 1
    facts = sm.Facts(settings=frozenset({"sense"}), split_changed=True, deletions=1, additions=1, undos=1)
    assert sm.STEPS[sm.current_step(facts, {"plate"})].key == "mass"
    assert sm.current_step(sm.Facts(target_resolved=True, practice_saved=True), {"plate", "settings", "split",
                                                                                 "delete", "add", "undo"}) == 8


def member_circles(labels, ids):
    centers, radii = [], []
    for i in ids:
        ys, xs = np.nonzero(labels == i)
        centers.append([xs.mean(), ys.mean()])
        radii.append(np.sqrt(len(xs) / np.pi))
    return np.array(centers), np.array(radii)


# ----- one participant, form to zip ------------------------------------------------------------
def test_a_participant_runs_the_whole_study(app, bundle, tmp_path):
    study = StudyController(app, apply_theme(app), bundle, tmp_path / "work", tmp_path)
    try:
        assert isinstance(study.view, FormView) and not study.view.start_button.isEnabled()
        study.set_name("Pilot 1")
        for key, _, choices in sm.QUESTIONS:
            study.set_answer(key, choices[-1])
        assert study.view.start_button.isEnabled()
        study.start()
        assert isinstance(study.view, ConceptsView)
        study.start_practice()
        d = study.detection
        assert study._plate() == sm.PRACTICE and not d.window.next_button.isVisible()

        def step():
            study.check_tutorial()
            return sm.STEPS[sm.current_step(study.facts(), study.passed)].key

        assert step() == "plate"
        study.pass_step()
        assert step() == "settings"
        d.spinner_value_changing("sense", d.session.params.sense)
        assert step() == "split"
        d.window.split_switch.toggle()
        d._detection_timer.stop()                                          # what the settle timer runs
        d.handle_backup_and_detection()
        assert step() == "delete"
        d.select_dropdown_option("DeleteIndividualColonies")
        x, y = d.session.colonies.centers[0]
        d.handle_delete_click(float(x), float(y))
        d.delete_selected_colonies_button_pushed()
        assert step() == "add"
        d.select_dropdown_option("AddIndividualColonies")
        d.add_new_circle(5.0, 5.0, 3.0)
        d.add_selected_colonies_button_pushed()
        assert step() == "undo"
        d.undo()
        assert step() == "mass" and not study.facts().target_resolved

        # the merged mass: delete what covers it, then one circle per colony
        x0, y0 = study._offset()
        centers, radii = member_circles(study.labels, bundle.target.colony_ids)
        d.select_dropdown_option("DeleteIndividualColonies")
        cx, cy = bundle.target.center[0] - x0, bundle.target.center[1] - y0
        near = np.hypot(d.session.colonies.centers[:, 0] - cx, d.session.colonies.centers[:, 1] - cy)
        for k in np.flatnonzero(near < bundle.target.radius * 1.2):
            px, py = d.session.colonies.centers[k]
            d.handle_delete_click(float(px), float(py))
        d.delete_selected_colonies_button_pushed()
        d.select_dropdown_option("AddIndividualColonies")
        for (px, py), r in zip(centers, radii):
            d.add_new_circle(float(px - x0), float(py - y0), float(r))
        d.add_selected_colonies_button_pushed()
        assert step() == "finish" and study.facts().target_resolved

        d.im_satisfied_pushed()                                            # practice saved: Plate 1 opens
        study.check_tutorial()
        record = study.manager.study_record()
        assert study.practice_done and "practice_saved" in record["times"] and study._plate() == record["order"][0]
        assert study.panel.progress.text() == "Plate 1 of 4"
        for _ in range(4):
            study.detection.im_satisfied_pushed()
            app.processEvents()
        assert isinstance(study.view, FinishView) and study.finished_path.exists()

        with zipfile.ZipFile(study.finished_path) as archive:
            names = archive.namelist()
            assert names == ["Pilot_1.qcproj", "participant.json"]
            saved = json.loads(archive.read("participant.json"))
            archive.extract("Pilot_1.qcproj", tmp_path / "out")
        assert saved["participant"] == {"name": "Pilot 1", **{k: c[-1] for k, _, c in sm.QUESTIONS}}
        assert saved["order"] == [p.name for p in bundle.scored]                 # the fixed order
        assert set(saved["times"]) == {"form_sent", "concepts_read", "practice_saved", "finished"}
        assert saved["study_version"] == sm.STUDY_VERSION and saved["tutorial_skipped"] == []

        db = sqlite3.connect(tmp_path / "out" / "Pilot_1.qcproj")
        photos = dict(db.execute("SELECT file_name, px_per_mm FROM photos").fetchall())
        assert photos == {p.file: pytest.approx(p.px_per_mm) for p in bundle.plates}   # the scorer's columns
        assert db.execute("SELECT COUNT(*) FROM detection").fetchone()[0] == 5
        assert db.execute("SELECT COUNT(DISTINCT index_id) FROM dev_detection_sessions").fetchone()[0] == 5
        assert db.execute("SELECT COUNT(*) FROM dev_initial_detection").fetchone()[0] >= 5
        stored = json.loads(db.execute("SELECT value FROM project WHERE key = 'study'").fetchone()[0])
        assert stored["order"] == saved["order"]
        db.close()
    finally:
        study.timer.stop()
        study.shell.closing.disconnect()                # no "Stop the study?" question at teardown
        study.shell.hide()


def test_stopping_early_saves_what_is_finished(app, bundle, tmp_path, monkeypatch):
    import quantacolony.study.controller as sc
    study = StudyController(app, apply_theme(app), bundle, tmp_path / "work", tmp_path)
    try:
        study.set_name("Early")
        for key, _, choices in sm.QUESTIONS:
            study.set_answer(key, choices[0])
        study.start()
        study.start_practice()
        study.detection.im_satisfied_pushed()
        monkeypatch.setattr(sc, "show_message", lambda *a, **k: "stop")
        study.shell.close()
        app.processEvents()
        assert isinstance(study.view, FinishView) and study.finished_path.exists()
        with zipfile.ZipFile(study.finished_path) as archive:
            assert "finished" in json.loads(archive.read("participant.json"))["times"]
    finally:
        study.timer.stop()
        study.shell.closing.disconnect()                # no "Stop the study?" question at teardown
        study.shell.hide()
