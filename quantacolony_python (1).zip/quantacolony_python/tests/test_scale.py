"""Per-photo scale (dish edge, scale bar, none, imported), spot layouts, and photos without a scale downstream."""

import io
import json
import sqlite3

import numpy as np
import pytest
from PIL import Image
from PySide6.QtWidgets import QApplication

from quantacolony.analyses.data import in_pixels_without_scale
from quantacolony.core import cropping as cp
from quantacolony.core import scale as sc
from quantacolony.core.colony_set import ColonySet
from quantacolony.core.measurements import measure_colonies, summarize_colonies
from quantacolony.core.params import DetectionParams
from quantacolony.core.stats import build_colony_table, build_index_table
from quantacolony.data import DataManager, Settings, create_library
from quantacolony.data.packets import LevelSpec, VariableSpec
from quantacolony.data.schema import SCHEMA_VERSION
from quantacolony.gui.cropping_controller import CroppingController
from quantacolony.gui.cropping_window import CroppingWindow
from quantacolony.theme import apply_theme


@pytest.fixture(scope="module")
def app():
    return QApplication.instance() or QApplication([])


def png(width=300, height=200) -> bytes:
    buffer = io.BytesIO()
    Image.fromarray(np.full((height, width, 3), 90, np.uint8)).save(buffer, format="PNG")
    return buffer.getvalue()


def design():
    return [VariableSpec("strain", "nominal", (LevelSpec("a"), LevelSpec("b"), LevelSpec("c")), "Strain")]


def open_manager(tmp_path, plate) -> DataManager:
    manager = DataManager(Settings(folder=tmp_path / "s"))
    manager.use_library(create_library(tmp_path / "L"))
    manager.create_project("Scales", design(), DetectionParams(), plate=plate)
    return manager


DISH = {"kind": "circular", "cx": 150.0, "cy": 100.0, "r": 90.0, "cuts": []}


# ----- the scale model ------------------------------------------------------------------------
def test_scale_from_each_method():
    dish = cp.DishLayout(100, 100, 90, ())
    assert sc.Scale(sc.DISH, dish_mm=90).px_per_mm(dish) == pytest.approx(2.0)
    assert sc.Scale(sc.DISH, dish_mm=90).px_per_mm(cp.GridLayout(0, 0, 10, 10, 0, 1, 1)) is None
    bar = sc.Scale(sc.BAR, bar=((10, 10), (110, 10)), length=5, unit="mm")
    assert bar.px_per_mm() == pytest.approx(20.0)
    assert bar.with_length(500, "um").px_per_mm() == pytest.approx(200.0)       # 500 µm is half a millimeter
    assert sc.Scale(sc.NONE).px_per_mm() is None and sc.Scale(sc.FIXED, value=6.4).px_per_mm() == 6.4
    assert sc.Scale(sc.BAR).problem() and sc.Scale(sc.BAR, bar=((0, 0), (50, 0))).problem().startswith("Enter")
    assert sc.Scale(sc.DISH).problem(dish).startswith("Enter") and not bar.problem()
    assert sc.scale_from_dict(json.loads(json.dumps(bar.to_dict()))) == bar
    assert sc.scale_from_dict({}) == sc.Scale() and sc.parse_number("2,5") == 2.5 and sc.parse_number("-1") is None


def test_defaults_and_carrying():
    assert sc.default_scale({"type": "circular", "dish_mm": 140}) == sc.Scale(sc.DISH, dish_mm=140.0)
    assert sc.default_scale({"type": "rectangular"}).method == sc.BAR
    drawn = sc.Scale(sc.BAR, bar=((10, 10), (250, 10)), length=10)
    assert drawn.carried_to((200, 300)) == drawn                               # a fixed camera keeps its bar
    assert drawn.carried_to((100, 100)) == sc.Scale(sc.BAR, length=10)         # off the photo: length only
    assert sc.Scale().with_bar((0, 0), (5, 5)).method == sc.BAR                # drawing a bar chooses it


def test_spot_grid_regions():
    grid = cp.GridLayout(150, 100, 150, 90, 0, 3, 5, cells=cp.SPOTS, spot=0.5)
    kind, geometry = grid.region(7)
    assert kind == "sector" and geometry["start_deg"] == 0 and geometry["end_deg"] == 360
    assert (geometry["cx"], geometry["cy"], geometry["radius"]) == pytest.approx((150, 100, 7.5))
    assert grid.spot_to(*grid.cell_center(0)).spot == cp.SPOT_MIN
    assert grid.with_spot(3).spot == 1.0 and grid.section_at(150, 100) == 7
    assert cp.layout_from_dict(grid.to_dict()) == grid
    old = {"kind": "rectangular", "cx": 1, "cy": 1, "width": 2, "height": 2, "angle": 0, "rows": 1, "cols": 1}
    assert cp.layout_from_dict(old).cells == cp.CELLS                        # layouts saved before spots


# ----- the project file ------------------------------------------------------------------------
def test_commit_stores_each_photos_scale(tmp_path):
    manager = open_manager(tmp_path, {"type": "circular", "sections": 1, "dish_mm": 90.0})
    try:
        dish, bar, bare, imported = (manager.add_photo(png(), file_name=f"{n}.png") for n in "abcd")
        assert manager.crop_packet().photos[0].scale["method"] == "dish"       # the project default
        manager.commit_photo(dish, DISH, [{"strain": "a"}])
        drawn = sc.Scale(sc.BAR, bar=((0, 0), (0, 150)), length=1.5, unit="mm")
        manager.commit_photo(bar, DISH, [{"strain": "b"}], scale=drawn.to_dict())
        manager.commit_photo(bare, DISH, [{"strain": "c"}], scale=sc.Scale(sc.NONE).to_dict())
        photos = {p.photo_id: p for p in manager.crop_packet().photos}
        assert photos[dish].px_per_mm == pytest.approx(2.0)                    # 180 px across a 90 mm dish
        assert photos[bar].px_per_mm == pytest.approx(100.0) and photos[bar].scale["method"] == "bar"
        assert photos[bare].px_per_mm is None
        resized = dict(DISH, r=45.0)                                          # moving the dish rescales it
        manager.commit_photo(dish, resized, [{"strain": "a"}])
        assert manager.crop_packet().photos[0].px_per_mm == pytest.approx(1.0)
        assert manager.checkout_image(manager.project_info().indices[2].index_id).record.px_per_mm is None
        photo = manager.add_photo(png(), 6.4, "e.png")
        assert {p.photo_id: p for p in manager.crop_packet().photos}[photo].scale["method"] == "fixed"
        assert imported
    finally:
        manager.close()


def test_version_5_files_keep_real_scales_only(tmp_path):
    manager = open_manager(tmp_path, {"type": "circular", "sections": 1, "dish_mm": 90.0})
    project_id, path = manager.project_id, manager.project_path
    placeholder, cropped, imported = (manager.add_photo(png(), file_name=f"{n}.png") for n in "abc")
    manager.close()
    old = sqlite3.connect(path)
    old.execute("ALTER TABLE photos DROP COLUMN scale")
    old.execute("ALTER TABLE photos DROP COLUMN scale_px_per_mm")
    old.execute("UPDATE photos SET px_per_mm = 1.0, scaling_method = 'dish'")              # version 5's placeholder
    old.execute("UPDATE photos SET px_per_mm = 2.0 WHERE photo_id = ?", (cropped,))       # a measured dish
    old.execute("UPDATE photos SET px_per_mm = 6.4, scaling_method = 'sample' WHERE photo_id = ?", (imported,))
    old.execute("UPDATE project SET value = '5' WHERE key = 'schema_version'")
    old.commit()
    old.close()
    manager.open_project(project_id)
    try:
        assert manager.project_info().schema_version == SCHEMA_VERSION
        photos = {p.photo_id: p for p in manager.crop_packet().photos}
        assert photos[placeholder].px_per_mm is None and photos[placeholder].scale["method"] == "dish"
        assert photos[cropped].px_per_mm == 2.0 and photos[cropped].scale == {"method": "dish", "dish_mm": 90.0,
                                                                              "unit": "mm"}
        assert photos[imported].px_per_mm == 6.4 and photos[imported].scale["method"] == "fixed"
    finally:
        manager.close()


# ----- sizes without a scale -------------------------------------------------------------------
def test_unscaled_measurements_stay_in_pixels():
    colonies = ColonySet.from_columns(np.array([[5.0, 5.0], [20.0, 20.0]]), np.array([2.0, 4.0]))
    rows = measure_colonies(colonies, None)
    assert rows[0]["radius_px"] == 2.0 and rows[0]["radius_um"] is None and rows[0]["area_um2"] is None
    summary = summarize_colonies(colonies, None)
    assert summary["unit"] == "px" and summary["um_per_px"] is None and summary["mean_um"] == pytest.approx(3.0)
    assert summarize_colonies(colonies, 2.0)["unit"] == "µm"
    table = build_colony_table([], [(1, {}, 2.0, measure_colonies(colonies, 2.0)), (2, {}, None, rows)])
    assert np.isnan(table.radius_um[2:]).all() and np.isnan(table.um_per_px[2:]).all()
    assert table.radius_um[0] == pytest.approx(1000.0)


def test_mixed_scales_are_shown_in_pixels_with_a_note():
    colonies = ColonySet.from_columns(np.array([[5.0, 5.0], [20.0, 20.0]]), np.array([2.0, 4.0]))
    table = build_colony_table([], [(1, {}, 2.0, measure_colonies(colonies, 2.0)),
                                    (2, {}, None, measure_colonies(colonies, None))])
    used = np.ones(len(table), bool)
    values, label, units, note = in_pixels_without_scale(table.radius_um, "Colony radius (µm)", table.um_per_px,
                                                         table.radius_px, table.index_ids, used)
    assert list(values) == [2.0, 4.0, 2.0, 4.0] and label == "Colony radius (px)" and (units == 1).all()
    assert note.startswith("1 of 2 plates have no scale")
    scaled = np.array([True, True, False, False])
    same = in_pixels_without_scale(table.radius_um, "Colony radius (µm)", table.um_per_px, table.radius_px,
                                   table.index_ids, scaled)
    assert same[1] == "Colony radius (µm)" and same[3] == ""                   # the unscaled plate is not shown
    index = build_index_table([], [(1, {}, 2.0, {"mean_radius_um": 1500.0, "mean_radius_px": 3.0}),
                                   (2, {}, None, {"mean_radius_um": np.nan, "mean_radius_px": 3.0})],
                              {"mean_radius_um": "Mean colony radius (µm)"})
    assert list(index.pixel_measures["mean_radius_um"]) == [3.0, 3.0] and np.isnan(index.um_per_px[1])


# ----- Cropping --------------------------------------------------------------------------------
def crop_window(app, manager):
    window = CroppingWindow(apply_theme(app), "Scales")
    window.report = lambda *a, **k: None
    return window, CroppingController(manager, window)


def test_rectangular_photos_start_from_a_scale_bar_and_carry_it(app, tmp_path):
    manager = open_manager(tmp_path, {"type": "rectangular", "rows": 1, "cols": 3, "cells": "spots"})
    for n in range(2):
        manager.add_photo(png(), file_name=f"p{n}.png")
    window, controller = crop_window(app, manager)
    try:
        layout, sections, _ = controller.current()
        assert layout.spots and layout.section_count == 3
        assert controller.current_scale().method == sc.BAR and not controller.can_confirm()
        assert window.length_edit.isVisible() or not window.isVisible()
        for k, strain in enumerate("abc"):
            controller.select_section(k)
            controller.pick(controller.variables[0], strain)
        assert controller.scale_problem().startswith("Drag")
        controller.bar_edited(((20.0, 180.0), (220.0, 180.0)), True)
        controller.set_bar_length("2")
        assert controller.can_confirm()
        controller.done_with_photo()
        first = manager.crop_packet().photos[0]
        assert first.px_per_mm == pytest.approx(100.0) and first.scale["length"] == 2.0
        regions = manager.project_info().indices
        assert controller.position == 1
        assert controller.current_scale().bar == ((20.0, 180.0), (220.0, 180.0))  # carried to the next photo
        controller.set_scale_method(sc.NONE)
        assert controller.current_scale().method == sc.NONE and not controller.scale_problem()
        assert len([i for i in regions if i.has_region]) == 3
    finally:
        window.close()
        manager.close()


def test_scale_change_on_a_saved_photo_is_a_change_to_save(app, tmp_path):
    manager = open_manager(tmp_path, {"type": "circular", "sections": 1, "dish_mm": 90.0})
    photo = manager.add_photo(png(), file_name="p.png")
    manager.commit_photo(photo, DISH, [{"strain": "a"}])
    manager.add_photo(png(), file_name="q.png")
    window, controller = crop_window(app, manager)
    try:
        controller.open_photo(0)
        assert controller.current()[2] and controller.current_scale().method == sc.DISH
        controller.set_dish_size("45")
        assert not controller.current()[2] and controller.can_confirm()
        controller.done_with_photo()
        assert manager.crop_packet().photos[0].px_per_mm == pytest.approx(4.0)
        controller.open_photo(0)
        controller.set_cells(cp.SPOTS)                                    # a round dish has no grid: no change
        assert controller.current()[2]
    finally:
        window.close()
        manager.close()
