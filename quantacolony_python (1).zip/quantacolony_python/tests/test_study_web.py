"""The browser study's engine (quantacolony/study/web.py), run natively: a participant from the form to the zip."""

import json
import sqlite3
import zipfile

from quantacolony.study import model as sm
from quantacolony.study.app import BUNDLE
from quantacolony.study.web import WebStudy


def test_engine_runs_a_whole_study(tmp_path):
    w = WebStudy(str(BUNDLE), str(tmp_path))
    assert w.questions() == [[k, q, list(c)] for k, q, c in sm.QUESTIONS] and len(w.concepts()) == 5
    assert not w.start("", {}, 1)["ok"]                                    # the form is checked here too
    assert w.start("Web", {k: c[0] for k, _, c in sm.QUESTIONS}, 3)["ok"] and w.open_next()
    assert w.plate()["practice"] and w.tutorial()["key"] == "photo" and w.tutorial()["hide_outlines"]
    assert len(w.target_ring()) == 3 and w.view()["count"] < 15           # the poorly tuned start
    w.pass_step()
    assert w.tutorial()["key"] == "detection" and not w.tutorial()["met"]
    w.pass_step()                                                         # unmet: stays
    assert w.tutorial()["key"] == "detection"
    w.pass_step(["grp-auto"])
    w.skip_step()                                                         # color
    w.skip_step()                                                         # shape
    counts = [w.view()["count"]]
    for key, section, change in (("threshold", "sec-threshold", {"threshold": 0.41}),
                                 ("size", "sec-size", {"rmax": 19.0}),
                                 ("sensitivity", "sec-sensitivity", {"sense": 0.9}),
                                 ("split", "sec-split", {"split": True})):
        assert w.tutorial(["grp-auto", section])["key"] == key
        for name in change:
            w.setting_changing(name)
        assert w.apply_settings(dict(w.view()["settings"], **change))["ok"]
        assert w.tutorial(["grp-auto", section])["met"]
        w.pass_step(["grp-auto", section])
        counts.append(w.view()["count"])
    assert counts == sorted(counts) and counts[-1] >= 80                  # each fix outlines more colonies
    assert w.view()["settings"]["maxpix"] == 2500                          # follows Max radius outside Circular
    assert w.tutorial(["grp-manual"])["key"] == "manual"
    w.pass_step(["grp-manual"])
    assert w.tutorial()["key"] == "delete" and len(w.tutorial()["ring"]) == 3   # the plate number, ringed
    lesson = dict(w.view()["settings"])
    w.apply_settings(dict(lesson, threshold=0.45))                          # off the lesson's settings: named
    restore = w.tutorial()["bullets"][0]
    assert restore.get("restore") and "Brightness threshold to 0.41 (now 0.45)" in restore["text"]
    w.apply_settings(lesson)
    assert not w.tutorial()["bullets"][0].get("restore")
    assert not w.tutorial()["met"]                                        # an outline sits on the number
    w.set_mode("DeleteIndividualColonies")
    cx, cy, r = w.tutorial()["ring"]
    for c in w.view()["colonies"]:
        if (c["x"] - cx) ** 2 + (c["y"] - cy) ** 2 < r * r:
            w.delete_click(c["x"], c["y"])
    w.delete_selected()
    assert w.tutorial()["met"]
    w.pass_step()
    w.skip_step()                                                         # delete_region
    assert w.tutorial()["key"] == "add"
    w.set_mode("AddIndividualColonies")
    fx, fy, fr = w.tutorial()["ring"]
    index = w.add_circle(fx, fy, 0.5)
    w.update_circle(index, fx, fy, fr - 6, True)
    assert w.unadded() == {"drawn": 1, "region": 0} and not w.tutorial()["met"]
    count = w.view()["count"]
    w.resolve_unadded("add", "finish")                                    # the warning's answer adds them
    assert w.view()["count"] == count + 1 and w.unadded()["drawn"] == 0 and w.tutorial()["met"]
    w.pass_step()
    assert w.tutorial()["key"] == "add_tools"
    w.set_contour(True)
    sx, sy, sr = w.tutorial()["ring"]
    index = w.add_circle(sx, sy, 0.5)
    w.update_circle(index, sx, sy, sr - 6, True)                          # a dark colony: the circle snaps
    count = w.view()["count"]
    assert w.tutorial()["block_add"]
    w.add_pending()                                                       # held until the right-click task
    assert w.view()["count"] == count and len(w.view()["pending"]) == 1
    w.remove_circle(index, "right")
    assert not w.tutorial()["block_add"]
    assert not w.tutorial()["met"]                                        # still to add it
    index = w.add_circle(sx, sy, 0.5)
    w.update_circle(index, sx, sy, sr - 6, True)
    w.add_pending()
    assert w.tutorial()["met"]
    w.pass_step()
    for _ in range(4):                                                    # region, undo, mass, skip
        w.skip_step()
    assert w.tutorial()["key"] == "finish"
    w.skip_step()                                                         # the finish step cannot be skipped
    assert w.tutorial()["key"] == "finish"
    check = w.finish_image()                                              # the training check fails
    assert not check["done"] and not check["training"]["passed"] and w.plate()["practice"]
    assert 0 < len(check["training"]["problems"]) <= 3                   # a few places, nothing drawn
    assert not w.view()["missed"] and not w.view()["flags"]
    w.set_mode("DeleteManyColonies")                                      # a passing answer: every required colony
    w.select_rect(0, 0, w.plate()["width"], w.plate()["height"])
    w.delete_selected()
    w.set_mode("AddIndividualColonies")
    w.set_contour(False)
    for x, y, r in w._reference_colonies():
        w.add_circle(x, y, r)
    w.add_pending()
    first = w.finish_image()
    assert first["training"]["passed"] and first["training"]["attempt"] == 2 and w.plate()["number"] == 1
    plates = 1
    while not w.finish_image()["done"]:
        plates += 1
        assert w.tutorial()["done"] and w.plate()["number"] == plates
    assert plates == 4
    review = w.review()
    assert [p["number"] for p in review] == [1, 2, 3, 4] and all(p["image"][:2] == b"\xff\xd8" for p in review)
    w.reopen(review[2]["value"])
    assert w.plate()["reviewing"] and w.plate()["number"] == 3 and w.finish_image() == {"done": True}
    w.confirm_review()
    result = w.results()
    path = tmp_path / result["name"]
    path.write_bytes(result["bytes"])
    with zipfile.ZipFile(path) as archive:
        record = json.loads(archive.read("participant.json"))
        archive.extract("Web.qcproj", tmp_path / "out")
        assert "Web - first pass.qcproj" in archive.namelist()
    assert record["tutorial_skipped"] == ["color", "shape", "delete_region", "region", "undo", "mass", "skip"]
    assert [a["passed"] for a in record["training_attempts"]] == [False, True]
    passes = [(e["position"], e["pass"]) for e in record["processing"]]
    assert passes == [(0, "practice")] + [(n, "first") for n in range(1, 5)] + [(3, "review")]
    assert record["reopened"][0]["plate"] == review[2]["value"] and "review_confirmed" in record["times"] and set(record["times"]) >= {"form_sent", "practice_saved", "finished"}
    db = sqlite3.connect(tmp_path / "out" / "Web.qcproj")
    assert db.execute("SELECT COUNT(*) FROM detection").fetchone()[0] == 5          # one per plate: its latest save
    kinds = dict(db.execute("SELECT kind, COUNT(*) FROM dev_detection_events GROUP BY kind").fetchall())
    assert {"detection", "edit", "mode", "select"} <= set(kinds)
    db.close()
