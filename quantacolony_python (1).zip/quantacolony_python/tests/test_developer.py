"""Developer mode: benchmark records in their own tables, the estimate start option, and file compatibility."""

import os
import sqlite3

import numpy as np
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
from PySide6.QtCore import QPointF  # noqa: E402
from PySide6.QtWidgets import QApplication  # noqa: E402

from quantacolony.app import build, developer_mode  # noqa: E402
from quantacolony.core.benchmark import CropRecorder, EventLog, reference_start  # noqa: E402
from quantacolony.data import DataManager, Settings, create_library  # noqa: E402
from quantacolony.data.schema import SCHEMA_VERSION  # noqa: E402
from sample_project import create_sample_project  # noqa: E402


@pytest.fixture(scope="module")
def app():
    return QApplication.instance() or QApplication([])


def tables(manager) -> set[str]:
    return {r[0] for r in manager._connection.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}


def detection_ui(app, tmp_path, developer):
    window, controller = build(app, settings=Settings(folder=tmp_path / "settings"),
                               library=create_library(tmp_path / "Library"), first_project=create_sample_project,
                               developer=developer)
    window.show()
    app.processEvents()
    return window, controller


class Clock:
    def __init__(self):
        self.now = 0.0

    def __call__(self):
        return self.now


def test_event_log_thins_continuous_events():
    clock = Clock()
    log = EventLog(clock)
    for t in (0.0, 0.5, 1.2, 2.5):
        clock.now = t
        log.record("pointer", 2000)
    log.record("edit", kind="Deletion")                       # 'kind' is event data, not the event's name
    assert [e.t_ms for e in log.events if e.kind == "pointer"] == [0, 2500]
    assert log.events[-1].data == {"kind": "Deletion"}


def test_crop_recorder_keeps_visits_per_photo():
    clock = Clock()
    recorder = CropRecorder(clock)
    recorder.open(1)
    recorder.record("rotate", degrees=5)
    clock.now = 3
    recorder.open(2)
    clock.now = 4
    recorder.open(1)
    bench = recorder.done(1, 8, "circular")
    assert bench.visits == 2 and [e.kind for e in bench.events] == ["opened", "rotate", "left", "opened"]
    assert recorder.done(1, 8, "circular") is not None          # a failed save keeps the record
    recorder.forget(1)
    assert recorder.done(1, 8, "circular") is None


def test_developer_flag(monkeypatch):
    monkeypatch.delenv("QUANTACOLONY_DEVELOPER", raising=False)
    assert developer_mode(["--developer"]) and not developer_mode([])
    monkeypatch.setenv("QUANTACOLONY_DEVELOPER", "1")
    assert developer_mode([])


def test_standard_mode_records_nothing(app, tmp_path):
    window, controller = detection_ui(app, tmp_path, developer=False)
    try:
        assert controller.recorder is None
        controller.im_satisfied_pushed(advance=False)
        assert not any(name.startswith("dev_") for name in tables(controller.data_manager))
        assert controller.data_manager._file.setting("developer") is None
    finally:
        window.close()
        controller.data_manager.close()


def test_developer_mode_records_a_session(app, tmp_path):
    window, controller = detection_ui(app, tmp_path, developer=True)
    manager = controller.data_manager
    try:
        assert {"dev_environment", "dev_detection_sessions", "dev_detection_events",
                "dev_initial_detection", "dev_initial_colonies", "dev_crop_sessions",
                "dev_crop_events"} <= tables(manager)
        assert manager._file.setting("schema_version") == SCHEMA_VERSION      # the standard schema is untouched
        session = controller.session
        index_id = session.record.index_id
        controller.dropdown_changed("DeleteIndividualColonies")
        for center in session.colonies.centers[:2]:
            window.canvas.tool.release(QPointF(*center))
        controller.delete_selected_colonies_button_pushed()
        controller.undo()
        controller.redo()
        controller.im_satisfied_pushed(advance=False)

        records = manager.developer_records()
        [row] = records.detection_sessions()
        assert row["index_id"] == index_id and row["revision"] == 1 and row["start_source"] in (
            "defaults", "estimate", "last image")
        events = records.detection_events(row["session_id"])
        kinds = [e["kind"] for e in events]
        assert kinds[0] == "detection" and events[0]["data"]["trigger"] == "initial"
        assert "mode" in kinds and kinds.count("select") == 2 and {"undo", "redo"} <= set(kinds)
        edit = next(e for e in events if e["kind"] == "edit")
        assert edit["data"]["kind"] == "Deletion" and edit["data"]["count"] == 2
        assert all(a["t_ms"] <= b["t_ms"] for a, b in zip(events, events[1:]))

        # the initial detection: settings estimated from the image, starting from the project defaults
        initial = records.initial_detection(row["session_id"])
        record = session.record
        expected = reference_start(record.image, record.mask, manager.detection_defaults())
        assert initial["colony_count"] == len(expected.colonies) == len(initial["radii"])
        origin = manager.crop_origin(index_id)
        assert np.allclose(initial["centers"], expected.colonies.centers + np.array(origin))
        assert records.environments()[0]["software_version"]

        # finishing again records a second session on the same index, started from the saved result
        controller.im_satisfied_pushed(advance=False)
        rows = records.detection_sessions()
        assert [r["revision"] for r in rows] == [1, 2] and rows[1]["start_source"] == "saved"
    finally:
        window.close()
        manager.close()


def test_developer_tables_travel_with_the_project(app, tmp_path):
    window, controller = detection_ui(app, tmp_path, developer=True)
    manager = controller.data_manager
    project_id = manager.project_id
    try:
        controller.im_satisfied_pushed(advance=False)
        exported = manager.export_project_file(project_id, tmp_path / "out" / "shared.qcproj")
    finally:
        window.close()
        manager.close()
    with sqlite3.connect(exported) as db:
        assert db.execute("SELECT COUNT(*) FROM dev_detection_sessions").fetchone()[0] == 1
    standard = DataManager(Settings(folder=tmp_path / "s2"))
    standard.use_library(create_library(tmp_path / "Other"))
    standard.open_project(standard.import_project_file(exported))
    try:
        assert standard.project_info().schema_version == SCHEMA_VERSION
        assert len(standard.developer_records().detection_sessions()) == 1
        assert standard.recording                          # recording belongs to the project, not the launch
    finally:
        standard.close()


def test_old_project_opens_in_developer_mode(tmp_path):
    from quantacolony.data.tutorial_project import TUTORIAL_FILE
    manager = DataManager(Settings(folder=tmp_path / "s"), developer=True)
    manager.use_library(create_library(tmp_path / "L"))
    manager.open_project(manager.import_project_file(TUTORIAL_FILE))
    try:
        assert manager.recording and "dev_detection_sessions" in tables(manager)
        assert manager.project_info().schema_version == SCHEMA_VERSION
    finally:
        manager.close()


def test_estimate_every_new_image(tmp_path):
    manager = DataManager(Settings(folder=tmp_path / "s"))
    manager.use_library(create_library(tmp_path / "L"))
    create_sample_project(manager)
    index_id = manager.first_index_for_detection()
    assert manager.new_image_start() == "last image"
    with manager._file.transaction():
        manager._file.set_setting("last_detection_params", {**manager.detection_defaults().__dict__, "rmin": 9.0})
    packet = manager.checkout_image(index_id)
    assert (packet.estimate, packet.start_source, packet.defaults.rmin) == (False, "last image", 9.0)
    manager.set_new_image_start("estimate")
    packet = manager.checkout_image(index_id)
    assert packet.estimate and packet.start_source == "estimate"
    assert packet.defaults == manager.detection_defaults()     # estimated from the defaults, never the last image
    manager.close()


def test_developer_mode_records_cropping(app, tmp_path, monkeypatch):
    window, controller = build(app, settings=Settings(folder=tmp_path / "s"), library=create_library(tmp_path / "L"),
                               demo_cropping=True, developer=True)
    monkeypatch.setattr(window, "report", lambda *a: None)
    manager = controller.manager
    try:
        genotype, medium = (next(v for v in controller.variables if v.name == n) for n in ("genotype", "medium"))
        controller.rotate(5.0)
        controller.open_photo(1)                                   # leave the first photo, then come back
        controller.open_photo(0)
        controller.select_section(0)
        for k in range(8):
            controller.pick(medium, medium.values[k // 4])
            controller.pick_by_number(k % 4)
        first = controller.photo.photo_id
        controller.done_with_photo()
        records = manager.developer_records()
        [row] = records.crop_sessions()
        assert row["photo_id"] == first and row["visits"] == 2 and row["section_count"] == 8
        kinds = [e["kind"] for e in records.crop_events(row["crop_session_id"])]
        assert kinds[:4] == ["opened", "rotate", "left", "opened"] and kinds.count("pick") == 16
    finally:
        window.close()
        manager.close()


def test_benchmark_report(app, tmp_path):
    from quantacolony.benchmark import divide_time, main, report_for_file
    # time: a 90 s gap is idle at a 60 s cutoff; time with the window inactive is away
    events = [{"t_ms": 0, "kind": "mode", "data": {"mode": "ModifyGlobalParameters"}},
              {"t_ms": 10_000, "kind": "mode", "data": {"mode": "DeleteIndividualColonies"}},
              {"t_ms": 20_000, "kind": "focus", "data": {"active": False}},
              {"t_ms": 50_000, "kind": "focus", "data": {"active": True}},
              {"t_ms": 140_000, "kind": "edit", "data": {"kind": "Deletion", "count": 1}}]
    time = divide_time(events, 150_000, 60_000)
    assert (time.active_ms, time.away_ms, time.idle_ms) == (30_000, 30_000, 90_000)
    assert time.by_mode == {"ModifyGlobalParameters": 10_000, "DeleteIndividualColonies": 20_000}

    window, controller = detection_ui(app, tmp_path, developer=True)
    manager = controller.data_manager
    project_id = manager.project_id
    try:
        controller.dropdown_changed("DeleteIndividualColonies")
        window.canvas.tool.release(QPointF(*controller.session.colonies.centers[0]))
        controller.delete_selected_colonies_button_pushed()
        controller.im_satisfied_pushed(advance=False)
        index_id = controller.session.record.index_id
        final = controller.session.colonies.translated(*manager.crop_origin(index_id))
        photo = manager.crop_packet().photos[0].file_name
        path = manager.export_project_file(project_id, tmp_path / "out" / "bench.qcproj")
    finally:
        window.close()
        manager.close()
    truth = tmp_path / "truth.csv"
    truth.write_text("photo,x,y,radius_px\n" + "".join(
        f"{photo},{x},{y},{r}\n" for (x, y), r in zip(final.centers, final.radii)), encoding="utf-8")
    report = report_for_file(path, truth, 60)
    assert report.pooled["corrected"].score.f1 == 1.0
    assert report.pooled["tuned"].score.extra >= 1                     # the deleted colony
    assert "automatic" in report.pooled and len(report.sessions) == 1
    row = report.sessions[0]
    assert row["deleted_net"] == 1 and row["corrections_net"] == 1
    assert main([str(path), "--truth", str(truth), "--out", str(tmp_path / "report")]) == 0
    assert {p.name for p in (tmp_path / "report").iterdir()} == {"accuracy.csv", "image_sessions.csv",
                                                                "cropping.csv", "environment.json", "summary.txt"}


def test_wizard_switch_makes_a_recording_project(app, tmp_path):
    from quantacolony.data.demo_project import draw_plate
    from quantacolony.gui.new_project import NewProjectController, NewProjectWindow
    from quantacolony.theme import apply_theme
    photos = []
    for n in (1, 2):
        path = tmp_path / f"Plate_{n}.jpg"
        path.write_bytes(draw_plate(n, 0.0, [1.0] * 8))
        photos.append(str(path))
    manager = DataManager(Settings(folder=tmp_path / "s"))                      # standard launch
    manager.use_library(create_library(tmp_path / "L"))
    window = NewProjectWindow(apply_theme(app))
    controller = NewProjectController(manager, window)
    try:
        controller.add_photos(photos)
        controller.set_name("Synthetic")
        controller.go(4)                                         # Review
        from quantacolony.gui.widgets import ToggleSwitch
        switch = window.pages.currentWidget().widget().findChild(ToggleSwitch, "record-benchmark")
        assert switch is not None and not switch.isChecked()
        switch.setChecked(True)
        assert controller.draft.record_benchmark
        controller.create()
        assert manager.is_open and manager.recording
        project_id = manager.project_id
        manager.close()
        manager.open_project(project_id)                                         # every later opening records
        assert manager.recording and "dev_detection_sessions" in tables(manager)
    finally:
        window.close()
        manager.close()


def test_projects_record_only_when_asked(tmp_path):
    manager = DataManager(Settings(folder=tmp_path / "s"))
    manager.use_library(create_library(tmp_path / "L"))
    create_sample_project(manager)
    assert not manager.recording and not any(name.startswith("dev_") for name in tables(manager))
    manager.close()
