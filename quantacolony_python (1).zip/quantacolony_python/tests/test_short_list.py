"""The short list: plates ticked in the plate table, shown on their own, and plotted on their own."""

from PySide6.QtCore import Qt


def test_short_list_filters_sorts_and_plots_only_its_plates(tmp_path):
    from PySide6.QtWidgets import QApplication
    from quantacolony.data import DataManager, Settings, create_library
    from quantacolony.gui.launch import open_stats
    from test_stats import apply_theme

    app = QApplication.instance() or QApplication([])
    manager = DataManager(Settings(folder=tmp_path / "s"))
    manager.use_library(create_library(tmp_path / "Library"))
    project_id = manager.add_tutorial_project()
    manager.open_project(project_id)
    window, controller = open_stats(manager, apply_theme(app))
    try:
        controller.choose_analysis("box")
        every = set(controller.data.index_ids.tolist())
        assert len(every) == 10
        controller.open_plates()
        dialog = window.plates_dialog
        assert dialog.isVisible() and dialog.table.rowCount() == 10
        assert not dialog.plot_short.isEnabled()                       # nothing on the short list yet

        dialog.filter.setText("16000X")                               # one plate
        shown = dialog.shown_ids()
        assert len(shown) == 1
        dialog.filter.setText("000X.")                                 # the photo names of 1000X to 128000X
        shown = dialog.shown_ids()
        assert len(shown) == 8
        dialog.add_shown.click()
        app.processEvents()
        assert set(controller.short_list) == set(shown)
        controller.flush_refresh()
        assert set(controller.data.index_ids.tolist()) == every       # the long list is still plotted

        dialog.plot_short.click()                                      # plot the short list only
        app.processEvents()
        controller.flush_refresh()
        assert controller.use_short and set(controller.data.index_ids.tolist()) == set(shown)
        controller.flush_refresh()
        assert any(n.startswith("Short list: 8 plates") for n in controller.data.notes)

        dialog.filter.setText("")
        dialog.show_list(True)                                         # the table shows the short list
        assert len(dialog.shown_ids()) == 8
        dialog.show_list(False)
        assert len(dialog.shown_ids()) == 10

        dialog.table.sortItems(dialog.COLONIES, Qt.DescendingOrder)    # sorted rows keep their own ticks
        top = int(dialog.table.item(0, dialog.SHORT).data(Qt.UserRole))
        dialog.table.item(0, dialog.SHORT).setCheckState(
            Qt.Unchecked if top in controller.short_list else Qt.Checked)
        app.processEvents()
        assert (top in controller.short_list) != (top in shown)

        reasons = controller.plate_reasons()
        off = [i for i in every if i not in controller.short_list]
        assert all("not on the short list" in reasons[i] for i in off)
        controller.set_plate_selection(True)                           # selection chooses from the short list only
        selection, _ = controller.selection()
        assert selection.chosen <= set(controller.short_list)
        controller.set_plate_selection(False)

        saved = manager.module_preferences("stats")
        assert saved["use_short_list"] and set(saved["short_list"]) == set(controller.short_list)
        dialog.clear_short.click()
        app.processEvents()
        assert not controller.short_list and not controller.use_short
        controller.flush_refresh()
        assert set(controller.data.index_ids.tolist()) == every
    finally:
        window.close()
        manager.close()
