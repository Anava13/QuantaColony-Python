"""The Colony Detection tour on the desktop program (gui/detection_guide.py): the practice project, the
guide's steps against the real Colony Detection screen, the arrow and corner dots, the held Add button,
the training check before Finish image, and the not-added question."""

import pytest
from PySide6.QtWidgets import QApplication

from quantacolony.core.params import DARK, LIGHT, IRREGULAR, CIRCULAR
from quantacolony.study import guide as gd


@pytest.fixture(scope="module")
def app():
    return QApplication.instance() or QApplication([])


def key(tour):
    return gd.STEPS[tour.guide.step].key


def advance(tour, expected):
    """The step's tasks are done: the tour moves on (by itself after a moment; here at once)."""
    tour.poll()
    t = tour.guide.tutorial(tour._open())
    assert t["key"] == expected and t["met"], t["bullets"]
    tour._advance(expected)


def open_section(window, key):
    """A click on a group's or section's title."""
    window.sections()[key].header.click()


def settle(detection):
    detection._detection_timer.stop()
    detection.handle_backup_and_detection()


def test_the_colony_detection_tour(app, tmp_path, monkeypatch):
    from quantacolony.app import start
    from quantacolony.data import DataManager, Settings, create_library
    monkeypatch.setattr(DataManager, "add_dissertation_projects", lambda self: [])   # not needed by this tour
    navigator = start(app, settings=Settings(folder=tmp_path / "s"), library=create_library(tmp_path / "Library"))
    try:
        navigator.start_tutorial("detection")
        tour = navigator.tutorial
        assert navigator.screen == "detection" and navigator.manager.tutorial_name == "practice"
        detection, window = navigator.controller, navigator.window
        tour.poll()
        assert detection.guide is tour.guide and key(tour) == "photo"
        assert tour.window.next_button.isVisibleTo(tour.window)                # no tasks: Next
        assert not tour.window.apply_button.isVisibleTo(tour.window)           # no automating
        assert not tour.window.why.isVisibleTo(tour.window)                    # context folded
        tour.next()
        assert key(tour) == "detection"
        assert not window.open_sections()                                       # every group starts closed
        from quantacolony.gui.detection_guide import anchors, reveal_target
        found = anchors(window)
        assert reveal_target(found["ctl-threshold"]) is window.groups["automatic"].header   # open Step 1 first
        open_section(window, "grp-auto")
        advance(tour, "detection")

        assert key(tour) == "color"
        assert reveal_target(found["ctl-color"]) is window.sections()["sec-appearance"].header
        open_section(window, "sec-appearance")
        window.set_polarity(LIGHT)
        detection.handle_backup_and_detection()
        window.set_polarity(DARK)
        settle(detection)
        advance(tour, "color")
        window.shape_buttons[CIRCULAR].setChecked(True)                        # a click checks, then signals
        detection.detection_type_switch_value_changed(CIRCULAR)
        assert window.largest_row.isVisibleTo(window)                           # Largest object: Circular only
        window.shape_buttons[IRREGULAR].setChecked(True)
        detection.detection_type_switch_value_changed(IRREGULAR)
        assert not window.largest_row.isVisibleTo(window)
        advance(tour, "shape")
        open_section(window, "sec-threshold")
        assert window.open_sections() == ["grp-auto", "sec-threshold"]         # one section open at a time
        window.level_row.set_value(0.41)
        settle(detection)
        advance(tour, "threshold")
        open_section(window, "sec-size")
        window.rmax_field.set_value(19)
        settle(detection)
        assert detection.session.params.maxpix == 2500                          # follows Max radius
        advance(tour, "size")
        open_section(window, "sec-sensitivity")
        window.sense_row.set_value(0.9)
        settle(detection)
        advance(tour, "sensitivity")
        open_section(window, "sec-split")
        window.split_switch.setChecked(True)
        settle(detection)
        advance(tour, "split")
        assert key(tour) == "manual"
        open_section(window, "grp-manual")
        assert window.open_sections() == ["grp-manual", "sec-split"]           # one group open at a time
        advance(tour, "manual")

        assert key(tour) == "delete"
        tour.poll()
        canvas = window.tool_surface()
        assert canvas.guide_arrow is not None and not canvas.guide_dots          # one target: an arrow
        window.level_row.set_value(0.45)
        settle(detection)
        restore = tour.guide.tutorial(tour._open())["bullets"][0]
        assert restore.get("restore") and "Brightness threshold to 0.41" in restore["text"]
        window.level_row.set_value(0.41)
        settle(detection)
        cx, cy, r = tour.guide.ring("marker")
        detection.select_dropdown_option("DeleteIndividualColonies")
        for k in range(len(detection.session.colonies)):
            x, y = detection.session.colonies.centers[k]
            if (x - cx) ** 2 + (y - cy) ** 2 < r * r:
                detection.handle_delete_click(x, y)
        detection.delete_selected_colonies_button_pushed()
        advance(tour, "delete")

        assert key(tour) == "delete_region"
        tour.poll()
        assert len(canvas.guide_dots) == 4 and canvas.guide_capture                  # a box: corner dots
        xs = [d[0] for d in canvas.guide_dots]
        ys = [d[1] for d in canvas.guide_dots]
        detection.select_dropdown_option("DeleteManyColonies")
        detection.highlight_colonies_in_rect(min(xs) - 3, min(ys) - 3, max(xs) + 3, max(ys) + 3)
        assert tour.guide.tutorial(tour._open())["bullets"][1]["done"]
        detection.delete_selected_colonies_button_pushed()
        advance(tour, "delete_region")

        assert key(tour) == "add"
        fx, fy, fr = tour.guide.ring("faint")
        detection.select_dropdown_option("AddIndividualColonies")
        index = detection.add_new_circle(fx, fy, 0.5)
        detection.update_circle(index, fx, fy, fr - 6, True)
        detection.add_selected_colonies_button_pushed()
        advance(tour, "add")

        assert key(tour) == "add_tools"
        window.contour_switch.setChecked(True)
        sx, sy, sr = tour.guide.ring("snap")
        index = detection.add_new_circle(sx, sy, 0.5)
        detection.update_circle(index, sx, sy, sr - 6, True)
        tour.poll()
        assert not window.add_one_button.isEnabled()                            # right-click first
        count = len(detection.session.colonies)
        detection.add_selected_colonies_button_pushed()
        assert len(detection.session.colonies) == count
        detection.remove_circle(index, "right")
        tour.poll()
        assert window.add_one_button.isEnabled()
        index = detection.add_new_circle(sx, sy, 0.5)
        detection.update_circle(index, sx, sy, sr - 6, True)
        detection.add_selected_colonies_button_pushed()
        advance(tour, "add_tools")
        window.contour_switch.setChecked(False)

        for _ in range(4):                                                      # region, undo, mass, skip
            tour.guide.skip_step()
        assert key(tour) == "finish"

        asked = []
        monkeypatch.setattr(window, "ask_unadded", lambda d, r, b: asked.append((d, r, b)) or "back")
        detection.select_dropdown_option("AddIndividualColonies")
        detection.add_new_circle(40, 40, 6)
        assert detection.finish_requested() is False and asked == [(1, 0, "finish")]   # not added: asked first
        monkeypatch.setattr(window, "ask_unadded", lambda d, r, b: "discard")
        assert detection.finish_requested() is False                           # then the training check fails
        assert not tour.guide.practice_done and tour.guide.last_check["problems"]
        tour.poll()
        assert tour.window.finding_action.isVisibleTo(tour.window)              # a few places, nothing drawn
        tour.show_place()

        detection.select_dropdown_option("DeleteManyColonies")
        h, w = detection.session.image.shape[:2]
        detection.highlight_colonies_in_rect(0, 0, w, h)
        detection.delete_selected_colonies_button_pushed()
        detection.select_dropdown_option("AddIndividualColonies")
        for x, y, r in tour.guide._reference_colonies():
            detection.add_new_circle(x, y, r)
        detection.add_selected_colonies_button_pushed()
        assert detection.finish_requested() is True and tour.guide.practice_done
        tour.poll()
        assert tour.window.title.text() == "Practice plate passed"
        assert "detection:finish" in navigator.manager.settings.tutorial_done
    finally:
        navigator.close_tutorial()
        if navigator.window is not None:
            navigator.window.close_guard = None
