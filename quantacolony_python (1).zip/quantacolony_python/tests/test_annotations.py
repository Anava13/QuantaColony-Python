"""Annotations: declarations, photo inheritance, plate overrides, measures, wizard draft,
the new per-plate analyses, and the overview PDF export."""

import io
from pathlib import Path

import numpy as np
import pytest
from PIL import Image

from quantacolony.analyses import data as ad
from quantacolony.analyses.registry import load_analyses
from quantacolony.core import new_project as npm
from quantacolony.core import stats as st
from quantacolony.core.colony_set import ColonySet
from quantacolony.core.params import DetectionParams
from quantacolony.core.record import DetectionResult
from quantacolony.data import DataManager, Settings, create_library
from quantacolony.data.packets import AnnotationSpec, Assignment, LevelSpec, VariableSpec
from quantacolony.data.store.annotations import AnnotationProblem

ANALYSES = load_analyses().analyses


def _png() -> bytes:
    buffer = io.BytesIO()
    Image.new("RGB", (200, 200), (25, 25, 25)).save(buffer, "PNG")
    return buffer.getvalue()


@pytest.fixture()
def annotated(tmp_path):
    manager = DataManager(Settings(folder=tmp_path / "s"), create_library(tmp_path / "lib"))
    manager.create_project(
        "Annotated", [VariableSpec("geno", "nominal", (LevelSpec("WT", is_control=True), LevelSpec("mut")),
                                   "Genotype")],
        DetectionParams(level=-0.45, rmin=3, rmax=31, maxpix=6250),
        plate={"type": "circular", "sections": 1, "scale": "none"},
        annotations=[AnnotationSpec("hce", "number", "Hemocytometer Cell Estimate", "cells"),
                     AnnotationSpec("plate_size", "choice", "Plate size", choices=("90 mm", "140 mm")),
                     AnnotationSpec("note", "text", "Note")])
    photo_id = manager.add_photo(_png(), 10.0, file_name="p1.png")
    manager.set_photo_annotations(photo_id, {"hce": "816", "plate_size": "90 mm"})
    index_id = manager.add_index({"geno": "WT"})
    manager.commit_assignments([Assignment(index_id, photo_id, "polygon",
                                           {"points": [[5, 5], [195, 5], [195, 195], [5, 195]]})])
    colonies = ColonySet.from_columns(np.array([[50.0, 50.0], [90.0, 90.0], [130.0, 60.0]]),
                                      np.array([5.0, 6.0, 7.0]), [None] * 3, ["irregular"] * 3,
                                      np.full(3, np.nan), np.arange(1, 4))
    manager.commit_detection(DetectionResult(index_id, DetectionParams(level=-0.45, rmin=3, rmax=31, maxpix=6250),
                                             colonies, colonies, (), 1))
    yield manager, photo_id, index_id
    manager.close()


def test_plates_inherit_photo_values_and_override_them(annotated):
    manager, photo_id, index_id = annotated
    assert manager.plate_annotations()[index_id] == {"hce": "816", "plate_size": "90 mm"}
    manager.set_plate_annotation(index_id, "hce", "160")
    assert manager.plate_annotations()[index_id]["hce"] == "160"
    manager.set_plate_annotation(index_id, "hce", "")              # back to the photo's value
    assert manager.plate_annotations()[index_id]["hce"] == "816"


def test_values_are_checked_against_their_kind(annotated):
    manager, _, index_id = annotated
    with pytest.raises(AnnotationProblem):
        manager.set_plate_annotation(index_id, "hce", "not a number")
    with pytest.raises(AnnotationProblem):
        manager.set_plate_annotation(index_id, "plate_size", "huge")
    with pytest.raises(AnnotationProblem):
        manager.set_plate_annotation(index_id, "unknown", "1")


def test_number_annotations_become_index_measures(annotated):
    manager, _, _ = annotated
    table = manager.index_table(coverage=False)
    assert "annotation:hce" in table.measures
    assert table.measures["annotation:hce"][0] == 816.0
    assert "annotation:plate_size" not in table.measures           # choices are labels, not measures
    assert "median_radius_um" in table.measures


def test_plate_details_reach_analyses(annotated):
    manager, _, index_id = annotated
    details = manager.plate_details()
    assert details[index_id]["annotations"]["plate_size"] == "90 mm"
    analysis = ANALYSES["plate_distributions"]
    data = ad.build_data(analysis, manager.colony_table(), None,
                         ad.default_assignment(analysis, manager.colony_table().variables),
                         plate_info=details)
    assert data.plate_info[index_id]["annotations"]["hce"] == "816"


def test_wizard_draft_checks_annotations(tmp_path):
    draft = npm.ProjectDraft(name="X", photos=[Path("a.png")])
    draft.annotations.append(npm.AnnotationDraft(name="HCE", kind="number", values={"a.png": "abc"}))
    assert not draft.annotations_ok()
    draft.annotations[0].values["a.png"] = "816"
    assert draft.annotations_ok()
    draft.annotations.append(npm.AnnotationDraft(name="Size", kind="choice", choices=["only one"]))
    assert "two choices" in draft.annotation_problem()
    draft.annotations[1].choices = ["90 mm", "140 mm"]
    assert draft.annotations_ok()
    specs = draft.annotation_specs()
    assert [s.name for s in specs] == ["hce", "size"]
    assert draft.photo_annotation_values() == {"a.png": {"hce": "816"}}


def _table(seed=0):
    geno = st.StatsVariable("geno", "Genotype", "nominal", ("WT", "mut"), ("WT", "mut"), "WT")
    passage = st.StatsVariable("passage", "Passage", "ordinal", ("1", "2"), ("P1", "P2"), None)
    rng = np.random.default_rng(seed)
    indices, index_id = [], 0
    for g in geno.values:
        for p in passage.values:
            for _ in range(3):
                index_id += 1
                base = 20.0 * (0.6 if g == "mut" else 1.0)
                rows = [{"radius_px": float(x), "radius_um": float(x) * 10}
                        for x in rng.lognormal(np.log(base), 0.3, 30)]
                indices.append((index_id, {"geno": g, "passage": p}, 100.0, rows))
    return st.build_colony_table([geno, passage], indices), index_id


def test_per_plate_distributions_draw_one_glyph_per_plate():
    table, plates = _table()
    analysis = ANALYSES["plate_distributions"]
    data = ad.build_data(analysis, table, None, ad.default_assignment(analysis, table.variables))
    result = analysis.compute(data, {"glyph": "auto", "axis": "linear", "counts": "show"})
    assert sum(len(b["plates"]) for b in result["blocks"]) == plates
    assert len(analysis.table(result)) == plates


def test_per_plate_statistic_reports_every_plate():
    table, plates = _table()
    analysis = ANALYSES["plate_statistic"]
    data = ad.build_data(analysis, table, None, ad.default_assignment(analysis, table.variables))
    result = analysis.compute(data, {"statistic": "Coefficient Of Variation"})
    assert sum(len(v) for v in result["cells"].values()) == plates


def test_within_group_predictor_recovers_the_planted_slope():
    geno = st.StatsVariable("geno", "Genotype", "nominal", ("WT", "mut"), ("WT", "mut"), "WT")
    rng = np.random.default_rng(2)
    rows = []
    for k, g in enumerate(("WT",) * 8 + ("mut",) * 8):
        count = float(rng.integers(50, 400))
        median = 2000.0 / count ** 0.5 * (0.7 if g == "mut" else 1.0)
        rows.append((k + 1, {"geno": g}, 100.0, {"colony_count": count, "median_radius_um": median,
                                                 "mean_radius_um": median}))
    labels = {"colony_count": "Colonies counted", "median_radius_um": "Median colony radius (µm)",
              "mean_radius_um": "Mean colony radius (µm)"}
    index_table = st.build_index_table([geno], rows, labels)
    analysis = ANALYSES["within_group_predictor"]
    colonies, _ = _table()
    data = ad.build_data(analysis, colonies, index_table, {"geno": "groups"}, measure="colony_count")
    result = analysis.compute(data, {"x_scale": "log"})
    assert result["fit"]["slope"] == pytest.approx(-0.5, abs=0.02)


def test_overview_pdf_writes_the_chosen_pages(tmp_path, annotated):
    manager, _, _ = annotated
    from quantacolony.stats.overview_pdf import export_overview_pdf, overview_choices
    choices = overview_choices(manager)
    assert choices[0][0] == "fidelity"
    out = export_overview_pdf(manager, tmp_path / "overview.pdf", ["fidelity", "box"])
    assert out.is_file() and out.stat().st_size > 10000


def test_overview_pdf_pages_follow_the_dissertation_format(tmp_path, annotated):
    """Letter pages, every figure inside the text block with no label under 7 pt, past an edge or over
    another label, and only Latin Modern Roman, embedded."""
    manager, _, _ = annotated
    from pypdf import PdfReader
    from quantacolony.dissertation import style as S
    from quantacolony.stats.overview_pdf import export_overview_pdf, overview_choices
    checks = []
    ids = [c[0] for c in overview_choices(manager) if c[2]]
    out = export_overview_pdf(manager, tmp_path / "overview.pdf", ids, checks=checks)
    failed = [(c.title, c.min_pt, c.outside, c.overlaps[:3]) for c in checks if not c.passed]
    assert not failed, failed
    sizes = {tuple(sorted((round(float(p.mediabox.width)), round(float(p.mediabox.height))))) for p in PdfReader(out).pages}
    assert sizes == {(612, 792)}
    fonts = S.pdf_fonts(out)
    assert fonts and all(embedded and "LMRoman10" in name for name, embedded in fonts)


def test_bundled_tutorial_project_carries_the_new_design(tmp_path):
    manager = DataManager(Settings(folder=tmp_path / "s"), create_library(tmp_path / "lib"))
    manager.open_project(manager.add_tutorial_project())
    info = manager.project_info()
    assert [v.name for v in info.variables] == ["dilution_level"]
    assert manager._file.setting("tutorial") == {"name": "crowding", "version": 3}
    assert {s["name"] for s in manager.annotation_specs()} == {"hce", "incubation_days"}
    hce = manager.index_table(coverage=False).measures["annotation:hce"]
    assert np.isfinite(hce).all() and len(hce) == 10
    manager.close()
