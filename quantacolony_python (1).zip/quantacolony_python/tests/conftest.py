"""Close every window and run pending deletions before the interpreter exits, so Qt objects
are not destroyed after the QApplication."""

import pytest


@pytest.fixture(scope="session", autouse=True)
def _close_qt_windows():
    yield
    from PySide6.QtCore import QCoreApplication, QEvent
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance()
    if app is None:
        return
    for widget in QApplication.topLevelWidgets():
        if hasattr(widget, "close_guard"):
            widget.close_guard = None                  # no "save this image?" question at teardown
        widget.close()
        widget.deleteLater()
    QCoreApplication.sendPostedEvents(None, QEvent.DeferredDelete)
    app.processEvents()


# Tests that open the bundled dissertation projects (quantacolony/data/dissertation/*.qcproj). Copies
# shared without those files skip them; with the files in place they run as usual.
NEEDS_DISSERTATION_FILES = {
    "test_first_start_puts_the_tutorial_project_in_a_new_library",
    "test_a_new_bundle_replaces_older_dissertation_copies_without_deleting_them",
    "test_tutorial_steps_check_the_screen",
    "test_guided_clicks_make_each_change_and_every_need_has_a_reason",
    "test_screens_swap_inside_one_master_window",
    "test_navigation_home_project_modules",
}


def pytest_collection_modifyitems(config, items):
    from quantacolony.data.tutorial_project import DISSERTATION_FILES
    missing = [name for name, path in DISSERTATION_FILES.items() if not path.exists()]
    if not missing:
        return
    skip = pytest.mark.skip(reason=f"bundled dissertation projects not in this copy: {', '.join(missing)}")
    for item in items:
        if item.name in NEEDS_DISSERTATION_FILES:
            item.add_marker(skip)
