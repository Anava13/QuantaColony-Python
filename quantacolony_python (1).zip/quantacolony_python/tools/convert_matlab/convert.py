"""Build the QuantaColony projects from the MATLAB composite (combined.mat).

Usage: python convert.py <combined.mat> <dataset: crowding|rescue|historical|anbalagan|all> <out_dir>

Everything is written through QuantaColony's own DataManager, so the files are what the app
itself would produce: variables and levels, one photo per plate (lossless PNG of the composite
image), a crop region per index, committed colonies (in_final = in_baseline), per-plate
annotations, and growth coverage cached so Stats opens with it measured.

Design rule carried through every dataset: the designed quantity is a variable, the measured
one is an annotation. The hemocytometer cell estimate, dish size, incubation days, source
file and source figure are annotations; dilution factor, genotype, passage, density tier and
series are variables.
"""
from __future__ import annotations

import collections
import io
import json
import re
import sys
import tempfile
from pathlib import Path

import numpy as np
import scipy.io as sio
from PIL import Image
from scipy import ndimage
from skimage.measure import approximate_polygon, find_contours

QC = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(QC))
from quantacolony.core.colony_set import ColonySet  # noqa: E402
from quantacolony.core.params import DetectionParams  # noqa: E402
from quantacolony.core.record import DetectionResult  # noqa: E402
from quantacolony.data.library import create_library  # noqa: E402
from quantacolony.data.manager import DataManager  # noqa: E402
from quantacolony.data.packets import AnnotationSpec, Assignment, LevelSpec, VariableSpec  # noqa: E402
from quantacolony.data.regions import crop_box, outline_from_geometry  # noqa: E402
from quantacolony.data.settings import Settings  # noqa: E402

KIND = {"irregular": "irregular", "circular": "circular", "Manual Addition": "manual"}


# ----- reading one MATLAB plate -------------------------------------------------------
def colonies_of(p):
    """Photo-coordinate colonies (0-based x/y) from the composite's Measurements."""
    M = p.Measurements
    n = int(np.size(M.Radius_Pixels))
    if n == 0:
        return ColonySet.empty()
    centers = np.atleast_2d(np.asarray(M.Centers, float)).reshape(-1, 2) - 1.0
    radii = np.atleast_1d(np.asarray(M.Radius_Pixels, float))
    kinds_raw = np.atleast_1d(M.DetectionType).tolist() if hasattr(M, "DetectionType") else ["irregular"] * n
    bnd_raw = np.atleast_1d(M.Boundaries) if hasattr(M, "Boundaries") else [None] * n
    if n == 1 and hasattr(M, "Boundaries") and np.asarray(M.Boundaries).dtype != object:
        bnd_raw = [M.Boundaries]
    boundaries = []
    for b in bnd_raw:
        if b is None:
            boundaries.append(None)
            continue
        b = np.asarray(b, float)
        if b.ndim != 2 or b.shape[1] != 2 or len(b) < 3:
            boundaries.append(None)
        else:
            boundaries.append(np.ascontiguousarray(b[:, ::-1] - 1.0))   # MATLAB [row col] 1-based -> x/y 0-based
    kinds = [KIND.get(str(k), "irregular") for k in kinds_raw]
    # A Colony Set merged from two sessions can carry outlines and types for only the first rows
    kinds = (kinds + ["manual"] * n)[:n]
    boundaries = (list(boundaries) + [None] * n)[:n]
    return ColonySet.from_columns(centers, radii, boundaries, kinds, np.full(n, np.nan), np.arange(1, n + 1))


def content_mask(image: np.ndarray) -> np.ndarray:
    """Pixels that are plate (the composite images are black outside the cropped region)."""
    mask = image[..., :3].max(axis=2) > 8
    mask = ndimage.binary_closing(mask, iterations=3)
    labels, count = ndimage.label(mask)
    if count > 1:
        sizes = ndimage.sum(mask, labels, range(1, count + 1))
        mask = labels == (1 + int(np.argmax(sizes)))
    return ndimage.binary_fill_holes(mask)


def circle_layout(image: np.ndarray) -> dict:
    mask = content_mask(image)
    ys, xs = np.nonzero(mask)
    cx, cy = float(xs.mean()), float(ys.mean())
    r = float(np.sqrt(mask.sum() / np.pi)) + 1.0
    return {"kind": "circular", "cx": cx, "cy": cy, "r": r, "cuts": []}


def polygon_geometry(image: np.ndarray) -> dict:
    mask = content_mask(image)
    padded = np.pad(mask, 1).astype(float)
    contour = max(find_contours(padded, 0.5), key=len) - 1.0          # (row, col)
    contour = approximate_polygon(contour, tolerance=0.75)
    return {"points": [[float(c), float(r)] for r, c in contour[:-1]]}  # x/y


def png_bytes(image: np.ndarray) -> bytes:
    buffer = io.BytesIO()
    Image.fromarray(np.ascontiguousarray(image[..., :3])).save(buffer, format="PNG", optimize=True)
    return buffer.getvalue()


def params_for(colonies: ColonySet) -> DetectionParams:
    """Placeholder settings bracketing the stored radii (the MATLAB settings are not in the composite)."""
    if len(colonies) == 0:
        return DetectionParams(level=-0.45, rmin=3.0, rmax=31.0, maxpix=6250.0)
    lo, hi = float(np.min(colonies.radii)), float(np.max(colonies.radii))
    rmin = max(1.0, np.floor(lo))
    rmax = max(rmin + 1.0, np.ceil(hi))
    return DetectionParams(level=-0.45, sense=0.9, rmin=rmin, rmax=min(200.0, rmax),
                           maxpix=float(min(10000.0, max(2000.0, np.ceil(np.pi * hi * hi * 1.5)))),
                           detection_type="Irregular")


# ----- generic builder ---------------------------------------------------------------
def build(name, variables, plate, entries, region_mode, out_dir: Path, extra=None, annotations=None,
          measure_coverage=True):
    """entries: dicts with keys levels, plate (MATLAB struct), photo_name, meta, annotations ({name: value})."""
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        manager = DataManager(Settings(folder=tmp / "settings"), create_library(tmp / "library"))
        manager.create_project(name, variables, DetectionParams(level=-0.45, rmin=3.0, rmax=31.0, maxpix=6250.0),
                               plate=plate, extra=extra or {}, annotations=annotations or [])
        rows = []
        for e in entries:
            p = e["plate"]
            image = np.asarray(p.image)
            photo_id = manager.add_photo(png_bytes(image), float(p.pixels_per_mm), file_name=e["photo_name"],
                                         scaling_method="composite")
            if region_mode == "circle":
                layout = circle_layout(image)
                manager.commit_photo(photo_id, layout, [e["levels"]])
                index_id = manager._structure.find_index(_level_ids(manager, e["levels"]))
            else:
                index_id = manager.add_index(e["levels"])
                manager.commit_assignments([Assignment(index_id, photo_id, "polygon", polygon_geometry(image))])
            assignment = manager._photos.assignment(index_id)
            outline = outline_from_geometry(assignment["region_kind"], json.loads(assignment["geometry"]))
            x0, y0, _, _ = crop_box(outline, image.shape)
            colonies = colonies_of(p)
            local = colonies.translated(-x0, -y0)
            result = DetectionResult(index_id, params_for(colonies), local, local, (), 1)
            manager.commit_detection(result)
            for key, value in (e.get("annotations") or {}).items():
                manager.set_plate_annotation(index_id, key, value)
            # check: colonies stay inside the region
            from skimage.draw import polygon2mask
            mask = polygon2mask(image.shape[:2], outline[:, ::-1])
            inside = [bool(mask[min(image.shape[0] - 1, max(0, int(round(y)))),
                                min(image.shape[1] - 1, max(0, int(round(x))))]) for x, y in colonies.centers]
            rows.append({"index_id": index_id, **e["meta"], **{f"level_{k}": v for k, v in e["levels"].items()},
                         "photo": e["photo_name"], "colonies": len(colonies),
                         "outside_region": len(inside) - sum(inside)})
        with manager._file.transaction():
            manager._file.set_setting("source_metadata", {
                "origin": "Converted from the MATLAB composite (combined.mat); colonies are the composite's final "
                          "Colony Sets, detection settings are placeholders",
                "plates": {str(r["index_id"]): {k: v for k, v in r.items() if not k.startswith("level_")}
                           for r in rows}})
        if measure_coverage:                        # cache growth coverage so Stats opens with it measured
            manager.index_table(coverage=True,
                                progress=lambda done, total: print(f"  coverage {done}/{total}", flush=True) or True)
        project_id = manager.project_id
        out = manager.export_project_file(project_id, out_dir / f"{name}.qcproj")
        manager.close()
    checks = [(r["photo"], r["colonies"], r["outside_region"]) for r in rows]
    print(f"{name}: {len(rows)} plates, {sum(c for _, c, _ in checks)} colonies, "
          f"{sum(o for _, _, o in checks)} outside regions -> {out}")
    return out, rows


def _level_ids(manager, levels):
    variables = manager._structure.variable_ids()
    known = manager._structure.level_ids()
    return {variables[n]: known[n][v] for n, v in levels.items()}


# ----- Crowding (part2): the tutorial project -------------------------------------------
def crowding(c, out_dir):
    """Wild-type dilution series: Dilution Level is the design, the cell estimate an annotation."""
    P = sorted(np.atleast_1d(c.part2.composite), key=lambda p: float(p.dilution_factor))
    variables = [VariableSpec("dilution_level", "ordinal",
                              tuple(LevelSpec(str(int(p.dilution_factor)), f"{int(p.dilution_factor)}X")
                                    for p in P), "Dilution Level")]
    annotations = [AnnotationSpec("hce", "number", "Hemocytometer Cell Estimate"),
                   AnnotationSpec("incubation_days", "number", "Incubation", "days")]
    entries = []
    for p in P:
        entries.append({
            "levels": {"dilution_level": str(int(p.dilution_factor))},
            "plate": p,
            "photo_name": re.sub(r"\.(jpe?g|png)$", "", str(p.filename), flags=re.I) + ".png",
            "annotations": {"hce": str(int(p.hce)), "incubation_days": str(int(p.incubation_days))},
            "meta": {"original_file": str(p.filename), "hce": int(p.hce),
                     "matlab_colony_count": int(p.colony_count),
                     "matlab_growth_coverage": float(p.biomass_occupation.growth),
                     "matlab_capture_ratio": float(p.biomass_occupation.CaptureRatio),
                     "matlab_median_radius_um": float(p.summary_stats.median),
                     "matlab_pixels_per_mm": round(float(p.pixels_per_mm), 4)},
        })
    plate = {"type": "circular", "sections": 1, "scale": "none"}
    extra = {"tutorial": {"name": "crowding", "version": 2},
             "variable_details": {"dilution_level": {"preset": "", "unit": "", "additive": ""}}}
    return build("Crowding", variables, plate, entries, "circle", out_dir, extra=extra, annotations=annotations)


# ----- Rescue (part3) --------------------------------------------------------------------
GENOTYPES = [("wild_type", "wild_type", "Wild type", True), ("dbf4-1", "dbf4-1", "dbf4-1", False),
             ("cdc13-2", "cdc13-2", "cdc13-2", False), ("double", "dbf4-1_cdc13-2", "dbf4-1 cdc13-2", False)]
SERIES = [("main", "Main", True), ("21_day", "21-day incubation", False),
          ("large_enriched", "Large-colony enriched", False), ("small_enriched", "Small-colony enriched", False)]
TIERS = [("1", "Low"), ("2", "Med"), ("3", "High")]

# Plates whose stored HCE places them in another density tier than their file name says
HCE_TIER = {"Double_P3V1_6Days_Low_RepA.JPG": "Med",       # HCE 816, the Med plates' HCE
            "Double_P3V1_6Days_Med_RepB.JPG": "Low",       # HCE 160, the Low plates' HCE
            "Double_P5_6Days_Med_A.JPG": "Low",            # HCE 144; P5 has no other Low plate
            "Double_P5_6Days_Med_B.JPG": "Low"}


def tier_from_name(name: str) -> str:
    if name in HCE_TIER:
        return HCE_TIER[name]
    for token, tier in (("_High", "High"), ("_Med", "Med"), ("_Low", "Low")):
        if token in name:
            return tier
    if "_50_" in name:
        return "Med"                                # single-density plate (HCE 800)
    if "LargePlate" in name:
        return "Low"                                # single-density plate (HCE 160)
    if "Colonies" in name:
        return "Med"                                # enriched plate (HCE 656-928)
    raise ValueError(name)


def series_of(p) -> str:
    name = str(p.filename)
    if int(p.incubation_days) == 21:
        return "21_day"
    if str(p.source_type) == "LargeSourced":
        return "large_enriched"
    if str(p.source_type) == "SmallSourced":
        return "small_enriched"
    return "main"


def rescue(c, out_dir):
    """Genotype x Passage x Density x Series, replicate plates numbered within each index.

    The density tier (Low/Med/High) is the designed variable; the exact hemocytometer cell
    estimate is a per-plate annotation. Plates that differ only by culture version (P2V2 vs
    P2V3) are replicate plates of one index; the original file name keeps them apart. The two
    double mutant P3 plates whose HCE places them in another tier than their file name says are
    technical replicates of the plate already in that tier, numbered after it."""
    P = list(np.atleast_1d(c.part3.composite))[:121]        # individual plates; later entries pool replicates
    gvalue = {g: v for g, v, _, _ in GENOTYPES}
    tier_value = {label: value for value, label in TIERS}
    raw = []
    for p in P:
        name = str(p.filename)
        tier = tier_from_name(name)
        rep = str(p.replicate) if str(p.replicate) in ("A", "B") else ""
        version = (re.search(r"P\d+(V\d+)", name) or [None, ""])[1]
        raw.append({"plate": p, "name": name, "tier": tier, "rep": rep, "version": version,
                    "genotype": gvalue[str(p.genotype)], "passage": str(int(p.passage)), "series": series_of(p)})
    groups = collections.defaultdict(list)
    for r in raw:
        groups[(r["genotype"], r["passage"], r["tier"], r["series"])].append(r)
    for members in groups.values():                          # replicate number: by culture version, then letter
        members.sort(key=lambda r: (r["version"], r["name"] in HCE_TIER, r["rep"], r["name"]))
        for number, r in enumerate(members, start=1):
            r["replicate"] = str(number)
    plates_per_index = max(len(m) for m in groups.values())
    variables = [
        VariableSpec("genotype", "nominal", tuple(LevelSpec(v, d, ctl) for _, v, d, ctl in GENOTYPES), "Genotype"),
        VariableSpec("passage", "ordinal", tuple(LevelSpec(str(i)) for i in range(1, 6)), "Passage"),
        VariableSpec("density", "ordinal", tuple(LevelSpec(v, d) for v, d in TIERS), "Density"),
        VariableSpec("replicate", "replicate",
                     tuple(LevelSpec(str(i)) for i in range(1, plates_per_index + 1)), "Replicate"),
        VariableSpec("series", "nominal", tuple(LevelSpec(v, d, ctl) for v, d, ctl in SERIES), "Series"),
    ]
    annotations = [AnnotationSpec("hce", "number", "Hemocytometer Cell Estimate"),
                   AnnotationSpec("plate_size", "choice", "Plate size", choices=("Standard", "Large")),
                   AnnotationSpec("incubation_days", "number", "Incubation", "days"),
                   AnnotationSpec("original_file", "text", "Original file")]
    entries, seen = [], collections.Counter()
    for r in raw:
        p = r["plate"]
        levels = {"genotype": r["genotype"], "passage": r["passage"], "density": tier_value[r["tier"]],
                  "replicate": r["replicate"], "series": r["series"]}
        key = tuple(levels.values())
        seen[key] += 1
        entries.append({"levels": levels, "plate": p,
                        "photo_name": re.sub(r"\.(jpe?g|png)$", "", r["name"], flags=re.I) + ".png",
                        "annotations": {"hce": str(int(p.hce)), "plate_size": str(p.plate_type.plate_size),
                                        "incubation_days": str(int(p.incubation_days)),
                                        "original_file": r["name"]},
                        "meta": {"original_file": r["name"], "hce": int(p.hce),
                                 "incubation_days": int(p.incubation_days), "source_type": str(p.source_type),
                                 "enrichment": str(p.enrichment), "culture_version": r["version"],
                                 "original_replicate": r["rep"], "filename_density": r["tier"],
                                 "matlab_colony_count": int(p.colony_count)}})
    duplicates = [k for k, n in seen.items() if n > 1]
    if duplicates:
        raise SystemExit(f"Colliding level combinations: {duplicates}")
    order = {v: i for i, (_, v, _, _) in enumerate(GENOTYPES)}
    sorder = {v: i for i, (v, _, _) in enumerate(SERIES)}
    entries.sort(key=lambda e: (order[e["levels"]["genotype"]], int(e["levels"]["passage"]),
                                sorder[e["levels"]["series"]], int(e["levels"]["density"]),
                                e["levels"]["replicate"]))
    plate = {"type": "circular", "sections": 1, "scale": "none"}
    extra = {"plates_per_index": plates_per_index,
             "variable_details": {"passage": {"preset": "", "unit": "", "additive": ""},
                                  "density": {"preset": "", "unit": "", "additive": ""}}}
    return build("Rescue", variables, plate, entries, "circle", out_dir, extra=extra, annotations=annotations)


# ----- Historical ----------------------------------------------------------------------
def historical(c, out_dir):
    H = np.atleast_1d(c.historical.composite)
    order = ["est1", "tlc1", "est21", "est31", "est41", "est11"]
    display = {str(p.genotype): str(p.genotype_display) for p in H}
    variables = [
        VariableSpec("genotype", "nominal", tuple(LevelSpec(g, display[g]) for g in order), "Genotype"),
        VariableSpec("passage", "ordinal", tuple(LevelSpec(str(i)) for i in range(1, 5)), "Passage"),
    ]
    annotations = [AnnotationSpec("source_paper", "text", "Source paper"),
                   AnnotationSpec("source_figure", "text", "Source figure")]
    entries = []
    for p in H:
        blank = float(p.pixels_per_mm) == 1.0 and int(p.colony_count) == 0
        if blank:
            continue
        g, ps = str(p.genotype), str(int(p.passage))
        entries.append({"levels": {"genotype": g, "passage": ps}, "plate": p,
                        "photo_name": f"{p.source_paper}_{g}_P{ps}.png",
                        "annotations": {"source_paper": str(p.source_paper), "source_figure": str(p.filename)},
                        "meta": {"source_figure": str(p.filename), "source_paper": str(p.source_paper),
                                 "matlab_colony_count": int(p.colony_count)}})
    entries.sort(key=lambda e: (order.index(e["levels"]["genotype"]), int(e["levels"]["passage"])))
    plate = {"type": "circular", "sections": 1, "scale": "none"}
    return build("Historical", variables, plate, entries, "polygon", out_dir,
                 extra={"variable_details": {"passage": {"preset": "", "unit": "", "additive": ""}}},
                 annotations=annotations)


# ----- Anbalagan -----------------------------------------------------------------------
def anbalagan(c, out_dir):
    """Senescence lineages: Genotype x Passage x Source figure.

    The two source figures hold separate lineages from separate experiments, so the figure is a
    nominal variable (Anbalagan's Figure 2C or 8D). Wild type and rif1 appear in both; the other
    genotypes in one, so the design is not fully crossed. The generation count travels as an
    annotation."""
    A = np.atleast_1d(c.anbalagan.composite)
    order = ["Wild_Type", "rif1", "cdc132", "est2", "rif1_cdc132", "rif1_est2"]
    display = {str(p.genotype): str(p.genotype_display) for p in A}
    groups = collections.defaultdict(list)
    for p in A:
        groups[(str(p.genotype), int(p.passage))].append(p)
    for members in groups.values():
        members.sort(key=lambda p: str(p.figure))
    figures = {"2": ("2C", "Figure 2C"), "8": ("8D", "Figure 8D")}
    variables = [
        VariableSpec("genotype", "nominal",
                     tuple(LevelSpec(g, display[g], g == "Wild_Type") for g in order if g in display), "Genotype"),
        VariableSpec("passage", "ordinal",
                     tuple(LevelSpec(str(i)) for i in sorted({int(p.passage) for p in A})), "Passage"),
        VariableSpec("source_figure", "nominal", tuple(LevelSpec(v, d) for v, d in figures.values()),
                     "Source figure"),
    ]
    annotations = [AnnotationSpec("source_figure", "text", "Source figure"),
                   AnnotationSpec("generations", "number", "Generations")]
    entries = []
    for (genotype, passage), members in sorted(groups.items(),
                                               key=lambda kv: (order.index(kv[0][0]), kv[0][1])):
        for p in members:
            entries.append({
                "levels": {"genotype": genotype, "passage": str(passage),
                           "source_figure": figures[str(p.figure)[0]][0]},
                "plate": p,
                "photo_name": f"{Path(str(p.filename)).stem}_{genotype}.png",
                "annotations": {"source_figure": str(p.figure), "generations": str(int(p.generations))},
                "meta": {"source_figure": str(p.figure), "original_file": str(p.filename),
                         "generations": int(p.generations), "matlab_colony_count": int(p.colony_count)}})
    plate = {"type": "circular", "sections": 1, "scale": "none"}
    extra = {"plates_per_index": 1,
             "variable_details": {"passage": {"preset": "", "unit": "", "additive": ""}}}
    return build("Anbalagan", variables, plate, entries, "polygon", out_dir, extra=extra, annotations=annotations)


BUILDERS = {"crowding": crowding, "rescue": rescue, "historical": historical, "anbalagan": anbalagan}

if __name__ == "__main__":
    mat, which, out_dir = sys.argv[1], sys.argv[2], Path(sys.argv[3])
    out_dir.mkdir(parents=True, exist_ok=True)
    data = sio.loadmat(mat, squeeze_me=True, struct_as_record=False)["composite"]
    for name in (BUILDERS if which == "all" else [which]):
        BUILDERS[name](data, out_dir)
