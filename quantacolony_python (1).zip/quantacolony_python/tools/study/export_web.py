#!/usr/bin/env python3
"""
export_web.py
=============

Copy what the browser study runs into the web repository (QuantaColony-External-Testing), so the page
runs QuantaColony's own code: the same detection, session, recorder and project file as the desktop.

    uv run python tools/study/export_web.py --site ../QuantaColony-External-Testing

What it writes in the site
--------------------------
python/quantacolony/    core/, data/ and study/ (model, project, web and the bundle of plates); the Qt
                        modules (gui, theme, stats, analyses, dissertation) stay out
study.json              the form's questions, the goal and the concept figures, so the reading pages
                        show while Python loads
assets/concepts/        the concept figures
python/SOURCE.json      the QuantaColony version and the files exported, with their SHA-256

The site's deploy workflow zips python/ into python.zip, which the page unpacks into Pyodide.
"""

import argparse
import hashlib
import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PACKAGE = ROOT / "quantacolony"
STUDY_FILES = ("__init__.py", "model.py", "project.py", "guide.py", "score.py", "practice.py", "web.py")   # study/ without its Qt views
SKIP = shutil.ignore_patterns("__pycache__", "*.pyc", "*.qcproj")      # bundled tutorial projects stay out


def main():
    parser = argparse.ArgumentParser(description="Export the browser study's Python code into the web repository.")
    parser.add_argument("--site", required=True)
    args = parser.parse_args()
    site = Path(args.site)
    target = site / "python" / "quantacolony"
    if target.exists():
        shutil.rmtree(target)
    target.mkdir(parents=True)
    shutil.copy(PACKAGE / "__init__.py", target / "__init__.py")
    for folder in ("core", "data"):
        shutil.copytree(PACKAGE / folder, target / folder, ignore=SKIP)
    (target / "study").mkdir()
    for name in STUDY_FILES:
        shutil.copy(PACKAGE / "study" / name, target / "study" / name)
    shutil.copytree(PACKAGE / "study" / "bundle", target / "study" / "bundle", ignore=SKIP)

    sys.path.insert(0, str(ROOT))
    from quantacolony import __version__
    from quantacolony.study import model as sm
    bundle = sm.load_bundle(PACKAGE / "study" / "bundle")
    concepts = site / "assets" / "concepts"
    if concepts.exists():
        shutil.rmtree(concepts)
    concepts.mkdir(parents=True)
    for c in bundle.concepts:
        shutil.copy(bundle.folder / "concepts" / c.file, concepts / c.file)
    study = {"study_version": sm.STUDY_VERSION, "bundle_version": bundle.version,
             "questions": [[k, q, list(c)] for k, q, c in sm.QUESTIONS], "goal": sm.GOAL,
             "concepts": [{"file": f"assets/concepts/{c.file}", "title": c.title, "caption": c.caption}
                          for c in bundle.concepts]}
    (site / "study.json").write_text(json.dumps(study, indent=2, ensure_ascii=False), encoding="utf-8")

    files = sorted(p for p in target.rglob("*") if p.is_file())
    source = {"quantacolony_version": __version__, "study_version": sm.STUDY_VERSION,
              "bundle_version": bundle.version,
              "files": {str(p.relative_to(target.parent)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
    (site / "python" / "SOURCE.json").write_text(json.dumps(source, indent=2), encoding="utf-8")
    print(f"{len(files)} files exported to {target}")


if __name__ == "__main__":
    main()
