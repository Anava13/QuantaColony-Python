#!/usr/bin/env python3
"""
expert_reference.py
===================

Turn the expert's study results into the reference for the real plates, in the truth format that
score_quantacolony.py reads, so every participant is scored on all study plates the same way.

    uv run python tools/study/expert_reference.py --expert "QuantaColony study - Alex - ....zip" \
        --truth study_set/truth --out study_truth

What it writes (a new folder; the study set's truth folder is not changed)
--------------------------------------------------------------------------
Everything in --truth, copied, plus for each real plate (study_05, study_06):
    <plate>_labels.png      every pixel's owner among the expert's final colonies (0 = agar)
    <plate>_truth.csv       one row per expert colony, with the columns the scorer reads
and run_record.json gains both plates (their scale and condition), so the scorer pairs them.

How the label image is made
---------------------------
Each final colony covers its saved outline, or its circle when it has none. A pixel that two
colonies cover goes to the colony whose center is nearer, which splits touching colonies along
the line halfway between them. Two colonies touch when their pixels lie within TOUCH_PX of each
other (split outlines meet edge to edge without sharing pixels); group_size counts the colonies in
each set of touching colonies.
The expert's radius_px is the reference radius. plateau_od and margin_width_mm describe how a
synthetic colony was drawn; real colonies have none, so both are NaN.
"""

import argparse
import csv
import io
import json
import shutil
import sqlite3
import tempfile
import zipfile
from pathlib import Path

import numpy as np
from PIL import Image
from scipy.sparse.csgraph import connected_components
from skimage.draw import disk, polygon

REAL = {"study_05": "sparse", "study_06": "crowded"}
TOUCH_PX = 2
COLUMNS = ["colony_id", "group_id", "group_size", "x_px", "y_px", "true_radius_px", "true_radius_mm",
           "true_area_mm2", "plateau_od", "margin_width_mm", "source"]


# =====================================================================================
# MODEL
# =====================================================================================

def read_expert(project: Path):
    """{photo stem: (px_per_mm, shape, [(x, y, radius_px, outline or None)])} for the real plates."""
    db = sqlite3.connect(f"file:{project}?mode=ro", uri=True)
    plates = {}
    query = ("SELECT p.file_name, p.px_per_mm, p.width, p.height, a.index_id FROM photos p "
             "JOIN assignments a ON a.photo_id = p.photo_id")
    for file_name, ppm, width, height, index_id in db.execute(query).fetchall():
        stem = Path(file_name).stem
        if stem not in REAL:
            continue
        colonies = []
        for x, y, r, boundary in db.execute("SELECT x, y, radius_px, boundary FROM colonies "
                                            "WHERE index_id = ? AND in_final = 1", (index_id,)):
            outline = None if boundary is None else np.load(io.BytesIO(boundary))
            colonies.append((x, y, r, outline))
        plates[stem] = (float(ppm), (int(height), int(width)), colonies)
    db.close()
    return plates


def colony_pixels(colony, shape):
    x, y, r, outline = colony
    if outline is not None and len(outline) > 2:
        return polygon(outline[:, 1], outline[:, 0], shape)
    return disk((y, x), r, shape=shape)


def label_image(colonies, shape):
    """Owner of every pixel (colony ids from 1); shared pixels go to the nearer center."""
    owner = np.zeros(shape, np.int32)
    distance = np.full(shape, np.inf)
    for k, colony in enumerate(colonies, start=1):
        rr, cc = colony_pixels(colony, shape)
        d = np.hypot(cc - colony[0], rr - colony[1])
        take = d < distance[rr, cc]
        owner[rr[take], cc[take]] = k
        distance[rr[take], cc[take]] = d[take]
    return owner


def touching_pairs(owner, reach=TOUCH_PX):
    """Pairs of colonies whose pixels lie within `reach` pixels of each other."""
    pairs = set()
    rows, cols = owner.shape
    padded = np.pad(owner, reach)
    for dy in range(-reach, reach + 1):
        for dx in range(-reach, reach + 1):
            if (dx, dy) == (0, 0) or dx * dx + dy * dy > reach * reach:
                continue
            shifted = padded[reach + dy:reach + dy + rows, reach + dx:reach + dx + cols]
            hit = (owner > 0) & (shifted > 0) & (owner != shifted)
            pairs.update(zip(owner[hit].tolist(), shifted[hit].tolist()))
    return pairs


def groups(count, touching):
    """(group id, group size) per colony, from the pairs that share pixels."""
    if count == 0:
        return np.array([], int), np.array([], int)
    graph = np.zeros((count, count), bool)
    for a, b in touching:
        graph[a - 1, b - 1] = graph[b - 1, a - 1] = True
    _, group = connected_components(graph, directed=False)
    sizes = np.bincount(group)
    return group + 1, sizes[group]


def truth_rows(colonies, ppm, group, size):
    rows = []
    for k, (x, y, r, _) in enumerate(colonies, start=1):
        rows.append(dict(colony_id=k, group_id=int(group[k - 1]), group_size=int(size[k - 1]), x_px=round(x, 3),
                         y_px=round(y, 3), true_radius_px=round(r, 4), true_radius_mm=round(r / ppm, 6),
                         true_area_mm2=round(np.pi * (r / ppm) ** 2, 6), plateau_od="nan", margin_width_mm="nan",
                         source="expert"))
    return rows


# =====================================================================================
# VIEW
# =====================================================================================

def write_plate(out: Path, stem: str, owner, rows):
    image = owner.astype(np.uint16) if owner.max() > 255 else owner.astype(np.uint8)
    Image.fromarray(image).save(out / f"{stem}_labels.png")
    with open(out / f"{stem}_truth.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=COLUMNS)
        writer.writeheader()
        writer.writerows(rows)


# =====================================================================================
# CONTROLLER
# =====================================================================================

def main():
    parser = argparse.ArgumentParser(description="The expert's study results as the real plates' reference.")
    parser.add_argument("--expert", required=True, help="the expert's results zip from the study app")
    parser.add_argument("--truth", required=True, help="the study set's truth folder")
    parser.add_argument("--out", required=True, help="new folder for the complete truth")
    args = parser.parse_args()
    out = Path(args.out)
    if out.exists():
        raise SystemExit(f"{out} exists; choose a new folder.")
    shutil.copytree(args.truth, out)

    with tempfile.TemporaryDirectory() as tmp, zipfile.ZipFile(args.expert) as archive:
        project = next(n for n in archive.namelist() if n.endswith(".qcproj"))
        archive.extract(project, tmp)
        expert = json.loads(archive.read("participant.json"))
        plates = read_expert(Path(tmp) / project)
    missing = set(REAL) - set(plates)
    if missing:
        raise SystemExit(f"The expert's project has no {', '.join(sorted(missing))}.")

    record = json.loads((out / "run_record.json").read_text())
    record["plates"] = [p for p in record["plates"] if p["file"] not in REAL]
    for stem, (ppm, shape, colonies) in sorted(plates.items()):
        owner = label_image(colonies, shape)
        group, size = groups(len(colonies), touching_pairs(owner))
        write_plate(out, stem, owner, truth_rows(colonies, ppm, group, size))
        record["plates"].append(dict(file=stem, role="scored", set="real", distribution=REAL[stem], seed="",
                                     perturbation="none", level="", pixels_per_mm=ppm, origin="expert run",
                                     expert=expert["participant"]["name"]))
        print(f"{stem}: {len(colonies)} expert colonies, {int(np.sum(size > 1))} touching")
    record["expert"] = {k: expert.get(k) for k in ("participant", "software_version", "study_version", "times")}
    (out / "run_record.json").write_text(json.dumps(record, indent=2))
    print(f"Truth for all plates in {out}")


if __name__ == "__main__":
    main()
