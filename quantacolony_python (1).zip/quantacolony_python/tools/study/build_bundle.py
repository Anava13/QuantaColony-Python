#!/usr/bin/env python3
"""
build_bundle.py
===============

The plates the user study ships with (quantacolony/study/bundle), built from the synthetic study set
and two real plates of combined.mat.

    uv run python tools/study/build_bundle.py --study-set study_set --generator "Scoring QC" \
        --medium Double_P2V2_6Days_Low_RepA.JPG --hard Dbf4_1_P4V2_6Days_High_RepA.JPG

What it writes
--------------
bundle/photos/          practice.png and the four study plates, shown in this fixed order (ORDER):
                        study_04  easy, synthetic: a whole dish, 40 colonies
                        study_05  medium, real: a square window of the dish (WINDOW_SIDE x its radius)
                        study_03  hard, synthetic: a dense region of a dish (make_study_plates dense_patch)
                        study_06  hard, real: a square window of a crowded dish
                        Windows keep the four plates to about 15 minutes in all.
bundle/practice_labels.png, practice_truth.csv, practice_artifacts.png
                        the practice plate's truth: labels, the truth table (required and optional
                        colonies) and the objects that are not colonies, for the guide and the
                        training check (study/score.py)
bundle/concepts/        figures for the concept page, drawn from the practice plate's truth
bundle/manifest.json    each plate's imported scale and dish circle, the tutorial target, the concepts, and
                        the marks: places the guide rings on the practice plate (the plate number, the
                        condensation, a faint colony, a dark colony for snapping, the brighter side, the
                        triple, the inseparable mass)

and, beside the study set's truth (never shipped):
truth/study_05_saved_measurements.csv, truth/study_06_saved_measurements.csv
                        the saved measurements of the real plates (isolated colonies only), for
                        checking the expert run against them
truth/key.csv           gains a row for each real plate

Choices
-------
Dish circle: core.cropping.fit_dish on each synthetic photo, then grown when needed so every true
colony lies inside it.
Real window: a square of WINDOW_SIDE[role] x the dish radius, inside the dish, at whichever of five places
(center and four diagonal offsets) holds the most colony-dark pixels. The window is the plate's photo
and its whole frame is the region, so participants and the expert measure the same part of the plate.
Tutorial target: a group of three touching colonies on the practice plate that the automatic
detection at the guide's tuned settings (tuned_detection) leaves merged. Among those, the one
nearest the plate center. The tutorial asks the participant to measure it as three colonies.
Concept figures: the triple and the pair of the practice plate with the deepest contact (never the
target), and a mid-sized isolated colony. Outlines are drawn from the truth labels, smoothed when zoomed.
"""

import argparse
import csv
import json
import os
import shutil
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter
from scipy import ndimage

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from quantacolony.core.cropping import fit_dish                                    # noqa: E402
from quantacolony.study.model import (BundlePlate, Concept, Target, manifest,  # noqa: E402
                                      target_resolved)

BUNDLE_VERSION = 3
REAL = {"medium": "study_05", "hard": "study_06"}
ORDER = ("study_04", "study_05", "study_03", "study_06")   # easy to hard; every participant, this order
ZOOM = 6                                    # concept figures: photo pixels to figure pixels
WINDOW_SIDE = {"medium": 0.6, "hard": 0.59}    # square side / dish radius
WINDOW_OFFSET = 0.35                        # candidate offsets from the dish center / radius
GREEN, RED = (60, 230, 60), (240, 60, 60)


# =====================================================================================
# MODEL
# =====================================================================================

def read_truth(path):
    with open(path) as f:
        return list(csv.DictReader(f))


def groups_of(rows, size):
    """{group id: [colony ids]} for groups of the given size."""
    found = {}
    for r in rows:
        if int(r["group_size"]) == size:
            found.setdefault(int(r["group_id"]), []).append(int(r["colony_id"]))
    return found


def dish_covering(image, centers, radii):
    """fit_dish, grown so every colony lies inside with a 1% margin."""
    cx, cy, r = fit_dish(image)
    if len(radii):
        reach = np.hypot(centers[:, 0] - cx, centers[:, 1] - cy) + radii
        r = max(r, float(reach.max()) * 1.01)
    return float(cx), float(cy), float(r)


def darkest_window(image, dish, fraction):
    """(x0, y0, side) of the window (side = fraction x radius) with the most colony-dark pixels among
    five places inside the dish."""
    cx, cy, r = dish
    side = int(fraction * r)
    gray = image[..., :3].mean(axis=2)
    yy, xx = np.mgrid[:gray.shape[0], :gray.shape[1]]
    inside = np.hypot(xx - cx, yy - cy) < r * 0.95
    dark = (gray < np.percentile(gray[inside], 25)) & inside
    best = None
    for dx, dy in ((0, 0), (1, 1), (1, -1), (-1, 1), (-1, -1)):
        x0 = int(cx + dx * WINDOW_OFFSET * r / np.sqrt(2) - side / 2)
        y0 = int(cy + dy * WINDOW_OFFSET * r / np.sqrt(2) - side / 2)
        score = dark[y0:y0 + side, x0:x0 + side].sum()
        if best is None or score > best[0]:
            best = (score, x0, y0)
    return best[1], best[2], side


def read_objects(path):
    return json.loads(Path(path).read_text())


REGION_THRESHOLD = 0.60          # the region step's threshold on the brighter side (guide text)
DOTS = 4                         # pale colonies the region step dots


def tuned_detection(photo, dish, level=0.41, roi=None):
    """The practice plate's colonies at the guide's tuned settings (threshold 0.41, Max radius 19,
    sensitivity 0.9, splitting on: where the settings steps leave a participant), photo pixels."""
    from quantacolony.core.autoparams import maxpix_for
    from quantacolony.core.detection import perform_detection
    from quantacolony.core.params import DetectionParams
    cx, cy, r = dish
    yy, xx = np.mgrid[:photo.shape[0], :photo.shape[1]]
    params = DetectionParams(level=level, sense=0.9, rmin=3, rmax=19, maxpix=maxpix_for(19),
                             detection_type="Irregular", split=True)
    return perform_detection(photo, params, roi=roi, region_mask=np.hypot(xx - cx, yy - cy) < r)


def dotted_colonies(photo, dish, labels, rows, bright, outlined):
    """The region step's dots: DOTS colonies on the brighter side that the tuned detection misses and a
    region at REGION_THRESHOLD finds, nearest the side's center."""
    bx, by, br = bright
    found = outlined_ids(tuned_detection(photo, dish, REGION_THRESHOLD, (bx - br, by - br, 2 * br, 2 * br)), labels)
    pale = [r for r in rows if int(r["colony_id"]) in found and int(r["colony_id"]) not in outlined
            and np.hypot(float(r["x_px"]) - bx, float(r["y_px"]) - by) < br]
    pale.sort(key=lambda r: np.hypot(float(r["x_px"]) - bx, float(r["y_px"]) - by))
    return tuple(int(r["colony_id"]) for r in pale[:DOTS])


def outlined_ids(found, labels):
    """Colony ids under the centers of a set of detections."""
    owners = set()
    for x, y in found.centers:
        owners.add(int(labels[min(int(round(y)), labels.shape[0] - 1), min(int(round(x)), labels.shape[1] - 1)]))
    return owners


def practice_marks(labels, rows, objects, target, outlined=frozenset(), dots=()):
    """The guide's rings on the practice plate (photo pixels). outlined: colonies the tuned detection finds;
    the ringed faint colony is one it misses."""
    marks = {"triple": target}
    for obj in objects["objects"]:
        if obj["kind"] in ("marker", "condensation") and obj["kind"] not in marks:
            marks[obj["kind"]] = Target((), tuple(obj["center"]), float(obj["radius"]) + 6)
    bx, by, br = objects["marks"]["bright"]
    marks["bright"] = Target(tuple(dots), (bx, by), br)
    h, w = labels.shape
    faint = [i for i in objects["marks"]["faint"] if i not in outlined] or objects["marks"]["faint"]
    centers = {int(r["colony_id"]): (float(r["x_px"]), float(r["y_px"])) for r in rows}
    near = min(faint, key=lambda i: np.hypot(centers[i][0] - w / 2, centers[i][1] - h / 2))
    marks["faint"] = Target((near,), mass_circle(labels, [near])[:2], mass_circle(labels, [near])[2] + 6)
    i = int(objects["marks"]["snap"][0])            # a large dark colony beyond the tuned Max radius
    marks["snap"] = Target((i,), mass_circle(labels, [i])[:2], mass_circle(labels, [i])[2] + 6)
    clump = objects["marks"]["clump"]
    marks["clump"] = Target(tuple(clump), mass_circle(labels, clump)[:2], mass_circle(labels, clump)[2] + 4)
    return marks


def mass_circle(labels, ids):
    ys, xs = np.nonzero(np.isin(labels, ids))
    cx, cy = xs.mean(), ys.mean()
    return float(cx), float(cy), float(np.hypot(xs - cx, ys - cy).max() + 3)


def choose_target(colonies, labels, rows):
    """The merged triple nearest the plate center (None when the detection merges no triple)."""
    h, w = labels.shape
    merged = []
    for ids in groups_of(rows, 3).values():
        cx, cy, r = mass_circle(labels, ids)
        target = Target(tuple(ids), (cx, cy), r)
        if not target_resolved(colonies, labels, target):
            merged.append((np.hypot(cx - w / 2, cy - h / 2), target))
    return min(merged, key=lambda m: m[0])[1] if merged else None


# =====================================================================================
# VIEW
# =====================================================================================

def outline(mask):
    return mask & ~ndimage.binary_erosion(mask, iterations=2)


def panel(photo, box, masks_colors):
    """A zoomed crop of the photo with outlines drawn (masks in photo pixels)."""
    x0, y0, x1, y1 = box
    crop = Image.fromarray(photo[y0:y1, x0:x1]).resize(((x1 - x0) * ZOOM, (y1 - y0) * ZOOM), Image.BICUBIC)
    out = np.asarray(crop).copy()
    for mask, color in masks_colors:
        small = Image.fromarray((mask[y0:y1, x0:x1] * 255).astype(np.uint8))
        big = np.asarray(small.resize(crop.size, Image.BICUBIC).filter(ImageFilter.GaussianBlur(ZOOM / 2))) > 127
        out[outline(big)] = color
    return out


def concept_figure(photo, labels, ids, path, kind, mask=None):
    """Three panels: the photo, a wrong outline, the right outlines.
    kind 'mass': one outline around the mass (wrong), one per colony (right).
    kind 'edge': an outline inside the faded margin (wrong), on the outer edge (right).
    kind 'skip': one outline around an inseparable mass (wrong), no outline (right).
    kind 'object': outlines on an object that is not a colony (mask; wrong), no outline (right)."""
    if kind == "object":
        ys, xs = np.nonzero(mask)
        cx, cy = xs.mean(), ys.mean()
        r = float(np.hypot(xs - cx, ys - cy).max() + 3)
        labels = np.where(mask, 1, 0)
        ids = [1]
    else:
        cx, cy, r = mass_circle(labels, ids)
    pad = int(r * 1.3) + 4
    box = (max(0, int(cx) - pad), max(0, int(cy) - pad), min(labels.shape[1], int(cx) + pad),
           min(labels.shape[0], int(cy) + pad))
    union = np.isin(labels, ids)
    if kind in ("mass", "skip", "object"):
        wrong = [(union, RED)] if kind != "object" else [(ndimage.binary_dilation(union, iterations=2), RED)]
    else:
        wrong = [(ndimage.binary_erosion(labels == i, iterations=max(2, int(r * 0.25))), RED) for i in ids]
    right = [] if kind in ("skip", "object") else [(labels == i, GREEN) for i in ids]
    panels = [panel(photo, box, []), panel(photo, box, wrong), panel(photo, box, right)]
    gap = np.full((panels[0].shape[0], 16, 3), 255, np.uint8)
    Image.fromarray(np.hstack([panels[0], gap, panels[1], gap, panels[2]])).save(path)


def write_saved_measurements(path, plate, window):
    """The saved colonies whose centers lie in the window, in window pixels."""
    x0, y0, side = window
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["x_px", "y_px", "radius_px"])
        for (x, y), r in zip(plate["centers"], plate["radii_px"]):
            if x0 <= x < x0 + side and y0 <= y < y0 + side:
                writer.writerow([round(float(x - x0), 3), round(float(y - y0), 3), round(float(r), 4)])


# =====================================================================================
# CONTROLLER
# =====================================================================================

def main():
    parser = argparse.ArgumentParser(description="Build the user study's bundle of plates.")
    parser.add_argument("--study-set", required=True)
    parser.add_argument("--generator", required=True, help="folder with synthetic_plates.py and combined.mat")
    parser.add_argument("--medium", required=True, help="real plate file name in combined.mat, part 3")
    parser.add_argument("--hard", required=True, help="real plate file name in combined.mat, part 3")
    parser.add_argument("--out", default=str(ROOT / "quantacolony" / "study" / "bundle"))
    args = parser.parse_args()
    study, out = Path(args.study_set), Path(args.out)
    if out.exists():
        shutil.rmtree(out)
    (out / "photos").mkdir(parents=True)
    (out / "concepts").mkdir()

    print("1/5  Synthetic plates")
    record = json.loads((study / "truth" / "run_record.json").read_text())
    plates = []
    for p in record["plates"]:
        name = p["file"]
        image = np.asarray(Image.open(study / "photos" / f"{name}.png").convert("RGB"))
        rows = read_truth(study / "truth" / f"{name}_truth.csv")
        centers = np.array([[float(r["x_px"]), float(r["y_px"])] for r in rows])
        radii = np.array([float(r["true_radius_px"]) for r in rows])
        Image.fromarray(image).save(out / "photos" / f"{name}.png")
        dish = None if p.get("window") else dish_covering(image, centers, radii)   # a region: the whole photo
        plates.append(BundlePlate(name, f"{name}.png", p["role"], float(p["pixels_per_mm"]), dish))
        print(f"     {name}: {'region of a dish' if dish is None else 'dish ' + str(tuple(round(v, 1) for v in dish))}")

    print("2/5  Real plates")
    sys.path.insert(0, os.path.abspath(args.generator))
    import synthetic_plates as sp
    settings = sp.Settings(source=os.path.join(args.generator, "combined.mat"))
    real = {p["name"]: p for p in sp.load_real_plates(settings, settings.dataset)}
    key_rows = []
    for role, source in (("medium", args.medium), ("hard", args.hard)):
        p, name = real[source], REAL[role]
        image = np.ascontiguousarray(np.asarray(p["image"], np.uint8))
        dish = dish_covering(image, np.asarray(p["centers"]), np.asarray(p["radii_px"]))
        x0, y0, side = darkest_window(image, dish, WINDOW_SIDE[role])
        Image.fromarray(image[y0:y0 + side, x0:x0 + side]).save(out / "photos" / f"{name}.png")
        plates.append(BundlePlate(name, f"{name}.png", "scored", float(p["pixels_per_mm"]), None))
        write_saved_measurements(study / "truth" / f"{name}_saved_measurements.csv", p, (x0, y0, side))
        key_rows.append([name, "scored", f"real ({role})", len(p["radii_px"]), "", "",
                         f"combined.mat/part3/{source} window x{x0} y{y0} side {side}"])
        print(f"     {name}: {source}, window at ({x0}, {y0}), side {side} px")
    with open(study / "truth" / "key.csv") as f:
        existing = [line for line in f.read().splitlines() if line and not line.startswith(tuple(REAL.values()))]
    with open(study / "truth" / "key.csv", "w") as f:
        f.write("\n".join(existing + [",".join(map(str, r)) for r in key_rows]) + "\n")

    print("3/5  Practice labels and the tutorial target")
    for part in ("labels.png", "truth.csv", "artifacts.png"):
        shutil.copy(study / "truth" / f"practice_{part}", out / f"practice_{part}")
    objects = read_objects(study / "truth" / "practice_artifacts.json")
    plates.sort(key=lambda p: (p.role != "practice", p.name))
    for p in plates:
        if p.role == "scored" and p.name not in ORDER:
            (out / "photos" / p.file).unlink()
    plates = [p for p in plates if p.role == "practice"] + [next(p for p in plates if p.name == n) for n in ORDER]
    (out / "manifest.json").write_text(json.dumps(manifest(BUNDLE_VERSION, plates, None, [], order=ORDER), indent=2))
    labels = np.asarray(Image.open(out / "practice_labels.png")).astype(int)
    rows = read_truth(study / "truth" / "practice_truth.csv")
    practice_photo = np.asarray(Image.open(out / "photos" / "practice.png").convert("RGB"))
    tuned = tuned_detection(practice_photo, next(p for p in plates if p.role == "practice").dish)
    target = choose_target(tuned, labels, rows)
    if target is None:
        raise SystemExit("The automatic detection merges no triple on the practice plate; draw another practice plate.")
    print(f"     target: colonies {target.colony_ids} at ({target.center[0]:.0f}, {target.center[1]:.0f})")

    print("4/5  Concept figures")
    photo = np.asarray(Image.open(out / "photos" / "practice.png").convert("RGB"))
    triples = [ids for ids in groups_of(rows, 3).values() if set(ids) != set(target.colony_ids)]
    pairs = list(groups_of(rows, 2).values())
    singles = sorted((int(r["colony_id"]) for r in rows if int(r["group_size"]) == 1
                      and int(r["colony_id"]) not in objects["marks"]["faint"] + objects["marks"]["snap"]),
                     key=lambda i: -np.sum(labels == i))
    overlap = {int(r["colony_id"]): float(r["contact_overlap"] or 0) for r in rows}

    def deepest(groups):
        return max(groups, key=lambda ids: sum(overlap[i] for i in ids))

    outlined = outlined_ids(tuned, labels)
    dots = dotted_colonies(practice_photo, next(p for p in plates if p.role == "practice").dish, labels, rows,
                           objects["marks"]["bright"], outlined)
    if len(dots) < DOTS:
        raise SystemExit(f"Only {len(dots)} pale colonies for the region step; draw another practice plate.")
    marks = practice_marks(labels, rows, objects, target, outlined, dots)
    print(f"     region dots: colonies {dots}")
    concepts = [Concept("mass_three.png", "A mass of three touching colonies",
                        "Measure three colonies, each with its own outline. One outline around the whole mass "
                        "counts one colony of the wrong size."),
                Concept("mass_two.png", "Two touching colonies",
                        "Two colonies, two outlines, even where they overlap deeply."),
                Concept("edge.png", "Where the edge is",
                        "A colony's outline follows its outer edge, including the pale margin around the dark "
                        "center."),
                Concept("clump.png", "A mass you cannot separate",
                        "A mass of five or more colonies that you cannot tell apart is skipped: no outline. "
                        "One outline around it counts as a wrong outline."),
                Concept("objects.png", "Objects that are not colonies",
                        "Plate numbers written in marker, bubbles, condensation, dust and shadows at the dish "
                        "edge are not colonies. Delete any outline on them.")]
    concept_figure(photo, labels, deepest(triples), out / "concepts" / concepts[0].file, "mass")
    concept_figure(photo, labels, deepest(pairs), out / "concepts" / concepts[1].file, "mass")
    concept_figure(photo, labels, [singles[len(singles) // 4]], out / "concepts" / concepts[2].file, "edge")
    concept_figure(photo, labels, list(marks["clump"].colony_ids), out / "concepts" / concepts[3].file, "skip")
    kinds = np.asarray(Image.open(out / "practice_artifacts.png"))
    marker = ndimage.binary_opening(kinds == 1)
    concept_figure(photo, labels, [], out / "concepts" / concepts[4].file, "object", mask=marker)

    print("5/5  Manifest")
    (out / "manifest.json").write_text(json.dumps(manifest(BUNDLE_VERSION, plates, target, concepts, marks, order=ORDER),
                                                  indent=2))
    print(f"     marks: {', '.join(marks)}")
    print(f"     {out}")


if __name__ == "__main__":
    main()
