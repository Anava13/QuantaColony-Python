# QuantaColony user study

The study measures whether Colony Detection gives the same measurements in different hands. Each
participant fills in a short form, reads what to measure, practices on a guided plate, then measures
six plates in a random order: four synthetic plates with known truth and two real plates. The program
records every action with its time. At the end it saves one zip file on the participant's Desktop.

## Plates

| File | Plate | Reference |
|---|---|---|
| practice | Synthetic, narrow, 100 colonies, 55% touching | not scored |
| study_01 | Synthetic two-peak, 150 colonies (publication plate_008) | truth |
| study_02 | Synthetic wide, 400 colonies, 64% touching | truth |
| study_03 | Synthetic two-peak, 400 colonies, 60% touching | truth |
| study_04 | Synthetic narrow, 60 colonies (publication plate_006) | truth |
| study_05 | Real sparse: Wild_Type_P1_6Days_Low_RepB | expert run |
| study_06 | Real crowded: Dbf4_1_P4V2_6Days_High_RepA | expert run |

`study_set/truth/key.csv` holds the same mapping. Participants see the plates as Plate 1 to Plate 6, so
a file name never shows whether a plate is synthetic.

## Steps

1. **Expert run (also the pilot).** Run the study yourself before sending it to anyone, without
   opening the truth overlays of the study plates. Fix anything that breaks or reads unclearly, then
   repeat your run on the fixed version.
2. **Freeze the version.** Every participant uses the same build. Each zip records the software,
   study and bundle versions.
3. **Send** this folder to participants. They double-click `Start QuantaColony Study.bat` (Windows)
   or `Start QuantaColony Study.command` (macOS). Both need uv, and the launchers explain how to get it.
4. **Collect** the zip files. Each holds `<name>.qcproj` and `participant.json`: the answers, the plate
   order and its seed, the stage times and any tutorial steps skipped.
5. **Build the full truth** from your own zip:

       uv run python tools/study/expert_reference.py --expert "<your zip>" \
           --truth study_set/truth --out study_truth

6. **Score** each participant's project with `score_quantacolony.py --truth study_truth`. Its
   `automatic` set is the last whole-plate detection, after any settings changes. The detection made
   before the participant did anything is in the project's `dev_initial_colonies` table. The timing
   tables are the same as in Synthetic.qcproj (`dev_detection_sessions`, `dev_detection_events`).

## Rebuilding the plates

`build_bundle.py` writes `quantacolony/study/bundle` from the study set and combined.mat. It fits each
dish circle, chooses the practice plate's tutorial mass, and draws the concept figures:

    uv run python tools/study/build_bundle.py --study-set study_set --generator "Scoring QC" \
        --sparse Wild_Type_P1_6Days_Low_RepB.JPG --crowded Dbf4_1_P4V2_6Days_High_RepA.JPG

Raise `BUNDLE_VERSION` in it whenever the plates change, and `STUDY_VERSION` in
`quantacolony/study/model.py` whenever the tutorial or the questions change.
