#!/bin/sh
# Starts the QuantaColony user study on macOS or Linux. The first start downloads Python and the
# libraries (a few minutes). The results file is saved on the Desktop at the end.
cd "$(dirname "$0")" || exit 1
if ! command -v uv >/dev/null 2>&1; then
    echo "uv is not installed. In Terminal, run:"
    echo "  curl -LsSf https://astral.sh/uv/install.sh | sh"
    echo "Then open a new Terminal and double-click this file again."
    read -r _
    exit 1
fi
echo "Starting the QuantaColony study (the first start takes a few minutes)..."
uv run --frozen --no-dev quantacolony-study
