@echo off
rem Starts the QuantaColony user study. The first start downloads Python and the libraries (a few minutes).
rem The results file is saved on the Desktop at the end; send it back to the person who gave you the study.
cd /d "%~dp0"
where uv >nul 2>nul
if errorlevel 1 goto no_uv
echo Starting the QuantaColony study (the first start takes a few minutes)...
uv run --frozen --no-dev quantacolony-study || goto failed
exit /b 0

:no_uv
echo uv is not installed. Open PowerShell and run:
echo   powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
echo Then close PowerShell and double-click this file again.
pause
exit /b 1

:failed
echo.
echo The study did not start; the messages above say why.
pause
exit /b 1
