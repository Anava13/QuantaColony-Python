"""Within-group predictors of colony size: does a plate-level value predict median colony size
once the group is fixed?

The chosen Measure is the predictor. The response is each plate's median colony radius. Both
are centered within every level of the Fixed-within slot, removing the between-level trend, so
the remaining slope is the within-group relationship: a plate with more colonies than its
group's average against a median radius above or below its group's average. Groups with one
plate drop out (nothing to center against).
"""

from __future__ import annotations

import numpy as np

from ..api import INDEX, NOMINAL, ORDINAL, REPLICATE, Analysis, Option, Slot
from ..common import show_message, style_axes

RESPONSE = "median_radius_um"
LOG_MEASURES = ("colony_count",)                  # predictors whose Auto transform is log


def fit_line(x: np.ndarray, y: np.ndarray) -> dict:
    """OLS slope, intercept and r² ({} when the fit is undetermined)."""
    if len(x) < 3 or np.ptp(x) == 0:
        return {}
    slope, intercept = np.polyfit(x, y, 1)
    predicted = slope * x + intercept
    total = float(np.sum((y - y.mean()) ** 2))
    r2 = 1.0 - float(np.sum((y - predicted) ** 2)) / total if total > 0 else np.nan
    return {"slope": float(slope), "intercept": float(intercept), "r2": r2}


class WithinGroupPredictor(Analysis):
    id = "within_group_predictor"
    name = "Within-group predictor of size"
    group = "Plates"
    unit = INDEX
    description = ("The chosen measure against median colony radius, both centered within every "
                   "Fixed-within level. The slope that remains is the within-group relationship, "
                   "free of the between-group trend.")
    slots = (Slot("groups", "Fixed within", (NOMINAL, ORDINAL, REPLICATE), min_variables=1,
                  description="The relationship is measured inside each level (for example "
                              "Genotype · Passage); the trend between levels is removed."),)
    options = (Option("x_scale", "Predictor scale",
                      (("auto", "Auto"), ("log", "Log"), ("linear", "Linear")), "auto"),)
    color_slots = ("groups",)

    def problem(self, data):
        if data.measure == RESPONSE:
            return ("Median colony radius is the response. Choose another measure as the predictor "
                    "(colony count, a coverage, or a numeric annotation).")
        if data.extra_measures is None or RESPONSE not in data.extra_measures:
            return "No per-plate median radius is available yet."
        return ""

    def title(self, data, options):
        within = data.axes["groups"].title or "group"
        return f"{data.value_label.split(' (')[0]} and median radius within {within}"

    def _transforms(self, data, options) -> tuple[str, str]:
        choice = options.get("x_scale", "auto")
        if choice == "auto":
            choice = "log" if data.measure in LOG_MEASURES or data.measure.startswith("annotation:") else "linear"
        return choice, "log"

    def compute(self, data, options):
        x_mode, y_mode = self._transforms(data, options)
        x = np.asarray(data.values, dtype=float)
        y = np.asarray(data.extra_measures[RESPONSE], dtype=float)
        blocks = data.positions["groups"]
        ok = np.isfinite(x) & np.isfinite(y) & (blocks >= 0)
        if x_mode == "log":
            ok &= x > 0
        ok &= y > 0
        x = np.where(ok, x, np.nan)
        tx = np.log10(x) if x_mode == "log" else x
        ty = np.log10(np.where(ok, y, np.nan))
        dx, dy = np.full_like(tx, np.nan), np.full_like(ty, np.nan)
        used_groups = 0
        for block in range(len(data.axes["groups"])):
            rows = ok & (blocks == block)
            if rows.sum() < 2:                                        # one plate cannot be centered
                continue
            dx[rows] = tx[rows] - np.nanmean(tx[rows])
            dy[rows] = ty[rows] - np.nanmean(ty[rows])
            used_groups += 1
        keep = np.isfinite(dx) & np.isfinite(dy)
        fit = fit_line(dx[keep], dy[keep])
        points = [{"index_id": int(data.index_ids[i]), "group": int(blocks[i]),
                   "label": data.axes["groups"].labels[blocks[i]],
                   "x": float(x[i]), "y": float(y[i]), "dx": float(dx[i]), "dy": float(dy[i])}
                  for i in np.flatnonzero(keep)]
        return {"title": self.title(data, options), "data": data, "points": points, "fit": fit,
                "x_mode": x_mode, "n": int(keep.sum()), "groups": used_groups,
                "skipped": int(ok.sum() - keep.sum())}

    def draw(self, figure, result, style):
        figure.clear()
        data, points = result["data"], result["points"]
        if not points:
            show_message(figure, "No group holds two or more plates with both values.", style)
            return None
        ax = figure.add_axes((0.1, 0.12, 0.64, 0.78))
        style_axes(ax, style)
        drawn = set()
        for p in points:
            color = style.color_for(data, groups=p["group"]) or style.group_color(p["group"])
            label = (p["label"] or "All plates") if p["group"] not in drawn else None
            drawn.add(p["group"])
            ax.scatter(p["dx"], p["dy"], s=30, color=color, edgecolor=style.ink, linewidth=0.4,
                       alpha=0.85, label=label, zorder=3)
        fit = result["fit"]
        if fit:
            xs = np.array([min(p["dx"] for p in points), max(p["dx"] for p in points)])
            ax.plot(xs, fit["slope"] * xs + fit["intercept"], color=style.ink, linewidth=1.8, zorder=2)
            ax.text(0.03, 0.97, f"slope {fit['slope']:.3f}\nr² {fit['r2']:.3f}\n{result['n']} plates in "
                    f"{result['groups']} groups", transform=ax.transAxes, va="top", ha="left",
                    fontsize=style.font_size, color=style.ink,
                    bbox={"facecolor": style.background, "edgecolor": style.spine,
                          "boxstyle": "round,pad=0.35", "alpha": 0.92})
        ax.axhline(0, color=style.grid, linewidth=1)
        ax.axvline(0, color=style.grid, linewidth=1)
        x_unit = "log10" if result["x_mode"] == "log" else "linear"
        predictor = data.value_label.split(" (")[0]
        ax.set_xlabel(f"{predictor}, centered within group ({x_unit})", color=style.ink)
        ax.set_ylabel("Median colony radius, centered within group (log10)", color=style.ink)
        if len(drawn) > 1:
            ax.legend(loc="upper left", bbox_to_anchor=(1.02, 1.0), frameon=False, fontsize=8,
                      title=data.axes["groups"].title or None, title_fontsize=9)
        ax.set_title(result["title"], fontsize=13, fontweight="bold", color=style.ink, loc="left")
        return None

    def table(self, result):
        data = result["data"]
        group_title = data.axes["groups"].title or "Group"
        predictor = data.value_label
        return [{group_title: p["label"], "plate": p["index_id"], predictor: p["x"],
                 "median radius (µm)": p["y"], "centered predictor": p["dx"],
                 "centered log10 median radius": p["dy"]} for p in result["points"]]

    def notes(self, result):
        fit = result["fit"]
        lines = []
        if fit:
            lines.append(f"Within-group slope {fit['slope']:.3f} (r² {fit['r2']:.3f}) over {result['n']} "
                         f"plates in {result['groups']} groups.")
        if result["skipped"]:
            lines.append(f"{result['skipped']} plates sit alone in their group and are left out: one "
                         "plate cannot be centered.")
        return list(result["data"].notes) + lines


ANALYSES = [WithinGroupPredictor()]
