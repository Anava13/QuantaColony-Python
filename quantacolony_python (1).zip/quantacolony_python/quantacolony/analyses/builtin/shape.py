"""Shape classifier: can a plate's colony-size shape alone tell one class from another?

Each plate with at least MIN_COLONIES colonies becomes one point in (coefficient of variation,
skew) space. Both features are standardized across every drawn plate. Two Classes levels each get a
centroid: the Target (the class being identified, for example dbf4-1) and the Reference (for example
Wild type). Left on their first choices, the reference is the first shown level and the target the
second. The boundary is the line of points equally far from both centroids. Every plate, of any
class, is assigned to the target or not by the nearer centroid. Accuracy is reported over every drawn plate and over the two classes alone, each
against its baseline (always guessing the larger side).
"""

from __future__ import annotations

import numpy as np

from ...core.stats import summary_values
from ..api import NOMINAL, ORDINAL, REPLICATE, Analysis, Option, Slot, level_value
from ..common import show_message, style_axes

MIN_COLONIES = 10                                 # plates with fewer colonies are left out


class ShapeClassifier(Analysis):
    id = "shape_classifier"
    name = "Shape classifier"
    group = "Per-plate shape"
    description = ("Every plate in (CV, skew) space. The Target and Reference levels of Classes each get a "
                   "centroid; the dashed boundary lies equally far from both, in features standardized across "
                   "all plates. Each plate is assigned to the target or not; accuracy is shown against the "
                   "baseline.")
    slots = (Slot("classes", "Classes", (NOMINAL, ORDINAL, REPLICATE), min_variables=1,
                  description="Two levels are compared (Target and Reference); every level is drawn and classified."),)
    options = (Option("target", "Target", (("auto", "Second shown level"),), "auto", levels_of="classes"),
               Option("reference", "Reference", (("auto", "First shown level"),), "auto", levels_of="classes"))
    color_slots = ("classes",)

    @staticmethod
    def _pick(data, options) -> tuple[int, int, str]:
        """(target position, reference position, problem) on the shown Classes levels."""
        keys = [level_value(k) for k in data.axes["classes"].keys]
        labels = data.axes["classes"].labels
        wanted = {}
        for name in ("target", "reference"):
            value = options.get(name, "auto")
            if value != "auto" and value not in keys:
                return -1, -1, f"The {name} level is switched off under Plates used."
            wanted[name] = keys.index(value) if value != "auto" else None
        target, reference = wanted["target"], wanted["reference"]
        n = len(keys)
        if reference is None:                                  # the first shown level, unless it is the target
            reference = 0 if target != 0 else (1 if n > 1 else -1)
        if target is None:                                     # the second shown level, unless it is the reference
            target = next((i for i in range(1, n) if i != reference), 0 if reference != 0 else -1)
        if target < 0 or reference < 0 or target == reference:
            return -1, -1, "Choose two different levels for Target and Reference."
        return target, reference, f"{labels[target]} against {labels[reference]}"

    def compute(self, data, options):
        plates = []
        for index_id in sorted({int(i) for i in data.index_ids}):
            keep = (data.index_ids == index_id) & np.isfinite(data.values)
            classes = data.positions["classes"][keep]
            if keep.sum() < MIN_COLONIES or len(set(classes.tolist())) != 1 or classes[0] < 0:
                continue
            stats = summary_values(data.values[keep])
            plates.append({"index_id": index_id, "class": int(classes[0]), "n": int(keep.sum()),
                           "cv": stats["Coefficient Of Variation"], "skew": stats["Skew"]})
        target, reference, problem = self._pick(data, options)
        present = {p["class"] for p in plates}
        if target < 0 or target not in present or reference not in present:
            missing = problem if target < 0 else "Target and Reference each need plates with 10 or more colonies."
            return {"plates": plates, "data": data, "problem": missing}
        cv = np.array([p["cv"] for p in plates])
        skew = np.array([p["skew"] for p in plates])
        center, scale = np.array([cv.mean(), skew.mean()]), np.array([cv.std() or 1.0, skew.std() or 1.0])
        z = (np.column_stack([cv, skew]) - center) / scale
        labels = np.array([p["class"] for p in plates])
        first, second = z[labels == reference].mean(axis=0), z[labels == target].mean(axis=0)
        for i, p in enumerate(plates):
            p["assigned"] = bool(np.linalg.norm(z[i] - second) < np.linalg.norm(z[i] - first))
            p["correct"] = p["assigned"] == (p["class"] == target)

        def score(rows):
            truth = sum(1 for p in rows if p["class"] == target)
            return (sum(p["correct"] for p in rows), len(rows), max(truth, len(rows) - truth) / len(rows))
        pair = [p for p in plates if p["class"] in (reference, target)]
        return {"plates": plates, "data": data, "all": score(plates), "pair": score(pair),
                "centroids": [tuple(first * scale + center), tuple(second * scale + center)],
                "classes": (reference, target), "center": center, "scale": scale}

    def draw(self, figure, result, style):
        figure.clear()
        data, plates = result["data"], result["plates"]
        if "all" not in result:
            show_message(figure, result.get("problem", "Nothing to classify."), style)
            return None
        ax = figure.add_axes((0.1, 0.12, 0.62, 0.76))
        style_axes(ax, style)
        labels = data.axes["classes"].labels
        drawn = set()
        for p in plates:
            color = style.color_for(data, classes=p["class"]) or style.group_color(p["class"])
            ax.scatter(p["cv"], p["skew"], s=30, color=color, marker="o" if p["class"] < 2 else "s",
                       edgecolor=style.ink, linewidth=0.3, alpha=0.85, zorder=3,
                       label=labels[p["class"]] if p["class"] not in drawn else None)
            drawn.add(p["class"])
        reference, target = result["classes"]
        for k, (x, y) in zip((reference, target), result["centroids"]):
            color = style.color_for(data, classes=k) or style.group_color(k)
            ax.scatter(x, y, s=220, marker="*", color=color, edgecolor=style.ink, linewidth=1.0, zorder=5,
                       label=f"centroid, {labels[k]}")
        (a, b), center, scale = [np.array(c) for c in result["centroids"]], result["center"], result["scale"]
        za, zb = (a - center) / scale, (b - center) / scale
        midpoint, normal = (za + zb) / 2, zb - za
        xs = np.linspace(*ax.get_xlim(), 50)
        if abs(normal[1]) > 1e-12:                                 # boundary: normal . (z - midpoint) = 0
            zx = (xs - center[0]) / scale[0]
            zy = midpoint[1] - normal[0] * (zx - midpoint[0]) / normal[1]
            ax.plot(xs, zy * scale[1] + center[1], color=style.ink, linestyle="--", linewidth=1.2, label="boundary")
        correct, total, baseline = result["all"]
        pc, pt, pb = result["pair"]
        ax.text(0.03, 0.97, f"all plates {correct}/{total} = {correct / total:.1%} (baseline {baseline:.1%})\n"
                            f"{labels[reference]} and {labels[target]} {pc}/{pt} = {pc / pt:.1%} (baseline {pb:.1%})",
                transform=ax.transAxes, va="top", fontsize=style.font_size - 1, color=style.ink,
                bbox={"facecolor": style.background, "edgecolor": style.spine, "boxstyle": "round,pad=0.35"})
        ax.set_xlabel("CV of colony radius", color=style.ink)
        ax.set_ylabel("Skew of colony radius", color=style.ink)
        ax.legend(loc="upper left", bbox_to_anchor=(1.02, 1.0), frameon=False, fontsize=9,
                  title=data.axes["classes"].title or None, title_fontsize=9)
        ax.set_title(f"{labels[target]} classifier", fontsize=12, fontweight="bold", color=style.ink, loc="left")
        return None

    def table(self, result):
        labels = result["data"].axes["classes"].labels
        target = labels[result["classes"][1]] if "classes" in result else "target"
        return [{"plate": p["index_id"], "class": labels[p["class"]], "n": p["n"], "cv": p["cv"], "skew": p["skew"],
                 f"assigned_to_{target}": p.get("assigned", ""), "correct": p.get("correct", "")}
                for p in result["plates"]]

    def notes(self, result):
        if "all" not in result:
            return []
        correct, total, baseline = result["all"]
        pc, pt, pb = result["pair"]
        labels = result["data"].axes["classes"].labels
        reference, target = result["classes"]
        return [f"Target {labels[target]}, reference {labels[reference]}. Accuracy {correct}/{total} "
                f"({correct / total:.1%}, baseline {baseline:.1%}) over every plate with {MIN_COLONIES}+ colonies; "
                f"{pc}/{pt} ({pc / pt:.1%}, baseline {pb:.1%}) over the two classes."]


ANALYSES = [ShapeClassifier()]
