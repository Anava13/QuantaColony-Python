"""Subpopulations: a LogNormal mixture per index (subpopfig), clustered by one slot and ordered by another.

Fits are kept per index while Stats is open: an index's fit depends only on its colony radii,
so changing slots, colors or hidden levels reuses every fit and redraws at once. Only indices
not fit before are fit, in the background (needs_background); the busy message counts them.
A change that alters an index's colonies (leaving split colonies out of sizes) is a new fit,
kept beside the first. With one plate per group on, every used plate is drawn and the chosen
plate of each block and column is the bright one (a column whose group is empty has none);
otherwise subpopfig picks the plate closest to the median colony count. subpopfig draws its own figure; draw() returns it so the window shows
it in place of its own.
"""

from __future__ import annotations

import contextlib
import io

import numpy as np

from ..api import NOMINAL, ORDINAL, REPLICATE, Analysis, Option, Slot

MIN_WEIGHT = 0.01                                 # components lighter than this are left off trajectories


class FitCache:
    """The session's fits, keyed by a digest of fit_key so they can be saved in the project file.

    fit_mixtures uses it like a dict keyed by fit_key tuples; to_json/from_json translate the
    kept fits to and from the form DataManager.save_mixture_fits stores."""

    def __init__(self):
        self._entries: dict[str, tuple] = {}
        self._pending: dict = {}                  # fits saved in the project, read back on first use

    @property
    def entries(self) -> dict:
        """The fits, read back from their saved form the first time a mixture analysis asks (reading them
        loads the fitting library, which takes seconds; Stats opens without it)."""
        if self._pending:
            from ...stats.subpopfig.fitting import fit_from_json
            pending, self._pending = self._pending, {}
            for digest, value in pending.items():
                try:
                    self._entries.setdefault(str(digest), fit_from_json(value))
                except (KeyError, TypeError, ValueError):
                    continue                          # a fit that does not read back is simply refit
        return self._entries

    @staticmethod
    def digest(key) -> str:
        import hashlib
        config, size, raw = key
        return hashlib.sha256((repr(config) + str(size)).encode() + raw).hexdigest()

    def __contains__(self, key) -> bool:
        return self.digest(key) in self.entries

    def __getitem__(self, key):
        return self.entries[self.digest(key)]

    def __setitem__(self, key, value) -> None:
        self.entries[self.digest(key)] = value

    def clear(self) -> None:
        self._entries.clear()
        self._pending = {}

    def to_json(self) -> dict:
        saved = {str(k): v for k, v in self._pending.items()}   # still in saved form: kept as they are
        if self._entries:
            from ...stats.subpopfig.fitting import fit_to_json
            saved.update({digest: fit_to_json(search, stats) for digest, (search, stats) in self._entries.items()})
        return saved

    def load_json(self, saved: dict) -> None:
        """Keep the saved fits; they are read back when first used (entries)."""
        for digest, value in (saved or {}).items():
            if str(digest) not in self._entries:
                self._pending[str(digest)] = value


SHARED_FITS = FitCache()                          # fits shared by both analyses below


class Subpopulations(Analysis):
    id = "subpopulations"
    name = "Mixture model"
    group = "Subpopulations"
    description = ("LogNormal mixture per index (subpopfig): the number of subpopulations with the lowest BIC, "
                   "up to four. Each column of circles is one index.")
    slots = (Slot("clusters", "Blocks", (NOMINAL, REPLICATE, ORDINAL),
                  description="Each level gets its own colored block along the bottom (for example Genotype)."),
             Slot("levels", "Columns", (ORDINAL, NOMINAL, REPLICATE),
                  description="Columns inside each block, joined by trajectory lines (for example Passage). "
                              "Every plate of a column is drawn in it."))
    background = True
    marks_selection = True                        # one plate per group: every used plate drawn, the chosen bright

    def __init__(self):
        self.fits = SHARED_FITS                   # fit_key(radii) -> fit, shared for the Stats session

    def reset_cache(self) -> None:
        """Forget every fit (Stats opening)."""
        SHARED_FITS.clear()

    def load_cache(self, saved: dict) -> None:
        """Fits persisted in the project file, so plates fit before are never fit again."""
        SHARED_FITS.load_json(saved)

    def dump_cache(self) -> dict:
        return SHARED_FITS.to_json()

    def _entry_radii(self, data) -> list:
        """Each index's radii, in the order the fit sees them."""
        frame, _ = self.frame(data)
        return [group["radius_um"].to_numpy(dtype=float) for _, group in frame.groupby("entry", sort=False)]

    def missing(self, data) -> int:
        """Indices whose fit is not kept yet."""
        from ...stats.subpopfig import fit_key
        return sum(1 for radii in self._entry_radii(data) if fit_key(radii) not in self.fits)

    def needs_background(self, data) -> bool:
        """Cheap when no fit is kept yet (the common first visit): grouping every colony into
        per-plate radius lists just to learn that everything is missing would stall the
        interface thread, so an empty cache answers immediately."""
        if not SHARED_FITS.entries:
            return True
        return self.missing(data) > 0

    def frame(self, data):
        """One row per colony with the subpopfig roles. EntryID is the index, so one mixture is fit per index.
        Levels become their position (1, 2, ...), with the level text as display."""
        import pandas as pd
        clusters, levels = data.axes["clusters"], data.axes["levels"]
        c_pos, l_pos = data.positions["clusters"], data.positions["levels"]
        keep = (c_pos >= 0) & (l_pos >= 0) & np.isfinite(data.values) & (data.values > 0)
        frame = pd.DataFrame({
            "entry": [f"index {i}" for i in data.index_ids[keep]],
            "nominal": [clusters.labels[c] or "All" for c in c_pos[keep]],
            "ordinal": l_pos[keep] + 1,
            "ordinal_display": [levels.labels[o] or "All" for o in l_pos[keep]],
            "radius_um": data.values[keep],
            "nominal_order": c_pos[keep],
        })
        if data.selected is not None:                # one plate per group chose these; the rest are drawn faded
            frame["selected"] = [int(i) in data.selected for i in data.index_ids[keep]]
        frame = frame.sort_values(["nominal_order", "ordinal"], kind="stable")
        schema = {
            "EntryID": {"column": "entry", "label": "Index"},
            "Nominal": {"column": "nominal", "label": clusters.title or "All"},
            "Ordinal": {"column": "ordinal", "display_column": "ordinal_display", "label": levels.title or "All"},
            "Measurement": {"column": "radius_um",
                            "label": "Radius (px)" if "(px)" in data.value_label else "Radius (µm)"},
        }
        if data.selected is not None:
            schema["Selected"] = {"column": "selected"}
        return frame.drop(columns="nominal_order"), schema

    def compute(self, data, options):
        from ...stats.subpopfig import fit_mixtures, from_dataframe
        frame, schema = self.frame(data)
        printed = io.StringIO()
        with contextlib.redirect_stdout(printed):
            workbook = from_dataframe(frame, schema, source="QuantaColony project")
            fits = fit_mixtures(workbook, cache=self.fits, progress=options.get("_progress"))
        return {"fits": fits, "printed": printed.getvalue()}

    def busy_text(self, data) -> str:
        """Cheap on purpose: it runs on the interface thread before the worker starts, so it
        counts plates without building the fit frame; the progress signal refines it."""
        entries = len(set(data.index_ids[np.isfinite(data.values)].tolist()))
        return f"Preparing LogNormal mixtures for {entries} plates…"

    def draw(self, figure, result, style):
        import matplotlib.pyplot as plt

        from ...stats.subpopfig import plot_subpopulations
        from ...stats.subpopfig.figure import FigureText
        fits = result["fits"]
        width = max(15.0, 0.62 * len(fits.levels.nominal_display) * len(fits.levels.ordinal))
        printed = io.StringIO()
        with contextlib.redirect_stdout(printed):
            text = FigureText(title="Subpopulation Analysis Across Selected Plates", unit_header="Plates",
                              selected="Selected plate", other="Other plates")
            if getattr(style, "print_mode", False):              # a printed page: the text block, print sizes
                import dataclasses
                from ...stats.print_pages import FIGURE_LANDSCAPE
                from ..common import print_heading
                shown = dataclasses.replace(fits, levels=dataclasses.replace(
                    fits.levels, nominal_display=[print_heading(n) for n in fits.levels.nominal_display]))
                drawn = plot_subpopulations(shown, figsize=FIGURE_LANDSCAPE, dpi=100, text=text,
                                            style=self.print_component_style(len(fits.entries)))
            else:
                drawn = plot_subpopulations(fits, figsize=(width, 7.5), dpi=100, text=text)
        plt.close(drawn.figure)                     # keep pyplot from holding every figure drawn
        result["drawn_notes"] = printed.getvalue()
        return drawn.figure

    @staticmethod
    def print_component_style(entries: int):
        """The subpopulation figure's look on a printed page (8.5 in wide, labels at least 7 pt)."""
        from ...stats.print_pages import FIGURE_LANDSCAPE
        from ...stats.subpopfig.figure import ComponentStyle
        width, height = FIGURE_LANDSCAPE
        legend_w, left = 1.1, 1.8
        crowd = min(1.0, 60.0 / max(entries, 1))               # circles shrink as plates crowd the axis
        return ComponentStyle(
            sel_whisker_width=1.1, other_whisker_width=0.7, size_base=2.0, size_scale=34.0 * crowd + 8.0,
            traj_min_width=0.5, traj_max_width=1.8, gutter_frac=0.3,
            axes_position=(left / width, 0.04, (width - left - 0.05) / width, 0.86),
            legend_position=(0.0, 0.04, legend_w / width, 0.86),
            legend_font_size=7.0, legend_header_size=8.5, legend_row_step=0.045, legend_header_gap=0.02,
            legend_glyph_x=0.1, legend_line_x=(0.02, 0.2), legend_text_x=0.25, legend_whisker_half=0.012,
            font_rc={}, show_title=True, title_font_size=10.0, ylabel_font_size=8.0, tick_font_size=7.0,
            ordinal_font_size=7.0, nominal_font_size=7.5, bracket_width=1.0, label_math=True, marker_edge_width=0.35,
            nominal_stagger=True)

    def table(self, result):
        rows = []
        for entry in result["fits"].entries:
            for c in range(entry.n_components):
                rows.append({"index": entry.entry_id, "cluster": entry.nominal_display, "level": entry.ordinal_display,
                             "selected": entry.selected, "k": entry.k, "fit_status": entry.fit_status,
                             "subpopulation": c + 1, "median_um": float(entry.component_medians[c]),
                             "weight": float(entry.component_weights[c]), "p25_um": float(entry.component_p25[c]),
                             "p75_um": float(entry.component_p75[c]), "colonies": int(entry.component_n[c])})
        return rows

    def notes(self, result):
        return [(result["printed"] + result.get("drawn_notes", "")).strip()]


class ComponentLocations(Subpopulations):
    """Where each plate's mixture components sit: median radius against the Columns levels.

    Reuses the Mixture model's fits (one LogNormal mixture per plate). Each component is one
    point: its y is the component's median radius, its size follows the component's share of
    the plate's colonies, and dominant components (the largest share on their plate) are filled
    while minor components are open. A line follows the mean dominant-component median of each
    block across the columns."""

    id = "component_locations"
    name = "Mixture components"
    description = ("Median radius of every mixture component, one point per component per plate, "
                   "across the Columns levels. Point size follows the component's share of the "
                   "plate; dominant components are filled, minor ones open. 'One column per plate' "
                   "draws each plate in its own column with the component quartiles; with one plate "
                   "per group the chosen plates are solid and the others faded.")
    options = (Option("layout", "Layout", (("levels", "Points per column level"), ("plates", "One column per plate")),
                      "levels"),
               Option("trajectory", "Trajectory", (("none", "None"), ("chosen", "Through chosen plates")), "none"),
               Option("reference", "Reference", (("none", "None"), ("first", "First block's chosen plate")), "none"),
               Option("overlap", "Overlap row", (("hide", "Hide"), ("show", "Show")), "hide"))
    marks_selection = True                        # every used plate is drawn; the chosen ones stand out
    color_slots = ("clusters",)

    def compute(self, data, options):
        result = super().compute(data, options)
        result["options"] = dict(options)
        result["chosen_known"] = data.selected is not None
        return result

    def draw(self, figure, result, style):
        if result.get("options", {}).get("layout") == "plates":
            return self._draw_plates(figure, result, style)
        return self._draw_levels(figure, result, style)

    @staticmethod
    def _nodes(entry) -> list[tuple[float, float]]:
        """(median, weight) of each component at or above MIN_WEIGHT, weights renormalized, by median."""
        keep = [(float(m), float(w)) for m, w in zip(entry.component_medians, entry.component_weights) if w >= MIN_WEIGHT]
        total = sum(w for _, w in keep) or 1.0
        return sorted((m, w / total) for m, w in keep)

    @staticmethod
    def mixture_density(entry, grid: np.ndarray) -> np.ndarray:
        """The plate's mixture density over ln radius: each component a normal in ln radius with its median and
        a spread from its quartiles (IQR / 1.349), weighted by its share of the plate."""
        density = np.zeros_like(grid)
        for m, w, q1, q3 in zip(entry.component_medians, entry.component_weights, entry.component_p25,
                                entry.component_p75):
            sigma = max((np.log(max(q3, 1e-9)) - np.log(max(q1, 1e-9))) / 1.349, 0.02)
            density += w * np.exp(-0.5 * ((grid - np.log(m)) / sigma) ** 2) / (sigma * np.sqrt(2 * np.pi))
        return density

    @classmethod
    def overlap(cls, entry, reference) -> float:
        """Shared area of two plates' mixture densities, 0 for none shared to 1 for identical."""
        low = min(np.log(entry.component_p25.min()), np.log(reference.component_p25.min())) - 2
        high = max(np.log(entry.component_p75.max()), np.log(reference.component_p75.max())) + 2
        grid = np.linspace(low, high, 2000)
        shared = np.minimum(cls.mixture_density(entry, grid), cls.mixture_density(reference, grid))
        return float(np.trapezoid(shared, grid) if hasattr(np, "trapezoid") else np.trapz(shared, grid))

    def _draw_plates(self, figure, result, style):
        """One column per plate, grouped by block and column level; chosen plates solid, the rest faded."""
        from matplotlib.lines import Line2D

        from ..common import plain_log_axis, show_message, style_axes
        figure.clear()
        options = result["options"]
        fits = result["fits"]
        entries = [e for e in fits.entries if e.n_components]
        if not entries:
            show_message(figure, "No plate has a mixture fit yet.", style)
            return None
        chosen_known = result.get("chosen_known", False)
        clusters = list(fits.levels.nominal_display)
        ordinals = [float(o) for o in np.asarray(fits.levels.ordinal)]
        ordinal_display = list(fits.levels.ordinal_display)
        overlap_row = options.get("overlap") == "show"
        ax = figure.add_axes((0.08, 0.24 if overlap_row else 0.2, 0.9, 0.66 if overlap_row else 0.7))
        style_axes(ax, style)
        ax.set_yscale("log")
        plain_log_axis(ax.yaxis)
        position, columns, block_marks, level_marks = 0.0, {}, [], []
        for c, cluster in enumerate(clusters):
            start = position
            for o, ordinal in enumerate(ordinals):
                cell = [e for e in entries if e.nominal_display == cluster and float(e.ordinal) == ordinal]
                if not cell:
                    continue
                cell.sort(key=lambda e: (not e.selected if chosen_known else 0, -int(np.sum(e.component_n))))
                level_start = position
                for e in cell:
                    columns[e.entry_id] = (position, c, o)
                    position += 1.0
                level_marks.append(((level_start + position - 1) / 2, ordinal_display[o]))
                position += 0.6
            if position > start:
                block_marks.append(((start + position - 1.6) / 2, cluster, c))
                position += 1.0
        reference = None
        if options.get("reference") == "first" or overlap_row:
            first = [e for e in entries if e.nominal_display == clusters[0] and (e.selected or not chosen_known)]
            reference = first[0] if first else None
        for e in entries:
            x, c, o = columns[e.entry_id]
            color = style.group_color(c)
            solid = e.selected or not chosen_known
            alpha = 1.0 if solid else 0.35
            for m, w, q1, q3 in zip(e.component_medians, e.component_weights, e.component_p25, e.component_p75):
                ax.plot([x, x], [q1, q3], color=color, alpha=alpha * 0.8, linewidth=1.0, zorder=2)
                ax.scatter(x, m, s=20 + 280 * float(w), color=color, alpha=alpha,
                           edgecolor=style.ink if (e.selected and chosen_known) else color,
                           linewidth=1.4 if (e.selected and chosen_known) else 0.6, zorder=3)
        if reference is not None and options.get("reference") == "first":
            for m, _ in self._nodes(reference):
                ax.axhline(m, color=style.group_color(0), linestyle="--", linewidth=1.0, zorder=1)
        if options.get("trajectory") == "chosen" and chosen_known:
            for c, cluster in enumerate(clusters):
                path = []
                for o, ordinal in enumerate(ordinals):
                    pick = [e for e in entries if e.nominal_display == cluster and float(e.ordinal) == ordinal
                            and e.selected]
                    if pick:
                        path.append((o, columns[pick[0].entry_id][0], self._nodes(pick[0])))
                for (o0, x0, a), (o1, x1, b) in zip(path, path[1:]):
                    dotted = o1 - o0 > 1
                    if len(a) == len(b):
                        pairs = list(zip(a, b))
                    elif len(a) == 1:
                        pairs = [(a[0], node) for node in b]
                    elif len(b) == 1:
                        pairs = [(node, b[0]) for node in a]
                    else:
                        pairs = [(a[0], b[0]), (a[-1], b[-1])]
                    for (m0, w0), (m1, w1) in pairs:
                        ax.plot([x0, x1], [m0, m1], color=style.group_color(c), linestyle=":" if dotted else "-",
                                linewidth=0.8 + 3.0 * (w0 + w1) / 2, alpha=0.8, zorder=1)
        ax.set_xlim(-0.8, position - 0.6)
        ax.set_xticks([])
        ax.set_ylabel("Component median radius (µm)", color=style.ink)
        from matplotlib.transforms import blended_transform_factory
        below = blended_transform_factory(ax.transData, ax.transAxes)
        for e in entries:
            x, _, _ = columns[e.entry_id]
            ax.text(x, -0.03, f"{int(np.sum(e.component_n))}", transform=below, ha="center", va="top",
                    fontsize=style.font_size - 2.5, color=style.muted, rotation=90 if len(entries) > 40 else 0)
        multiple_levels = len({o for _, _, o in columns.values()}) > 1
        if multiple_levels:
            for x, text in level_marks:
                ax.text(x, -0.09, text, transform=below, ha="center", va="top", fontsize=style.font_size - 2,
                        color=style.ink)
        for x, text, c in block_marks:
            ax.text(x, -0.15 if multiple_levels else -0.09, text, transform=below, ha="center", va="top",
                    fontsize=style.font_size - 1, fontweight="bold", color=style.group_color(c))
        result["overlaps"] = {}
        if overlap_row and reference is not None:
            for c, cluster in enumerate(clusters):
                values = [self.overlap(e, reference) for e in entries
                          if e.nominal_display == cluster and e.entry_id != reference.entry_id]
                if values:
                    result["overlaps"][cluster] = (min(values), max(values))
            for x, text, c in block_marks:
                low, high = result["overlaps"].get(text, (np.nan, np.nan))
                if np.isfinite(low):
                    label = f"{low:.2f}" if abs(high - low) < 0.005 else f"{low:.2f}–{high:.2f}"
                    ax.text(x, -0.21 if multiple_levels else -0.15, label, transform=below, ha="center", va="top",
                            fontsize=style.font_size - 2, color=style.ink)
            ax.text(-0.01, -0.21 if multiple_levels else -0.15, "overlap", transform=ax.transAxes, ha="right",
                    va="top", fontsize=style.font_size - 2, color=style.muted)
        ax.text(-0.01, -0.03, "colonies", transform=ax.transAxes, ha="right", va="top",
                fontsize=style.font_size - 2, color=style.muted)
        handles = [Line2D([], [], color=style.ink, marker="o", markerfacecolor="none", linestyle="none",
                          label="chosen plate (outlined)")] if chosen_known else []
        if options.get("reference") == "first" and reference is not None:
            handles.append(Line2D([], [], color=style.group_color(0), linestyle="--",
                                  label=f"components of the chosen {clusters[0]} plate"))
        if handles:
            ax.legend(handles=handles, loc="upper right", frameon=False, fontsize=8)
        ax.set_title("Mixture component locations, one column per plate", fontsize=13, fontweight="bold",
                     color=style.ink, loc="left")
        return None

    def _draw_levels(self, figure, result, style):
        import numpy as np

        from ..common import level_ticks, plain_log_axis, show_message, style_axes
        figure.clear()
        fits = result["fits"]
        entries = [e for e in fits.entries if e.n_components]
        if not entries:
            show_message(figure, "No plate has a mixture fit yet.", style)
            return None
        clusters = list(fits.levels.nominal_display)
        ordinals = [float(o) for o in np.asarray(fits.levels.ordinal)]
        ordinal_display = list(fits.levels.ordinal_display)
        ax = figure.add_axes((0.08, 0.14, 0.68, 0.76))
        style_axes(ax, style)
        ax.set_yscale("log")
        plain_log_axis(ax.yaxis)
        n_clusters = max(1, len(clusters))
        step = 0.6 / n_clusters
        for c, cluster in enumerate(clusters):
            color = style.group_color(c)
            xs, dominant_means = [], []
            drawn = False
            for o, ordinal in enumerate(ordinals):
                cell = [e for e in entries if e.nominal_display == cluster and float(e.ordinal) == ordinal]
                if not cell:
                    continue
                center = o + 1 + (c - (n_clusters - 1) / 2) * step
                dominants = []
                for k, e in enumerate(cell):
                    offset = (k - (len(cell) - 1) / 2) * (step * 0.5 / max(1, len(cell)))
                    weights = np.asarray(e.component_weights, dtype=float)
                    top = int(np.argmax(weights))
                    for i in range(e.n_components):
                        dominant = i == top
                        label = (cluster or "All plates") if dominant and not drawn else None
                        ax.scatter(center + offset, float(e.component_medians[i]),
                                   s=18 + 160 * float(weights[i]),
                                   facecolor=color if dominant else "none", edgecolor=color,
                                   linewidth=1.2, alpha=0.85 if dominant else 0.7, zorder=3,
                                   label=label)
                        drawn = drawn or label is not None
                    dominants.append(float(e.component_medians[top]))
                xs.append(center)
                dominant_means.append(float(np.mean(dominants)))
            if len(xs) > 1:
                ax.plot(xs, dominant_means, color=color, linewidth=1.8, alpha=0.8, zorder=2)
        level_ticks(ax, ordinal_display, style)
        ax.set_xlim(0.4, len(ordinals) + 0.6)
        ax.set_ylabel("Component median radius (µm)", color=style.ink)
        if fits.labels.ordinal:
            ax.set_xlabel(fits.labels.ordinal, color=style.ink)
        ax.legend(loc="upper left", bbox_to_anchor=(1.02, 1.0), frameon=False, fontsize=9,
                  title=fits.labels.nominal or None, title_fontsize=9)
        ax.set_title("Mixture component locations", fontsize=13, fontweight="bold", color=style.ink,
                     loc="left")
        return None

    def notes(self, result):
        entries = [e for e in result["fits"].entries if e.n_components]
        multi = sum(1 for e in entries if e.n_components > 1)
        notes = [f"{len(entries)} plates fit; {multi} with more than one component. "
                 "Point size follows the component's share of the plate's colonies."]
        if result.get("overlaps"):
            notes.append("Overlap with the first block's chosen plate (shared area of the two mixture densities, "
                         "each component a lognormal from its median and quartiles): " + "; ".join(
                             f"{k} {lo:.2f}" + ("" if abs(hi - lo) < 0.005 else f" to {hi:.2f}")
                             for k, (lo, hi) in result["overlaps"].items()) + ".")
        return notes

    def table(self, result):
        rows = super().table(result)
        overlaps = result.get("overlaps", {})
        for row in rows:
            if row["cluster"] in overlaps:
                row["overlap_range"] = "{:.2f} to {:.2f}".format(*overlaps[row["cluster"]])
        return rows


ANALYSES = [Subpopulations(), ComponentLocations()]
