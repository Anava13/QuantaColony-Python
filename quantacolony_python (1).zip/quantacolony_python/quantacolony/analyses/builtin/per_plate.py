"""Per-plate views of colony size: one glyph or one point per plate instead of one per group.

Plate distributions draws one box or violin per plate, plates grouped by the Groups slot and
ordered inside a group by colony count. Per-plate statistic computes one summary statistic per
plate and shows every plate as a point across the x-axis levels, with a line through the group
means. Both read the plate's replicate number and annotations from AnalysisData.plate_info:
choice-annotation values held by a minority of the drawn plates are flagged with a star, so a
plate that differs from the rest (a 140 mm dish among 90 mm dishes) is visible on the figure.
"""

from __future__ import annotations

import numpy as np
from matplotlib.colors import to_rgba

from ...core import stats as st
from ..api import NOMINAL, ORDINAL, REPLICATE, Analysis, Option, Slot
from ..common import group_bandwidth, level_ticks, panel_grid, plain_log_axis, show_message, style_axes
from .distributions import box_numbers

GROUP_GAP = 1.6                                   # empty space between group blocks (plate columns)
VIOLIN_MIN = 10                                   # 'Auto' glyph: violin from this many colonies
VIOLIN_MIN_MATLAB = 50                            # 'Violin from 50': the MATLAB rescue figure's cutoff
OTHERS_RANGE = (100, 200)                         # 'Others with 100 to 200 colonies' (the MATLAB share figure)
LINE_STYLES = ("-", "--", ":", "-.")
VIOLIN_WIDTH = 0.8
BOX_WIDTH = 0.55


def minority_flags(data, index_ids) -> tuple[dict, list[str]]:
    """Drawn plates whose choice-annotation value differs from the project's most common value.

    The majority is taken over every plate of the project, so a 140 mm dish is starred even in a
    view where 140 mm dishes outnumber 90 mm ones. Returns ({index id: [flag text, ...]}, legend
    lines). Only choice annotations are read: numbers are measures and notes are free text."""
    if not data.plate_info:
        return {}, []
    drawn = {int(i) for i in index_ids}
    values_of = {}                                                      # name -> {index id: value}, every plate
    for i, info in data.plate_info.items():
        for name, value in info.get("annotations", {}).items():
            values_of.setdefault(name, {})[int(i)] = value
    flags: dict[int, list] = {}
    legend = []
    for name, values in sorted(values_of.items()):
        counts: dict[str, int] = {}
        for value in values.values():
            counts[value] = counts.get(value, 0) + 1
        if len(counts) < 2 or not drawn <= set(values):                 # uniform, or not every drawn plate has it
            continue
        if len(counts) > max(4, len(values) // 4):                      # a free label (a file name), not a category
            continue
        if not all(isinstance(v, str) and not _is_number(v) for v in counts):
            continue                                                    # numbers are measures, not flags
        modal = max(counts, key=counts.get)
        for i, value in values.items():
            if value != modal and i in drawn:
                flags.setdefault(i, []).append(f"{name}: {value}")
        legend.append(f"★ {name} differs from the majority ({modal})")
    return flags, legend


def _is_number(text) -> bool:
    try:
        float(text)
        return True
    except (TypeError, ValueError):
        return False


def plate_label(data, index_id: int) -> str:
    info = (data.plate_info or {}).get(int(index_id), {})
    return str(info.get("replicate", "")) or ""


class PlateDistributions(Analysis):
    id = "plate_distributions"
    name = "Per-plate distributions"
    group = "Distributions"
    description = ("One box or violin per plate, so replicate plates are seen one by one instead of "
                   "pooled. Plates are grouped by the Groups slot and ordered inside a group by "
                   "colony count; each plate carries its colony count.")
    slots = (Slot("groups", "Groups", (NOMINAL, ORDINAL, REPLICATE),
                  description="Each level is one block of plate columns (for example Genotype · Passage)."),)
    options = (Option("glyph", "Glyph", (("auto", "Auto"), ("auto50", "Violin from 50 colonies"), ("box", "Boxes"),
                                         ("violin", "Violins")), "auto"),
               Option("axis", "Y axis", (("linear", "Linear"), ("log", "Log")), "linear"),
               Option("counts", "Colony counts", (("show", "Show"), ("hide", "Hide")), "show"))
    normalize = ("groups", "groups")
    color_slots = ("groups",)

    def title(self, data, options):
        by = f" by {data.axes['groups'].title}" if data.axes["groups"].title else ""
        return f"Colony size per plate{by}, {data.scheme_label}"

    def compute(self, data, options):
        blocks = []
        for g in range(len(data.axes["groups"])):
            keep_group = data.select(groups=g)
            ids = sorted({int(i) for i in data.index_ids[keep_group]})
            plates = []
            for index_id in ids:
                keep = keep_group & (data.index_ids == index_id)
                values = data.values[keep]
                if values.size == 0:
                    continue
                cell = box_numbers(values)
                cell["index_id"], cell["values"] = index_id, values
                cell["label"] = plate_label(data, index_id)
                if values.size >= 2:
                    h = group_bandwidth(data, keep)
                    low = values.min() - 3 * h
                    if data.scheme == "raw":
                        low = max(low, values.min() * 0.5 if options.get("axis") == "log" else 0.0)
                    grid = np.linspace(max(low, 1e-9), values.max() + 3 * h, 160)
                    cell["grid"], cell["density"], cell["bandwidth"] = grid, st.kde(values, grid, h), h
                plates.append(cell)
            plates.sort(key=lambda c: c["n"])
            if plates:
                blocks.append({"group": g, "label": data.axes["groups"].labels[g] or "All plates",
                               "plates": plates})
        flagged, legend = minority_flags(data, [p["index_id"] for b in blocks for p in b["plates"]])
        return {"title": self.title(data, options), "data": data, "blocks": blocks,
                "glyph": options.get("glyph", "auto"), "axis": options.get("axis", "linear"),
                "counts": options.get("counts", "show") == "show", "flags": flagged, "flag_legend": legend}

    PRINT_PLATES = 30                              # plates per printed page

    def draw(self, figure, result, style):
        """One figure; on a printed page with more than PRINT_PLATES plates, a list of pages (the first is
        `figure`), each holding whole groups where they fit and splitting a group too large for one page."""
        blocks = result["blocks"]
        if not getattr(style, "print_mode", False) or sum(len(b["plates"]) for b in blocks) <= self.PRINT_PLATES:
            return self._draw_page(figure, result, blocks, style)
        from matplotlib.figure import Figure
        pages, current, count = [], [], 0
        for block in blocks:
            plates = block["plates"]
            for start in range(0, len(plates), self.PRINT_PLATES):
                part = plates[start:start + self.PRINT_PLATES]
                piece = dict(block, plates=part, label=block["label"] + (" (continued)" if start else ""))
                if count + len(part) > self.PRINT_PLATES and current:
                    pages.append(current)
                    current, count = [], 0
                current.append(piece)
                count += len(part)
        if current:
            pages.append(current)
        figures = []
        for k, page in enumerate(pages):
            target = figure if k == 0 else Figure(figsize=figure.get_size_inches(), facecolor=style.background)
            drawn = self._draw_page(target, dict(result, title=f"{result['title']} ({k + 1} of {len(pages)})"), page, style)
            figures.append(drawn if drawn is not None else target)
        return figures

    def _draw_page(self, figure, result, blocks, style):
        figure.clear()
        data = result["data"]
        if not blocks:
            show_message(figure, "No plate has colonies yet.", style)
            return None
        printing = getattr(style, "print_mode", False)
        ax = figure.add_axes((0.08, 0.15, 0.9, 0.66) if printing else (0.07, 0.13, 0.9, 0.70))
        style_axes(ax, style)
        if result["axis"] == "log":
            ax.set_yscale("log")
            plain_log_axis(ax.yaxis)
        position, centers, ticks, tick_labels, flag_points = 1.0, [], [], [], []
        for b, block in enumerate(blocks):
            start = position
            color = style.color_for(data, groups=block["group"]) or style.group_color(block["group"])
            for cell in block["plates"]:
                glyph = result["glyph"]
                least = VIOLIN_MIN_MATLAB if glyph == "auto50" else VIOLIN_MIN
                violin = glyph == "violin" or (glyph in ("auto", "auto50") and cell["n"] >= least and "density" in cell)
                if violin and "density" in cell:
                    half = cell["density"] / cell["density"].max() * (VIOLIN_WIDTH / 2)
                    ax.fill_betweenx(cell["grid"], position - half, position + half,
                                     facecolor=to_rgba(color, 0.65), edgecolor=color, linewidth=1)
                    ax.plot([position - VIOLIN_WIDTH / 3, position + VIOLIN_WIDTH / 3], [cell["median"]] * 2,
                            color=style.ink, linewidth=1.8)
                else:
                    stats = [{"med": cell["median"], "q1": cell["q1"], "q3": cell["q3"],
                              "whislo": cell["whisker_low"], "whishi": cell["whisker_high"],
                              "fliers": cell["outliers"]}]
                    ax.bxp(stats, positions=[position], widths=BOX_WIDTH, patch_artist=True, showfliers=True,
                           boxprops={"facecolor": to_rgba(color, 0.65), "edgecolor": color, "linewidth": 1.1},
                           whiskerprops={"color": color, "linewidth": 1.1},
                           capprops={"color": color, "linewidth": 1.1},
                           medianprops={"color": style.ink, "linewidth": 1.8},
                           flierprops={"marker": "o", "markersize": 3, "markerfacecolor": color,
                                       "markeredgecolor": color, "alpha": 0.8})
                top = cell["whisker_high"] if "density" not in cell else float(cell["grid"][-1])
                flagged = cell["index_id"] in result["flags"]
                if result["counts"]:
                    ax.annotate(str(cell["n"]), (position, top), textcoords="offset points",
                                xytext=(0, 12 if flagged else 3),
                                ha="center", va="bottom", fontsize=style.font_size - 2.5, color=style.muted,
                                rotation=90 if printing else 0)
                if flagged:
                    flag_points.append((position, top))
                ticks.append(position)
                tick_labels.append(cell["label"])
                position += 1.0
            centers.append(((start + position - 1) / 2, block["label"]))
            if b < len(blocks) - 1:
                position += GROUP_GAP
        from matplotlib.transforms import offset_copy
        lifted = offset_copy(ax.transData, fig=figure, y=6, units="points")
        for x, y in flag_points:                      # just above the plate's top, under its colony count                      # a star marker (the star glyph is missing from some fonts)
            ax.plot([x], [y], marker="*", ms=7, color=style.ink, lw=0, transform=lifted, clip_on=False)
        ax.set_xlim(0.2, position - 0.2)
        if printing and result["counts"] and result["axis"] != "log":     # room for the counts inside the axes
            low, high = ax.get_ylim()
            ax.set_ylim(low, high + 0.14 * (high - low))
        if any(tick_labels):
            level_ticks(ax, tick_labels, style, positions=np.array(ticks))
        else:
            ax.set_xticks([])
        top = ax.get_ylim()[1]
        for center, label in centers:
            ax.text(center, top, label.replace(" · ", "\n") if len(blocks) > 3 else label, ha="center",
                    va="bottom", fontweight="bold", color=style.ink, fontsize=style.font_size, linespacing=1.1)
        ax.set_ylabel(data.value_label, color=style.ink)
        if any(tick_labels):
            ax.set_xlabel("Plate", color=style.ink)
        figure.suptitle(result["title"], fontsize=13, fontweight="bold", color=style.ink, x=0.07, y=0.98,
                        ha="left")
        return None

    def table(self, result):
        data = result["data"]
        group_title = data.axes["groups"].title or "Group"
        rows = []
        for block in result["blocks"]:
            for cell in block["plates"]:
                info = (data.plate_info or {}).get(cell["index_id"], {})
                row = {group_title: block["label"], "plate": cell["label"] or cell["index_id"],
                       "photo": info.get("photo", ""), "n": cell["n"], "median": cell["median"],
                       "mean": cell["mean"], "q1": cell["q1"], "q3": cell["q3"],
                       "outliers": int(cell["outliers"].size)}
                row.update({f"annotation {k}": v for k, v in info.get("annotations", {}).items()})
                rows.append(row)
        return rows

    def notes(self, result):
        data = result["data"]
        plates = sum(len(b["plates"]) for b in result["blocks"])
        return list(data.notes) + result["flag_legend"] + [
            f"{int(np.isfinite(data.values).sum())} colonies on {plates} plates."]


POINT_OPTIONS = (
    Option("lines", "Line through", (("means", "Group means"), ("selected", "Chosen plates")), "means"),
    Option("others", "Other plates", (("all", "All"), ("range", "100 to 200 colonies"), ("none", "None")), "all"),
    Option("layout", "Layout", (("together", "Together"), ("panels", "One panel per group")), "together"),
    Option("band", "Band", (("none", "None"), ("control", "Control range")), "none"),
)


def control_groups(data) -> list[int]:
    """Groups-slot positions whose first variable sits at its control level (the reference band)."""
    axis = data.axes["groups"]
    if not axis.variables or not axis.keys:
        return []
    first = axis.variables[0]
    control = first.control or (first.values[0] if first.values else None)
    return [g for g, key in enumerate(axis.keys) if key and key[0] == control]


def draw_plate_points(figure, result, style, ylabel: str, ylim=None) -> None:
    """Every plate as a point across the x-axis levels, one color per group.

    Lines: through the group means, or (with one plate per group) through each group's chosen plate,
    dotted across an x level with no chosen plate. With chosen plates the others are open circles,
    all of them, only those with 100 to 200 colonies, or none. A second variable in the Groups slot
    sets the line style (solid, dashed, ...), so lineages of one genotype share a color. The band
    spans every value of the control groups (the first Groups variable at its control level)."""
    from matplotlib.lines import Line2D
    data, cells = result["data"], result["cells"]
    options = result["options"]
    chosen = data.selected
    through_chosen = options.get("lines") == "selected" and chosen is not None
    groups_axis = data.axes["groups"]
    groups = [g for g in range(len(groups_axis)) if any(key[0] == g for key in cells)]
    panels = options.get("layout") == "panels" and len(groups) > 1
    if panels:
        axes, columns, _ = panel_grid(figure, len(groups), sharey=True)
        place = {g: (axes[k], k) for k, g in enumerate(groups)}
    else:
        ax = figure.add_axes((0.08, 0.14, 0.68, 0.76))
        place = {g: (ax, 0) for g in groups}
    second = groups_axis.variables[1] if len(groups_axis.variables) > 1 else None
    style_of = {}
    if second is not None:
        for g, key in enumerate(groups_axis.keys):
            style_of[g] = LINE_STYLES[list(second.values).index(key[1]) % len(LINE_STYLES)]
    band = None
    if options.get("band") == "control":
        reference = [p["value"] for (g, _), plates in cells.items() if g in control_groups(data) for p in plates
                     if np.isfinite(p["value"])]
        band = (min(reference), max(reference)) if reference else None
    n_groups = 1 if panels or through_chosen or second is not None else max(1, len(groups_axis))
    step = 0.6 / n_groups
    first_colors = {}
    for g in groups:
        ax, k = place[g]
        key = groups_axis.keys[g] if groups_axis.keys else ()
        color = style.color_for(data, groups=g)
        if color is None:                                     # lineages of one first level share a color
            first_level = key[0] if key else None
            color = first_colors.setdefault(first_level, style.group_color(len(first_colors)))
        slot = 0 if n_groups == 1 else g
        xs, ys, line_x, line_y = [], [], [], []
        for x in range(len(data.axes["x"])):
            plates = cells.get((g, x))
            if not plates:
                continue
            center = x + 1 + (slot - (n_groups - 1) / 2) * step
            mine = [p for p in plates if through_chosen and p["index_id"] in chosen]
            others = [p for p in plates if p not in mine]
            if through_chosen:
                low, high = OTHERS_RANGE
                keep = options.get("others", "all")
                others = [p for p in others if keep == "all" or (keep == "range" and low <= p["n"] <= high)]
            offsets = np.linspace(-0.12, 0.12, len(others)) if len(others) > 1 else [0.0] * len(others)
            for offset, p in zip(offsets, others):
                ax.scatter(center + offset, p["value"], s=30, facecolor="none" if through_chosen else color,
                           edgecolor=color if through_chosen else style.ink, linewidth=1.2 if through_chosen else 0.4,
                           zorder=3)
                if p["index_id"] in result.get("flags", {}):
                    from matplotlib.transforms import offset_copy
                    lifted = offset_copy(ax.transData, fig=figure, y=7, units="points")
                    ax.plot([center + offset], [p["value"]], marker="*", ms=6, color=style.ink, lw=0, transform=lifted)
            for p in mine:
                ax.scatter(center, p["value"], s=34, color=color, edgecolor=color, zorder=4)
                line_x.append(center)
                line_y.append(p["value"])
            if not through_chosen and plates:
                line_x.append(center)
                line_y.append(float(np.mean([p["value"] for p in plates])))
            xs.append(center)
        linestyle = style_of.get(g, "-")
        if len(line_x) > 1:
            levels = [round(v - 1) for v in line_x] if n_groups == 1 else None
            for i in range(len(line_x) - 1):                  # dotted across an x level with no point
                gap = levels is not None and levels[i + 1] - levels[i] > 1
                ax.plot(line_x[i:i + 2], line_y[i:i + 2], color=color, linewidth=1.8, alpha=0.85, zorder=2,
                        linestyle=":" if gap else linestyle)
        if panels:
            ax.set_title(groups_axis.labels[g] or "All plates", fontsize=11, fontweight="bold", color=color)
    for ax, k in {id(a): (a, k) for a, k in place.values()}.values():
        style_axes(ax, style)
        if band is not None:
            ax.axhspan(band[0], band[1], color=style.zone_colors[0], alpha=0.18, linewidth=0, zorder=0)
        level_ticks(ax, list(data.axes["x"].labels), style)
        ax.set_xlim(0.4, len(data.axes["x"]) + 0.6)
        if ylim is not None:
            ax.set_ylim(*ylim)
        if not panels or k % columns == 0:
            ax.set_ylabel(ylabel, color=style.ink)
        if data.axes["x"].title:
            ax.set_xlabel(data.axes["x"].title, color=style.ink)
    if not panels:
        handles, seen = [], set()
        for g in groups:
            key = groups_axis.keys[g] if groups_axis.keys else ()
            color = style.color_for(data, groups=g) or first_colors.get(key[0] if key else None, style.group_color(0))
            handles.append(Line2D([], [], color=color, marker="o", linestyle=style_of.get(g, "-"),
                                  label=groups_axis.labels[g] or "All plates"))
        if through_chosen:
            handles.append(Line2D([], [], color=style.ink, marker="o", linestyle="-", label="chosen plate"))
            if options.get("others", "all") != "none":
                text = "other plates" if options.get("others") == "all" else "other plates, 100 to 200 colonies"
                handles.append(Line2D([], [], color=style.ink, marker="o", markerfacecolor="none", linestyle="none",
                                      label=text))
        if band is not None:
            from matplotlib.patches import Patch
            handles.append(Patch(color=style.zone_colors[0], alpha=0.18, label="control range"))
        ax.legend(handles=handles, loc="upper left", bbox_to_anchor=(1.02, 1.0), frameon=False, fontsize=9,
                  title=groups_axis.title or None, title_fontsize=9)
        ax.set_title(result["title"], fontsize=13, fontweight="bold", color=style.ink, loc="left")
    else:
        figure.suptitle(result["title"], fontsize=13, fontweight="bold", color=style.ink)
        figure.tight_layout(rect=(0, 0, 1, 0.94))


STATISTICS = ("Median", "Mean", "Standard Deviation", "Coefficient Of Variation", "Skew", "Kurtosis", "Colony Count")


class PlateStatistic(Analysis):
    id = "plate_statistic"
    name = "Per-plate statistic"
    group = "Across ordinal levels"
    description = ("One summary statistic of colony size per plate: every plate is a point, with a line "
                   "through the group means across the x-axis levels. The pooled statistic hides "
                   "plate-to-plate spread; this shows it.")
    slots = (Slot("x", "X axis", (ORDINAL, NOMINAL), min_variables=1,
                  description="Each level is one position along the x axis (for example Passage)."),
             Slot("groups", "Groups", (NOMINAL, REPLICATE, ORDINAL),
                  description="Each level is its own color and mean line (for example Genotype)."))
    options = (Option("statistic", "Statistic",
                      tuple((name, {"Standard Deviation": "SD", "Coefficient Of Variation": "CV",
                                    "Colony Count": "Colonies"}.get(name, name)) for name in STATISTICS),
                      "Coefficient Of Variation"),) + POINT_OPTIONS
    normalize = ("groups", "x")
    color_slots = ("groups",)
    marks_selection = True                        # one plate per group: every used plate drawn, a line through the chosen

    def title(self, data, options):
        label = options.get("statistic", "Coefficient Of Variation")
        return f"Per-plate {label.lower()} across {data.axes['x'].title}, {data.scheme_label}"

    def compute(self, data, options):
        statistic = options.get("statistic", "Coefficient Of Variation")
        if statistic not in STATISTICS:
            statistic = "Coefficient Of Variation"
        cells = {}
        for g in range(len(data.axes["groups"])):
            for x in range(len(data.axes["x"])):
                keep_cell = data.select(groups=g, x=x)
                plates = []
                for index_id in sorted({int(i) for i in data.index_ids[keep_cell]}):
                    values = data.values[keep_cell & (data.index_ids == index_id)]
                    if statistic == "Colony Count":
                        value = float(values.size)
                    elif values.size < 3:                             # a statistic of 1-2 colonies is noise
                        continue
                    else:
                        value = st.summary_values(values)[statistic]
                    plates.append({"index_id": index_id, "n": int(values.size), "value": value,
                                   "label": plate_label(data, index_id)})
                if plates:
                    cells[(g, x)] = plates
        flagged, legend = minority_flags(data, [p["index_id"] for plates in cells.values() for p in plates])
        return {"title": self.title(data, options), "data": data, "cells": cells, "statistic": statistic,
                "flags": flagged, "flag_legend": legend, "options": dict(options)}

    def draw(self, figure, result, style):
        figure.clear()
        if not result["cells"]:
            show_message(figure, "No plate has three or more colonies yet.", style)
            return None
        labels = {"Standard Deviation": "Standard deviation", "Coefficient Of Variation":
                  "Coefficient of variation (per plate)", "Colony Count": "Colonies counted (per plate)"}
        draw_plate_points(figure, result, style, labels.get(result["statistic"], f"{result['statistic']} (per plate)"))
        return None

    def table(self, result):
        data = result["data"]
        group_title = data.axes["groups"].title or "Group"
        x_title = data.axes["x"].title or "X"
        rows = []
        for (g, x), plates in sorted(result["cells"].items()):
            for p in plates:
                rows.append({group_title: data.axes["groups"].labels[g], x_title: data.axes["x"].labels[x],
                             "plate": p["label"] or p["index_id"], "index_id": p["index_id"], "n": p["n"],
                             "chosen": "" if data.selected is None else p["index_id"] in data.selected,
                             result["statistic"]: p["value"]})
        return rows

    def notes(self, result):
        data = result["data"]
        plates = sum(len(p) for p in result["cells"].values())
        rule = ("Every plate with colonies is counted." if result["statistic"] == "Colony Count" else
                "Plates with fewer than three colonies are left out.")
        return list(data.notes) + result["flag_legend"] + [f"{plates} plates. {rule}"]


class ThresholdShare(Analysis):
    id = "threshold_share"
    name = "Share beyond a size"
    group = "Across ordinal levels"
    description = ("The share of each plate's colonies, or of its mixture components' weight, below or above a "
                   "radius cutoff, across the x-axis levels. Every plate is a point, with a line through the "
                   "group means.")
    slots = (Slot("x", "X axis", (ORDINAL, NOMINAL), min_variables=1,
                  description="Each level is one position along the x axis (for example Passage)."),
             Slot("groups", "Groups", (NOMINAL, REPLICATE, ORDINAL),
                  description="Each level is its own color and mean line (for example Genotype)."))
    options = (Option("cutoff", "Cutoff (µm)",
                      (("300", "300"), ("450", "450"), ("600", "600"), ("900", "900"), ("1100", "1100")), "450",
                      number=True),
               Option("side", "Side", (("below", "Below"), ("above", "Above")), "below"),
               Option("count", "Count", (("colonies", "Colonies"), ("components", "Mixture components")),
                      "colonies")) + POINT_OPTIONS
    color_slots = ("groups",)
    marks_selection = True
    background = True                             # only while mixture fits are missing (needs_background)
    background_sometimes = True                   # Stats may open on it: a colony count never waits

    def __init__(self):
        from .subpopulations import SHARED_FITS
        self.fits = SHARED_FITS                   # the mixture fits shared with Mixture model and components

    @staticmethod
    def _words(options) -> str:
        side = options.get("side", "below")
        what = "component weight" if options.get("count") == "components" else "colonies"
        return f"Share of {what} {side} {float(options.get('cutoff', '450')):g} µm"

    def title(self, data, options):
        return f"{self._words(options)} across {data.axes['x'].title}"

    def problem(self, data):
        if data.scheme != "raw":
            return "The cutoff is in micrometers, so this analysis uses the raw measurement."
        return ""

    def _plates(self, data):
        """(index id, its radii in data order) for every plate with colonies."""
        out = []
        for index_id in sorted({int(i) for i in data.index_ids[np.isfinite(data.values)]}):
            values = data.values[(data.index_ids == index_id) & np.isfinite(data.values)]
            if values.size:
                out.append((index_id, values))
        return out

    def needs_background(self, data, options=None) -> bool:
        if (options or {}).get("count") != "components":
            return False
        from ...stats.subpopfig.fitting import fit_key
        return any(fit_key(v) not in self.fits for _, v in self._plates(data))

    def busy_text(self, data) -> str:
        return "Fitting LogNormal mixtures for the component shares…"

    def compute(self, data, options):
        cutoff = float(options.get("cutoff", "450"))
        above = options.get("side", "below") == "above"
        components = options.get("count") == "components"
        progress = options.get("_progress")
        shares, fits = {}, {}
        plates = self._plates(data)
        for done, (index_id, values) in enumerate(plates, start=1):
            if components:
                from ...stats.subpopfig.fitting import fit_one
                _, stats = fit_one(values, self.fits)
                beyond = stats.median > cutoff if above else stats.median < cutoff
                shares[index_id] = float(stats.weight[beyond].sum())
                fits[index_id] = stats
            else:
                shares[index_id] = float((values > cutoff).mean() if above else (values < cutoff).mean())
            if progress is not None and components:
                progress(done, len(plates))
        cells = {}
        for g in range(len(data.axes["groups"])):
            for x in range(len(data.axes["x"])):
                keep_cell = data.select(groups=g, x=x)
                ids = sorted({int(i) for i in data.index_ids[keep_cell]} & set(shares))
                cell = [{"index_id": i, "n": int(np.sum(keep_cell & (data.index_ids == i))), "value": shares[i],
                         "label": plate_label(data, i)} for i in ids]
                if cell:
                    cells[(g, x)] = cell
        return {"title": self.title(data, options), "data": data, "cells": cells, "cutoff": cutoff,
                "words": self._words(options), "options": dict(options), "components": components}

    def dump_cache(self) -> dict:
        return self.fits.to_json()

    def draw(self, figure, result, style):
        figure.clear()
        if not result["cells"]:
            show_message(figure, "No plate has colonies yet.", style)
            return None
        draw_plate_points(figure, result, style, result.get("words", "Share"), (-0.03, 1.03))
        return None

    def table(self, result):
        data = result["data"]
        group_title = data.axes["groups"].title or "Group"
        x_title = data.axes["x"].title or "X"
        words = result.get("words", "share").lower()
        rows = []
        for (g, x), plates in sorted(result["cells"].items()):
            for p in plates:
                rows.append({group_title: data.axes["groups"].labels[g], x_title: data.axes["x"].labels[x],
                             "plate": p["label"] or p["index_id"], "index_id": p["index_id"], "n": p["n"],
                             "chosen": "" if data.selected is None else p["index_id"] in data.selected,
                             words: p["value"]})
        return rows

    def notes(self, result):
        plates = sum(len(p) for p in result["cells"].values())
        how = ("each plate's mixture components (LogNormal, BIC), the share being the weight of the components "
               "whose median lies beyond the cutoff" if result.get("components") else "every colony of the plate")
        return list(result["data"].notes) + [f"{plates} plates; the share counts {how}."]


ANALYSES = [PlateDistributions(), PlateStatistic(), ThresholdShare()]
