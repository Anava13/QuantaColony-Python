"""Distributions of colony size: density plots, box plots and violin plots.

Box and violin plots follow the MATLAB Plots module:
- x-axis levels sit at positions 1..n, colored by their group (or by "Color by");
- 'Together' draws every group on one axis, with two empty positions between groups and
  the group's name above it; 'Separate' gives each group its own axis;
- boxes use 1.5 x IQR whiskers with outliers drawn as points;
- each violin is a Gaussian kernel density scaled to its own maximum, 0.4 wide, with a median
  line and a white dot; a group with fewer than two values is drawn as a single point.
Violins use the same bandwidth as the density plots (Freedman-Diaconis, never below one pixel
at the group's scale, or 0.05 when normalized), so a violin and a density curve of the same
group agree.
"""

from __future__ import annotations

import numpy as np
from matplotlib.colors import to_rgba

from ...core import stats as st
from ..api import NOMINAL, ORDINAL, REPLICATE, Analysis, Option, Slot
from ..common import (group_bandwidth, grouped_statistics, level_ticks, panel_grid, plain_log_axis, show_message,
                      statistics_rows, style_axes)

GAP = 2                                           # empty positions between groups ('Together')
BOX_WIDTH = 0.6
VIOLIN_WIDTH = 0.4
VIEW = Option("view", "Layout", (("together", "Together"), ("separate", "Separate")), "together")
Y_AXIS = Option("axis", "Y axis", (("linear", "Linear"), ("log", "Log")), "linear")
NUMBERS = Option("numbers", "Numbers", (("hide", "Hide"), ("show", "n and median")), "hide")
PEAK_SHARE = 0.2                                  # a marked peak reaches at least this share of its curve's maximum


def log_kde(values: np.ndarray, points: int = 300) -> tuple[np.ndarray, np.ndarray, float]:
    """Kernel density of log radius, as in the MATLAB analyses (QC.computeLogKDE): a Gaussian kernel on
    ln(radius) with the robust Silverman bandwidth shrunk by 0.9 to keep modes apart. Returns the
    radii of the grid, the density per log10 unit of radius (the area over a log axis is one) and
    the bandwidth in ln units."""
    logs = np.log(values[values > 0])
    n = logs.size
    sigma = float(np.std(logs, ddof=1))
    iqr = float(np.subtract(*np.percentile(logs, [75, 25])))
    spread = min(sigma, iqr / 1.34) if iqr > 0 else sigma
    h = 0.9 * 0.9 * (spread if spread > 0 else 0.1) * n ** (-1 / 5)
    grid = np.linspace(logs.min() - 3 * h, logs.max() + 3 * h, points)
    density = np.exp(-0.5 * ((grid[:, None] - logs[None, :]) / h) ** 2).sum(axis=1) / (n * h * np.sqrt(2 * np.pi))
    return np.exp(grid), density * np.log(10), h


def peaks_of(grid: np.ndarray, density: np.ndarray) -> list[float]:
    """Local maxima of a density curve that reach PEAK_SHARE of its maximum, as grid positions."""
    top = float(density.max())
    return [float(grid[i]) for i in range(1, len(density) - 1)
            if density[i] > density[i - 1] and density[i] >= density[i + 1] and density[i] >= PEAK_SHARE * top]


# ======================================================================================
# density plots
# ======================================================================================
class DensityPlots(Analysis):
    id = "density"
    name = "Density plots"
    group = "Distributions"
    description = ("Kernel density of colony size, one panel per panel level and one curve per curve level. "
                   "Bandwidth: Freedman-Diaconis, never below one pixel (raw) or 0.05 (normalized).")
    slots = (Slot("panels", "Panels", (NOMINAL, REPLICATE, ORDINAL),
                  description="Each level gets its own panel (for example Genotype)."),
             Slot("curves", "Curves", (ORDINAL, NOMINAL, REPLICATE),
                  description="Each level is its own curve inside every panel (for example Passage)."))
    options = (Option("scale", "Scale", (("linear", "Linear"), ("log", "Log radius")), "linear"),
               Option("peaks", "Peaks", (("hide", "Hide"), ("show", "Mark")), "hide"))
    normalize = ("panels", "curves")
    color_slots = ("panels", "curves")

    def title(self, data, options):
        across = f" across {data.axes['curves'].title}" if data.axes["curves"].title else ""
        return f"Colony size distribution{across}, {data.scheme_label}"

    def compute(self, data, options):
        result = {"title": self.title(data, options), "stats": grouped_statistics(data, "panels", "curves"),
                  "scale": options.get("scale", "linear"), "peaks": options.get("peaks", "hide") == "show"}
        if result["scale"] == "log":                          # one log-space curve per group, on its own grid
            curves = {}
            for (p, c), group in result["stats"].groups.items():
                values = data.cell(panels=p, curves=c)
                values = values[values > 0]
                if values.size >= 3:
                    grid, density, h = log_kde(values)
                    curves[(p, c)] = {"grid": grid, "density": density, "bandwidth": h, "n": int(values.size),
                                      "peaks": peaks_of(grid, density)}
            result["log_curves"] = curves
        else:
            result["peak_marks"] = {key: peaks_of(result["stats"].grid, g.density)
                                    for key, g in result["stats"].groups.items() if g.density is not None}
        return result

    def draw(self, figure, result, style):
        grouped = result["stats"]
        data = grouped.data
        figure.clear()
        log = result.get("scale") == "log"
        curves = result["log_curves"] if log else {
            key: {"grid": grouped.grid, "density": g.density, "n": g.n, "peaks": result.get("peak_marks", {}).get(key, [])}
            for key, g in grouped.groups.items() if g.density is not None}
        panels = [p for p in range(len(data.axes["panels"])) if any((p, c) in curves for c in range(len(data.axes["curves"])))]
        if not panels:
            show_message(figure, "No group has three or more colonies yet.", style)
            return None
        colors = style.step_colors(len(data.axes["curves"]))
        top = max(float(curve["density"].max()) for curve in curves.values()) * (1.18 if result.get("peaks") else 1.08)
        printing = getattr(style, "print_mode", False)
        if printing:
            from ..common import print_heading, print_panels
            lines = max(print_heading(data.axes["panels"].labels[p] or "All colonies").count("\n") + 2 for p in panels)
            axes, columns, rows = print_panels(figure, len(panels), heading_lines=lines, legend_row=True,
                                               sharex=True, sharey=True)
        else:
            axes, columns, rows = panel_grid(figure, len(panels), sharex=True, sharey=True)
        shared = {}                                      # curve level -> (color, label): the printed legend row
        for k, (ax, p) in enumerate(zip(axes, panels)):
            style_axes(ax, style)
            if log:
                ax.set_xscale("log")
                plain_log_axis(ax.xaxis)
            for c in range(len(data.axes["curves"])):
                curve = curves.get((p, c))
                if curve is None:
                    continue
                group = grouped.groups[(p, c)]
                label = f"{group.second} (n={curve['n']})" if group.second else f"n={curve['n']}"
                color = style.color_for(data, panels=p, curves=c) or colors[c]
                ax.plot(curve["grid"], curve["density"], color=color, linewidth=1.2 if printing else 1.8, label=label)
                shared.setdefault(c, (color, group.second or "All"))
                if result.get("peaks"):
                    for x in curve["peaks"]:
                        ax.axvline(x, color=style.ink, linestyle="--", linewidth=0.9, zorder=1)
                        ax.annotate(f"{x:.0f}", (x, top / 1.18 * 1.02), xytext=(3, 0), textcoords="offset points",
                                    fontsize=style.font_size - 1.5, color=style.ink)
            heading = data.axes["panels"].labels[p] or "All colonies"
            ax.set_ylim(0, top)
            if printing:                                 # heading lines, then the curves' colony counts
                counts = ", ".join(str(curves[(p, c)]["n"]) for c in range(len(data.axes["curves"])) if (p, c) in curves)
                ax.set_title(f"{print_heading(heading)}\nn = {counts}", fontsize=7.5, color=style.ink,
                             linespacing=1.15, pad=3)
            else:
                ax.set_title(heading, fontsize=11, fontweight="bold", color=style.ink)
                ax.legend(fontsize=7.5, frameon=False, title=data.axes["curves"].title or None, title_fontsize=8)
            if k % columns == 0:
                ax.set_ylabel("Density", color=style.ink)
            if k // columns == rows - 1:
                ax.set_xlabel(data.value_label, color=style.ink)
        if printing:
            from matplotlib.lines import Line2D
            handles = [Line2D([], [], color=color, lw=1.2) for color, _ in shared.values()]
            figure.legend(handles, [label for _, label in shared.values()], loc="lower center", ncol=min(8, len(handles)),
                          title=data.axes["curves"].title or None, frameon=False, fontsize=7, title_fontsize=7,
                          bbox_to_anchor=(0.5, 0.0))
            figure.text(0.0, 0.995, result["title"], ha="left", va="top", fontsize=10, fontweight="bold", color=style.ink)
            return None
        figure.suptitle(result["title"], fontsize=13, fontweight="bold", color=style.ink)
        figure.tight_layout(rect=(0, 0, 1, 0.95), h_pad=1.6)
        return None

    def table(self, result):
        rows = statistics_rows(result["stats"])               # one row per group, in sorted group order
        marks = result.get("log_curves") or {k: {"peaks": v} for k, v in result.get("peak_marks", {}).items()}
        for row, key in zip(rows, sorted(result["stats"].groups)):
            if key in marks:
                row["Peaks"] = ", ".join(f"{x:.1f}" for x in marks[key]["peaks"])
        return rows

    def notes(self, result):
        data = result["stats"].data
        return list(data.notes) + [f"{int(np.isfinite(data.values).sum())} colonies in "
                                   f"{len(result['stats'].groups)} groups."]


# ======================================================================================
# box and violin plots
# ======================================================================================
def box_numbers(values: np.ndarray) -> dict:
    """Quartiles, 1.5 x IQR whiskers (to the most extreme value inside them) and outliers."""
    q1, median, q3 = np.percentile(values, [25, 50, 75])
    iqr = q3 - q1
    inside = values[(values >= q1 - 1.5 * iqr) & (values <= q3 + 1.5 * iqr)]
    low, high = (float(inside.min()), float(inside.max())) if inside.size else (float(q1), float(q3))
    outliers = values[(values < low) | (values > high)]
    return {"n": int(values.size), "mean": float(np.mean(values)), "median": float(median), "q1": float(q1),
            "q3": float(q3), "whisker_low": low, "whisker_high": high, "outliers": outliers}


class _BoxOrViolin(Analysis):
    group = "Distributions"
    slots = (Slot("x", "X axis", (ORDINAL, NOMINAL, REPLICATE),
                  description="Each level is one position along the x axis (for example Passage)."),
             Slot("groups", "Groups", (NOMINAL, REPLICATE, ORDINAL),
                  description="Each level is its own colored shape at every x position (for example Genotype)."))
    options = (VIEW, Y_AXIS, NUMBERS,
               Option("space", "Space by", (("none", "None"),), "none", variables_of="x"))
    normalize = ("groups", "x")
    color_slots = ("groups", "x")
    kind = ""

    def title(self, data, options):
        across = f" across {data.axes['x'].title}" if data.axes["x"].title else ""
        return f"Colony size{across}, {data.scheme_label}"

    def compute(self, data, options):
        cells = {}
        for g in range(len(data.axes["groups"])):
            for x in range(len(data.axes["x"])):
                keep = data.select(groups=g, x=x)
                values = data.values[keep]
                if values.size == 0:
                    continue
                cell = box_numbers(values)
                cell["values"] = values
                if self.kind == "violin" and values.size >= 2:
                    h = group_bandwidth(data, keep)
                    low = values.min() - 3 * h
                    if data.scheme == "raw":
                        low = max(low, 0.0)
                    grid = np.linspace(low, values.max() + 3 * h, 160)
                    cell["grid"], cell["density"], cell["bandwidth"] = grid, st.kde(values, grid, h), h
                cells[(g, x)] = cell
        return {"title": self.title(data, options), "data": data, "cells": cells, "view": options.get("view"),
                "axis": options.get("axis", "linear"), "numbers": options.get("numbers", "hide") == "show",
                "space": options.get("space", "none")}

    @staticmethod
    def columns(axis, xs, space: str) -> list:
        """X columns in drawing order: None marks an empty spacer column. Spacing by an x-axis variable puts
        that variable outermost (its levels in their own order) and leaves one empty column wherever its level
        changes."""
        names = [v.name for v in axis.variables]
        if space not in names:
            return list(xs)
        i = names.index(space)
        rank = {}
        for x in xs:
            rank.setdefault(axis.keys[x][i], len(rank))
        ordered = sorted(xs, key=lambda x: rank[axis.keys[x][i]])       # stable: inner order kept
        out, previous = [], None
        for x in ordered:
            if previous is not None and axis.keys[x][i] != previous:
                out.append(None)
            out.append(x)
            previous = axis.keys[x][i]
        return out

    @staticmethod
    def _numbers(ax, cells_at: list, style, first: bool) -> None:
        """Colony count and median above each cell: two rows of text just above the axes."""
        from matplotlib.transforms import blended_transform_factory
        mark = blended_transform_factory(ax.transData, ax.transAxes)
        size = style.font_size - 2
        for position, cell in cells_at:
            ax.text(position, 1.075, f"{cell['n']}", transform=mark, ha="center", va="bottom", fontsize=size,
                    color=style.ink, clip_on=False)
            ax.text(position, 1.015, f"{cell['median']:.0f}", transform=mark, ha="center", va="bottom", fontsize=size,
                    color=style.ink, clip_on=False)
        if first:
            ax.text(-0.01, 1.075, "n", transform=ax.transAxes, ha="right", va="bottom", fontsize=size, color=style.muted)
            ax.text(-0.01, 1.015, "Median", transform=ax.transAxes, ha="right", va="bottom", fontsize=size,
                    color=style.muted)

    def draw(self, figure, result, style):
        figure.clear()
        data, cells = result["data"], result["cells"]
        if not cells:
            show_message(figure, "No group has colonies yet.", style)
            return None
        groups = [g for g in range(len(data.axes["groups"])) if any(key[0] == g for key in cells)]
        n_x = len(data.axes["x"])
        printing = getattr(style, "print_mode", False)
        if printing and len(groups) > 1:                 # a printed page: one panel per group, its own levels only
            from ..common import print_heading, print_panels
            lines = max(print_heading(data.axes["groups"].labels[g]).count("\n") + 1 for g in groups)
            lines += 2 if result.get("numbers") else 0
            axes, columns, rows = print_panels(figure, len(groups), heading_lines=lines, sharey=True)
        elif result["view"] == "separate" and len(groups) > 1:
            axes, columns, rows = panel_grid(figure, len(groups), sharey=True)
        if (printing or result["view"] == "separate") and len(groups) > 1:
            for k, (ax, g) in enumerate(zip(axes, groups)):
                style_axes(ax, style)
                if result.get("axis") == "log":
                    ax.set_yscale("log")
                    plain_log_axis(ax.yaxis)
                order = self.columns(data.axes["x"], [x for x in range(n_x) if (g, x) in cells],
                                     result.get("space", "none"))           # each panel shows only its own levels
                placed = [(slot + 1, x) for slot, x in enumerate(order) if x is not None]
                for position, x in placed:
                    self._draw_cell(ax, cells[(g, x)], position, self._color(data, g, x, style), style)
                if result.get("numbers"):
                    self._numbers(ax, [(position, cells[(g, x)]) for position, x in placed], style,
                                  k % columns == 0)
                if printing:                             # one or two cells keep the width of three
                    center, half = (1 + len(order)) / 2, max(len(order), 3) / 2 + 0.1
                    ax.set_xlim(center - half, center + half)
                else:
                    ax.set_xlim(0.4, len(order) + 0.6)
                level_ticks(ax, [data.axes["x"].labels[x] for _, x in placed], style,
                            positions=np.array([position for position, _ in placed]))
                if printing:
                    ax.set_title(print_heading(data.axes["groups"].labels[g]), fontsize=7.5, color=style.ink,
                                 linespacing=1.15, pad=24 if result.get("numbers") else 3)
                else:
                    ax.set_title(data.axes["groups"].labels[g], fontsize=11, fontweight="bold", color=style.ink,
                                 pad=42 if result.get("numbers") else 6)
                if k % columns == 0:
                    ax.set_ylabel(data.value_label, color=style.ink)
                if k // columns == rows - 1 and data.axes["x"].title:
                    ax.set_xlabel(data.axes["x"].title, color=style.ink)
            if printing:
                figure.text(0.0, 0.995, result["title"], ha="left", va="top", fontsize=10, fontweight="bold",
                            color=style.ink)
                return None
            figure.suptitle(result["title"], fontsize=13, fontweight="bold", color=style.ink)
            figure.tight_layout(rect=(0, 0, 1, 0.95), h_pad=1.6)
            return None

        ax = figure.add_axes((0.07, 0.12, 0.9, 0.62 if result.get("numbers") else 0.70))
        style_axes(ax, style)
        if result.get("axis") == "log":
            ax.set_yscale("log")
            plain_log_axis(ax.yaxis)
        ticks, labels, centers, numbered = [], [], [], []
        position = 1
        for i, g in enumerate(groups):
            start = position
            for x in self.columns(data.axes["x"], range(n_x), result.get("space", "none")):
                if x is None:                                       # a spacer column
                    position += 1
                    continue
                if (g, x) in cells:
                    self._draw_cell(ax, cells[(g, x)], position, self._color(data, g, x, style), style)
                    numbered.append((position, cells[(g, x)]))
                ticks.append(position)
                labels.append(data.axes["x"].labels[x])
                position += 1
            centers.append(((start + position - 1) / 2, data.axes["groups"].labels[g]))
            if i < len(groups) - 1:
                position += GAP
        ax.set_xlim(0.4, position - 0.4)
        level_ticks(ax, labels, style, positions=np.array(ticks))
        if result.get("numbers"):
            self._numbers(ax, numbered, style, True)
        from matplotlib.transforms import blended_transform_factory
        above = blended_transform_factory(ax.transData, ax.transAxes)
        height = 1.15 if result.get("numbers") else 1.0                       # group names sit above the numbers
        stacked = any(len(label) > 2.2 * (n_x + GAP) for _, label in centers)   # too wide for its group: one level per line
        for center, label in centers:
            if label:
                ax.text(center, height, label.replace(" · ", "\n") if stacked else label, ha="center", va="bottom",
                        transform=above, fontweight="bold", color=style.ink, fontsize=style.font_size, linespacing=1.1,
                        clip_on=False)
        ax.set_ylabel(data.value_label, color=style.ink)
        if data.axes["x"].title:
            ax.set_xlabel(data.axes["x"].title, color=style.ink)
        figure.suptitle(result["title"], fontsize=13, fontweight="bold", color=style.ink, x=0.07, y=0.98,
                        ha="left")
        return None

    @staticmethod
    def _color(data, g, x, style) -> str:
        return style.color_for(data, groups=g, x=x) or style.group_color(g)

    def _draw_cell(self, ax, cell, position, color, style):
        raise NotImplementedError

    def table(self, result):
        data = result["data"]
        group_title = data.axes["groups"].title or "Group"
        x_title = data.axes["x"].title or "X"
        rows = []
        for (g, x), cell in sorted(result["cells"].items()):
            row = {group_title: data.axes["groups"].labels[g], x_title: data.axes["x"].labels[x]}
            row.update({k: v for k, v in cell.items() if k not in ("values", "grid", "density", "outliers")})
            row["outliers"] = int(cell["outliers"].size)
            rows.append(row)
        return rows

    def notes(self, result):
        data = result["data"]
        return list(data.notes) + [f"{int(np.isfinite(data.values).sum())} colonies in {len(result['cells'])} groups."]


class BoxPlots(_BoxOrViolin):
    id = "box"
    name = "Box plots"
    kind = "box"
    description = ("Median, quartiles and 1.5 × IQR whiskers of colony size for every x-axis level and "
                   "group. Points beyond the whiskers are drawn as outliers.")

    def _draw_cell(self, ax, cell, position, color, style):
        stats = [{"med": cell["median"], "q1": cell["q1"], "q3": cell["q3"], "whislo": cell["whisker_low"],
                  "whishi": cell["whisker_high"], "fliers": cell["outliers"], "mean": cell["mean"]}]
        ax.bxp(stats, positions=[position], widths=BOX_WIDTH, patch_artist=True, showfliers=True,
               boxprops={"facecolor": to_rgba(color, 0.7), "edgecolor": color, "linewidth": 1.2},
               whiskerprops={"color": color, "linewidth": 1.2}, capprops={"color": color, "linewidth": 1.2},
               medianprops={"color": style.ink, "linewidth": 2},
               flierprops={"marker": "o", "markersize": 4, "markerfacecolor": color, "markeredgecolor": color,
                           "alpha": 0.8})
        ax.scatter([position], [cell["median"]], s=22, color=style.marker_fill, edgecolor=color, linewidth=1.4, zorder=4)


class ViolinPlots(_BoxOrViolin):
    id = "violin"
    name = "Violin plots"
    kind = "violin"
    description = ("Kernel density of colony size for every x-axis level and group, drawn as a violin with "
                   "its median. Bandwidth matches the density plots.")

    def _draw_cell(self, ax, cell, position, color, style):
        if "density" not in cell:                                   # fewer than two values: one point
            ax.scatter([position], [cell["values"][0]], s=50, color=color, edgecolor=style.ink, zorder=3)
            return
        half = cell["density"] / cell["density"].max() * (VIOLIN_WIDTH / 2)
        ax.fill_betweenx(cell["grid"], position - half, position + half, facecolor=to_rgba(color, 0.7),
                         edgecolor=style.ink, linewidth=1)
        ax.plot([position - VIOLIN_WIDTH / 2, position + VIOLIN_WIDTH / 2], [cell["median"]] * 2, color=color,
                linewidth=2)
        ax.scatter([position], [cell["median"]], s=25, color=style.marker_fill, edgecolor=color, linewidth=1.5, zorder=4)


ANALYSES = [DensityPlots(), BoxPlots(), ViolinPlots()]
