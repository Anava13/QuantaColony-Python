"""Plate photos: each plate's photo with the colonies Colony Detection kept outlined, and its
numbers underneath (colony count, median radius, capture ratio, a numeric annotation).

The dissertation's detection figures (the dilution series, the streak-out quadrants and sectors,
the selected rescue plates) are this view. Plates are laid out by the Rows and Columns slots; a
cell holding several plates places them side by side. With one plate per group on, only the
chosen plates are drawn. The photo is shown in grayscale so the outlines stand out; pixels outside
the plate's region are black.
"""

from __future__ import annotations

import math

import numpy as np

from ..api import INDEX, NOMINAL, ORDINAL, REPLICATE, Analysis, Option, Slot
from ..common import show_message

MAX_SIDE = 420                                    # photos are reduced to this many pixels on their longer side
MAX_PLATES = 60                                   # more than this: hide levels first (each photo is read from the file)
VALUES = {
    "count_ratio_hce": (("colony_count", "Colonies"), ("capture_ratio", "Capture Ratio"), ("hce", "HCE")),
    "count_median_ratio": (("colony_count", "Colonies"), ("median_radius_um", "Median radius"),
                           ("capture_ratio", "Capture Ratio")),
    "count": (("colony_count", "Colonies"),),
}


class PlatePhotos(Analysis):
    id = "plate_photos"
    name = "Plate photos"
    group = "Plates"
    description = ("Each plate's photo with its detected colonies outlined, laid out by Rows and Columns, "
                   "with its colony count and other per-plate numbers underneath.")
    unit = INDEX
    slots = (Slot("rows", "Rows", (NOMINAL, ORDINAL, REPLICATE),
                  description="Each level is one row of photos (for example Genotype)."),
             Slot("columns", "Columns", (ORDINAL, NOMINAL, REPLICATE),
                  description="Each level is one column of photos (for example Passage)."))
    options = (Option("values", "Numbers", (("count_ratio_hce", "Colonies, capture ratio, HCE"),
                                            ("count_median_ratio", "Colonies, median radius, capture ratio"),
                                            ("count", "Colonies")), "count_median_ratio"),
               Option("bar", "Scale bar", (("none", "None"), ("5", "5 mm"), ("10", "10 mm")), "none"))
    needs_images = True                           # Stats hands compute() a reader of each plate's photo

    def title(self, data, options):
        return "Detected colonies on each plate"

    def __init__(self):
        self._pictures: dict = {}                 # (reader owner, index id) -> reduced picture, for this session

    def problem(self, data):
        plates = len({int(i) for i, v in zip(data.index_ids, data.values) if np.isfinite(v)})
        if plates > MAX_PLATES:
            return (f"{plates} plates are shown; Plate photos draws at most {MAX_PLATES}. Switch off levels under "
                    "Plates used, or turn on one plate per group.")
        return ""

    def _picture(self, reader, index_id: int):
        key = (id(getattr(reader, "__self__", reader)), index_id)
        if key not in self._pictures:
            self._pictures[key] = _reduce(reader(index_id))
        return self._pictures[key]

    def compute(self, data, options):
        rows_axis, columns_axis = data.axes["rows"], data.axes["columns"]
        reader = getattr(data, "images", None)
        cells = {}
        for k, index_id in enumerate(np.asarray(data.index_ids)):
            r, c = int(data.positions["rows"][k]), int(data.positions["columns"][k])
            if r < 0 or c < 0 or not np.isfinite(data.values[k]):
                continue
            cells.setdefault((r, c), []).append(k)
        plates = []
        for (r, c), members in sorted(cells.items()):
            for k in members:
                index_id = int(data.index_ids[k])
                picture = self._picture(reader, index_id) if reader is not None else None
                numbers = []
                annotations = (data.plate_info or {}).get(index_id, {}).get("annotations", {})
                for key, label in VALUES[options.get("values", "count_median_ratio")]:
                    if key in (data.extra_measures or {}):
                        numbers.append((label, float(data.extra_measures[key][k]), key))
                    elif key in annotations:
                        numbers.append((label, _number(annotations[key]), key))
                parts = [x for x in (rows_axis.labels[r] if rows_axis.title else "",
                                     columns_axis.labels[c] if columns_axis.title else "") if x]
                plates.append({"index_id": index_id, "row": r, "column": c, "title": " · ".join(parts),
                               "picture": picture, "numbers": numbers})
        return {"title": self.title(data, options), "plates": plates, "bar": options.get("bar", "none"),
                "rows": rows_axis.labels, "columns": columns_axis.labels, "data": data}

    PRINT_COLUMNS, PRINT_ROWS = 5, 2                   # plates per printed page: two rows of five

    def draw(self, figure, result, style):
        if getattr(style, "print_mode", False) and result["plates"]:
            return self._draw_printed(figure, result, style)
        figure.clear()
        plates = result["plates"]
        if not plates:
            show_message(figure, "No plate is detected yet.", style)
            return None
        n_rows = max(p["row"] for p in plates) + 1
        per_row = {}
        for p in plates:
            per_row.setdefault(p["row"], []).append(p)
        columns = max(len(v) for v in per_row.values())
        if n_rows == 1 and columns > 5:                      # one long row: wrap it
            columns = math.ceil(math.sqrt(len(plates)) * 1.3)
            places = [(i // columns, i % columns) for i in range(len(plates))]
            n_rows = math.ceil(len(plates) / columns)
        else:
            places = []
            for p in plates:
                places.append((p["row"], per_row[p["row"]].index(p)))
        lines = max((len(p["numbers"]) for p in plates), default=0)
        gutter = 0.05 + 0.06 * lines
        height = (0.9 - 0.04) / n_rows
        width = 0.96 / columns
        for p, (r, c) in zip(plates, places):
            left, bottom = 0.02 + c * width, 0.92 - (r + 1) * height
            ax = figure.add_axes((left + width * 0.05, bottom + height * gutter / 0.9 + 0.01, width * 0.9,
                                  height * (1 - gutter / 0.9) - 0.03))
            ax.set_xticks([])
            ax.set_yticks([])
            for spine in ax.spines.values():
                spine.set_visible(False)
            picture = p["picture"]
            if picture is not None:
                image, outlines, px_per_mm = picture
                ax.imshow(image, cmap="gray", vmin=0, vmax=255, interpolation="bilinear")
                for outline in outlines:
                    ax.plot(outline[:, 0], outline[:, 1], color="#E0389A", linewidth=0.7)
                if result["bar"] != "none" and px_per_mm > 0:
                    length = float(result["bar"]) * px_per_mm
                    h, w = image.shape[:2]
                    ax.plot([w * 0.06, w * 0.06 + length], [h * 0.93] * 2, color="white", linewidth=2.5,
                            solid_capstyle="butt")
            ax.set_title(p["title"], fontsize=style.font_size - 1, color=style.ink, pad=3)
            for i, (label, value, key) in enumerate(p["numbers"]):
                ax.text(0.5, -0.03 - 0.085 * i, f"{label}  {_format(key, value)}", transform=ax.transAxes,
                        ha="center", va="top", fontsize=style.font_size - 2, color=style.ink)
        figure.suptitle(result["title"], fontsize=13, fontweight="bold", color=style.ink, x=0.02, ha="left", y=0.985)
        return None

    def _draw_printed(self, figure, result, style):
        """Printed pages: two rows of five photos per page at a fixed size in inches, each photo's values on
        their own lines beneath it; a list of figures when the plates need more than one page."""
        from matplotlib.figure import Figure
        plates = result["plates"]
        per_page = self.PRINT_COLUMNS * self.PRINT_ROWS
        chunks = [plates[k:k + per_page] for k in range(0, len(plates), per_page)]
        width, height = figure.get_size_inches()
        size, cell_w, cell_h, top = 1.25, width / self.PRINT_COLUMNS, 2.3, 0.45
        figures = []
        for page, chunk in enumerate(chunks):
            target = figure if page == 0 else Figure(figsize=(width, height), facecolor=style.background)
            target.clear()
            for k, p in enumerate(chunk):
                r, c = divmod(k, self.PRINT_COLUMNS)
                x = c * cell_w + (cell_w - size) / 2
                y_top = top + r * cell_h + 0.2                          # inches from the figure's top
                ax = target.add_axes((x / width, 1 - (y_top + size) / height, size / width, size / height))
                ax.set_xticks([])
                ax.set_yticks([])
                for spine in ax.spines.values():
                    spine.set_visible(False)
                picture = p["picture"]
                if picture is not None:
                    image, outlines, px_per_mm = picture
                    ax.imshow(image, cmap="gray", vmin=0, vmax=255, interpolation="bilinear")
                    for outline in outlines:
                        ax.plot(outline[:, 0], outline[:, 1], color="#E0389A", linewidth=0.5)
                    if result["bar"] != "none" and px_per_mm > 0:
                        length = float(result["bar"]) * px_per_mm
                        h, w = image.shape[:2]
                        ax.plot([w * 0.06, w * 0.06 + length], [h * 0.93] * 2, color="white", linewidth=1.5,
                                solid_capstyle="butt")
                ax.set_title(p["title"], fontsize=7.5, color=style.ink, pad=2)
                for i, (label, value, key) in enumerate(p["numbers"]):
                    ax.annotate(f"{label}  {_format(key, value)}", (0.5, 0), xycoords="axes fraction",
                                xytext=(0, -3 - 9 * i), textcoords="offset points", ha="center", va="top",
                                fontsize=7, color=style.ink)
            part = f" ({page + 1} of {len(chunks)})" if len(chunks) > 1 else ""
            target.text(0.0, 1 - 0.08 / height, result["title"] + part, ha="left", va="top", fontsize=10,
                        fontweight="bold", color=style.ink)
            figures.append(target)
        return figures if len(figures) > 1 else figures[0]

    def table(self, result):
        rows = []
        for p in result["plates"]:
            row = {"plate": p["title"] or p["index_id"], "index_id": p["index_id"]}
            row.update({label: value for label, value, _ in p["numbers"]})
            rows.append(row)
        return rows

    def notes(self, result):
        return list(result["data"].notes) + [f"{len(result['plates'])} plates drawn."]


def _number(text) -> float:
    try:
        return float(text)
    except (TypeError, ValueError):
        return float("nan")


def _format(key: str, value: float) -> str:
    if not np.isfinite(value):
        return "–"
    if key == "capture_ratio":
        return f"{value * 100:.1f}%"
    if key == "median_radius_um":
        return f"{value:.0f} µm"
    return f"{value:.0f}"


def _reduce(picture):
    """(gray image, colony outlines, px per mm) at no more than MAX_SIDE pixels on the longer side."""
    image, mask, colonies, px_per_mm = picture
    gray = np.asarray(image[..., :3], dtype=float) @ np.array([0.299, 0.587, 0.114]) if image.ndim == 3 else \
        np.asarray(image, dtype=float)
    if mask is not None:
        gray = np.where(mask, gray, 0.0)
    step = max(1, int(math.ceil(max(gray.shape) / MAX_SIDE)))
    small = gray[::step, ::step]
    outlines = []
    for i in range(len(colonies)):
        boundary = colonies.boundaries[i]
        if boundary is not None and len(boundary) > 2:
            outline = np.vstack([boundary, boundary[:1]]).astype(float)
        else:
            (x, y), radius = colonies.centers[i], float(colonies.radii[i])
            angles = np.linspace(0, 2 * np.pi, 32)
            outline = np.column_stack([x + radius * np.cos(angles), y + radius * np.sin(angles)])
        outlines.append(outline / step)
    return small, outlines, px_per_mm / step


ANALYSES = [PlatePhotos()]
