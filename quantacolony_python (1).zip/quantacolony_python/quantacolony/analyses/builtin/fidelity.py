"""Measurement fidelity: the uncertainty of each colony radius from ±0.5 px edge localization.

Always computed on raw pixel radii (0.5 / radius in px), never normalized.
A: histogram with five uncertainty zones. B: median uncertainty per row and column level.
C: the conclusion text.
"""

from __future__ import annotations

import math

import numpy as np
from matplotlib.colors import to_rgba
from matplotlib.layout_engine import LayoutEngine
from matplotlib.patches import Rectangle

from ...core import stats as st
from ..api import NOMINAL, ORDINAL, REPLICATE, Analysis, Option, Slot
from ..common import show_message

ZONE_NAMES = ("High", "Good", "Moderate", "Low", "Sub-pixel")


GRID_LEFT, GRID_RIGHT, GRID_FONT_MIN = 0.50, 0.985, 4.5


class _FitPanelB(LayoutEngine):
    """Keeps panel B's text inside its space at any figure size: the grid starts right of its row labels
    (which shrink, then wrap at ' · ', when they would push into panel A), and every cell's text shrinks to fit
    its cell, all cells at one size."""

    _adjust_compatible = True
    _colorbar_gridspec = False

    def __init__(self, grid, cell_texts, columns, rows):
        super().__init__()
        self.grid, self.cell_texts, self.columns, self.rows = grid, cell_texts, columns, rows
        self.base = cell_texts[0].get_fontsize() if cell_texts else 8
        self.labels = [t.get_text() for t in grid.get_yticklabels()]

    def execute(self, fig):
        if self.grid not in fig.axes:                           # the figure now shows another analysis
            return
        renderer = fig._get_renderer()
        width_px = fig.bbox.width
        grid = self.grid
        position = grid.get_position()
        ticks = grid.get_yticklabels()
        for size, wrap in ((8, False), (7, False), (6.5, True), (6, True), (5, True)):
            for tick, label in zip(ticks, self.labels):
                tick.set_text(label.replace(" · ", "\n") if wrap else label)
                tick.set_fontsize(size)
            widest = max((t.get_window_extent(renderer).width for t in ticks), default=0) + 8
            left = GRID_LEFT + widest / width_px
            if GRID_RIGHT - left >= 0.22:
                break
        grid.set_position([left, position.y0, max(0.1, GRID_RIGHT - left), position.height])
        cell_w = grid.bbox.width / max(self.columns, 1) * 0.92
        cell_h = grid.bbox.height / max(self.rows, 1) * 0.9
        scale = 1.0
        for text in self.cell_texts:
            text.set_fontsize(self.base)
            box = text.get_window_extent(renderer)
            if box.width > 0 and box.height > 0:
                scale = min(scale, cell_w / box.width, cell_h / box.height)
        size = max(GRID_FONT_MIN, self.base * scale)
        for text in self.cell_texts:
            text.set_fontsize(size)
        extra = getattr(self, "extra", None)
        if extra:
            self._fit_rest(fig, renderer, **extra)

    @staticmethod
    def _shrink(text, renderer, fits, start: float, smallest: float = 5.0) -> None:
        """The largest font size from start down to smallest at which fits(window extent) holds."""
        size = start
        text.set_fontsize(size)
        while size > smallest and not fits(text.get_window_extent(renderer)):
            size -= 0.5
            text.set_fontsize(size)

    def _fit_rest(self, fig, renderer, ax, zones, lines, title, note, conclusion) -> None:
        """Panel A's zone counts fit their zones (hidden when a zone is too narrow); its line labels, panel B's
        title and the conclusion stay inside their panels."""
        to_px = ax.transData.transform
        for label, (x0, x1) in zones:
            width = abs(to_px((x1, 0))[0] - to_px((x0, 0))[0]) - 4
            label.set_visible(True)
            self._shrink(label, renderer, lambda box, w=width: box.width <= w, 8, 5)
            label.set_visible(label.get_window_extent(renderer).width <= width)
        height = ax.bbox.height * 0.5
        for label in lines:
            self._shrink(label, renderer, lambda box: box.height <= height, 7.5, 5)
        right, top = fig.bbox.width - 4, fig.bbox.height - 2
        self._shrink(title, renderer, lambda box: box.x1 <= right, 11, 7)
        over = title.get_window_extent(renderer).y1 - top
        if over > 0:                                            # a short figure: lower panel B under its title
            position = self.grid.get_position()
            drop = over / fig.bbox.height
            self.grid.set_position([position.x0, position.y0, position.width, max(0.1, position.height - drop)])
        # the conclusion: wrapped to the panel's width at the largest size whose lines all fit
        import textwrap
        if not hasattr(conclusion, "_lines"):
            conclusion._lines = conclusion.get_text().split("\n")
        conclusion.set_wrap(False)
        box_note = note.get_window_extent(renderer)
        width = box_note.width - 16
        size = 9.5
        while True:
            conclusion.set_fontsize(size)
            per_char = conclusion.get_fontsize() * fig.dpi / 72 * 0.52
            chars = max(20, int(width / per_char))
            conclusion.set_text("\n".join(textwrap.fill(line, chars) for line in conclusion._lines))
            box = conclusion.get_window_extent(renderer)
            if (box.y0 >= box_note.y0 + 2 and box.x1 <= box_note.x1 - 4) or size <= 5:
                break
            size -= 0.5


class MeasurementFidelity(Analysis):
    id = "fidelity"
    name = "Measurement fidelity"
    group = "Measurement quality"
    description = ("Measurement uncertainty of each colony from ±0.5 px edge localization (0.5 / radius in px). "
                   "Always computed on raw pixel radii.")
    slots = (Slot("rows", "Rows", (NOMINAL, REPLICATE, ORDINAL),
                  description="Each level gets its own row of panels."),
             Slot("columns", "Columns", (ORDINAL, NOMINAL, REPLICATE),
                  description="Each level gets its own column of panels."))
    options = (Option("cell", "Cell value", (("colonies", "Median of all colonies"),
                                             ("plates", "Mean of plate medians")), "colonies"),)

    def compute(self, data, options):
        rows_axis, columns_axis = data.axes["rows"], data.axes["columns"]
        placed = (data.positions["rows"] >= 0) & (data.positions["columns"] >= 0)
        valid = placed & np.isfinite(data.radius_px) & (data.radius_px > 0)
        uncertainty = 0.5 / data.radius_px[valid] * 100
        counts, _ = np.histogram(uncertainty, bins=np.asarray(st.ZONE_EDGES))
        total = int(counts.sum())
        pct = counts / total * 100 if total else np.zeros(len(counts))
        medians = np.full((len(rows_axis), len(columns_axis)), np.nan)
        grid_counts = np.zeros((len(rows_axis), len(columns_axis)), dtype=int)
        every = np.where(valid, 0.5 / np.where(valid, data.radius_px, 1) * 100, np.nan)
        per_plate = options.get("cell") == "plates"
        plates = np.zeros((len(rows_axis), len(columns_axis)), dtype=int)
        areas = np.full((len(rows_axis), len(columns_axis)), np.nan)         # px of the cell's median colony
        for r in range(len(rows_axis)):
            for c in range(len(columns_axis)):
                keep = (data.positions["rows"] == r) & (data.positions["columns"] == c) & valid
                cell = every[keep]
                grid_counts[r, c] = cell.size
                ids = data.index_ids[keep]
                plates[r, c] = len(set(ids.tolist()))
                radii = data.radius_px[keep]
                if cell.size and per_plate:                  # each plate's median, then their mean
                    each = sorted(set(ids.tolist()))
                    medians[r, c] = float(np.mean([np.median(cell[ids == i]) for i in each]))
                    areas[r, c] = float(np.mean([math.pi * np.median(radii[ids == i]) ** 2 for i in each]))
                elif cell.size:
                    medians[r, c] = float(np.median(cell))
                    areas[r, c] = math.pi * float(np.median(radii)) ** 2
        row_labels = tuple(label or "All" for label in rows_axis.labels)
        column_labels = tuple(label or "All" for label in columns_axis.labels)
        used_rows = [r for r in range(len(row_labels)) if grid_counts[r].sum() > 0] or list(range(len(row_labels)))
        used_columns = [c for c in range(len(column_labels)) if grid_counts[:, c].sum() > 0] or \
            list(range(len(column_labels)))                 # a level combination nobody plated is no row
        medians, grid_counts = medians[np.ix_(used_rows, used_columns)], grid_counts[np.ix_(used_rows, used_columns)]
        plates, areas = plates[np.ix_(used_rows, used_columns)], areas[np.ix_(used_rows, used_columns)]
        row_labels = tuple(row_labels[r] for r in used_rows)
        column_labels = tuple(column_labels[c] for c in used_columns)
        conclusion = st.fidelity_conclusion(counts, pct, total, medians, grid_counts, row_labels, column_labels)
        overall = float(np.median(uncertainty)) if uncertainty.size else np.nan
        return {"per_plate": per_plate, "plates": plates, "overall": overall, "areas": areas,
                "uncertainty": uncertainty, "counts": counts, "pct": pct, "medians": medians,
                "grid_counts": grid_counts, "rows": row_labels, "columns": column_labels, "conclusion": conclusion,
                "indices": len(set(data.index_ids[valid].tolist()))}

    def draw(self, figure, result, style):
        figure.clear()
        figure.set_facecolor(style.background)
        if not len(result["uncertainty"]):
            show_message(figure, "No colonies with a measured radius yet.", style)
            return None
        ink, zone_colors = style.ink, style.zone_colors
        ax = figure.add_axes((0.07, 0.36, 0.40, 0.56))
        zone_texts, zone_labels, line_labels = [], [], []
        x_max = min(100.0, max(55.0, math.ceil(float(result["uncertainty"].max()) / 5) * 5))
        edges = np.arange(0, x_max + 0.5, 0.5)
        counts, _ = np.histogram(np.minimum(result["uncertainty"], x_max - 0.25), bins=edges)
        y_max = max(counts.max() * 1.25, 1)
        zone_edges = list(st.ZONE_EDGES[:-1]) + [x_max]
        for z in range(5):
            ax.add_patch(Rectangle((zone_edges[z], 0), zone_edges[z + 1] - zone_edges[z], y_max,
                                   color=zone_colors[z], alpha=0.25, linewidth=0))
            zone_texts.append((zone_edges[z], zone_edges[z + 1]))
            zone_labels.append(ax.text((zone_edges[z] + zone_edges[z + 1]) / 2, y_max * 0.97,
                    f"{result['counts'][z]}\n({result['pct'][z]:.1f}%)", ha="center", va="top", fontsize=8,
                    fontweight="bold", bbox={"facecolor": style.background, "edgecolor": style.panel_edge, "pad": 2.5}))
        ax.bar(edges[:-1] + 0.25, counts, width=0.5, color=style.bar, alpha=0.7)
        for value, text in zip((5, 10, 25, 50), ("5% (10 px)", "10% (5 px)", "25% (2 px)", "50% (1 px)")):
            ax.axvline(value, color=style.bar, linestyle="--", linewidth=1.2)
            line_labels.append(ax.text(value, y_max * 0.32, "  " + text, rotation=90, va="center", ha="left", fontsize=7.5,
                    fontweight="bold", color=style.bar,
                    bbox={"facecolor": style.background, "edgecolor": "none", "pad": 1}))
        ax.set_xlim(0, x_max)
        ax.set_ylim(0, y_max)
        ax.set_xlabel("Measurement uncertainty (%)", color=ink)
        ax.set_ylabel("Colony count", color=ink)
        ax.set_title("A   Project-wide measurement fidelity", fontsize=11, fontweight="bold", color=ink, loc="left")
        ax.tick_params(labelsize=9)

        grid = figure.add_axes((0.62, 0.36, 0.36, 0.56))
        rows, columns = len(result["rows"]), len(result["columns"])
        cell_texts = []
        for r in range(rows):
            for c in range(columns):
                value, count = result["medians"][r, c], result["grid_counts"][r, c]
                color = (to_rgba(zone_colors[st.zone_of(value)], 0.5) if np.isfinite(value)
                         else to_rgba(style.empty_cell))
                grid.add_patch(Rectangle((c, rows - r - 1), 1, 1, facecolor=color, edgecolor=style.spine,
                                         linewidth=0.8))
                if np.isfinite(value):
                    area = result["areas"][r, c]
                    extra = f", n = {result['plates'][r, c]}" if result["per_plate"] else f"\nn={count}"
                    text = f"{value:.1f}%, {area:.0f} px\n{ZONE_NAMES[st.zone_of(value)]}{extra}"
                else:
                    text = "no data"
                cell_texts.append(grid.text(c + 0.5, rows - r - 0.5, text, ha="center", va="center",
                                            fontsize=8 if rows * columns <= 40 else 6.5, color=ink))
        grid.set_xlim(0, columns)
        grid.set_ylim(0, rows)
        grid.set_xticks(np.arange(columns) + 0.5, result["columns"], fontsize=8)
        grid.set_yticks(np.arange(rows) + 0.5, list(reversed(result["rows"])), fontsize=8)
        grid.xaxis.tick_top()
        grid.tick_params(length=0)
        for spine in grid.spines.values():
            spine.set_visible(False)
        title_b = grid.set_title("B   Mean of per-plate median uncertainty" if result["per_plate"] else
                       "B   Median uncertainty per group", fontsize=11, fontweight="bold", color=ink, loc="left", pad=22)
        if np.isfinite(result["overall"]):
            area = math.pi * (0.5 / (result["overall"] / 100)) ** 2
            ax.text(0.98, 0.62, f"Median colony: {result['overall']:.1f}%, {area:.0f} px", transform=ax.transAxes,
                    ha="right", va="top", fontsize=8.5, color=ink,
                    bbox={"facecolor": style.background, "edgecolor": style.panel_edge, "pad": 2.5})

        note = figure.add_axes((0.07, 0.03, 0.91, 0.22))
        note.set_xticks([])
        note.set_yticks([])
        for spine in note.spines.values():
            spine.set_color(style.panel_edge)
        note.text(0.015, 0.92, "C   Conclusion", fontsize=11, fontweight="bold", color=ink, va="top",
                  transform=note.transAxes)
        conclusion = note.text(0.015, 0.70, "\n".join(result["conclusion"]), fontsize=9.5, color=ink, va="top",
                               wrap=True, transform=note.transAxes)
        fit = _FitPanelB(grid, cell_texts, columns, rows)        # refits at every draw size
        fit.extra = dict(ax=ax, zones=list(zip(zone_labels, zone_texts)), lines=line_labels, title=title_b,
                         note=note, conclusion=conclusion)
        figure.set_layout_engine(fit)
        return None

    def table(self, result):
        name = "mean_plate_median_uncertainty_pct" if result["per_plate"] else "median_uncertainty_pct"
        return [{"row": result["rows"][r], "column": result["columns"][c],
                 "colonies": int(result["grid_counts"][r, c]), "plates": int(result["plates"][r, c]),
                 name: float(result["medians"][r, c]),
                 "category": ZONE_NAMES[st.zone_of(result["medians"][r, c])] if np.isfinite(result["medians"][r, c])
                 else ""}
                for r in range(len(result["rows"])) for c in range(len(result["columns"]))]

    def notes(self, result):
        return [f"{len(result['uncertainty'])} colonies from {result['indices']} indices."]


ANALYSES = [MeasurementFidelity()]
