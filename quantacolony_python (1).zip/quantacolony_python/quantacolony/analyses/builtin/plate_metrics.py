"""Plate metrics: one value per index (colony count, coverage, ...), compared across levels.

Each index is one point; the bar marks the mean of its group and the whiskers ±1 standard
deviation. View: Bars draws that chart, Table writes the same cells as a grid (x-axis levels as rows,
groups as columns). Values: Show writes each bar's mean above it. Groups sit side by side at each x-axis level. The capture ratio is drawn with the
separable-range cutoff (25%): plates below it hold growth that merged instead of forming
separate colonies.
"""

from __future__ import annotations

import numpy as np

from ...core.growth import SEPARABLE_CAPTURE_RATIO
from ..api import INDEX, NOMINAL, ORDINAL, REPLICATE, Analysis, Option, Slot
from ..common import level_ticks, show_message, style_axes

SPREAD = 0.7                                      # width of one x-axis level taken by its groups


class PlateMetrics(Analysis):
    id = "plate_metrics"
    name = "Plate metrics"
    group = "Plates"
    unit = INDEX
    description = ("One value per index: colony count, growth coverage, colony coverage, capture ratio or mean "
                   "colony radius. Points are indices; bars show the group mean ± 1 SD.")
    slots = (Slot("x", "X axis", (ORDINAL, NOMINAL, REPLICATE),
                  description="Each level is one position along the x axis; every plate is one point."),
             Slot("groups", "Groups", (NOMINAL, REPLICATE, ORDINAL),
                  description="Each level is its own color (for example Genotype)."))
    normalize = ("groups", "x")
    color_slots = ("groups",)                         # the legend names one color per group
    options = (Option("view", "View", (("bars", "Bars"), ("table", "Table")), "bars"),
               Option("values", "Values", (("hide", "Hide"), ("show", "Over each bar")), "hide"))

    @staticmethod
    def value_text(value: float, measure: str) -> str:
        """A cell's value as the figure writes it: percent for ratios and coverage, whole numbers for counts."""
        if not np.isfinite(value):
            return ""
        if measure in ("capture_ratio", "growth_coverage", "colony_coverage") or measure.endswith("coverage"):
            return f"{value:.1%}"
        if measure == "colony_count" or float(value).is_integer():
            return f"{value:.0f}"
        return f"{value:.3g}"

    def title(self, data, options):
        across = f" across {data.axes['x'].title}" if data.axes["x"].title else ""
        return f"{data.value_label.split(' (')[0]}{across}, {data.scheme_label}"

    def compute(self, data, options):
        cells = {}
        for g in range(len(data.axes["groups"])):
            for x in range(len(data.axes["x"])):
                keep = data.select(groups=g, x=x)
                values = data.values[keep]
                if values.size:
                    cells[(g, x)] = {"values": values, "index_ids": data.index_ids[keep], "n": int(values.size),
                                     "mean": float(np.mean(values)),
                                     "sd": float(np.std(values, ddof=1)) if values.size > 1 else 0.0}
        return {"title": self.title(data, options), "data": data, "cells": cells,
                "view": options.get("view", "bars"), "values": options.get("values", "hide")}

    def draw(self, figure, result, style):
        figure.clear()
        data, cells = result["data"], result["cells"]
        if not cells:
            show_message(figure, "No index has this measurement yet.", style)
            return None
        if result.get("view") == "table":
            self._draw_table(figure, result, style)
            return None
        ax = figure.add_axes((0.08, 0.14, 0.68, 0.76))
        style_axes(ax, style)
        n_groups = len(data.axes["groups"])
        step = SPREAD / n_groups
        rng = np.random.default_rng(0)                            # fixed jitter: the figure redraws identically
        drawn = set()
        for (g, x), cell in sorted(cells.items()):
            center = x + 1 + (g - (n_groups - 1) / 2) * step
            color = style.color_for(data, groups=g) or style.group_color(g)
            label = (data.axes["groups"].labels[g] or "All indices") if g not in drawn else None
            drawn.add(g)
            ax.bar(center, cell["mean"], width=step * 0.8, color=color, alpha=0.25, edgecolor=color, label=label)
            ax.errorbar(center, cell["mean"], yerr=cell["sd"], color=color, capsize=3, linewidth=1.2)
            jitter = rng.uniform(-step * 0.25, step * 0.25, cell["n"])
            ax.scatter(center + jitter, cell["values"], s=18, color=color, edgecolor=style.ink, linewidth=0.4,
                       zorder=3)
            if result.get("values") == "show":
                top = max(cell["mean"] + cell["sd"], float(np.nanmax(cell["values"])))
                ax.annotate(self.value_text(cell["mean"], data.measure), (center, top), xytext=(0, 4),
                            textcoords="offset points", ha="center", va="bottom", fontsize=style.font_size,
                            color=style.ink, zorder=6)
        level_ticks(ax, list(data.axes["x"].labels), style)
        ax.set_xlim(0.4, len(data.axes["x"]) + 0.6)
        if data.measure == "capture_ratio" and data.scheme == "raw":
            ax.axhline(SEPARABLE_CAPTURE_RATIO, color=style.muted, linestyle="--", linewidth=1.2, zorder=1)
            ax.text(len(data.axes["x"]) + 0.55, SEPARABLE_CAPTURE_RATIO, f"{SEPARABLE_CAPTURE_RATIO:.0%} cutoff: "
                    "below it, colonies merged (overplated)", va="bottom", ha="right", fontsize=style.font_size, color=style.ink, zorder=5,
                    bbox={"facecolor": style.background, "edgecolor": style.muted, "boxstyle": "round,pad=0.3",
                          "alpha": 0.92})
            ax.set_ylim(bottom=0)
        ax.set_ylabel(data.value_label, color=style.ink)
        if data.axes["x"].title:
            ax.set_xlabel(data.axes["x"].title, color=style.ink)
        ax.legend(loc="upper left", bbox_to_anchor=(1.02, 1.0), frameon=False, fontsize=9,
                  title=data.axes["groups"].title or None, title_fontsize=9)
        ax.set_title(result["title"], fontsize=13, fontweight="bold", color=style.ink, loc="left")
        return None

    def _draw_table(self, figure, result, style):
        """The cells as a grid: one row per x-axis level, one column per group; mean ± SD (n) for pooled cells."""
        data, cells = result["data"], result["cells"]
        groups = [label or "All indices" for label in data.axes["groups"].labels]
        levels = [label or "All" for label in data.axes["x"].labels]
        text = []
        for x in range(len(levels)):
            row = []
            for g in range(len(groups)):
                cell = cells.get((g, x))
                if cell is None:
                    row.append("")
                elif cell["n"] == 1:
                    row.append(self.value_text(cell["mean"], data.measure))
                else:
                    row.append(f"{self.value_text(cell['mean'], data.measure)} ± "
                               f"{self.value_text(cell['sd'], data.measure)} (n={cell['n']})")
            text.append(row)
        ax = figure.add_axes((0.04, 0.04, 0.92, 0.84))
        ax.axis("off")
        table = ax.table(cellText=text, rowLabels=levels, colLabels=groups, loc="upper center", cellLoc="center")
        table.auto_set_font_size(False)
        table.set_fontsize(max(9, style.font_size))
        table.scale(1, 1.6)
        for (r, c), cell in table.get_celld().items():
            cell.set_edgecolor(style.muted)
            cell.get_text().set_color(style.ink)
            if r == 0 or c == -1:
                cell.get_text().set_fontweight("bold")
        corner = data.axes["x"].title or ""
        if corner:
            ax.text(0.0, 1.0, f"Rows: {corner}" + (f"   ·   Columns: {data.axes['groups'].title}"
                                                   if data.axes["groups"].title else ""),
                    transform=ax.transAxes, fontsize=style.font_size, color=style.muted, va="bottom")
        figure.suptitle(result["title"], fontsize=13, fontweight="bold", color=style.ink, x=0.04, ha="left")

    def table(self, result):
        data = result["data"]
        group_title, x_title = data.axes["groups"].title or "Group", data.axes["x"].title or "X"
        return [{group_title: data.axes["groups"].labels[g], x_title: data.axes["x"].labels[x], "indices": cell["n"],
                 "mean": cell["mean"], "sd": cell["sd"],
                 "values": " ".join(f"{v:.4g}" for v in cell["values"])}
                for (g, x), cell in sorted(result["cells"].items())]

    def notes(self, result):
        data = result["data"]
        notes = list(data.notes) + [f"{int(np.isfinite(data.values).sum())} indices with this measurement."]
        if data.measure == "capture_ratio" and data.scheme == "raw":
            below = int(np.sum(data.values[np.isfinite(data.values)] < SEPARABLE_CAPTURE_RATIO))
            notes.append(f"{below} below the {SEPARABLE_CAPTURE_RATIO:.0%} cutoff. Colonies on those plates merged, so "
                         "their colony count and sizes are not reliable; 'Overplated: Leave out' removes "
                         "them from every analysis.")
        return notes


ANALYSES = [PlateMetrics()]
