"""Helpers the built-in analyses share: per-group statistics on two slots, and figure styling.

Any analysis may use these; none has to.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from ..core import stats as st
from .api import AnalysisData, PlotStyle
from .data import RAW


# ----- per-group statistics -----------------------------------------------------------
@dataclass(frozen=True)
class GroupStatistics:
    first: str                                    # level label on the first slot
    second: str                                   # level label on the second slot
    n: int
    values: dict                                  # statistic name -> value
    density: np.ndarray | None                    # on the shared grid, None when n < 3
    bandwidth: float


@dataclass(frozen=True)
class GroupedStatistics:
    data: AnalysisData
    first: str                                    # slot keys
    second: str
    grid: np.ndarray
    groups: dict = field(default_factory=dict)    # (first pos, second pos) -> GroupStatistics


def density_grid(values: np.ndarray, points: int = 200) -> np.ndarray:
    finite = values[np.isfinite(values)]
    top = float(np.max(finite)) * 1.1 if finite.size else 1.0
    low = min(0.0, float(np.min(finite)) * 1.1) if finite.size else 0.0
    return np.linspace(low, top, points)


def group_bandwidth(data: AnalysisData, keep: np.ndarray) -> float:
    """Freedman-Diaconis bandwidth of one group, floored at one pixel (raw) or 0.05 (normalized)."""
    floor = st.bandwidth_floor(data.um_per_px[keep], normalized=data.scheme != RAW)
    return st.bandwidth(data.values[keep], floor)


def grouped_statistics(data: AnalysisData, first: str, second: str) -> GroupedStatistics:
    """Summary statistics, density and peak of every (first, second) level pair with values."""
    grid = density_grid(data.values)
    groups = {}
    for a in range(len(data.axes[first])):
        for b in range(len(data.axes[second])):
            keep = data.select(**{first: a, second: b})
            values = data.values[keep]
            if values.size == 0:
                continue
            stats = st.summary_values(values)
            density, h = None, np.nan
            if values.size >= 3:
                h = group_bandwidth(data, keep)
                density = st.kde(values, grid, h)
                peak = int(np.argmax(density))
                stats["Peak Location"], stats["Peak Density"] = float(grid[peak]), float(density[peak])
            else:
                stats["Peak Location"] = stats["Peak Density"] = np.nan
            groups[(a, b)] = GroupStatistics(data.axes[first].labels[a], data.axes[second].labels[b],
                                             int(values.size), stats, density, float(h))
    return GroupedStatistics(data, first, second, grid, groups)


def statistics_rows(grouped: GroupedStatistics) -> list[dict]:
    """One row per group, for Save table."""
    data = grouped.data
    first_title = data.axes[grouped.first].title or grouped.first.capitalize()
    second_title = data.axes[grouped.second].title or grouped.second.capitalize()
    rows = []
    for (_, _), group in sorted(grouped.groups.items()):
        row = {first_title: group.first, second_title: group.second, "n": group.n, "Bandwidth": group.bandwidth}
        row.update(group.values)
        rows.append(row)
    return rows


# ----- figure styling ---------------------------------------------------------------------
def style_axes(ax, style: PlotStyle) -> None:
    ax.set_facecolor(style.background)
    ax.spines[["top", "right"]].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_color(style.spine)
    ax.tick_params(colors=style.ink, labelsize=style.font_size - 1)
    ax.grid(True, color=style.grid, linewidth=0.8)
    ax.set_axisbelow(True)


def show_message(figure, message: str, style: PlotStyle) -> None:
    figure.clear()
    figure.set_facecolor(style.background)
    figure.text(0.5, 0.5, message, ha="center", va="center", color=style.muted, fontsize=style.font_size + 2,
                wrap=True)


def panel_grid(figure, count: int, max_columns: int = 4, **subplot_args):
    """count axes in a grid of at most max_columns; unused cells hidden. Returns (axes list, columns, rows)."""
    columns = max(1, min(max_columns, count))
    rows = max(1, math.ceil(count / columns))
    grid = figure.subplots(rows, columns, squeeze=False, **subplot_args)
    axes = [grid[k // columns][k % columns] for k in range(rows * columns)]
    for ax in axes[count:]:
        ax.set_visible(False)
    return axes[:count], columns, rows


def print_heading(label: str, width: int = 16) -> str:
    """A panel heading for a printed page: each ' · ' part on its own line, long parts broken at spaces."""
    import textwrap
    lines = []
    for part in (label or "").split(" · "):
        lines.extend(textwrap.wrap(part, width) or [""])
    return "\n".join(lines)


def print_panels(figure, count: int, max_columns: int = 4, heading_lines: int = 2, legend_row: bool = False,
                 **subplot_args):
    """Panels for a printed page: like panel_grid, with room between rows for headings of heading_lines
    lines (about 7 pt each) and, with legend_row, a band beneath the panels for one shared legend."""
    columns = max(1, min(max_columns, count))
    rows = max(1, math.ceil(count / columns))
    height = figure.get_figheight()
    head = (0.12 + 0.14 * heading_lines) / height                 # figure fraction for one row's heading
    bottom = (0.95 if legend_row else 0.42) / height
    top = 1 - 0.42 / height - head
    panel = (top - bottom - (rows - 1) * (head + 0.42 / height)) / rows
    grid = figure.subplots(rows, columns, squeeze=False, gridspec_kw={
        "left": 0.75 / figure.get_figwidth(), "right": 0.99, "bottom": bottom, "top": top, "wspace": 0.18,
        "hspace": (head + 0.42 / height) / max(panel, 0.05)}, **subplot_args)
    axes = [grid[k // columns][k % columns] for k in range(rows * columns)]
    for ax in axes[count:]:
        ax.set_visible(False)
    return axes[:count], columns, rows


def plain_log_axis(axis) -> None:
    """Round-number ticks on a log axis (100, 200, 500, 1000, ...) labelled as plain numbers."""
    from matplotlib.ticker import FuncFormatter, LogLocator, NullFormatter
    axis.set_major_locator(LogLocator(base=10, subs=(1.0, 2.0, 5.0)))
    axis.set_major_formatter(FuncFormatter(lambda value, _: f"{value:g}"))
    axis.set_minor_formatter(NullFormatter())


def level_ticks(ax, labels, style: PlotStyle, positions=None) -> None:
    positions = np.arange(1, len(labels) + 1) if positions is None else positions
    rotate = 30 if labels and max(map(len, labels)) > 8 else 0
    ax.set_xticks(positions, labels, rotation=rotate, ha="right" if rotate else "center")
