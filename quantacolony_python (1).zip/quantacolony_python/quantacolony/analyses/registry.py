"""Finds the analyses Stats offers: the built-in ones, then any in the library's Analyses folder.

A module offers analyses through a list named ANALYSES (or a single one named ANALYSIS). A
file that fails to load, or an analysis that breaks the contract, is skipped and reported;
it never stops Stats from opening. Loading a file runs its Python code, so only put files
you trust in the Analyses folder.
"""

from __future__ import annotations

import importlib
import importlib.util
import sys
import traceback
from pathlib import Path

from .api import API_VERSION, COLONY, INDEX, LoadReport, Option, Slot

BUILTIN_MODULES = ("distributions", "per_plate", "across_levels", "fidelity", "subpopulations", "plate_metrics", "predictors",
                   "shape", "photos")
GROUP_ORDER = ("Distributions", "Across ordinal levels", "Measurement quality", "Subpopulations", "Plates")


def contract_problem(analysis) -> str:
    """Why an object cannot be used as an analysis, or ''."""
    for attribute in ("id", "name", "compute", "draw"):
        if not getattr(analysis, attribute, None):
            return f"it has no {attribute}"
    if getattr(analysis, "unit", COLONY) not in (COLONY, INDEX):
        return f"unit must be '{COLONY}' or '{INDEX}'"
    if getattr(analysis, "api_version", API_VERSION) > API_VERSION:
        return f"it needs a newer QuantaColony (analysis API {analysis.api_version}, this one is {API_VERSION})"
    slots = getattr(analysis, "slots", ())
    if not all(isinstance(slot, Slot) for slot in slots):
        return "every slot must be an analyses.api.Slot"
    if len({slot.key for slot in slots}) != len(slots):
        return "two slots share a key"
    if not all(isinstance(option, Option) for option in getattr(analysis, "options", ())):
        return "every option must be an analyses.api.Option"
    normalize = getattr(analysis, "normalize", None)
    if normalize is not None and not set(normalize) <= {slot.key for slot in slots}:
        return "normalize names a slot it does not have"
    return ""


def _offered(module) -> list:
    if hasattr(module, "ANALYSES"):
        return list(module.ANALYSES)
    if hasattr(module, "ANALYSIS"):
        return [module.ANALYSIS]
    return []


def _add(report: LoadReport, analysis, source: str) -> None:
    problem = contract_problem(analysis)
    name = getattr(analysis, "name", "") or getattr(analysis, "id", "") or repr(analysis)
    if problem:
        report.problems.append(f"{source}: '{name}' was skipped because {problem}.")
    elif analysis.id in report.analyses:
        report.problems.append(f"{source}: '{name}' was skipped because another analysis already has the id "
                               f"'{analysis.id}' ({report.sources[analysis.id]}).")
    else:
        report.analyses[analysis.id] = analysis
        report.sources[analysis.id] = source


def load_analyses(user_folder: Path | None = None) -> LoadReport:
    report = LoadReport()
    for name in BUILTIN_MODULES:
        module = importlib.import_module(f"{__package__}.builtin.{name}")
        for analysis in _offered(module):
            _add(report, analysis, "built-in")
    if user_folder is not None and Path(user_folder).is_dir():
        for path in sorted(Path(user_folder).glob("*.py")):
            module_name = f"quantacolony_user_analysis_{path.stem}"
            try:
                spec = importlib.util.spec_from_file_location(module_name, path)
                module = importlib.util.module_from_spec(spec)
                sys.modules[module_name] = module
                spec.loader.exec_module(module)
            except Exception:                                    # any error in a user file is reported, not raised
                sys.modules.pop(module_name, None)
                last = traceback.format_exc().strip().splitlines()[-1]
                report.problems.append(f"{path.name} could not be loaded: {last}")
                continue
            offered = _offered(module)
            if not offered:
                report.problems.append(f"{path.name} defines no ANALYSES list.")
            for analysis in offered:
                _add(report, analysis, path.name)
    return report


def sections(report: LoadReport) -> list[tuple[str, list[tuple[str, str]]]]:
    """(group title, [(id, name)]) in the built-in group order, then other groups alphabetically."""
    groups: dict[str, list[tuple[str, str]]] = {}
    for analysis in report.analyses.values():
        groups.setdefault(analysis.group or "Other", []).append((analysis.id, analysis.name))
    order = [g for g in GROUP_ORDER if g in groups] + sorted(g for g in groups if g not in GROUP_ORDER)
    return [(group, groups[group]) for group in order]


BUILT_IN_TITLE = "QuantaColony Sourced Analyses"
ADDED_TITLE = "Analyses you added"


def sections_by_origin(report: LoadReport) -> list[tuple[str, list[tuple[str, list[tuple[str, str]]]]]]:
    """(top title, [(group title, [(id, name)])]): the built-in analyses under one heading, and the
    analyses loaded from the library's Analyses folder under another. The second heading appears
    only when such a file contributed an analysis."""
    built_in = LoadReport(analyses={k: v for k, v in report.analyses.items()
                                    if report.sources.get(k) == "built-in"}, sources=report.sources)
    added = LoadReport(analyses={k: v for k, v in report.analyses.items()
                                 if report.sources.get(k) != "built-in"}, sources=report.sources)
    result = [(BUILT_IN_TITLE, sections(built_in))]
    if added.analyses:
        result.append((ADDED_TITLE, sections(added)))
    return result


EXAMPLE = '''"""An example QuantaColony analysis. Rename this file to end in .py to load it.

Every file ending in .py in this folder is loaded when Stats opens. Each defines ANALYSES, a
list of analysis objects. See quantacolony/analyses/api.py for the full contract.
"""

import numpy as np

from quantacolony.analyses.api import NOMINAL, ORDINAL, REPLICATE, Analysis, Slot
from quantacolony.analyses.common import show_message, style_axes


class ColonyCounts(Analysis):
    id = "example:colony_counts"            # unique; prefix it with something of your own
    name = "Colony counts"
    group = "My analyses"
    description = "Number of colonies for every level of the x axis."
    unit = "colony"                          # 'colony' (a row per colony) or 'index' (a row per index)
    slots = (Slot("x", "X axis", (NOMINAL, ORDINAL, REPLICATE), min_variables=1),)

    def compute(self, data, options):
        axis = data.axes["x"]
        counts = [int(data.select(x=i).sum()) for i in range(len(axis))]
        return {"labels": list(axis.labels), "counts": counts, "title": axis.title}

    def draw(self, figure, result, style):
        figure.clear()
        if not sum(result["counts"]):
            show_message(figure, "No colonies yet.", style)
            return None
        ax = figure.add_subplot(111)
        style_axes(ax, style)
        ax.bar(np.arange(len(result["counts"])), result["counts"], color=style.group_color(0))
        ax.set_xticks(np.arange(len(result["labels"])), result["labels"])
        ax.set_xlabel(result["title"], color=style.ink)
        ax.set_ylabel("Colonies", color=style.ink)
        return None

    def table(self, result):
        return [{"level": label, "colonies": count} for label, count in zip(result["labels"], result["counts"])]


ANALYSES = [ColonyCounts()]
'''

CLASSIFIER_EXAMPLE = '''"""Nearest-centroid classifier on per-plate shape features. Rename to end in .py to load it.

Each plate becomes one point in (coefficient of variation, skew) space, computed from its
colony radii. Each Classes level gets a centroid; every plate is assigned to the nearest
centroid in z-scored feature space, and the accuracy says how separable the classes are by
distribution shape alone. Compare against the baseline (always guessing the largest class).
"""

import numpy as np

from quantacolony.analyses.api import NOMINAL, ORDINAL, REPLICATE, Analysis, Slot
from quantacolony.analyses.common import show_message, style_axes
from quantacolony.core.stats import summary_values

MIN_COLONIES = 10                                 # plates with fewer are left out


class ShapeClassifier(Analysis):
    id = "example:shape_classifier"
    name = "Shape classifier"
    group = "My analyses"
    description = ("Nearest-centroid assignment of every plate in (CV, skew) space, one centroid per "
                   "Classes level. Accuracy over the baseline shows how separable the classes are by "
                   "distribution shape alone.")
    unit = "colony"
    slots = (Slot("classes", "Classes", (NOMINAL, ORDINAL, REPLICATE), min_variables=1,
                  description="Each level is one class with its own centroid."),)
    color_slots = ("classes",)

    def compute(self, data, options):
        plates = []
        for index_id in sorted({int(i) for i in data.index_ids}):
            keep = (data.index_ids == index_id) & np.isfinite(data.values)
            c = data.positions["classes"][keep]
            if keep.sum() < MIN_COLONIES or len(set(c.tolist())) != 1 or c[0] < 0:
                continue
            stats = summary_values(data.values[keep])
            plates.append({"index_id": index_id, "class": int(c[0]), "n": int(keep.sum()),
                           "cv": stats["Coefficient Of Variation"], "skew": stats["Skew"]})
        if len(plates) < 4:
            return {"plates": plates, "data": data}
        cv = np.array([p["cv"] for p in plates])
        skew = np.array([p["skew"] for p in plates])
        labels = np.array([p["class"] for p in plates])
        z = np.stack([(cv - cv.mean()) / (cv.std() or 1.0), (skew - skew.mean()) / (skew.std() or 1.0)], axis=1)
        classes = sorted(set(labels.tolist()))
        centroids = {c: z[labels == c].mean(axis=0) for c in classes}
        for i, p in enumerate(plates):
            distances = {c: float(np.linalg.norm(z[i] - centroid)) for c, centroid in centroids.items()}
            p["assigned"] = min(distances, key=distances.get)
            p["correct"] = p["assigned"] == p["class"]
        correct = sum(p["correct"] for p in plates)
        baseline = max(np.bincount(labels).max() / len(labels), 1.0 / len(classes))
        per_class = {c: (sum(p["correct"] for p in plates if p["class"] == c),
                         sum(1 for p in plates if p["class"] == c)) for c in classes}
        raw_centroids = {c: (float(cv[labels == c].mean()), float(skew[labels == c].mean())) for c in classes}
        return {"plates": plates, "data": data, "accuracy": correct / len(plates),
                "baseline": float(baseline), "per_class": per_class, "centroids": raw_centroids}

    def draw(self, figure, result, style):
        figure.clear()
        data, plates = result["data"], result["plates"]
        if "accuracy" not in result:
            show_message(figure, f"Needs at least 4 plates with {MIN_COLONIES}+ colonies.", style)
            return None
        ax = figure.add_axes((0.1, 0.12, 0.64, 0.78))
        style_axes(ax, style)
        drawn = set()
        for p in plates:
            color = style.color_for(data, classes=p["class"]) or style.group_color(p["class"])
            label = data.axes["classes"].labels[p["class"]] if p["class"] not in drawn else None
            drawn.add(p["class"])
            ax.scatter(p["cv"], p["skew"], s=36, color=color, label=label, zorder=3,
                       edgecolor=style.ink if p["correct"] else "#D62728",
                       linewidth=0.5 if p["correct"] else 1.8)
        for c, (x, y) in result["centroids"].items():
            color = style.color_for(data, classes=c) or style.group_color(c)
            ax.scatter(x, y, s=180, marker="X", color=color, edgecolor=style.ink, linewidth=1.2, zorder=4)
        ax.set_xlabel("Coefficient of variation (per plate)", color=style.ink)
        ax.set_ylabel("Skew (per plate)", color=style.ink)
        ax.text(0.03, 0.97, f"accuracy {result[\'accuracy\']:.0%}\\nbaseline {result[\'baseline\']:.0%}",
                transform=ax.transAxes, va="top", fontsize=style.font_size, color=style.ink,
                bbox={"facecolor": style.background, "edgecolor": style.spine, "boxstyle": "round,pad=0.35"})
        ax.legend(loc="upper left", bbox_to_anchor=(1.02, 1.0), frameon=False, fontsize=9,
                  title=data.axes["classes"].title or None, title_fontsize=9)
        ax.set_title("Nearest-centroid assignment, red edge = misassigned", fontsize=12,
                     fontweight="bold", color=style.ink, loc="left")
        return None

    def table(self, result):
        data = result["data"]
        labels = data.axes["classes"].labels
        return [{"plate": p["index_id"], "class": labels[p["class"]], "n": p["n"], "cv": p["cv"],
                 "skew": p["skew"], "assigned": labels[p.get("assigned", p["class"])],
                 "correct": p.get("correct", "")} for p in result["plates"]]

    def notes(self, result):
        if "accuracy" not in result:
            return []
        parts = [f"{labels_n[0]}/{labels_n[1]} correct" for labels_n in result["per_class"].values()]
        return [f"Accuracy {result[\'accuracy\']:.0%} over {len(result[\'plates\'])} plates "
                f"(baseline {result[\'baseline\']:.0%}; per class: {\', \'.join(parts)})."]


ANALYSES = [ShapeClassifier()]
'''

