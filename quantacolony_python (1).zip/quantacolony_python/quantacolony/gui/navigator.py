"""Navigator: which screen is open. Every screen shows in the master window's main panel (gui/shell.py).

    Home page (projects)  ->  project page  ->  Cropping / Colony Detection / Stats
                          <-                <-  closing a module, or its Back button

Closing the home page or the project page quits; closing a module returns to the
project page. The tutorial panel (gui/tutorial.py) shows in the master window's dock; tutorial_state
tells it what is on screen. The DataManager keeps one project open while its page or a module is
showing, and closes it (leaving a backup when it changed) on the way back home.
"""

from __future__ import annotations

from PySide6.QtCore import Qt, QEvent, QObject, QTimer
from PySide6.QtWidgets import QApplication

from ..data import DataManager, ProjectError
from .home import HomeController, HomeWindow
from .launch import open_cropping, open_detection, open_stats
from .project_page import ProjectController, ProjectWindow
from .dialogs import ERROR, SUCCESS, WARNING, notify


class Navigator(QObject):
    def __init__(self, app: QApplication, theme, manager: DataManager):
        super().__init__()
        self.app = app
        self.theme = theme
        self.manager = manager
        self.window = None
        self.controller = None
        self.screen = ""                 # 'home', 'project' or a module name
        self._previous_screen = ""
        self._switching = False
        self.tutorial = None             # TutorialController while the tutorial panel is open
        from .shell import Shell
        self.shell = Shell(theme)        # the master window: screens swap inside it
        self.shell.closing.connect(self._shell_closing)
        app.setQuitOnLastWindowClosed(False)
        app.aboutToQuit.connect(self.close_tutorial)

    # ----- screens --------------------------------------------------------
    def show_home(self) -> None:
        self.manager.close()
        window = HomeWindow(self.theme)
        controller = HomeController(self.manager, window, can_create=True)
        controller.openProject.connect(self.open_project)
        controller.newProject.connect(self.show_new_project)
        controller.startTutorial.connect(self.choose_tutorial)
        controller.exportDissertation.connect(self.export_dissertation)
        controller.exportReports.connect(lambda: self.export_dissertation(reports_only=True))
        self._show(window, controller, "home")

    def export_dissertation(self, reports_only: bool = False) -> None:
        """CONTROLLER: choose a folder, export every dissertation data figure and value (or, with reports_only,
        the five dataset report PDFs), report the result."""
        def ask_folder(parent):
            # VIEW: the destination folder (TERMINAL)
            from PySide6.QtWidgets import QFileDialog
            return QFileDialog.getExistingDirectory(parent, "Folder for the dissertation reports" if reports_only
                                                    else "Folder for the dissertation figures")

        def run_export(nav, folder):
            # MODEL: the export, with a cancellable progress window (TERMINAL)
            from pathlib import Path
            from PySide6.QtWidgets import QProgressDialog
            from ..dissertation.export import REPORTS_ONLY, export_dissertation
            dialog = QProgressDialog("Preparing the dissertation projects…", "Stop", 0, 1, nav.window)
            dialog.setWindowTitle("Export dissertation reports" if reports_only else "Export dissertation figures")
            dialog.setWindowModality(Qt.WindowModal)
            dialog.setMinimumDuration(0)
            dialog.show()

            def progress(step, total, text):
                dialog.setMaximum(total)
                dialog.setValue(step)
                dialog.setLabelText(text)
                QApplication.processEvents()
                return not dialog.wasCanceled()
            try:
                return export_dissertation(Path(folder), nav.manager, nav.theme, progress,
                                           what=REPORTS_ONLY if reports_only else "all")
            except InterruptedError:
                return {"stopped": True}
            except Exception as error:                 # noqa: BLE001  (reported to the user)
                return {"error": str(error)}
            finally:
                dialog.close()

        def report_export(parent, result):
            # VIEW: the outcome (TERMINAL)
            if result.get("stopped"):
                return
            if "error" in result:
                notify(parent, ERROR, "The export stopped", result["error"])
                return
            if reports_only:
                text = "Reports written to " + str(result["folder"]) + ":\n" + "\n".join(result.get("reports", []))
                if result["problems"]:
                    notify(parent, WARNING, "Reports exported, with pages to check",
                           text + "\n\nPages failing a check: " + ", ".join(result["problems"]))
                else:
                    notify(parent, SUCCESS, "Dissertation reports exported", text)
                return
            text = (f"{result['figures']} figures and {result['values']} values ({result['changed']} differ from the "
                    f"printed text) in {result['folder']}, in the folders Crowding, Rescue and "
                    f"QuantaColony_Validation. Each holds its figures, one values CSV and one values .tex.")
            if result["problems"]:
                notify(parent, WARNING, "Exported, with figures to check",
                       text + "\n\nSee the report for: " + ", ".join(result["problems"]))
            else:
                notify(parent, SUCCESS, "Dissertation figures exported", text)

        folder = ask_folder(self.window)
        if not folder:
            return
        result = run_export(self, folder)
        report_export(self.window, result)

    def show_new_project(self) -> None:
        from .new_project import NewProjectController, NewProjectWindow
        self.manager.close()
        window = NewProjectWindow(self.theme)
        controller = NewProjectController(self.manager, window)
        controller.cancelled.connect(self.show_home)
        controller.created.connect(self._project_created)
        self._show(window, controller, "new")

    def _project_created(self, project_id: str) -> None:
        """The wizard leaves the new project open: its page, then Cropping."""
        self.show_project()
        self.open_module("cropping")

    def open_project(self, project_id: str) -> None:
        try:
            self.manager.open_project(project_id)
        except ProjectError as error:
            notify(self.window, ERROR, "Could not open the project", str(error))
            return
        self.show_project()

    def show_project(self) -> None:
        window = ProjectWindow(self.theme, self.manager.project_info().name)
        controller = ProjectController(self.manager, window)
        controller.openModule.connect(self.open_module)
        controller.showProjects.connect(self.show_home)
        self._show(window, controller, "project")

    def open_module(self, name: str) -> None:
        builders = {"cropping": open_cropping, "detection": open_detection, "stats": open_stats}
        try:
            window, controller = builders[name](self.manager, self.theme)
        except ProjectError as error:
            notify(self.window, ERROR, "Could not open", str(error))
            return
        if name == "cropping":
            controller.finished.connect(lambda: self.open_module("detection"))
        if name == "detection":
            controller.leave_to = lambda target: (QTimer.singleShot(0, lambda: self.open_module("stats"))
                                                  if target == "stats" else QTimer.singleShot(0, self.show_project))
        if name == "stats":
            window.backRequested.connect(self.show_project)
        self._show(window, controller, name)

    # ----- window switching -------------------------------------------------
    def _show(self, window, controller, screen: str) -> None:
        previous = self.window
        self._previous_screen = self.screen
        self.window, self.controller, self.screen = window, controller, screen
        window.installEventFilter(self)
        self.shell.set_main(window)
        if not self.shell.isVisible():
            self.shell.fit_to_screen()
            self.shell.show()
        self.shell.raise_()
        self.shell.activateWindow()
        if previous is not None:
            self._switching = True
            previous.close()
            previous.deleteLater()
            self._switching = False

    # ----- the tutorial ----------------------------------------------------
    def choose_tutorial(self) -> None:
        """The tour picker, in the master window's tutorial panel; choosing a tour starts it there."""
        from .tutorial import TourPicker
        if self.tutorial is not None:
            self.shell.dock.set_folded(False)
            return
        picker = TourPicker(self.theme, self.manager.settings)
        picker.chosen.connect(self.start_tutorial)
        picker.closed.connect(self.shell.hide_tutorial)
        self._picker = picker
        self.shell.show_tutorial(picker)

    def start_tutorial(self, tour_key: str = "crowding") -> None:
        """Show the tutorial panel for one tour; its project is added to the library when missing."""
        from ..core.tutorial import tour as tour_of
        from .tutorial import TutorialController, TutorialWindow
        chosen = tour_of(tour_key)
        if chosen.key == "detection":
            self.start_detection_tour(chosen)
            return
        copies = [e for e in self.manager.list_projects() if e.tutorial_name == chosen.project]
        project = max(copies, key=lambda e: e.tutorial_version) if copies else None     # the newest copy
        if project is None and self.screen == "home":
            try:
                project_id = self.manager.add_dissertation_project(chosen.project)
            except (ProjectError, OSError) as error:
                notify(self.window, ERROR, "Could not add the tutorial project", str(error))
                return
            self.controller.refresh(project_id)
        elif project is not None and self.screen == "home":
            self.controller.refresh(project.project_id)
        if self.tutorial is not None:
            self.tutorial.window.raise_()
            return
        window = TutorialWindow(self.theme)
        self.tutorial = TutorialController(self, window, chosen)
        self.shell.show_tutorial(window)
        self.tutorial.finished.connect(self._tutorial_closed)
        window.closeRequested.connect(self._tutorial_closed)

    def start_detection_tour(self, chosen) -> None:
        """The Colony Detection tour: a fresh practice project (an earlier copy goes to the Trash), opened in
        Colony Detection, with the tour's panel beside it (gui/detection_guide.py)."""
        from ..study.guide import POOR
        from ..study.project import create_practice_project
        from .detection_guide import DetectionGuideController, practice_bundle
        from .tutorial import TutorialWindow
        if self.tutorial is not None:
            self.close_tutorial()
        if self.screen != "home":
            self.show_home()
            if self.screen != "home":                   # the open screen kept its unsaved edits
                return
        self.manager.close()
        try:
            earlier = [e.project_id for e in self.manager.list_projects() if e.tutorial_name == "practice"]
            if earlier:
                self.manager.delete_projects(earlier)
            bundle = practice_bundle()
            create_practice_project(self.manager, bundle, POOR)
        except (ProjectError, OSError) as error:
            notify(self.window, ERROR, "Could not make the practice project", str(error))
            return
        self.show_project()
        self.open_module("detection")
        window = TutorialWindow(self.theme)
        self.tutorial = DetectionGuideController(self, window, bundle, chosen)
        self.shell.show_tutorial(window)
        self.tutorial.finished.connect(self._tutorial_closed)
        window.closeRequested.connect(self._tutorial_closed)

    def _tutorial_closed(self) -> None:
        self.tutorial = None
        self.shell.hide_tutorial()

    def close_tutorial(self) -> None:
        if self.tutorial is not None:
            self.tutorial.close()
            self.tutorial = None
        self.shell.hide_tutorial()

    def _shell_closing(self, event) -> None:
        """The master window closes: the screen it shows may refuse (unsaved edits); otherwise quit."""
        if self.window is not None and self.screen not in ("home", "project", "new"):
            self._switching = True                  # closing a module here quits; it does not go back
            closed = self.window.close()
            self._switching = False
            if not closed:
                event.ignore()
                return
        event.accept()
        self.close_tutorial()
        self.app.quit()

    def tutorial_state(self):
        """What is on screen, for the tutorial's checks."""
        from ..core.tutorial import TutorialState
        c, screen = self.controller, self.screen
        state = {"screen": screen, "tutorial_open": self.manager.is_open and self.manager.is_tutorial_open,
                 "project": self.manager.tutorial_name if self.manager.is_open else ""}
        try:
            if screen == "cropping":
                state["photo"] = int(c.position)
            elif screen == "detection":
                state["index_values"] = tuple(label.value for label in c.session.record.labels)
                state["split"] = bool(c.session.params.split)
                state["growth"] = bool(self.window.growth_shown())
            elif screen == "stats":
                state.update(analysis=c.analysis_id, slots=dict(c.assignment), leave_out=c.leave_out,
                             measure=c.data.measure if c.data is not None else "",
                             options=dict(c.option_values()),
                             hidden={name: tuple(values) for name, values in c.hidden.items()},
                             selection_on=bool(c.choice.on), matched=tuple(c.choice.matched),
                             window=(c.choice.count_min, c.choice.count_max), target=c.choice.target,
                             not_chosen={k: tuple(v) for k, v in c.choice.not_chosen.items()},
                             by_hand=frozenset(c.plate_name(i) for i in c.by_hand), color_by=c.color_by,
                             levels={v.name: tuple(v.values) for v in c.variables},
                             scheme=c.scheme if c.current.normalize is not None else "raw")
        except AttributeError:                      # a screen still being built
            pass
        return TutorialState(**state)

    def tutorial_glossary(self):
        """The names the tutorial panel shows: every analysis, and the open project's variables."""
        from ..analyses import data as ad
        from ..analyses.registry import load_analyses, sections
        from ..core.tutorial import Glossary
        if getattr(self, "_glossary", None) is None:
            report = load_analyses()
            glossary = Glossary()
            for section, items in sections(report):
                for key, title in items:
                    glossary.analyses[key] = (title, section)
            for key, analysis in report.analyses.items():
                for slot in analysis.slots:
                    glossary.slots[(key, slot.key)] = slot.title
                for option in analysis.options:
                    glossary.options[(key, option.key)] = (option.title, dict(option.choices))
            glossary.measures.update({k: v.split(" (")[0] for k, v in ad.COLONY_MEASURES.items()})
            self._glossary = glossary
        glossary = self._glossary
        glossary.variables = {}
        if self.manager.is_open:
            try:
                for v in self.manager.stats_variables():
                    glossary.variables[v.name] = (v.display_name, dict(zip(v.values, v.displays)))
            except Exception:                       # names only: the tutorial falls back to raw names
                pass
        if self.screen == "stats" and getattr(self.controller, "indices", None) is not None:
            labels = getattr(self.controller.indices, "measure_labels", {}) or {}
            glossary.measures.update({k: v.split(" (")[0] for k, v in dict(labels).items()})
        return glossary

    def tutorial_spot(self, anchor: tuple, reveal: bool = False):
        """(widget, rectangle in it) for a tutorial anchor (core.tutorial.anchor_of), or a nearer step
        toward it: the module button, the back button, a folded section. None when nothing fits."""
        if not anchor or self.window is None:
            return None
        where, kind, *args = anchor
        screen, window = self.screen, self.window
        modules = ("cropping", "detection", "stats")

        def back():                                 # from a module or the project page toward another screen
            for name in ("back_button", "projects_button"):
                button = getattr(window, name, None)
                if button is not None and button.isVisible():
                    return button, button.rect()
            return None

        def module_button(name):
            entry = getattr(window, "step_widgets", {}).get(name)
            return (entry[1], entry[1].rect()) if entry else None

        if where == "home":
            if screen != "home":
                return back()
            return self._home_spot(args[0], reveal)
        if where == "project":                      # a module's button on the project page
            if screen == "project":
                return module_button(args[0])
            return back() if screen in modules else self._home_spot(self.tutorial.tour.project, reveal) \
                if self.tutorial is not None and screen == "home" else None
        target = {"cropping": "cropping", "detection": "detection"}.get(where, "stats")
        if screen != target:
            if screen == "project":
                return module_button(target)
            if screen in modules:
                return back()
            return None
        if where == "cropping":
            return window.photo_label, window.photo_label.rect()
        if where == "detection":
            widget = {"index": window.image_picker, "split": window.split_switch,
                      "growth": window.growth_switch}[kind]
            return widget, widget.rect()
        if where == "selection":
            dialog = getattr(window, "selection_dialog", None)
            if dialog is not None and dialog.isVisible():
                return dialog.locate(kind)
            return window.locate("button", "Selection…", reveal=reveal)
        if where == "plates":
            dialog = getattr(window, "plates_dialog", None)
            if dialog is not None and dialog.isVisible():
                return dialog.locate(kind)
            return window.locate("button", "Plates…", reveal=reveal)
        return window.locate(kind, *args, reveal=reveal)

    def tutorial_apply(self, need) -> None:
        """Guided clicks: make one need's change for the user (core.tutorial.Need)."""
        kind, a, c = need.kind, need.args, self.controller
        if kind == "project":
            copies = [e for e in self.manager.list_projects() if e.tutorial_name == a[0]]
            if not copies:
                return
            if self.screen != "home":
                self.show_home()
            self.open_project(max(copies, key=lambda e: e.tutorial_version).project_id)
        elif kind == "screen":
            if self.screen == "project":
                self.open_module(a[0])
            elif self.screen in ("cropping", "detection", "stats"):
                self.window.close()                 # back to the project page (it asks about unsaved edits)
                QTimer.singleShot(100, lambda: self.screen == "project" and self.open_module(a[0]))
        elif kind == "photo":
            c.open_photo(a[0])
        elif kind == "index":
            ids = {tuple(label.value for label in i.labels): i.index_id for i in self.manager.project_info().indices}
            if tuple(a[0]) in ids:
                c.open_index(ids[tuple(a[0])])
        elif kind in ("split", "growth"):
            (self.window.split_switch if kind == "split" else self.window.growth_switch).setChecked(True)
        elif kind == "analysis":
            c.choose_analysis(a[0])
        elif kind == "slot":
            c.set_slot(a[1], a[2])
        elif kind == "levels":
            variable, used = a
            c.show_all_levels(variable)
            if used:
                values = next(v.values for v in c.variables if v.name == variable)
                for value in values:
                    if value not in used:
                        c.toggle_level(variable, value)
        elif kind == "color":
            c.set_color_by(a[0])
        elif kind == "leave_out":
            c.set_leave_out(a[0])
        elif kind == "selection":
            c.set_plate_selection(a[0])
        elif kind == "matched":
            for v in c.variables:
                if (v.name in c.choice.matched) != (v.name in a[0]):
                    c.toggle_matched(v.name)
        elif kind == "window":
            c.set_count_window(a[0], a[1])
        elif kind == "fit":
            c.set_target("least_deviation")
        elif kind == "by_hand":
            for index_id in list(c.by_hand):
                if not any(c.plate_name(index_id).startswith(p) for p in a[0]):
                    c.toggle_by_hand(index_id)
            for index_id in c.indices.index_ids:
                index_id = int(index_id)
                if index_id not in c.by_hand and any(c.plate_name(index_id).startswith(p) for p in a[0]):
                    c.toggle_by_hand(index_id)
        elif kind == "option":
            c.set_option(a[1], a[2])
        elif kind == "measure":
            c.set_measure(a[0])
        elif kind == "scheme":
            c.set_scheme(a[0])

    def _home_spot(self, project: str, reveal: bool):
        """The tour project's row in the home tree (its folder's row while the folder is folded)."""
        from PySide6.QtWidgets import QTreeWidgetItemIterator
        tree = getattr(self.window, "tree", None)
        if tree is None:
            return None
        copies = [e for e in self.manager.list_projects() if e.tutorial_name == project]
        if not copies:
            return None
        wanted = max(copies, key=lambda e: e.tutorial_version).project_id
        iterator = QTreeWidgetItemIterator(tree)
        while iterator.value() is not None:
            item = iterator.value()
            data = item.data(0, Qt.UserRole)
            if data and data[0] == "project" and data[1] == wanted:
                parent = item.parent()
                while parent is not None and not parent.isExpanded():
                    if not reveal:
                        item = parent
                        parent = item.parent()
                        continue
                    parent.setExpanded(True)
                    parent = parent.parent()
                tree.scrollToItem(item)
                return tree.viewport(), tree.visualItemRect(item)
            iterator += 1
        return None

    def eventFilter(self, watched, event) -> bool:
        if event.type() == QEvent.Close and watched is self.window and not self._switching:
            # Act once the close has happened: a window can refuse it (unsaved colonies)
            QTimer.singleShot(0, lambda w=watched: self._closed(w))
        return False

    def _closed(self, window) -> None:
        if window is not self.window or window.isVisible():
            return
        if self.screen in ("home", "project"):
            self.app.quit()
        elif self.screen == "new":
            self.show_home()                       # closing the wizard cancels it
        else:
            self.show_project()                    # a module closed: back to its project
