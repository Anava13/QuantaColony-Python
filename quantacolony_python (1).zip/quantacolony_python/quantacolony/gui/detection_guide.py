"""The Colony Detection tour: the user replicability study's guide (study/guide.py) on the desktop program.

The tour runs on a practice project made from the study's practice plate: a synthetic plate whose true
colonies are known, with objects that are not colonies (a plate number, bubbles, condensation, dust),
faint colonies, a brighter side and an inseparable mass. Detection starts poorly tuned; the tour fixes
one setting at a time, then uses each manual tool on a part of the plate built for it, then checks the
whole plate against the truth (study/score.py) before the tour ends.

    DetectionGuide            model: the shared guide (study/practice.py) reading the open Colony
                              Detection controller
    DetectionGuideController  controller: polls the guide, fills the tutorial panel (TutorialWindow),
                              points the spotlight, draws the arrow or corner dots on the plate, moves
                              on by itself once a step's tasks are done, and holds Finish image until
                              the practice plate passes its check
    ANCHORS                   the controls the guide's tasks point at, by the browser page's ids
"""

from __future__ import annotations

from PySide6.QtCore import QObject, QRect, QTimer, Signal

from ..core.params import DARK, IRREGULAR
from ..study import guide as gd
from ..study import model as sm
from ..study.practice import PracticeGuide
from .widgets import Collapsible

POLL_MS = 400
ADVANCE_MS = 1200                # a finished step stays this long, so its checkmarks are seen, then moves on
TOUR_KEY = "detection"


# ======================================================================================
# Model
# ======================================================================================
class DetectionGuide(PracticeGuide):
    """The shared guide, reading what the open Colony Detection controller shows."""

    def __init__(self, bundle):
        self.bundle = bundle
        self.controller = None
        self.manager = None                       # no study record: attempts go to the image's benchmark record
        self.last_check = None
        self.load_practice(bundle)

    # what PracticeGuide reads from its host
    session = property(lambda self: self.controller.session if self.controller else None)
    recorder = property(lambda self: self.controller.recorder if self.controller else None)
    mode = property(lambda self: self.controller.mode if self.controller else "")
    roi = property(lambda self: self.controller.roi if self.controller else None)
    candidates = property(lambda self: self.controller.candidates if self.controller else None)
    selection_rect = property(lambda self: self.controller.selection_rect if self.controller else None)
    contour = property(lambda self: bool(self.controller.contour_enabled) if self.controller else False)

    def _record(self, event: str, every_ms: int = 0, **data) -> None:
        if self.controller is not None:
            self.controller._record(event, every_ms, **data)

    # what the controller asks
    def adding_blocked(self) -> bool:
        return self._adding_blocked()

    def before_finish(self) -> bool:
        """Finish image on the practice plate: only once its outlines pass the check."""
        if not self._is_practice() or self.practice_done or not self.truth:
            return True
        if gd.STEPS[self.step].key != "finish":
            self.controller.window.show_status("Finish the tour's steps first; Finish image comes last.")
            return False
        self.last_check = self._training_check()
        if self.last_check["passed"]:
            self.practice_done = True
        return self.practice_done


# ======================================================================================
# Controller
# ======================================================================================
def anchors(window) -> dict:
    """The detection window's controls by the page ids the guide's tasks use."""
    w = window
    shape = w.shape_buttons[IRREGULAR].parentWidget()
    color = w.polarity_buttons[DARK].parentWidget()
    out = dict(w.sections())                   # grp-auto, grp-manual and the five settings sections
    out.update({"ctl-color": color, "ctl-shape": shape, "ctl-threshold": w.level_row, "ctl-rmax": w.rmax_field,
           "ctl-sense": w.sense_row, "ctl-split": w.split_switch, "sw-contour": w.contour_switch, "btn-delete": w.delete_one_button,
           "btn-delete-region": w.delete_region_button, "btn-add": w.add_one_button,
           "btn-add-region": w.region_add_button, "btn-undo": w.undo_button, "btn-redo": w.redo_button,
           "btn-finish": w.finish_button, "btn-estimate": w.auto_button})
    out.update({f"mode-{key}": button for key, button in w.mode_buttons.items()})
    return out


def reveal_target(widget):
    """What to outline for a task's control: the control, or, while it sits inside a closed group or section,
    the title of the outermost closed one, so it is opened first (as in the browser study)."""
    if isinstance(widget, Collapsible):
        widget = widget.header
    closed = None
    parent = widget.parentWidget()
    while parent is not None:
        if isinstance(parent, Collapsible) and not parent.is_open() and not parent.rail:
            closed = parent
        parent = parent.parentWidget()
    return closed.header if closed is not None else widget


class DetectionGuideController(QObject):
    """Drives the tutorial panel through the guide's steps while Colony Detection shows the practice plate."""

    finished = Signal()

    def __init__(self, navigator, window, bundle, tour):
        super().__init__()
        self.navigator = navigator
        self.window = window
        self.tour = tour
        self.guide = DetectionGuide(bundle)
        self.spotlight = None
        self._advancing = None
        self._zoomed = None
        self._place = -1
        window.nextRequested.connect(self.next)
        window.closeRequested.connect(self.close)
        window.showMeRequested.connect(lambda _p: self._point(reveal=True))
        window.findingActionRequested.connect(self.show_place)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.poll)
        self.timer.start(POLL_MS)
        self.poll()

    # ----- the detection screen --------------------------------------------------------------
    def _detection(self):
        """The open Colony Detection controller, with the guide attached; None on any other screen."""
        nav = self.navigator
        controller = nav.controller if nav.screen == "detection" else None
        if controller is None or not hasattr(controller, "session"):
            self.guide.controller = None
            return None
        if self.guide.controller is not controller:
            self.guide.controller = controller
            controller.guide = self.guide
            self._zoomed = None
            controller.window.close_sections()          # the practice plate opens with every group closed
            for box in controller.window.sections().values():
                box.toggled.connect(lambda _open: QTimer.singleShot(0, self.poll))
        return controller

    def _open(self) -> list:
        controller = self.guide.controller
        return controller.window.open_sections() if controller is not None else []

    # ----- checking ---------------------------------------------------------------------------
    def poll(self) -> None:
        controller = self._detection()
        if controller is None or not self.guide._is_practice():
            self.window.show_step(self._waiting_view())
            self._hide_spotlight()
            return
        t = self.guide.tutorial(self._open())
        canvas = controller.window.tool_surface()
        if t["done"]:
            canvas.set_guide()
            controller.window.add_one_button.setEnabled(True)
            self._save(done_all=True)
            self.window.show_step(self._finished_view())
            self._hide_spotlight()
            return
        arrow = t["arrow"] or None
        canvas.set_guide(tuple(arrow) if arrow else None, t["dots"], t["dots_capture"])
        target = t["arrow"] or t["ring"]
        if target and self._zoomed != t["key"]:
            self._zoomed = t["key"]
            canvas.focus_on(target[0], target[1], target[2])
        controller.window.add_one_button.setEnabled(not t["block_add"])
        self.window.show_step(self._view(t))
        self._point(reveal=False)
        tracked = any(not b["info"] for b in t["bullets"])
        if tracked and t["met"] and t["key"] != "finish" and self._advancing != t["key"]:
            self._advancing = t["key"]
            QTimer.singleShot(ADVANCE_MS, lambda key=t["key"]: self._advance(key))

    def _advance(self, key: str) -> None:
        self._advancing = None
        if gd.STEPS[self.guide.step].key == key:
            self.guide.pass_step(self._open())
            self._save()
            self.poll()

    def next(self) -> None:
        """Next: on a step without tasks, and Finish at the end of the tour."""
        if self.guide.practice_done:
            self.close()
            self.finished.emit()
            return
        self.guide.pass_step(self._open())
        self._save()
        self.poll()

    # ----- the panel ----------------------------------------------------------------------------
    def _steps(self) -> list:
        return [(s.title, "current" if i == self.guide.step else ("done" if i < self.guide.step else "todo"))
                for i, s in enumerate(gd.STEPS)]

    def _view(self, t: dict) -> dict:
        first = next((i for i, b in enumerate(t["bullets"]) if not b["done"] and not b["info"]), None)
        needs = [(b["text"], "", "info" if b["info"] else "done" if b["done"] else "next" if i == first else "todo", "")
                 for i, b in enumerate(t["bullets"])]
        tracked = any(not b["info"] for b in t["bullets"])
        check = self.guide.last_check if t["key"] == "finish" else None
        view = {"number": t["number"], "total": t["total"], "tour": self.tour.title, "module": "Colony Detection",
                "figure": "", "title": t["title"], "why": t["text"], "needs": needs, "done": t["met"] and tracked,
                "reading": not tracked, "finding": "", "steps": self._steps(), "guided": True,
                "moving_on": t["met"] and tracked and t["key"] != "finish", "auto_advance": True, "forward_only": True}
        if check is not None and not check["passed"]:
            pct = lambda v: f"{round(100 * v)}%"
            problems = check.get("problems", [])
            view["finding_head"] = f"NOT PASSED YET (CHECK {check['attempt']})"
            view["finding"] = (f"Colonies found: {pct(check['found_share'])}; needed {pct(check['found_min'])}.\n"
                               f"Outlines correct: {pct(check['correct_share'])}; needed {pct(check['correct_min'])}.\n"
                               "Here are a few places to look again; the rest of the plate is up to you. Correct it, "
                               "then press Finish image again.")
            view["finding_action"] = (f"Show a place to look again ({self._place % len(problems) + 2 if self._place >= 0 else 1}"
                                      f" of {len(problems)})") if problems else ""
            view["done"] = True
        return view

    def _waiting_view(self) -> dict:
        return {"number": self.guide.step + 1, "total": len(gd.STEPS), "tour": self.tour.title,
                "module": "Colony Detection", "figure": "", "title": "Open the practice plate",
                "why": "The tour runs in Colony Detection on the Colony Detection practice project.",
                "needs": [], "done": False, "reading": True,
                "finding": "Open the Colony Detection practice project, then Colony Detection.",
                "steps": self._steps(), "guided": True, "forward_only": True}

    def _finished_view(self) -> dict:
        check = self.guide.last_check or {}
        return {"number": len(gd.STEPS), "total": len(gd.STEPS), "tour": self.tour.title,
                "module": "Colony Detection", "figure": "", "title": "Practice plate passed",
                "why": "", "needs": [], "done": True, "reading": True, "steps": self._steps(), "guided": True,
                "forward_only": True,
                "finding": f"{round(100 * check.get('found_share', 1))}% of the colonies to measure found, "
                           f"{round(100 * check.get('correct_share', 1))}% of the outlines correct. Every plate is "
                           "measured the same way: each colony you can tell apart gets its own outline on its "
                           "outer edge, masses of five or more that cannot be told apart are skipped, and nothing "
                           "that is not a colony keeps an outline. Press Finish to end the tour."}

    def show_place(self) -> None:
        """The next of the failed check's places: the plate view moves there; nothing is drawn on the plate."""
        check = self.guide.last_check or {}
        problems = check.get("problems", [])
        controller = self._detection()
        if not problems or controller is None:
            return
        self._place = (self._place + 1) % len(problems)
        x, y, r, label = problems[self._place]
        controller.window.tool_surface().focus_on(x, y, max(r, 6))
        controller.window.show_status(f"Place {self._place + 1} of {len(problems)}, at the center of the view: "
                                      f"{label}.")
        self.poll()

    # ----- pointing -------------------------------------------------------------------------------
    def _point(self, reveal: bool) -> None:
        controller = self._detection()
        t = self.guide.tutorial(self._open()) if controller is not None else None
        anchor = t.get("anchor") if t and not t.get("done") else ""
        widget = anchors(controller.window).get(anchor) if controller is not None and anchor else None
        widget = reveal_target(widget) if widget is not None else None
        if widget is None or not widget.isVisible():
            self._hide_spotlight()
            return
        from .tutorial import Spotlight
        host = widget.window()
        if self.spotlight is None or self.spotlight.parentWidget() is not host:
            self._hide_spotlight()
            self.spotlight = Spotlight(host, self.window.light.link)
        self.spotlight.show_at(QRect(widget.mapTo(host, widget.rect().topLeft()), widget.rect().size()), strong=reveal)

    def _hide_spotlight(self) -> None:
        if self.spotlight is not None:
            from shiboken6 import isValid
            if isValid(self.spotlight):
                self.spotlight.hide()
                self.spotlight.deleteLater()
        self.spotlight = None

    # ----- progress -------------------------------------------------------------------------------
    def _save(self, done_all: bool = False) -> None:
        settings = self.navigator.manager.settings
        others = [k for k in settings.tutorial_done if not k.startswith(f"{TOUR_KEY}:")]
        upto = len(gd.STEPS) if done_all else self.guide.step
        mine = [f"{TOUR_KEY}:{s.key}" for s in gd.STEPS[:upto]]
        settings.set_tutorial(f"{TOUR_KEY}:{gd.STEPS[min(self.guide.step, len(gd.STEPS) - 1)].key}", others + mine)

    def close(self) -> None:
        self.timer.stop()
        self._hide_spotlight()
        controller = self.guide.controller
        if controller is not None:
            controller.guide = None
            controller.window.tool_surface().set_guide()
            controller.window.add_one_button.setEnabled(True)
        self.window.close()


def practice_bundle():
    """The study bundle (the practice plate and its truth) that ships with QuantaColony."""
    from ..study.app import BUNDLE
    return sm.load_bundle(BUNDLE)
