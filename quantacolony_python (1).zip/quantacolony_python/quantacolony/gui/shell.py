"""The master window: every QuantaColony screen shows in its main panel, and the tutorial, while one runs,
in a panel beside it.

    Shell         view: the main panel and the tutorial dock, split by a draggable divider. Without a
                  tutorial the main panel fills the window. Closing it asks the navigator first.
    TutorialDock  view: the tutorial panel in a scroll area, with Fold (a narrow strip with the step
                  number) and Float (its own window, for a second screen) and back.
"""

from __future__ import annotations

from PySide6.QtCore import QEvent, Qt, QTimer, Signal
from PySide6.QtWidgets import QFrame, QHBoxLayout, QMainWindow, QScrollArea, QSplitter, QVBoxLayout, QWidget

from ..theme import Theme
from ..theme.icons import app_icon
from ..theme.stylesheet import build_light_stylesheet
from .light import light_button, light_label

STRIP_WIDTH = 46                                 # the folded tutorial


class TutorialDock(QFrame):
    """The tutorial panel's home inside the master window."""

    floatToggled = Signal(bool)                  # True: float in its own window
    widthWanted = Signal()                       # the panel changed size: refit the divider

    def __init__(self, theme: Theme):
        super().__init__()
        light = theme.style.light
        self.light = light
        self.setObjectName("LightWindow")                      # the light stylesheet's scope
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setStyleSheet(build_light_stylesheet(light, theme.ui_family, theme.brand_family)
                           + f"\nQFrame#LightWindow {{ background: {light.page}; border-left: 1px solid {light.border}; }}")
        column = QVBoxLayout(self)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(0)
        # header: fold and float
        self.header = QWidget()
        head = QHBoxLayout(self.header)
        head.setContentsMargins(12, 6, 8, 6)
        head.setSpacing(6)
        head.addWidget(light_label("TUTORIAL", "section"))
        head.addStretch(1)
        self.float_button = light_button("Float", None, "Show the tutorial in its own window")
        self.float_button.clicked.connect(lambda: self.floatToggled.emit(not self.floating))
        head.addWidget(self.float_button)
        self.fold_button = light_button("Fold ▸", None, "Fold the tutorial to a narrow strip")
        self.fold_button.clicked.connect(lambda: self.set_folded(True))
        head.addWidget(self.fold_button)
        column.addWidget(self.header)
        self.scroll = QScrollArea()
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        column.addWidget(self.scroll, 1)
        self.footer_slot = QVBoxLayout()                        # the panel's buttons, pinned to the bottom
        self.footer_slot.setContentsMargins(0, 0, 0, 0)
        column.addLayout(self.footer_slot)
        # the folded strip
        self.strip = QWidget()
        strip = QVBoxLayout(self.strip)
        strip.setContentsMargins(4, 8, 4, 8)
        strip.setSpacing(8)
        self.unfold_button = light_button("◂", None, "Open the tutorial")
        self.unfold_button.clicked.connect(lambda: self.set_folded(False))
        strip.addWidget(self.unfold_button, 0, Qt.AlignHCenter)
        self.strip_text = light_label("", "small")
        self.strip_text.setStyleSheet(f"color: {light.text}; font-weight: 600;")
        self.strip_text.setAlignment(Qt.AlignHCenter)
        self.strip_text.setWordWrap(True)
        strip.addWidget(self.strip_text)
        strip.addStretch(1)
        column.addWidget(self.strip)
        self.strip.setVisible(False)
        self.panel = None
        self.folded = False
        self.floating = False

    def set_panel(self, panel: QWidget) -> None:
        self.panel = panel
        self.scroll.setWidget(panel)
        footer = getattr(panel, "footer", None)
        while self.footer_slot.count():                         # the previous panel's buttons go
            old = self.footer_slot.takeAt(0).widget()
            if old is not None and old is not footer:
                old.setParent(None)
        if footer is not None:
            self.footer_slot.addWidget(footer)
            footer.setVisible(not self.folded)
        why = getattr(panel, "whyToggled", None)
        if why is not None:
            why.connect(lambda _open: self.widthWanted.emit())
        self.set_folded(False)

    def eventFilter(self, watched, event) -> bool:
        return False

    def wanted_width(self) -> int:
        if self.folded:
            return STRIP_WIDTH
        if self.panel is None:
            return 400
        nominal = getattr(self.panel, "nominal_width", None)  # the same width on every step
        width = nominal() if nominal else self.panel.sizeHint().width()
        return width + self.scroll.verticalScrollBar().sizeHint().width() + 4

    def set_folded(self, folded: bool) -> None:
        self.folded = folded
        self.header.setVisible(not folded)
        self.scroll.setVisible(not folded)
        footer = getattr(self.panel, "footer", None)
        if footer is not None:
            footer.setVisible(not folded)
        self.strip.setVisible(folded)
        self.widthWanted.emit()

    def set_progress(self, text: str) -> None:
        """The folded strip's text: the step number."""
        self.strip_text.setText(text)


class Shell(QMainWindow):
    """The master window. The navigator puts each screen in the main panel (set_main)."""

    closing = Signal(object)                     # the close event: the navigator accepts or ignores it

    def __init__(self, theme: Theme):
        super().__init__()
        self.setWindowIcon(app_icon())
        self.setWindowTitle("QuantaColony")
        self.splitter = QSplitter(Qt.Horizontal)
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setHandleWidth(6)
        self.setCentralWidget(self.splitter)
        self.main_host = QWidget()
        self.main_layout = QVBoxLayout(self.main_host)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        # a screen taller or wider than the window scrolls inside it, so the window never outgrows the
        # display (which would push the tutorial's buttons off its bottom edge)
        self.main_scroll = QScrollArea()
        self.main_scroll.setFrameShape(QFrame.NoFrame)
        self.main_scroll.setWidgetResizable(True)
        self.main_scroll.setWidget(self.main_host)
        self.splitter.addWidget(self.main_scroll)
        self.dock = TutorialDock(theme)
        self.splitter.addWidget(self.dock)
        self.splitter.setStretchFactor(0, 1)
        self.splitter.setStretchFactor(1, 0)
        self.dock.setVisible(False)
        self.dock.widthWanted.connect(lambda: QTimer.singleShot(0, self.fit_dock))
        self.dock.floatToggled.connect(self.set_floating)
        self.current = None
        self._float_window = None

    # ----- the main panel ---------------------------------------------------------------
    def set_main(self, widget: QWidget) -> None:
        """Show one screen in the main panel (the previous one is the navigator's to close)."""
        widget.setParent(self.main_host, Qt.Widget)
        self.main_layout.addWidget(widget)
        widget.show()
        self.current = widget
        self.setWindowTitle(widget.windowTitle() or "QuantaColony")
        self.keep_on_screen()

    def keep_on_screen(self) -> None:
        """Shrink the window back inside the display's usable area."""
        if not self.isVisible() or self.isMaximized() or self.isFullScreen():
            return
        available = self.screen().availableGeometry()
        frame = self.frameGeometry()
        if frame.height() > available.height() or frame.width() > available.width() or frame.bottom() > available.bottom():
            extra_h = frame.height() - self.height()
            extra_w = frame.width() - self.width()
            self.resize(min(self.width(), available.width() - extra_w), min(self.height(), available.height() - extra_h))
            frame = self.frameGeometry()
            self.move(max(available.left(), min(frame.left(), available.right() - frame.width())),
                      max(available.top(), min(frame.top(), available.bottom() - frame.height())))

    def fit_to_screen(self) -> None:
        available = self.screen().availableGeometry()
        self.setGeometry(available.adjusted(20, 40, -20, -20))
        QTimer.singleShot(0, self.keep_on_screen)

    def closeEvent(self, event) -> None:
        self.closing.emit(event)

    # ----- the tutorial dock ------------------------------------------------------------
    def show_tutorial(self, panel: QWidget) -> None:
        self.dock.set_panel(panel)
        self.dock.setVisible(True)
        QTimer.singleShot(0, self.fit_dock)

    def hide_tutorial(self) -> None:
        if self.dock.floating:
            self.set_floating(False)
        self.dock.setVisible(False)

    def fit_dock(self) -> None:
        """Give the dock the width its panel needs; the main panel keeps the rest."""
        if self.dock.floating or not self.dock.isVisible():
            return
        wanted = self.dock.wanted_width()
        total = sum(self.splitter.sizes())
        self.dock.setMinimumWidth(min(wanted, STRIP_WIDTH if self.dock.folded else 260))
        self.splitter.setSizes([max(200, total - wanted), wanted])

    def set_floating(self, floating: bool) -> None:
        """Float the tutorial in its own window, or put it back beside the main panel."""
        dock = self.dock
        if floating == dock.floating:
            return
        dock.floating = floating
        if floating:
            self._float_window = QWidget(None, Qt.Window)
            self._float_window.setWindowTitle("QuantaColony · Tutorial")
            self._float_window.setWindowIcon(app_icon())
            layout = QVBoxLayout(self._float_window)
            layout.setContentsMargins(0, 0, 0, 0)
            layout.addWidget(dock)
            dock.float_button.setText("Dock")
            dock.fold_button.setVisible(False)
            self._float_window.resize(dock.wanted_width(), min(900, self.height()))
            self._float_window.show()
            self._float_window.installEventFilter(self)
        else:
            self.splitter.addWidget(dock)
            dock.float_button.setText("Float")
            dock.fold_button.setVisible(True)
            if self._float_window is not None:
                self._float_window.removeEventFilter(self)
                self._float_window.close()
                self._float_window.deleteLater()
                self._float_window = None
            dock.setVisible(True)
            QTimer.singleShot(0, self.fit_dock)

    def eventFilter(self, watched, event) -> bool:
        if watched is self._float_window and event.type() == QEvent.Close:
            QTimer.singleShot(0, lambda: self.set_floating(False))   # closing the floating window docks it
        return False
