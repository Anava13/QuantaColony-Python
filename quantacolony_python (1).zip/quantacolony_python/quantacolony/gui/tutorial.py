"""The tutorial panel: a window that stays beside every screen and walks through one tour (steps and
needs in core/tutorial.py).

    TutorialWindow      view: progress strip, step outline, the step's why, a live checklist of its
                        needs (done, next, still to do) with Show me on the next one, and the finding
    Spotlight           view: a pulsing outline drawn on screen around the control the next need uses
    TutorialController  asks the navigator what is on screen twice a second, ticks needs off, points
                        the spotlight, and keeps progress in settings.json (on this computer)
    TourPicker          view: one card per tour with its progress
"""

from __future__ import annotations

from PySide6.QtCore import QObject, QRect, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLayout, QPushButton, QVBoxLayout, QWidget

from ..core.tutorial import KINDS, TOURS, anchor_of, describe, is_done, reason, tour as tour_of
from ..theme import Theme
from ..theme.icons import app_icon
from ..theme.stylesheet import build_light_stylesheet
from .light import clear_layout, light_button, light_label

POLL_MS = 500
WIDTH = 400                                      # the tour picker's width
TEXT_WIDTH = 364                                 # the left column: the step and its checklist
REASON_WIDTH = 364                               # the right column: why each change
GAP = 18
REASONS_MAX_HEIGHT = 470                         # longer lists scroll; the next change stays in view
FULL_WIDTH = TEXT_WIDTH + GAP + REASON_WIDTH


# ======================================================================================
# Views
# ======================================================================================
class TutorialWindow(QWidget):
    """View. Controllers use only its signals, show_step and show_outline."""

    backRequested = Signal()
    nextRequested = Signal()
    closeRequested = Signal()
    jumpRequested = Signal(int)                  # a step's position, from the progress strip or the outline
    showMeRequested = Signal(int)                # a need's position in the current step
    applyRequested = Signal()                    # Automate Step: make every change the step still needs
    whyToggled = Signal(bool)                    # the WHY EACH CHANGE column folded (False) or opened
    findingActionRequested = Signal()            # the button under the finding (the Colony Detection tour's check)

    def __init__(self, theme: Theme):
        super().__init__(None)                                  # lives in the master window's tutorial dock
        self.setObjectName("LightWindow")
        self.setAttribute(Qt.WA_StyledBackground, True)
        light = theme.style.light
        self.light = light
        self.setStyleSheet(build_light_stylesheet(light, theme.ui_family, theme.brand_family)
                           + f"\nQWidget#LightWindow {{ background: {light.page}; }}"
                           + f"\nQFrame#Finding {{ background: {light.accent_soft}; border: none; "
                             f"border-left: 3px solid {light.accent}; border-radius: 4px; }}"
                           + f"\nQFrame#Checklist {{ background: {light.surface}; border: 1px solid {light.border}; "
                             "border-radius: 8px; }"
                           + f"\nQFrame#ReasonNext {{ background: {light.accent_soft}; border-radius: 6px; }}")
        self.setWindowTitle("QuantaColony · Tutorial")
        self.setWindowIcon(app_icon())
        column = QVBoxLayout(self)
        column.setSizeConstraint(QLayout.SetFixedSize)          # the window is as tall as its contents
        column.setContentsMargins(18, 14, 18, 14)
        column.setSpacing(8)
        # tour name and the outline switch
        top = QHBoxLayout()
        self.tour_name = light_label("", "section")
        top.addWidget(self.tour_name)
        top.addStretch(1)
        self.why_open = True
        self.why_button = light_button("Hide why", "quiet", "Fold or open the column that explains each change")
        self.why_button.clicked.connect(lambda: self.set_why_open(not self.why_open))
        top.addWidget(self.why_button)
        self.outline_button = light_button("All steps ▾", "quiet", "List every step of this tour")
        self.outline_button.clicked.connect(lambda: self._set_outline(not self.outline.isVisible()))
        top.addWidget(self.outline_button)
        column.addLayout(top)
        # progress: one segment per step
        self.strip = QHBoxLayout()
        self.strip.setSpacing(3)
        column.addLayout(self.strip)
        self.outline = QFrame(objectName="Checklist")
        self.outline_rows = QVBoxLayout(self.outline)
        self.outline_rows.setContentsMargins(10, 8, 10, 8)
        self.outline_rows.setSpacing(0)
        self.outline.setVisible(False)
        column.addWidget(self.outline)
        body = QHBoxLayout()
        body.setSpacing(GAP)
        left = QVBoxLayout()
        left.setSpacing(8)
        body.addLayout(left)
        main_column, column = column, left                      # the step's widgets go in the left column
        self.where = light_label("", "small")
        column.addWidget(self.where)
        self.title = light_label("", "h2", wrap=True)
        column.addWidget(self.title)
        # why the step is there: under More context, folded, so the step reads as its tasks
        self.context_open = False
        self._context_step = None
        self.context_button = light_button("More context ▸", "quiet", "Why this step is there")
        self.context_button.setStyleSheet(f"QPushButton {{ color: {light.link}; font-weight: 600; text-align: left; "
                                          "padding: 0; min-height: 0; background: transparent; border: none; }")
        self.context_button.clicked.connect(lambda: self._set_context(not self.context_open))
        self.why = light_label("", "body", wrap=True)
        # the checklist
        self.checklist = QFrame(objectName="Checklist")
        checks = QVBoxLayout(self.checklist)
        checks.setContentsMargins(12, 10, 12, 10)
        checks.setSpacing(6)
        head = QHBoxLayout()
        head.addWidget(light_label("TO DO", "section"))
        head.addStretch(1)
        self.count = light_label("", "small")
        head.addWidget(self.count)
        checks.addLayout(head)
        self.need_rows = QVBoxLayout()
        self.need_rows.setSpacing(4)
        checks.addLayout(self.need_rows)
        column.addWidget(self.checklist)
        self.moving_on = light_label("Done. Moving on…", "small")
        self.moving_on.setStyleSheet(f"color: {light.link}; font-weight: 600;")
        column.addWidget(self.moving_on)
        column.addWidget(self.context_button, 0, Qt.AlignLeft)
        column.addWidget(self.why)
        # what the result shows
        self.finding_box = QFrame(objectName="Finding")
        finding = QVBoxLayout(self.finding_box)
        finding.setContentsMargins(12, 10, 12, 10)
        finding.setSpacing(4)
        self.finding_head = light_label("WHAT THIS SHOWS", "section")
        finding.addWidget(self.finding_head)
        self.finding = light_label("", "body", wrap=True)
        finding.addWidget(self.finding)
        self.finding_action = light_button("", None)
        self.finding_action.clicked.connect(self.findingActionRequested.emit)
        finding.addWidget(self.finding_action, 0, Qt.AlignLeft)
        column.addWidget(self.finding_box)
        column.addStretch(1)
        # the right column: why each change is made
        from PySide6.QtWidgets import QScrollArea
        self.reasons = QFrame(objectName="Checklist")
        self.reasons.setFixedWidth(REASON_WIDTH)
        reasons = QVBoxLayout(self.reasons)
        reasons.setContentsMargins(12, 10, 4, 10)
        reasons.setSpacing(6)
        reasons.addWidget(light_label("WHY EACH CHANGE", "section"))
        self.reason_scroll = QScrollArea()
        self.reason_scroll.setWidgetResizable(True)
        self.reason_scroll.setFrameShape(QFrame.NoFrame)
        self.reason_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.reason_scroll.setStyleSheet("QScrollArea, QScrollArea > QWidget > QWidget { background: transparent; }")
        holder = QWidget()
        self.reason_rows = QVBoxLayout(holder)
        self.reason_rows.setContentsMargins(0, 0, 8, 0)
        self.reason_rows.setSpacing(4)
        self.reason_scroll.setWidget(holder)
        reasons.addWidget(self.reason_scroll)
        body.addWidget(self.reasons, 0, Qt.AlignTop)
        column = main_column
        column.addLayout(body)
        for frame in (self.checklist, self.finding_box):
            frame.setFixedWidth(TEXT_WIDTH)
        self.outline.setFixedWidth(FULL_WIDTH)
        for label in (self.title, self.why, self.finding):    # a fixed width lets wrapped text report its height
            label.setFixedWidth(TEXT_WIDTH if label is not self.finding else TEXT_WIDTH - 24)
        self.footer = QWidget()                                 # the dock pins it to its bottom edge
        self.footer.setObjectName("LightWindow")
        self.footer.setAttribute(Qt.WA_StyledBackground, True)
        self.footer.setStyleSheet(self.styleSheet() + f"\nQWidget#LightWindow {{ border-top: 1px solid {light.border}; }}")
        row = QHBoxLayout(self.footer)
        row.setContentsMargins(18, 8, 18, 10)
        self.close_button = light_button("Close", "quiet", "Close the tutorial; Start tutorial on the home page "
                                                           "comes back to this step")
        row.addWidget(self.close_button)
        row.addStretch(1)
        self.back_button = light_button("Back", None)
        self.next_button = light_button("Next", "primary")
        row.addWidget(self.back_button)
        row.addWidget(self.next_button)
        self.apply_button = light_button("Automate Step", "primary",
                                         "Make every change this step still needs")
        self.apply_button.clicked.connect(self.applyRequested.emit)
        row.addWidget(self.apply_button)                        # always the bottom right corner
        for button, width in ((self.back_button, 80), (self.next_button, 80), (self.apply_button, 150)):
            button.setFixedWidth(width)                         # a label change never moves its neighbors

        self.back_button.clicked.connect(self.backRequested.emit)
        self.next_button.clicked.connect(self.nextRequested.emit)
        self.close_button.clicked.connect(self.closeRequested.emit)
        self._shown = None                                      # what the checklist shows, to skip refills

    # ----- the step ---------------------------------------------------------------------
    def show_step(self, view: dict) -> None:
        """view: number, total, tour, module, figure, title, why, needs [(label, where, state)], done,
        reading, finding, steps [(title, state)] with state 'done', 'current' or 'todo'."""
        if view == self._shown:
            return
        self._shown = view
        light = self.light
        self.tour_name.setText(view["tour"].upper())
        wide = any(n[3] for n in view["needs"]) and self.why_open      # the WHY EACH CHANGE column shows
        self.outline.setFixedWidth(FULL_WIDTH if wide else TEXT_WIDTH)
        clear_layout(self.strip)
        for position, (title, state) in enumerate(view["steps"]):
            segment = QPushButton()
            count = len(view["steps"])
            width = FULL_WIDTH if wide else TEXT_WIDTH
            segment.setFixedSize(max(4, (width - 3 * (count - 1)) // count), 8 if state == "current" else 6)
            segment.setCursor(Qt.PointingHandCursor)
            segment.setToolTip(f"{position + 1}. {title}")
            color = light.accent if state == "done" else light.surface
            edge = light.link if state == "current" else (light.accent if state == "done" else light.border)
            segment.setStyleSheet(f"QPushButton {{ background: {color}; border: {2 if state == 'current' else 1}px "
                                  f"solid {edge}; border-radius: 3px; min-height: 0; padding: 0; }}")
            segment.clicked.connect(lambda _c=False, p=position: self.jumpRequested.emit(p))
            self.strip.addWidget(segment)
        self._fill_outline(view["steps"])
        figure = f" · {view['figure']}" if view["figure"] else ""
        self.where.setText(f"Step {view['number']} of {view['total']} · {view['module']}{figure}")
        self.title.setText(view["title"])
        self.why.setText(view["why"])
        step_id = (view["tour"], view["number"])
        if step_id != self._context_step:                       # each step opens with its context folded
            self._context_step = step_id
            self.context_open = False
        self.context_button.setVisible(bool(view["why"]))
        self.context_button.setText("More context ▾" if self.context_open else "More context ▸")
        self.why.setVisible(bool(view["why"]) and self.context_open)
        needs = view["needs"]
        self.checklist.setVisible(bool(needs))
        clear_layout(self.need_rows)
        for position, (label, where, state, _reason) in enumerate(needs):
            self.need_rows.addWidget(self._need_row(position, label, where, state))
        explained = [n for n in needs if n[3]]
        self.reasons.setVisible(bool(explained) and self.why_open)
        self.why_button.setVisible(bool(explained))
        self._fill_reasons(explained)
        tracked = [n for n in needs if n[2] != "info"]
        self.apply_button.setEnabled(any(state == "next" for *_, state, _r in needs))
        met = sum(1 for _, _, state, _r in tracked if state == "done")
        self.count.setText(f"{met} of {len(tracked)} done" if tracked else "")
        done, reading = view["done"], view["reading"]
        guided = view.get("guided", False)            # a learning tour: no skipping, no automating
        self.moving_on.setVisible(bool(view.get("moving_on")))
        self.finding_box.setVisible((done or reading) and bool(view["finding"]))
        self.finding_head.setText(view.get("finding_head") or ("WHAT THIS SHOWS" if not reading else "NOTE"))
        self.finding.setText(view["finding"])
        self.finding_action.setText(view.get("finding_action", ""))
        self.finding_action.setVisible(bool(view.get("finding_action")))
        self.back_button.setEnabled(view["number"] > 1)
        self.back_button.setVisible(not view.get("forward_only", False))
        self.apply_button.setVisible(not guided)
        last = view["number"] == view["total"]
        self.next_button.setText("Finish" if last else ("Next" if done or reading or guided else "Skip"))
        self.next_button.setToolTip("" if done or reading or guided else "Move on without finishing this step")
        self.next_button.setEnabled(done or reading or not guided)
        self.next_button.setVisible(not view.get("moving_on") and (reading or not view.get("auto_advance", False)))
        self.next_button.setProperty("variant", "primary" if done or reading else "quiet")
        self.next_button.style().unpolish(self.next_button)
        self.next_button.style().polish(self.next_button)
        for label in (self.title, self.why, self.finding):      # wrapped text: as tall as it needs
            label.ensurePolished()
            label.setMinimumHeight(label.heightForWidth(label.width()) if label.text() else 0)
        self.adjustSize()

    def _set_context(self, open_: bool) -> None:
        self.context_open = open_
        shown, self._shown = self._shown, None
        if shown is not None:
            self.show_step(shown)

    def set_why_open(self, open_: bool) -> None:
        """Fold or open the WHY EACH CHANGE column; the panel narrows to the step column while folded."""
        self.why_open = open_
        self.why_button.setText("Hide why" if open_ else "Show why")
        self.outline.setFixedWidth(FULL_WIDTH if open_ else TEXT_WIDTH)
        shown, self._shown = self._shown, None                  # redraw with the new width
        if shown is not None:
            self.show_step(shown)
        self.adjustSize()
        self.whyToggled.emit(open_)

    def nominal_width(self) -> int:
        """The panel's width on any step: both columns, or the step column alone while WHY is folded."""
        margins = self.layout().contentsMargins()
        return (FULL_WIDTH if self.why_open else TEXT_WIDTH + 120) + margins.left() + margins.right()

    def _need_row(self, position: int, label: str, where: str, state: str) -> QWidget:
        light = self.light
        holder = QWidget()
        rows = QVBoxLayout(holder)
        rows.setContentsMargins(0, 0, 0, 0)
        rows.setSpacing(1)
        line = QHBoxLayout()
        line.setSpacing(8)
        mark = light_label({"done": "✓", "next": "➜", "info": "•"}.get(state, "○"))
        mark.setFixedWidth(16)
        mark.setStyleSheet(f"color: {light.link if state != 'todo' else light.swatch_todo}; font-weight: 700;")
        line.addWidget(mark, 0, Qt.AlignTop)
        text = light_label(label, "body", wrap=True)
        text.setFixedWidth(TEXT_WIDTH - 24 - 16 - 8 - (72 if state == "next" else 0))
        text.setStyleSheet(f"color: {light.text_muted};" if state == "done" else
                           "font-weight: 600;" if state == "next" else "")
        line.addWidget(text, 0, Qt.AlignTop)
        line.addStretch(1)
        if state == "next":
            show = light_button("Show me", "quiet", "Point at the control on screen, opening what hides it")
            show.setStyleSheet(f"QPushButton {{ color: {light.link}; font-weight: 600; padding: 0 4px; "
                               "min-height: 0; background: transparent; border: none; }")
            show.clicked.connect(lambda _c=False, p=position: self.showMeRequested.emit(p))
            line.addWidget(show, 0, Qt.AlignTop)
        rows.addLayout(line)
        if state == "next" and where:
            hint = light_label(where, "small", wrap=True)
            hint.setFixedWidth(TEXT_WIDTH - 24 - 24)
            hint.setContentsMargins(24, 0, 0, 0)
            rows.addWidget(hint)
        for widget in holder.findChildren(type(text)):
            widget.ensurePolished()
            if widget.wordWrap():
                widget.setMinimumHeight(widget.heightForWidth(widget.width()))
        return holder

    def _fill_reasons(self, needs: list) -> None:
        """One entry per reason; needs that share a reason share an entry. The next change is highlighted."""
        light = self.light
        clear_layout(self.reason_rows)
        groups = []                                             # [labels, reason, state]
        for label, _where, state, reason in needs:
            if groups and groups[-1][1] == reason:
                groups[-1][0].append(label)
                if state == "next" or groups[-1][2] == "next":
                    groups[-1][2] = "next"
                elif state != "done":
                    groups[-1][2] = "todo"
            else:
                groups.append([[label], reason, state])
        total, current = 0, None
        for labels, reason, state in groups:
            box = QFrame(objectName="ReasonNext" if state == "next" else "")
            inner = QVBoxLayout(box)
            inner.setContentsMargins(8, 6, 8, 6)
            inner.setSpacing(2)
            head = light_label(" · ".join(labels), "small", wrap=True)
            head.setFixedWidth(REASON_WIDTH - 24 - 24)
            head.setStyleSheet(f"font-weight: 700; color: {light.text_muted if state == 'done' else light.text};")
            inner.addWidget(head)
            text = light_label(reason, "small" if state != "next" else "body", wrap=True)
            text.setFixedWidth(REASON_WIDTH - 24 - 24)
            if state == "done":
                text.setStyleSheet(f"color: {light.text_muted};")
            inner.addWidget(text)
            for widget in (head, text):
                widget.ensurePolished()
                widget.setMinimumHeight(widget.heightForWidth(widget.width()))
            if state == "next":
                current = box
            self.reason_rows.addWidget(box)
            total += head.minimumHeight() + text.minimumHeight() + 18
        self.reason_rows.addStretch(1)
        self.reason_scroll.setFixedHeight(min(total + 4, REASONS_MAX_HEIGHT))
        if current is not None:                                  # keep the next change's reason in view
            QTimer.singleShot(60, lambda b=current: self.reason_scroll.ensureWidgetVisible(b, 0, 40)
                              if b is not None else None)

    # ----- the outline ------------------------------------------------------------------
    def _fill_outline(self, steps: list) -> None:
        clear_layout(self.outline_rows)
        for position, (title, state) in enumerate(steps):
            mark = {"done": "✓", "current": "➜"}.get(state, " ")
            button = light_button(f"{mark}  {position + 1}. {title}", "quiet")
            button.setStyleSheet(f"QPushButton {{ text-align: left; padding: 2px 4px; min-height: 0; border: none; "
                                 f"background: transparent; font-weight: {700 if state == 'current' else 400}; "
                                 f"color: {self.light.text if state != 'done' else self.light.text_muted}; }}")
            button.clicked.connect(lambda _c=False, p=position: (self._set_outline(False), self.jumpRequested.emit(p)))
            self.outline_rows.addWidget(button)

    def _set_outline(self, shown: bool) -> None:
        self.outline.setVisible(shown)
        self.outline_button.setText("All steps ▴" if shown else "All steps ▾")
        self.adjustSize()

    def place_beside(self, screen_geometry) -> None:
        """At the right edge of the screen, near the top, where the module windows leave room."""
        self.adjustSize()
        self.move(screen_geometry.right() - self.width() - 24, screen_geometry.top() + 80)


class Spotlight(QWidget):
    """A pulsing outline around one control. It is a child of the control's own window, so it sits in that
    window's stacking order: another window in front covers it. Clicks pass through it."""

    MARGIN = 5

    def __init__(self, host: QWidget, color: str):
        super().__init__(host)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WA_NoSystemBackground, True)
        self.setFocusPolicy(Qt.NoFocus)
        self.color = QColor(color)
        self.phase = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._pulse)
        self.timer.start(60)

    def show_at(self, rect: QRect, strong: bool = False) -> None:
        """rect: in the host window's coordinates."""
        m = self.MARGIN
        rect = rect.adjusted(-m, -m, m, m).intersected(self.parentWidget().rect())
        if rect != self.geometry():
            self.setGeometry(rect)
        if strong:
            self.phase = 0
        self.raise_()
        if not self.isVisible():
            self.show()

    def _pulse(self) -> None:
        if self.isVisible():
            self.phase = (self.phase + 1) % 30
            self.update()

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        wave = abs(15 - self.phase) / 15                         # 1 -> 0 -> 1
        color = QColor(self.color)
        color.setAlpha(int(140 + 115 * (1 - wave)))
        painter.setPen(QPen(color, 3))
        painter.setBrush(Qt.NoBrush)
        inset = 2 + int(2 * wave)
        painter.drawRoundedRect(self.rect().adjusted(inset, inset, -inset, -inset), 6, 6)


# ======================================================================================
# Controller
# ======================================================================================
class TutorialController(QObject):
    """Checks the current step's needs against the screen (navigator.tutorial_state), points the
    spotlight at the next unmet one and moves through the chosen tour. Progress is kept per tour (keys
    stored as 'tour:step')."""

    finished = Signal()

    def __init__(self, navigator, window: TutorialWindow, tour=None):
        super().__init__()
        self.navigator = navigator
        self.window = window
        self.tour = tour or tour_of("crowding")
        self.spotlight = None                                  # Spotlight, a child of the window it points into
        self._pointed = None                                   # (step, need) the spotlight was last forced onto
        settings = navigator.manager.settings
        stored = settings.tutorial_step
        if ":" in stored:
            tour_key, _, stored = stored.partition(":")
            stored = stored if tour_key == self.tour.key else ""
        elif self.tour.key != "crowding":                       # unprefixed entries are the old crowding run
            stored = ""
        self.position = self._step_index(stored) if stored else 0
        self.done = set()
        for key in settings.tutorial_done:
            tour_key, _, step_key = key.partition(":") if ":" in key else ("crowding", "", key)
            if tour_key == self.tour.key and any(step.key == step_key for step in self.tour.steps):
                self.done.add(step_key)
        window.backRequested.connect(lambda: self.go(self.position - 1))
        window.nextRequested.connect(self.next)
        window.closeRequested.connect(self.close)
        window.jumpRequested.connect(self.go)
        window.showMeRequested.connect(self.show_me)
        window.applyRequested.connect(self.automate_step)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.poll)
        self.timer.start(POLL_MS)
        self.poll()

    def _step_index(self, key: str) -> int:
        return next((i for i, step in enumerate(self.tour.steps) if step.key == key), 0)

    @property
    def step(self):
        return self.tour.steps[self.position]

    # ----- checking -----------------------------------------------------------------------
    def poll(self) -> None:
        step = self.step
        state = self.navigator.tutorial_state()
        met = [need.met(state) for need in step.needs]
        if step.key not in self.done and is_done(step, state):
            self.done.add(step.key)
            self._save()
        self._show(met)
        self._point(met)

    def _show(self, met: list[bool]) -> None:
        step = self.step
        glossary = self.navigator.tutorial_glossary()
        first_unmet = next((i for i, ok in enumerate(met) if not ok), None)
        needs = []
        for i, need in enumerate(step.needs):
            label, where = describe(need, glossary)
            needs.append((label, where, "done" if met[i] else ("next" if i == first_unmet else "todo"),
                          reason(need, step, glossary)))
        steps = [(s.title, "current" if i == self.position else ("done" if s.key in self.done else "todo"))
                 for i, s in enumerate(self.tour.steps)]
        self.window.setWindowTitle(f"QuantaColony · Tutorial · {self.tour.title}")
        shell = getattr(self.navigator, "shell", None)
        if shell is not None:
            shell.dock.set_progress(f"Step\n{self.position + 1}\nof {len(self.tour.steps)}")
        self.window.show_step({
            "number": self.position + 1, "total": len(self.tour.steps), "tour": self.tour.title,
            "module": step.module, "figure": step.figure, "title": step.title, "why": step.why,
            "needs": needs, "done": step.key in self.done and bool(step.needs),
            "reading": step.reading, "finding": step.finding, "steps": steps, "guided": self.tour.kind == "guide"})

    # ----- pointing -----------------------------------------------------------------------
    def _point(self, met: list[bool]) -> None:
        """The spotlight follows the next unmet need: on its control when it is on screen, else on the
        nearest step toward it (the module button, a folded section, the analysis group)."""
        first_unmet = next((i for i, ok in enumerate(met) if not ok), None)
        if first_unmet is None:
            self._hide_spotlight()
            return
        self._spot(first_unmet, reveal=False)

    def _spot(self, position: int, reveal: bool) -> bool:
        need = self.step.needs[position]
        spot = self.navigator.tutorial_spot(anchor_of(need, self.navigator.tutorial_glossary()), reveal=reveal)
        if spot is None or spot[0] is None or not spot[0].isVisible() or spot[1].isEmpty():
            self._hide_spotlight()
            return False
        widget, rect = spot
        host = widget.window()
        if not self._spotlight_alive() or self.spotlight.parentWidget() is not host:
            self._hide_spotlight()
            self.spotlight = Spotlight(host, self.window.light.link)
        self.spotlight.show_at(QRect(widget.mapTo(host, rect.topLeft()), rect.size()), strong=reveal)
        return True

    def _spotlight_alive(self) -> bool:
        from shiboken6 import isValid
        return self.spotlight is not None and isValid(self.spotlight)

    def _hide_spotlight(self) -> None:
        if self._spotlight_alive():
            self.spotlight.hide()
            self.spotlight.deleteLater()
        self.spotlight = None

    def show_me(self, position: int) -> None:
        """Open whatever hides the need's control, bring its window forward and point at it."""
        window = self.navigator.window
        if window is not None:
            window.raise_()
            window.activateWindow()
        self._spot(position, reveal=True)
        QTimer.singleShot(50, lambda: self._spot(position, reveal=True))      # after the layout settles

    # ----- automating -----------------------------------------------------------------------
    def apply_next(self) -> None:
        """Make the next unmet change, then point at the control it changed."""
        state = self.navigator.tutorial_state()
        position = next((i for i, need in enumerate(self.step.needs) if not need.met(state)), None)
        if position is None:
            return
        self.navigator.tutorial_apply(self.step.needs[position])
        self.poll()
        self.show_me(position)

    def automate_step(self) -> None:
        """Make every change the step still needs, one after another in checklist order. A change that opens a
        screen gets a moment to finish; the run stops when a change makes no progress (for example a question
        about unsaved edits that is still open)."""
        from PySide6.QtCore import QEventLoop
        from PySide6.QtWidgets import QApplication

        def wait(ms: int) -> None:
            loop = QEventLoop()
            QTimer.singleShot(ms, loop.quit)
            loop.exec()

        step = self.step
        for _ in range(3 * len(step.needs) + 3):
            if self.step is not step:
                return
            state = self.navigator.tutorial_state()
            position = next((i for i, need in enumerate(step.needs) if not need.met(state)), None)
            if position is None:
                break
            need = step.needs[position]
            self.navigator.tutorial_apply(need)
            QApplication.processEvents()
            for _ in range(20):                                  # screens open on a short timer
                if need.met(self.navigator.tutorial_state()):
                    break
                wait(50)
            if not need.met(self.navigator.tutorial_state()):
                break
        self.poll()
        state = self.navigator.tutorial_state()
        left = next((i for i, need in enumerate(step.needs) if not need.met(state)), None)
        if left is not None:
            self.show_me(left)                                   # point at what still needs a hand

    # ----- moving -------------------------------------------------------------------------
    def go(self, position: int) -> None:
        self.position = max(0, min(position, len(self.tour.steps) - 1))
        self._save()
        self.poll()

    def next(self) -> None:
        if self.position == len(self.tour.steps) - 1:
            self.position, self.done = 0, set()            # a finished tutorial starts over next time
            self._save()
            self.close()
            self.finished.emit()
            return
        self.go(self.position + 1)

    def _save(self) -> None:
        settings = self.navigator.manager.settings
        others = [key for key in settings.tutorial_done
                  if (key.partition(":")[0] if ":" in key else "crowding") != self.tour.key]
        mine = [f"{self.tour.key}:{key}" for key in self.done]
        settings.set_tutorial(f"{self.tour.key}:{self.step.key}", others + mine)

    def close(self) -> None:
        self.timer.stop()
        self._hide_spotlight()
        self.window.close()


class TourPicker(QWidget):
    """Choose a guided tour: one card per tour with its progress."""

    chosen = Signal(str)
    closed = Signal()                            # Close: the dock hides

    def __init__(self, theme: Theme, settings):
        super().__init__(None)                                  # shown in the master window's tutorial dock
        self.setObjectName("LightWindow")
        self.setAttribute(Qt.WA_StyledBackground, True)
        light = theme.style.light
        self.setStyleSheet(build_light_stylesheet(light, theme.ui_family, theme.brand_family)
                           + f"\nQWidget#LightWindow {{ background: {light.page}; }}")
        self.setWindowTitle("QuantaColony · Tutorials")
        self.setWindowIcon(app_icon())
        column = QVBoxLayout(self)
        column.setSizeConstraint(QLayout.SetFixedSize)
        column.setContentsMargins(18, 16, 18, 14)
        column.setSpacing(10)
        column.addWidget(light_label("Guided tours", "h2"))
        column.addWidget(light_label("Every step lists the changes it needs, says why each one is made, and "
                                     "points at each control on screen.", "small", wrap=True))
        done = set(settings.tutorial_done)
        for kind, heading, blurb in KINDS:
            column.addSpacing(6)
            column.addWidget(light_label(heading.upper(), "section"))
            note = light_label(blurb, "small", wrap=True)
            note.setFixedWidth(WIDTH - 36)
            column.addWidget(note)
            for tour in (t for t in TOURS if t.kind == kind):
                column.addWidget(self._card(tour, done))
        close = light_button("Close", "quiet")
        close.clicked.connect(lambda: (self.closed.emit(), self.close()))
        column.addWidget(close, 0, Qt.AlignRight)

    def _card(self, tour, done: set) -> QFrame:
        finished = sum(1 for step in tour.steps
                       if f"{tour.key}:{step.key}" in done or (tour.key == "crowding" and step.key in done))
        box = QFrame(objectName="LightPanel")
        inner = QVBoxLayout(box)
        inner.setContentsMargins(12, 10, 12, 10)
        inner.setSpacing(4)
        title = light_label(tour.title, "body")
        title.setStyleSheet("font-weight: 600;")
        inner.addWidget(title)
        text = light_label(tour.description, "small", wrap=True)
        text.setFixedWidth(WIDTH - 60)
        inner.addWidget(text)
        row = QHBoxLayout()
        row.addWidget(light_label(f"{finished} of {len(tour.steps)} steps done", "small"))
        row.addStretch(1)
        start = light_button("Start", "primary" if finished < len(tour.steps) else None)
        start.clicked.connect(lambda _c=False, key=tour.key: (self.chosen.emit(key), self.close()))
        row.addWidget(start)
        inner.addLayout(row)
        return box
