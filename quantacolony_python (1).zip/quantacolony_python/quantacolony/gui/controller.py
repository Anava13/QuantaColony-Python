"""ColonyDetectionController: connects the window (view) to the session (model).

Method names follow the MATLAB app in Python style, e.g. dropdownChanged ->
dropdown_changed, handleBackupAndDetection -> handle_backup_and_detection.

The controller holds the state that is not part of the record and is not
undoable: the current mode, colonies selected for deletion, circles drawn
but not yet added, and the region preview.
"""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import QApplication

from ..core import cropping as cp
from ..core.colony_set import ColonySet
from ..core.drawing import DrawnCircle, drawn_to_colonies, hit_test
from ..core.benchmark import (POINTER_EVERY_MS, SETTING_EVERY_MS, DetectionRecorder, params_data,
                              reference_start)
from ..core.measurements import summarize_colonies
from ..core.messages import compose_message
from ..core.autoparams import maxpix_for
from ..core.params import CIRCULAR, DetectionParams, validate_detection_parameters
from ..core.session import DetectionSession
from ..data import DataManager, ProjectError
from ..data.exports import export_problem
from .main_window import ColonyDetectionWindow
from .modes import DEFAULT_MODE, MODES
from .tools import AddIndividualTool, AddManyTool, DeleteIndividualTool, DeleteManyTool
from ..core.session import session_from_packet  # noqa: F401  (kept importable from here)


DETECTION_DELAY_MS = 150          # wait for slider drags and clicks to settle before re-detecting
GROWTH_DELAY_MS = 400             # wait for edits to settle before measuring growth again
SELECTION_TOLERANCE = 2.0         # click within 2 radii of a center (isWithinSelectionTolerance)


class ColonyDetectionController:
    def __init__(self, session: DetectionSession, window: ColonyDetectionWindow, data_manager: DataManager,
                 review_reason: str = ""):
        self.session = session
        self.window = window
        self.data_manager = data_manager          # receives the result on "Finish image"
        self.leave_to = None                      # set by the navigator: called with 'stats' or 'project'
        self.label = session.record.display_label

        # Temporary interaction state
        self.mode = DEFAULT_MODE
        self.selected_ids: set[int] = set()
        self.selection_rect = None
        self.pending_circles: list[DrawnCircle] = []       # drawn, not yet added
        self.contour_enabled = False
        self.roi = None
        self.roi_params: DetectionParams | None = None
        self.candidates: ColonySet | None = None
        self.recorder: DetectionRecorder | None = None   # developer mode: this image session's record
        self.guide = None                         # the Colony Detection tour (gui/detection_guide.py), when running

        self._detection_timer = QTimer()
        self._detection_timer.setSingleShot(True)
        self._detection_timer.setInterval(DETECTION_DELAY_MS)
        self._detection_timer.timeout.connect(self.handle_backup_and_detection)
        self._region_timer = QTimer()
        self._region_timer.setSingleShot(True)
        self._region_timer.setInterval(DETECTION_DELAY_MS)
        self._region_timer.timeout.connect(self.update_region_detection)
        self._growth_timer = QTimer()
        self._growth_timer.setSingleShot(True)
        self._growth_timer.setInterval(GROWTH_DELAY_MS)
        self._growth_timer.timeout.connect(self.update_growth)

        colors = window.theme.style.colony
        canvas = window.tool_surface()
        self.tools = {
            "DeleteIndividualColonies": DeleteIndividualTool(canvas, self.handle_delete_click),
            "DeleteManyColonies": DeleteManyTool(canvas, self.highlight_colonies_in_rect, colors.selected),
            "AddIndividualColonies": AddIndividualTool(canvas, editor=self, guide_color=colors.manual),
            "AddManyColonies": AddManyTool(canvas, self.start_region_detection, colors.manual),
        }

        self._connect_signals()
        self._setup_navigation()
        self._watch_focus()
        self._bind(session, review_reason)

    def _bind(self, session: DetectionSession, review_reason: str = "") -> None:
        """Show one index: its image, its colonies and its settings."""
        self.session = session
        self.label = session.record.display_label
        self._clear_pending()
        session.subscribe(self._on_session_changed)
        self.window.show_image(session.image)
        self.window.set_growth(None)
        if self.window.growth_shown():
            self._growth_timer.start()
        self.window.set_spinner_values(session.params)
        self.window.set_new_image_start(self.data_manager.new_image_start())
        self._show_position()
        self._start_recording()
        self.notifyuser("ImageLoaded")
        if session.loaded_revision:
            self.notifyuser("LoadedSaved", (len(session.colonies), session.loaded_revision))
        else:
            self.notifyuser("DetectionResults", (len(session.colonies), session.params))
        if review_reason:
            self.notifyuser("NeedsReview", review_reason)
        self.select_dropdown_option(self.mode if self.mode in MODES else DEFAULT_MODE)

    # ----- moving between indices -----------------------------------------
    def _setup_navigation(self) -> None:
        """The index board (same rows / columns / pages view as Cropping) and the previous / next arrows."""
        w = self.window
        prefs = self.data_manager.module_preferences("detection")
        self.variables = list(self.data_manager.crop_packet().variables)
        cropping = self.data_manager.crop_packet().preferences.get("scope", {})
        scope = {v.name: cropping.get(v.name, cp.default_scope(self.variables)[v.name]) for v in self.variables}
        default_view = cp.default_view(self.variables, scope)
        self.view = {v.name: prefs.get("view", {}).get(v.name, default_view[v.name]) for v in self.variables}
        self.pages = {v.name: v.values[0] for v in self.variables}
        w.set_navigation(True, True)
        w.previousRequested.connect(lambda: self.step_index(-1))
        w.nextRequested.connect(lambda: self.step_index(1))
        w.boardRequested.connect(self.show_index_board)
        w.indexChosen.connect(self.open_index)
        w.set_close_guard(self.ready_to_leave)

    def index_status(self) -> list[tuple[int, tuple, str]]:
        """(index id, design level values in variable order, 'waiting' / 'detected' / 'review') for every plate with
        a region, in level order (last variable fastest; the plates of one index in the order they were made)."""
        order = {key: i for i, key in enumerate(cp.all_index_keys(self.variables))}
        info = self.data_manager.project_info()
        names = {v.display_name: v.name for v in info.variables}
        found = []
        for index in info.indices:
            if not index.has_region:
                continue
            levels = {names[label.variable]: label.value for label in index.labels}
            key = cp.index_key(levels, self.variables)
            state = "review" if index.needs_review else "detected" if index.revision else "waiting"
            found.append((index.index_id, key, state))
        return sorted(found, key=lambda item: order.get(item[1], len(order)))

    def _show_position(self) -> None:
        indices = self.index_status()
        ids = [i for i, _, _ in indices]
        current = self.session.record.index_id
        position = f"{ids.index(current) + 1} of {len(ids)}" if current in ids else ""
        record = self.session.record
        self.window.set_image_label(record.nominal_display, record.ordinal_display, position)
        self.window.set_navigation(True, len(ids) > 1)
        if self.window.board_open():
            self._fill_index_board()

    def _fill_index_board(self) -> None:
        indices = self.index_status()
        status: dict[tuple, list] = {}
        for index_id, key, state in indices:
            status.setdefault(key, []).append((state, index_id))
        current = next((key for index_id, key, _ in indices if index_id == self.session.record.index_id), None)
        board = cp.build_status_board(self.variables, self.view, self.pages, status, current)
        places = {cp.ROWS: "Rows", cp.COLUMNS: "Columns", cp.PAGES: "Pages"}
        view_rows = [(v.display_name, [(places[p], self.view[v.name] == p, lambda v=v, p=p: self.set_board_view(v, p))
                                       for p in places]) for v in self.variables]
        page_rows = [(v.display_name, [(v.display(x), self.pages[v.name] == x,
                                        lambda v=v, x=x: self.set_board_page(v, x)) for x in v.values])
                     for v in self.variables if self.view[v.name] == cp.PAGES]
        counts = [state for _, _, state in indices]
        summary = f"{counts.count('detected')} of {len(indices)} plates detected"
        if counts.count("review"):
            summary += f" · {counts.count('review')} to review"
        note = ("Click a cell to open that index (its first plate still to detect). Page Up and Page Down step "
                "through every plate in level order.")
        if board.counted:
            note = f"{board.counted} is counted inside each cell (too many columns to show it). " + note
        self.window.set_board(summary, view_rows, page_rows, board, note)

    def show_index_board(self) -> None:
        self._fill_index_board()
        self.window.show_index_popup()

    def set_board_view(self, variable, place: str) -> None:
        self.view[variable.name] = place
        self.data_manager.save_module_preferences("detection", {"view": self.view})
        self._fill_index_board()

    def set_board_page(self, variable, value: str) -> None:
        self.pages[variable.name] = value
        self._fill_index_board()

    def step_index(self, step: int) -> None:
        ids = [i for i, _, _ in self.index_status()]
        if not ids:
            return
        current = self.session.record.index_id
        position = ids.index(current) if current in ids else -1
        self.open_index(ids[(position + step) % len(ids)])

    def has_unsaved_edits(self) -> bool:
        return self.session.undo_depth() > 0

    def ready_to_leave(self) -> bool:
        """Ask about edits that are not saved; True when it is fine to leave this index."""
        if not self.has_unsaved_edits():
            return True
        answer = self.window.ask_save_before_leaving(self.session.record.display_label)
        if answer == "save":
            return self.im_satisfied_pushed(advance=False)
        return answer == "discard"

    def open_index(self, index_id: int) -> bool:
        """Leave the open index (asking about unsaved edits) and show another one."""
        self.window.hide_board()
        if index_id == self.session.record.index_id or not self.ready_to_leave():
            return False
        try:
            packet = self.data_manager.checkout_image(index_id)
        except ProjectError as error:
            self.window.report("Could not open the index", str(error))
            return False
        self._detection_timer.stop()
        self._region_timer.stop()
        self._growth_timer.stop()
        review = packet.saved.review_reason if packet.saved and packet.saved.needs_review else ""
        self._bind(session_from_packet(packet), review)
        return True

    # ----- developer mode: recording ----------------------------------------
    def _start_recording(self, initial=None) -> None:
        """Developer mode: start the record of this image session (see core/benchmark.py). The
        initial detection is computed here unless it is passed on from the session's last record."""
        if not self.data_manager.recording:
            self.recorder = None
            return
        session, record = self.session, self.session.record
        if initial is None:
            initial = reference_start(record.image, record.mask, self.data_manager.detection_defaults())
        self.recorder = DetectionRecorder(record.index_id, record.image.shape[:2], int(record.mask.sum()),
                                          record.px_per_mm, session.start_source, session.params, initial)
        if not session.loaded_revision:
            self._record_detection("initial")

    def _record(self, event: str, every_ms: int = 0, **data) -> None:
        if self.recorder is not None:
            self.recorder.record(event, every_ms, **data)

    def _record_detection(self, trigger: str) -> None:
        session = self.session
        self._record("detection", trigger=trigger, params=params_data(session.params),
                     compute_ms=round(session.last_compute_ms, 1), colonies=len(session.colonies))

    def _record_edit(self) -> None:
        edit = self.session.last_edit
        if edit is not None:
            self._record("edit", kind=edit.kind, count=edit.count, colony_ids=list(edit.colony_ids), mode=self.mode)

    def _watch_focus(self) -> None:
        """Developer mode: note when the program becomes active or inactive (time spent in another program)."""
        app = QApplication.instance()
        if not self.data_manager.developer or app is None:
            return
        app.applicationStateChanged.connect(self._application_state)

        def stop(_object=None) -> None:
            try:
                app.applicationStateChanged.disconnect(self._application_state)
            except (RuntimeError, TypeError):
                pass

        self.window.destroyed.connect(stop)

    def _application_state(self, state) -> None:
        self._record("focus", active=state == Qt.ApplicationActive)

    # ----- wiring ---------------------------------------------------------
    def _connect_signals(self) -> None:
        w = self.window
        w.modeChosen.connect(self.dropdown_changed)
        w.settingEdited.connect(self.spinner_value_changing)
        w.shapeChosen.connect(self.detection_type_switch_value_changed)
        w.estimateRequested.connect(self.estimate_settings)
        w.newImageStartChosen.connect(self.set_new_image_start)
        w.deleteRequested.connect(self.delete_selected_colonies_button_pushed)
        w.addRequested.connect(self.add_selected_colonies_button_pushed)
        w.clearRequested.connect(self.clear_selection)
        w.contourToggled.connect(self.controller_contour_circle)
        w.growthToggled.connect(lambda _on: self.update_growth())
        w.undoRequested.connect(self.undo)
        w.redoRequested.connect(self.redo)
        w.finishRequested.connect(self.finish_requested)
        w.helpRequested.connect(self.colony_detection_help)
        w.pointerMoved.connect(self._pointer_moved)

    def _pointer_moved(self, x: float, y: float) -> None:
        self._record("pointer", POINTER_EVERY_MS)
        rows, cols = self.session.image.shape[:2]
        self.window.set_pointer(x, y, -0.5 <= x < cols - 0.5 and -0.5 <= y < rows - 0.5)

    def _on_session_changed(self, _event: str) -> None:
        self.window.set_spinner_values(self.session.params)
        self.display_colonies()
        self.window.set_growth(None)
        if self.window.growth_shown():
            self._growth_timer.start()                 # restarts while edits keep coming
        else:
            self.window.show_growth(None, None)

    def update_growth(self) -> None:
        """Measure growth on the current colonies; tint it on the image when Show is on."""
        from ..core.growth import growth_mask
        self._growth_timer.stop()
        session = self.session
        result = growth_mask(session.image, session.mask, session.colonies)
        try:
            self.window.set_growth(result.metrics())
            if self.window.growth_shown():
                self.window.show_growth(result.growth, result.colonies)
            else:
                self.window.show_growth(None, None)
        except RuntimeError:                           # the window closed while growth was measured
            pass

    # ----- modes ----------------------------------------------------------
    def dropdown_changed(self, mode_key: str) -> None:
        if mode_key != self.mode and self.settle_unadded("mode"):
            self.select_dropdown_option(mode_key)
        else:
            self.window.mode_buttons[self.mode].setChecked(True)

    def settle_unadded(self, before: str) -> bool:
        """Drawn circles and region outlines count only once added. Before Finish image or a tool change drops
        them, ask: add them, discard them, or go back. True when the action can go ahead."""
        drawn = len(self.pending_circles)
        region = 0 if self.candidates is None else len(self.candidates)
        if not drawn and not region:
            return True
        choice = self.window.ask_unadded(drawn, region, before)
        self._record("unadded", choice=choice, before=before, drawn=drawn, region=region)
        if choice == "add":
            self.add_selected_colonies_button_pushed()
        elif choice == "discard":
            self.pending_circles.clear()
            self.candidates = None
            self.roi = None
            self.display_colonies()
        return choice != "back"

    def select_dropdown_option(self, mode_key: str) -> None:
        """Leave the current mode, enter the new one (handleInteractionSpecificActions)."""
        self._detection_timer.stop()
        self._region_timer.stop()
        if self.mode in self.tools:
            self.tools[self.mode].deactivate()
        self._clear_pending()
        self.mode = mode_key
        self._record("mode", mode=mode_key)
        spec = MODES[mode_key]
        self.window.set_tool(self.tools.get(mode_key))
        self.window.set_spinner_values(self.session.params)
        self.window.update_mode_specific_view(spec)
        self.display_colonies()

    def _clear_pending(self) -> None:
        self.selected_ids.clear()
        self.selection_rect = None
        self.pending_circles.clear()
        self.roi = None
        self.roi_params = None
        self.candidates = None

    def clear_selection(self) -> None:
        """Esc: drop the selection, the deletion box, or the detection region."""
        self.selected_ids.clear()
        self.selection_rect = None
        if self.roi is not None:
            self.roi = None
            self.roi_params = None
            self.candidates = None
            self.window.set_spinner_values(self.session.params)
        self.display_colonies()

    # ----- automatic detection (settings) ---------------------------------
    def spinner_value_changing(self, field_name: str, value: float) -> None:
        self._record("setting", SETTING_EVERY_MS, field=field_name)
        if MODES[self.mode].region_parameters:
            base = self.roi_params or self.session.params
            self.roi_params = base.with_value(field_name, value)
            self._region_timer.start()
            return
        self._detection_timer.start()       # restarts while the user keeps changing values

    def estimate_settings(self) -> None:
        """Estimate the settings from this image and rerun detection with them (undoable)."""
        self._detection_timer.stop()
        params = self.session.estimated_parameters()
        if params == self.session.params:
            self.notifyuser("SettingsAlreadyEstimated")
            return
        self._clear_pending()
        count = self.session.detect_colonies(params)
        self._record_detection("estimate")
        self._record_edit()
        self.notifyuser("SettingsEstimated", (count, params))

    def set_new_image_start(self, mode: str) -> None:
        """How new images choose their starting settings, for this project ('estimate' or 'last image')."""
        try:
            self.data_manager.set_new_image_start(mode)
        except ProjectError as error:
            self.window.report("Could not change the setting", str(error))
            mode = self.data_manager.new_image_start()
        self.window.set_new_image_start(mode)
        self.window.show_status("New images start from their own estimate" if mode == "estimate"
                                else "New images start from the last image you finished")

    def detection_type_switch_value_changed(self, kind: str) -> None:
        if MODES[self.mode].region_parameters:
            base = self.roi_params or self.session.params
            self.roi_params = base.with_value("detection_type", kind)
            self.update_region_detection()
        else:
            self.handle_backup_and_detection("shape")

    def _params_from_controls(self) -> DetectionParams:
        settings = self.window.settings()
        if settings["detection_type"] != CIRCULAR:          # Largest object is a Circular setting
            settings["maxpix"] = maxpix_for(settings["rmax"])
        return DetectionParams(**settings)

    def handle_backup_and_detection(self, trigger: str = "settings") -> None:
        """Validate the settings, then rerun detection as an undoable command."""
        params = self._params_from_controls()
        if params == self.session.params:
            return
        error = validate_detection_parameters(params)
        if error:
            self.notifyuser("ParameterError", error)
            self.window.set_spinner_values(self.session.params)
            return
        self._clear_pending()
        count = self.session.detect_colonies(params)
        self._record_detection(trigger)
        self._record_edit()
        self.notifyuser("DetectionResults", (count, params))

    # ----- Delete colonies (one at a time) -------------------------------
    def handle_delete_click(self, x: float, y: float) -> None:
        colonies = self.session.colonies
        index, distance = colonies.nearest((x, y))
        if index < 0 or distance > SELECTION_TOLERANCE * colonies.radii[index]:
            self.notifyuser("ClickNotCloseEnough")
            return
        colony_id = int(colonies.ids[index])
        if colony_id in self.selected_ids:
            self.selected_ids.discard(colony_id)
            self.notifyuser("ColonyDeselected", colonies.centers[index])
        else:
            self.selected_ids.add(colony_id)
            self.notifyuser("ColonySelected", colonies.centers[index])
        self._record("select", how="click", count=len(self.selected_ids))
        self.display_colonies()

    # ----- Delete a region ------------------------------------------------
    def highlight_colonies_in_rect(self, x0: float, y0: float, x1: float, y1: float) -> None:
        ids = self.session.colonies.ids_in_rect(x0, y0, x1, y1)
        self.selected_ids = {int(i) for i in ids}
        self.selection_rect = (x0, y0, x1, y1)
        self._record("select", how="rectangle", count=len(ids))
        self.notifyuser("RectangleSelectionCount", len(ids))
        self.display_colonies()

    def delete_selected_colonies_button_pushed(self) -> None:
        if not self.selected_ids:
            self.notifyuser("NoColoniesSelected")
            return
        deleted = self.session.delete_colonies(sorted(self.selected_ids))
        if deleted:
            self._record_edit()
        self.selected_ids.clear()
        self.selection_rect = None
        self.notifyuser("ColoniesDeleted", (deleted, len(self.session.colonies)))
        self.display_colonies()

    # ----- Add colonies (the tool's CircleEditor interface) --------------
    def hit_test_circle(self, x: float, y: float, edge_tolerance: float) -> tuple[int, str]:
        return hit_test(self.pending_circles, x, y, edge_tolerance)

    def circle_geometry(self, index: int) -> tuple[float, float, float]:
        circle = self.pending_circles[index]
        return circle.x, circle.y, circle.r

    def add_new_circle(self, x: float, y: float, r: float) -> int:
        """Start a new circle; the tool then sizes it with update_circle (addNewCircle)."""
        self.pending_circles.append(DrawnCircle(x, y, r))
        self._record("draw", circles=len(self.pending_circles))
        self.display_colonies()
        return len(self.pending_circles) - 1

    def update_circle(self, index: int, x: float, y: float, r: float, final: bool) -> None:
        """Move or resize a drawn circle. The contour is refitted when the drag ends."""
        circle = self.pending_circles[index]
        circle = circle.moved_to(x, y) if (x, y) != (circle.x, circle.y) else circle
        circle = circle.resized_to(r) if r != circle.r else circle.without_contour()
        if final and self.contour_enabled:
            circle = self._contour(circle)
        if final:
            snapped = circle.contour is not None and circle.contour.found
            self._record("draw", circles=len(self.pending_circles), snapped=bool(snapped))
        self.pending_circles[index] = circle
        self.display_colonies()

    def describe_radius(self, r: float) -> str:
        """Radius readout next to the pointer while drawing."""
        um = r / self.session.px_per_mm * 1000 if self.session.px_per_mm else None
        return f"r {r:.1f} px" + (f" · {um:,.0f} µm" if um is not None else "")

    def remove_circle(self, index: int, how: str = "right") -> None:
        """A drawn circle removed: a right-click on it ('right'), or a click too short to draw ('click')."""
        del self.pending_circles[index]
        self._record("draw_removed", how=str(how), circles=len(self.pending_circles))
        if how == "right":
            self.notifyuser("CircleRemoved")
        self.display_colonies()

    def controller_contour_circle(self, enabled: bool) -> None:
        """Snap-to-edge switch (Controller_ContourCircle): fit or clear outlines on every drawn circle."""
        self.contour_enabled = enabled
        self.notifyuser("ContourOn" if enabled else "ContourOff")
        if enabled:
            self.pending_circles = [self._contour(circle) for circle in self.pending_circles]
        else:
            self.pending_circles = [circle.without_contour() for circle in self.pending_circles]
        self.display_colonies()

    def _contour(self, circle: DrawnCircle) -> DrawnCircle:
        fitted = circle.with_contour(self.session.image, self.session.mask)
        if not fitted.contour.found:
            self.notifyuser("ContourFailed", fitted.contour.reason)
        return fitted

    # ----- Detect in a region ---------------------------------------------
    def start_region_detection(self, x0: float, y0: float, x1: float, y1: float) -> None:
        self.roi = (min(x0, x1), min(y0, y1), abs(x1 - x0), abs(y1 - y0))
        self.roi_params = self.roi_params or self.session.params
        self.update_region_detection()

    def update_region_detection(self) -> None:
        if self.roi is None:
            return
        self.candidates = self.session.preview_region_detection(self.roi_params, self.roi)
        self._record("region_preview", roi=[round(float(v), 1) for v in self.roi], params=params_data(self.roi_params),
                     compute_ms=round(self.session.last_compute_ms, 1), candidates=len(self.candidates))
        self.notifyuser("RegionCandidates", len(self.candidates))
        self.display_colonies()

    def add_selected_colonies_button_pushed(self) -> None:
        if self.guide is not None and self.mode != "AddManyColonies" and self.guide.adding_blocked():
            self.window.show_status("Right-click the circle to remove it first; Add colonies comes after.")
            return
        if self.mode == "AddManyColonies":
            new = self.candidates if self.candidates is not None else ColonySet.empty()
        else:
            new = drawn_to_colonies(self.pending_circles)
        if len(new) == 0:
            self.notifyuser("NothingToAdd")
            return
        added = self.session.add_colonies(new, skip_overlapping=self.mode == "AddManyColonies")
        if added:
            self._record_edit()
        self.pending_circles.clear()
        self.candidates = None
        self.roi = None
        self.notifyuser("ColoniesAdded", (added, len(new) - added, len(self.session.colonies)))
        self.display_colonies()

    # ----- undo / redo ----------------------------------------------------
    def undo(self) -> None:
        self._clear_pending()
        command = self.session.undo()
        if command is None:
            self.notifyuser("NoUndoActions")
            return
        self._record("undo", kind=command.kind, count=command.count)
        self.notifyuser("Undo", self._describe(command))

    def redo(self) -> None:
        self._clear_pending()
        command = self.session.redo()
        if command is None:
            self.notifyuser("NoRedoActions")
            return
        self._record("redo", kind=command.kind, count=command.count)
        self.notifyuser("Redo", self._describe(command))

    @staticmethod
    def _describe(command) -> str:
        noun = "colony" if command.count == 1 else "colonies"
        verbs = {"Detection": "detection of", "Deletion": "deletion of", "Addition": "addition of"}
        return f"{verbs.get(command.kind, command.kind.lower())} {command.count} {noun}"

    # ----- finishing ------------------------------------------------------
    @property
    def output_folder(self) -> Path:
        return self.data_manager.exports_folder

    def finish_requested(self) -> bool:
        """Finish image: outlines not added are settled first; the tour's practice plate is checked first."""
        if not self.settle_unadded("finish"):
            return False
        if self.guide is not None and not self.guide.before_finish():
            return False
        return self.im_satisfied_pushed()

    def im_satisfied_pushed(self, advance: bool = True) -> bool:
        """Send the working copy to the DataManager, which stores it as the truth and exports
        the measurement table, then open the next index waiting for detection or review
        (FinishColonySetAndNavigate). Returns whether the save worked."""
        index_id = self.session.record.index_id
        benchmark = self.recorder.finish(self.session.params) if self.recorder is not None else None
        try:
            revision = self.data_manager.commit_detection(self.session.result(), benchmark)
        except (ProjectError, OSError) as error:
            self.window.report("Could not save", str(error))
            return False
        self.session.mark_committed(revision)              # saved in the project, whatever happens to the export
        if self.recorder is not None:                      # work that continues on this image is a new session
            self.session.start_source = "saved"
            self._start_recording(self.recorder.initial)
        self.data_manager.request_derived("plate_coverage", index_id)   # measured once, kept
        try:
            path = self.data_manager.export_colonies_csv(index_id)
            exported = f"{path.parent.name}/{path.name}"
        except OSError as error:
            exported = "the colony table was not exported"
            self.notifyuser("ExportFailed", export_problem(error, self.data_manager.exports_folder))
        self.notifyuser("Saved", (len(self.session.colonies), revision, exported))
        self._show_position()
        if advance:
            indices = self.index_status()
            ids = [i for i, _, _ in indices]
            current = ids.index(self.session.record.index_id) if self.session.record.index_id in ids else -1
            following = indices[current + 1:] + indices[:current + 1]
            waiting = next((i for i, _, state in following if state in ("waiting", "review")), None)
            if waiting is not None:
                self.open_index(waiting)
            else:
                self.all_indices_detected(len(ids))
        return True

    def all_indices_detected(self, count: int) -> None:
        """Nothing is left to detect or review: offer Stats or the project page."""
        self.notifyuser("AllDetected")
        if self.leave_to is None or self.guide is not None:   # no navigator, or the tour's practice plate
            return
        choice = self.window.ask_all_detected(count)
        if choice in ("stats", "project"):
            self.leave_to(choice)

    def colony_detection_help(self) -> None:
        from .help import show_help
        show_help("detection", self.window)

    # ----- display --------------------------------------------------------
    def notifyuser(self, message_key: str, value=None) -> None:
        message = compose_message(message_key, self.label, value)
        if message.kind:
            self.window.add_activity(message.kind, message.text, message.detail)
        else:
            self.window.show_status(message.text)

    def display_colonies(self) -> None:
        self.window.draw_colonies(
            self.session.colonies,
            selected_ids=self.selected_ids,
            pending_circles=self.pending_circles,
            candidates=self.candidates,
            selection_rect=self.selection_rect,
            region_rect=(None if self.roi is None else
                         (self.roi[0], self.roi[1], self.roi[0] + self.roi[2], self.roi[1] + self.roi[3])),
            dim_existing=self.mode == "AddManyColonies" and self.roi is not None,
        )
        self.window.set_history(self.session.can_undo(), self.session.can_redo(), self.session.undo_depth())
        self.window.set_interaction_state(
            selected=len(self.selected_ids), box=self.selection_rect is not None,
            pending=len(self.pending_circles), region=self.roi is not None,
            candidates=None if self.candidates is None else len(self.candidates))
        self.window.set_summary(summarize_colonies(self.session.colonies, self.session.px_per_mm))
