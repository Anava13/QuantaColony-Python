"""DetectCanvas: the plate image with colony overlays (view).

Scene coordinates equal image coordinates: the pixmap is offset by half a
pixel, so the center of pixel (row r, column c) sits at scene point (c, r),
the same convention the core uses. Mouse events go to the active tool.

Navigation: the wheel zooms toward the pointer (customWheelZoom), middle-drag
or Space + left-drag pans, double-click resets the view. Left and right
clicks go to the active tool.
"""

from __future__ import annotations

import numpy as np
from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QBrush, QColor, QImage, QPainter, QPainterPath, QPen, QPixmap, QTransform
from PySide6.QtWidgets import QGraphicsScene, QGraphicsView

from ..core.colony_set import KIND_MANUAL, KIND_SPLIT, ColonySet
from ..theme.tokens import ColonyColors
from ..theme.tokens import get_quanta_colony_style


DRAWN = "#ECEEE6"                # a drawn circle, not added yet
MARK = "#FF3DFF"                 # the tour's arrow and corner dots
DOT_HELD = "#7BF501"             # a corner dot inside the box


class DetectCanvas(QGraphicsView):
    ZOOM_STEP = 1.15
    MAX_SCALE = 40.0            # screen pixels per image pixel at full zoom

    pointerMoved = Signal(float, float)      # image coordinates under the pointer
    zoomChanged = Signal(float)              # screen pixels per image pixel

    def __init__(self, colony_colors: ColonyColors, frame_color: str = get_quanta_colony_style().colors.frame, parent=None):
        super().__init__(parent)
        self.setObjectName("DetectCanvas")
        self.colors = colony_colors
        self.frame_color = frame_color
        self.pan_mode = False                # toolbar hand button: left-drag pans
        self.setScene(QGraphicsScene(self))
        self.setRenderHint(QPainter.Antialiasing)
        self.setTransformationAnchor(QGraphicsView.NoAnchor)
        self.setResizeAnchor(QGraphicsView.NoAnchor)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.StrongFocus)         # receives the Space key for panning
        self.tool = None                    # active CanvasTool, set by the controller
        self._image_item = None
        self._image_rect = QRectF()
        self._fit_scale = 1.0
        self._overlay_items: list = []
        self._user_zoomed = False
        self._pan_origin = None
        self._space_down = False
        self.guide_arrow = None              # (x, y, r): the tour's arrow points at this circle's edge
        self.guide_dots = []                 # [(x, y)]: the corners of the box the tour asks for
        self.guide_capture = False           # dots turn green inside the box being dragged or drawn
        self._live_box = None                # (x0, y0, x1, y1) of the box being dragged
        self._boxes = {}                     # the drawn selection and region boxes

    # ----- image --------------------------------------------------------
    def set_overlay(self, rgba: np.ndarray | None) -> None:
        """A see-through layer over the image (growth), or None to remove it."""
        if getattr(self, "_overlay_item", None) is not None and self._overlay_item.scene() is self.scene():
            self.scene().removeItem(self._overlay_item)
        self._overlay_item = None
        if rgba is None:
            return
        data = np.ascontiguousarray(rgba, dtype=np.uint8)
        rows, cols = data.shape[:2]
        qimage = QImage(data.data, cols, rows, 4 * cols, QImage.Format_RGBA8888).copy()
        self._overlay_item = self.scene().addPixmap(QPixmap.fromImage(qimage))
        self._overlay_item.setOffset(-0.5, -0.5)
        self._overlay_item.setZValue(-0.75)                 # above the image, below the frame and colonies

    def set_image(self, image: np.ndarray) -> None:
        self.set_overlay(None)
        rgb = np.ascontiguousarray(image[..., :3])
        rows, cols = rgb.shape[:2]
        qimage = QImage(rgb.data, cols, rows, 3 * cols, QImage.Format_RGB888).copy()
        if self._image_item is not None:
            self.scene().removeItem(self._image_item)
        self._image_item = self.scene().addPixmap(QPixmap.fromImage(qimage))
        self._image_item.setOffset(-0.5, -0.5)
        self._image_item.setZValue(-1)
        self._image_rect = QRectF(-0.5, -0.5, cols, rows)
        frame = QPainterPath()
        frame.addRoundedRect(self._image_rect.adjusted(-0.6, -0.6, 0.6, 0.6), 2, 2)
        frame_pen = QPen(QColor(self.frame_color), 1)
        frame_pen.setCosmetic(True)
        if getattr(self, "_frame_item", None) is not None and self._frame_item.scene() is self.scene():
            self.scene().removeItem(self._frame_item)        # a new image replaces the old frame
        self._frame_item = self.scene().addPath(frame, frame_pen)
        self._frame_item.setZValue(-0.5)
        # A scene much larger than the image lets the view move freely, so a
        # zoom can stay anchored on the pointer even near the image edges
        self.setSceneRect(self._image_rect.adjusted(-10 * cols, -10 * rows, 10 * cols, 10 * rows))
        self.reset_axes_view()

    def reset_axes_view(self) -> None:
        """Whole image in view (resetAxesView)."""
        self._user_zoomed = False
        if self._image_rect.isEmpty():
            return
        # Leave room around the plate for the floating chips and zoom toolbar
        w, h = self._image_rect.width(), self._image_rect.height()
        self.fitInView(self._image_rect.adjusted(-0.05 * w, -0.13 * h, 0.05 * w, 0.17 * h), Qt.KeepAspectRatio)
        self._fit_scale = self.transform().m11()
        self.centerOn(self._image_rect.center() + QPointF(0, 0.02 * h))
        self.zoomChanged.emit(self.view_scale())

    def zoom_in(self) -> None:
        self.zoom_at(QPointF(self.viewport().rect().center()), self.ZOOM_STEP ** 2)

    def zoom_out(self) -> None:
        self.zoom_at(QPointF(self.viewport().rect().center()), self.ZOOM_STEP ** -2)

    def view_scale(self) -> float:
        """Screen pixels per image pixel."""
        return self.transform().m11()

    def screen_to_image_distance(self, pixels: float) -> float:
        return pixels / self.view_scale()

    def set_tool_cursor(self, shape) -> None:
        if not (self.pan_mode or self._space_down):
            self.viewport().setCursor(shape)

    def set_pan_mode(self, enabled: bool) -> None:
        self.pan_mode = enabled
        self.viewport().setCursor(Qt.OpenHandCursor if enabled else Qt.ArrowCursor)

    # ----- overlays (renderDisplay / renderColonies) ---------------------
    def render_colonies(self, colonies: ColonySet, selected_ids=(), pending_circles=(),
                        candidates: ColonySet | None = None, selection_rect=None,
                        region_rect=None, dim_existing: bool = False) -> None:
        """dim_existing draws current colonies in black (Add Many mode), so candidates stand out."""
        for item in self._overlay_items:
            self.scene().removeItem(item)
        self._overlay_items = []
        c = self.colors
        selected = np.isin(colonies.ids, np.asarray(list(selected_ids), dtype=np.int64))

        detected_path, center_path, manual_path, selected_path, split_path = (
            QPainterPath(), QPainterPath(), QPainterPath(), QPainterPath(), QPainterPath())
        for i in range(len(colonies)):
            x, y = colonies.centers[i]
            radius = colonies.radii[i]
            outline = colonies.boundaries[i]
            kind = colonies.kinds[i]
            target = manual_path if kind == KIND_MANUAL else split_path if kind == KIND_SPLIT else detected_path
            self._add_shape(target, outline, x, y, radius)
            if colonies.kinds[i] != KIND_MANUAL:
                self._add_plus(center_path, x, y, 1.6)
            if selected[i]:
                self._add_shape(selected_path, outline, x, y, radius)
                self._add_plus(selected_path, x, y, 2.2)

        alpha = c.dimmed_alpha if dim_existing else 255
        self._add_path(manual_path, c.halo, c.manual_width + 2, alpha=alpha)
        self._add_path(manual_path, c.manual, c.manual_width, alpha=alpha)
        self._add_path(detected_path, c.detected, c.detected_width, alpha=alpha)
        self._add_path(split_path, c.split, c.detected_width, alpha=alpha)
        if not dim_existing:
            self._add_path(center_path, c.detected, 1.0)

        if candidates is not None and len(candidates):
            candidate_path = QPainterPath()
            for i in range(len(candidates)):
                x, y = candidates.centers[i]
                self._add_shape(candidate_path, candidates.boundaries[i], x, y, candidates.radii[i])
            # Found in the region, not yet added: dashed, like drawn circles
            self._add_path(candidate_path, c.candidate, c.detected_width, style=Qt.DashLine, fill_alpha=36)

        if pending_circles:
            # Drawn circles: plain circles are filled; contoured ones show the
            # fitted outline solid and the drawn circle as a faint dashed guide
            plain_path, guide_path, contour_path = QPainterPath(), QPainterPath(), QPainterPath()
            for circle in pending_circles:
                if circle.outline is not None:
                    guide_path.addEllipse(QPointF(circle.x, circle.y), circle.r, circle.r)
                    self._add_shape(contour_path, circle.outline, circle.x, circle.y, circle.r)
                else:
                    plain_path.addEllipse(QPointF(circle.x, circle.y), circle.r, circle.r)
            # drawn, not added yet: white and dashed (added colonies are lime)
            self._add_path(plain_path, c.halo, 3.4, style=Qt.DashLine)
            self._add_path(plain_path, DRAWN, 1.8, style=Qt.DashLine, fill_alpha=20)
            self._add_path(guide_path, DRAWN, 1.4, style=Qt.DashLine)
            self._add_path(contour_path, c.halo, 4.0)
            self._add_path(contour_path, DRAWN, 2.4, style=Qt.DashLine)

        self._add_path(selected_path, c.selected, c.selected_width, fill_alpha=56)
        self._boxes = {"selection": selection_rect, "region": region_rect}
        for rect, color in ((selection_rect, c.selected), (region_rect, c.manual)):   # red deletes, green adds
            if rect is not None:
                x0, y0, x1, y1 = rect
                rect_path = QPainterPath()
                rect_path.addRect(QRectF(QPointF(min(x0, x1), min(y0, y1)), QPointF(max(x0, x1), max(y0, y1))))
                self._add_path(rect_path, color, 3.0, style=Qt.DotLine, fill_alpha=8)
        self.viewport().update()

    # ----- the tour's marks: an arrow at one target, or the corners of a box to drag ----------------
    def set_guide(self, arrow=None, dots=(), capture: bool = False) -> None:
        if (arrow, list(dots), capture) != (self.guide_arrow, self.guide_dots, self.guide_capture):
            self.guide_arrow, self.guide_dots, self.guide_capture = arrow, [tuple(d) for d in dots], capture
            self.viewport().update()

    def set_live_box(self, box) -> None:
        self._live_box = box
        if self.guide_dots:
            self.viewport().update()

    def drawForeground(self, painter: QPainter, rect: QRectF) -> None:
        """The marks keep their size on screen at any zoom: lengths are screen pixels / scale."""
        if not self.guide_dots and self.guide_arrow is None:
            return
        scale = max(self.transform().m11(), 1e-6)
        painter.setRenderHint(QPainter.Antialiasing)
        box = self._live_box or self._boxes.get("region") or self._boxes.get("selection")
        if box is not None:
            box = (min(box[0], box[2]), min(box[1], box[3]), max(box[0], box[2]), max(box[1], box[3]))
        for x, y in self.guide_dots:
            held = self.guide_capture and box is not None and box[0] <= x <= box[2] and box[1] <= y <= box[3]
            r = 10 / scale
            painter.setPen(Qt.NoPen)
            painter.setBrush(QColor(get_quanta_colony_style().colony.halo))
            painter.drawEllipse(QPointF(x, y), r + 2.5 / scale, r + 2.5 / scale)
            painter.setBrush(QColor(DOT_HELD if held else MARK))
            pen = QPen(QColor("#FFFFFF"), 3 / scale)
            painter.setPen(pen)
            painter.drawEllipse(QPointF(x, y), r, r)
        if self.guide_arrow is not None:
            cx, cy, r = self.guide_arrow
            ux = uy = 0.7071
            tip = QPointF(cx - ux * (r + 2 / scale), cy - uy * (r + 2 / scale))
            length, head, half, shaft = 95 / scale, 34 / scale, 19 / scale, 7 / scale
            base = QPointF(tip.x() - ux * head, tip.y() - uy * head)
            px, py = -uy, ux
            path = QPainterPath()
            path.moveTo(tip)
            path.lineTo(base.x() + px * half, base.y() + py * half)
            path.lineTo(base.x() + px * shaft, base.y() + py * shaft)
            path.lineTo(tip.x() - ux * length + px * shaft, tip.y() - uy * length + py * shaft)
            path.lineTo(tip.x() - ux * length - px * shaft, tip.y() - uy * length - py * shaft)
            path.lineTo(base.x() - px * shaft, base.y() - py * shaft)
            path.lineTo(base.x() - px * half, base.y() - py * half)
            path.closeSubpath()
            pen = QPen(QColor("#FFFFFF"), 3 / scale)
            pen.setJoinStyle(Qt.RoundJoin)
            painter.setPen(pen)
            painter.setBrush(QColor(MARK))
            painter.drawPath(path)

    @staticmethod
    def _add_shape(path: QPainterPath, outline, x: float, y: float, radius: float) -> None:
        if outline is not None and len(outline) > 2:
            path.moveTo(float(outline[0, 0]), float(outline[0, 1]))
            for px, py in outline[1:]:
                path.lineTo(float(px), float(py))
            path.closeSubpath()
        else:
            path.addEllipse(QPointF(float(x), float(y)), float(radius), float(radius))

    @staticmethod
    def _add_plus(path: QPainterPath, x: float, y: float, half: float) -> None:
        path.moveTo(x - half, y)
        path.lineTo(x + half, y)
        path.moveTo(x, y - half)
        path.lineTo(x, y + half)

    def _add_path(self, path: QPainterPath, color: str, width: float,
                  style=Qt.SolidLine, fill_alpha: int = 0, alpha: int = 255) -> None:
        if path.isEmpty():
            return
        stroke = QColor(color)
        stroke.setAlpha(alpha)
        pen = QPen(stroke, width, style)
        pen.setCosmetic(True)                      # width in screen pixels at any zoom
        pen.setJoinStyle(Qt.RoundJoin)
        if style == Qt.DashLine:
            pen.setDashPattern([4, 3])
        elif style == Qt.DotLine:
            pen.setDashPattern([3, 2])
        fill = QColor(color)
        fill.setAlpha(fill_alpha)
        item = self.scene().addPath(path, pen, QBrush(fill) if fill_alpha else QBrush(Qt.NoBrush))
        self._overlay_items.append(item)

    # ----- temporary drawing used by tools -------------------------------
    def add_preview_item(self, item) -> None:
        self.scene().addItem(item)

    def remove_preview_item(self, item) -> None:
        if item is not None and item.scene() is self.scene():
            self.scene().removeItem(item)

    # ----- zoom, pan, mouse ----------------------------------------------
    def zoom_at(self, view_point: QPointF, factor: float) -> None:
        """Scale by factor while the image point under view_point stays under it."""
        anchor = self.mapToScene(view_point.toPoint())
        current = self.view_scale()
        target = min(max(current * factor, self._fit_scale), self.MAX_SCALE)
        if factor < 1 and target <= self._fit_scale * 1.001:
            self.reset_axes_view()                 # fully zoomed out: recenter the plate
            return
        self.setTransform(QTransform.fromScale(target, target))
        viewport_center = QPointF(self.viewport().width() / 2, self.viewport().height() / 2)
        self.centerOn(anchor - (view_point - viewport_center) / target)
        self._user_zoomed = True
        self.zoomChanged.emit(target)

    def focus_on(self, x: float, y: float, radius: float) -> None:
        """Center a circle of the image in view, zoomed so it fills about a third of the view."""
        side = max(min(self.viewport().width(), self.viewport().height()), 100)
        target = min(max(side / (3 * max(radius, 3.0)), self._fit_scale), min(4 * self._fit_scale, self.MAX_SCALE))
        self.setTransform(QTransform.fromScale(target, target))
        self.centerOn(QPointF(x, y))
        self._user_zoomed = True
        self.zoomChanged.emit(target)

    def pan_by(self, delta: QPointF) -> None:
        """Move the view by a screen-pixel delta."""
        center = self.mapToScene(self.viewport().rect().center())
        self.centerOn(center - delta / self.view_scale())

    def wheelEvent(self, event) -> None:   # customWheelZoom
        steps = event.angleDelta().y() / 120
        if steps:
            self.zoom_at(event.position(), self.ZOOM_STEP ** steps)

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        if not self._user_zoomed and self._image_item is not None:
            self.reset_axes_view()

    def keyPressEvent(self, event) -> None:
        if event.key() == Qt.Key_Space and not event.isAutoRepeat():
            self._space_down = True
            self.viewport().setCursor(Qt.OpenHandCursor)
            return
        super().keyPressEvent(event)

    def keyReleaseEvent(self, event) -> None:
        if event.key() == Qt.Key_Space and not event.isAutoRepeat():
            self._space_down = False
            self.viewport().unsetCursor()
            return
        super().keyReleaseEvent(event)

    def mousePressEvent(self, event) -> None:
        self.setFocus()
        panning = event.button() == Qt.MiddleButton or (
            event.button() == Qt.LeftButton and (self._space_down or self.pan_mode))
        if panning:
            self._pan_origin = event.position()
            self.viewport().setCursor(Qt.ClosedHandCursor)
            return
        if self.tool and not (self.pan_mode and event.button() == Qt.RightButton):
            self.tool.press(self.mapToScene(event.position().toPoint()), event.button())

    def mouseMoveEvent(self, event) -> None:
        scene_point = self.mapToScene(event.position().toPoint())
        self.pointerMoved.emit(scene_point.x(), scene_point.y())
        if self._pan_origin is not None:
            self.pan_by(event.position() - self._pan_origin)
            self._pan_origin = event.position()
            self._user_zoomed = True
            return
        if self.tool:
            self.tool.move(self.mapToScene(event.position().toPoint()))

    def mouseReleaseEvent(self, event) -> None:
        if self._pan_origin is not None:
            self._pan_origin = None
            self.viewport().setCursor(Qt.OpenHandCursor if (self._space_down or self.pan_mode) else Qt.ArrowCursor)
            return
        if self.tool:
            self.tool.release(self.mapToScene(event.position().toPoint()), event.button())

    def mouseDoubleClickEvent(self, event) -> None:
        if event.button() == Qt.LeftButton:
            self.reset_axes_view()
