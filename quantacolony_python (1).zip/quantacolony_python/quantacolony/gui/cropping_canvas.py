"""CropCanvas: a plate photo with its layout drawn on top, and the mouse tool that edits the layout.

Round dish: drag the center to move the dish, the square on the rim to resize
it, the large handle to rotate every cut, a small cut handle to move that cut
alone; right-click a cut handle to remove it. Rectangular plate: drag the
center, a corner (resizes about the center) or the rotation handle; with spots,
the handle on the first spot's edge sets every spot's diameter. Clicking
inside a section selects it. Zoom and pan work as in Colony Detection.

Scale bar (while the photo's scale is a bar): dragging across empty photo draws
the bar; its end handles move one end, its middle handle moves the whole bar.
"""

from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QBrush, QColor, QFont, QPainterPath, QPen
from PySide6.QtWidgets import (QGraphicsEllipseItem, QGraphicsItem, QGraphicsPathItem, QGraphicsRectItem,
                               QGraphicsSimpleTextItem)

from ..core.cropping import DishLayout, GridLayout, clock_angle, point_at
from .canvas import DetectCanvas
from .tools import CanvasTool
from ..theme.tokens import get_quanta_colony_style

_C = get_quanta_colony_style().colors
LIME, LIME_TEXT, DANGER, HALO = _C.accent, _C.accent_text, _C.danger, _C.canvas
BAR_COLOR = "#FFB020"             # the scale bar, apart from the plate's lime
HANDLE_PX = 9                     # grab distance around a handle, screen pixels
CLICK_PX = 4                      # a drag shorter than this (screen pixels) is a click


class CropCanvas(DetectCanvas):
    layoutEdited = Signal(object, bool)       # new layout, drag finished
    sectionPicked = Signal(int)
    cutRemoved = Signal(int)
    barEdited = Signal(object, bool)          # ((x0, y0), (x1, y1)) in photo pixels, drag finished

    def __init__(self, colony_colors, frame_color: str = _C.frame, parent=None):
        super().__init__(colony_colors, frame_color, parent)
        self.layout_model = None
        self.bar_model = None                 # scale bar end points, or None
        self.bar_active = False               # the photo's scale is a bar: empty-photo drags draw it
        self.tool = PlateTool(self)
        self._plate_items: list = []
        self._bar_items: list = []

    def set_image(self, image) -> None:
        """New photo: the scene starts empty (no frame or layout left from the previous photo)."""
        self.scene().clear()
        self._image_item = None
        self._frame_item = None
        self._overlay_items = []
        self._plate_items = []
        self._bar_items = []
        super().set_image(image)

    # ----- drawing -------------------------------------------------------
    def show_layout(self, layout, labels: list[tuple[str, str, str]], selected: int, problems: set[int]) -> None:
        """labels: (title, text, state) per section; state 'confirmed', 'proposed' or 'unused'."""
        self.layout_model = layout
        for item in self._plate_items:
            self.scene().removeItem(item)
        self._plate_items = []
        if layout is None:
            return
        for index in range(layout.section_count):
            if index == selected or index in problems:
                color = QColor(LIME if index == selected else DANGER)
                color.setAlpha(34)
                self._path(self._section_path(layout, index), None, 0, fill=color)
        if isinstance(layout, DishLayout):
            outline = QPainterPath()
            outline.addEllipse(QPointF(layout.cx, layout.cy), layout.r, layout.r)
            self._path(outline, LIME, 2.5)
            cuts = QPainterPath()
            for angle in layout.cuts:
                cuts.moveTo(layout.cx, layout.cy)
                cuts.lineTo(*point_at(layout.cx, layout.cy, angle, layout.r))
            self._path(cuts, LIME, 2, dashed=True)
            for i, angle in enumerate(layout.cuts):
                self._handle(*point_at(layout.cx, layout.cy, angle, layout.r), big=i == 0)
            self._handle(*self.tool.radius_handle(layout), square=True)
        else:
            outline = QPainterPath()
            corners = layout.corners()
            outline.moveTo(*corners[0])
            for corner in corners[1:]:
                outline.lineTo(*corner)
            outline.closeSubpath()
            self._path(outline, LIME, 2.5 if not layout.spots else 1.5, dashed=layout.spots)
            lines = QPainterPath()
            for (x0, y0), (x1, y1) in layout.grid_lines():
                lines.moveTo(x0, y0)
                lines.lineTo(x1, y1)
            if layout.spots:
                spots = QPainterPath()
                for index in range(layout.section_count):
                    spots.addEllipse(QPointF(*layout.cell_center(index)), layout.spot_radius, layout.spot_radius)
                self._path(spots, LIME, 2.5)
                self._handle(*layout.spot_handle())
            else:
                self._path(lines, LIME, 2, dashed=True)
            for corner in corners:
                self._handle(*corner, square=True)
            self._handle(*self.tool.rotation_handle(layout), big=True)
        center = layout.cx, layout.cy
        cross = QPainterPath()
        size = self.screen_to_image_distance(8)
        cross.moveTo(center[0] - size, center[1])
        cross.lineTo(center[0] + size, center[1])
        cross.moveTo(center[0], center[1] - size)
        cross.lineTo(center[0], center[1] + size)
        self._path(cross, LIME, 2)
        for index, (title, text, state) in enumerate(labels):
            self._label(*layout.label_point(index), title, text, state, index == selected, index in problems)

    def show_bar(self, bar, active: bool) -> None:
        """The scale bar: its line, a tick at each end and handles while the bar is the photo's scale."""
        self.bar_model, self.bar_active = bar, active
        for item in self._bar_items:
            self.scene().removeItem(item)
        self._bar_items = []
        if bar is None or not active:
            return
        (x0, y0), (x1, y1) = bar
        line = QPainterPath()
        line.moveTo(x0, y0)
        line.lineTo(x1, y1)
        length = math.hypot(x1 - x0, y1 - y0) or 1.0
        nx, ny = -(y1 - y0) / length, (x1 - x0) / length         # unit normal, for the end ticks
        tick = self.screen_to_image_distance(7)
        for x, y in bar:
            line.moveTo(x - nx * tick, y - ny * tick)
            line.lineTo(x + nx * tick, y + ny * tick)
        pen = QPen(QColor(BAR_COLOR), 2.5)
        pen.setCosmetic(True)
        item = self.scene().addPath(line, pen)
        item.setZValue(5)
        self._bar_items.append(item)
        for x, y in (*bar, ((x0 + x1) / 2, (y0 + y1) / 2)):
            handle = QGraphicsEllipseItem(-5, -5, 10, 10)
            handle.setFlag(QGraphicsItem.ItemIgnoresTransformations)
            handle.setPos(x, y)
            handle.setBrush(QBrush(QColor(HALO)))
            handle.setPen(QPen(QColor(BAR_COLOR), 2))
            handle.setZValue(6)
            self.scene().addItem(handle)
            self._bar_items.append(handle)

    @staticmethod
    def _section_path(layout, index: int) -> QPainterPath:
        path = QPainterPath()
        if isinstance(layout, GridLayout) and layout.spots:
            path.addEllipse(QPointF(*layout.cell_center(index)), layout.spot_radius, layout.spot_radius)
            return path
        if isinstance(layout, GridLayout):
            cell = layout.cell(index)
            path.moveTo(*cell[0])
            for point in cell[1:]:
                path.lineTo(*point)
            path.closeSubpath()
            return path
        a, b = layout.spans()[index]
        if layout.section_count == 1:
            path.addEllipse(QPointF(layout.cx, layout.cy), layout.r, layout.r)
            return path
        rect = QRectF(layout.cx - layout.r, layout.cy - layout.r, 2 * layout.r, 2 * layout.r)
        path.moveTo(layout.cx, layout.cy)
        path.arcTo(rect, 90 - a, -(b - a))            # Qt: degrees counterclockwise from 3 o'clock
        path.closeSubpath()
        return path

    def _path(self, path: QPainterPath, color: str | None, width: float, dashed: bool = False, fill=None) -> None:
        pen = QPen(Qt.NoPen) if color is None else QPen(QColor(color), width, Qt.DashLine if dashed else Qt.SolidLine)
        if color is not None:
            pen.setCosmetic(True)
            if dashed:
                pen.setDashPattern([5, 4])
        item = self.scene().addPath(path, pen, QBrush(fill) if fill is not None else QBrush(Qt.NoBrush))
        item.setZValue(1)
        self._plate_items.append(item)

    def _handle(self, x: float, y: float, big: bool = False, square: bool = False) -> None:
        size = 18 if big else 11
        item = (QGraphicsRectItem if square else QGraphicsEllipseItem)(-size / 2, -size / 2, size, size)
        item.setFlag(QGraphicsItem.ItemIgnoresTransformations)
        item.setPos(x, y)
        item.setBrush(QBrush(QColor(LIME if big else HALO)))
        item.setPen(QPen(QColor(HALO if big else LIME), 2.5 if big else 2))
        item.setZValue(3)
        self.scene().addItem(item)
        self._plate_items.append(item)

    def _label(self, x: float, y: float, title: str, text: str, state: str, selected: bool, problem: bool) -> None:
        tag = QGraphicsPathItem()
        tag.setFlag(QGraphicsItem.ItemIgnoresTransformations)
        tag.setPos(x, y)
        tag.setZValue(4)
        font = QFont()
        font.setPixelSize(13)
        font.setWeight(QFont.DemiBold)
        small = QFont(font)
        small.setPixelSize(10)
        top = QGraphicsSimpleTextItem(title, tag)
        top.setFont(small)
        top.setBrush(QBrush(QColor(_C.section_label_top)))
        main = QGraphicsSimpleTextItem(text, tag)
        main.setFont(font)
        main.setBrush(QBrush(QColor(_C.section_label if state != "unused" else _C.section_label_unused)))
        width = max(top.boundingRect().width(), main.boundingRect().width()) + 18
        height = top.boundingRect().height() + main.boundingRect().height() + 8
        top.setPos(-top.boundingRect().width() / 2, -height / 2 + 3)
        main.setPos(-main.boundingRect().width() / 2, -height / 2 + 3 + top.boundingRect().height())
        outline = QPainterPath()
        outline.addRoundedRect(QRectF(-width / 2, -height / 2, width, height), 5, 5)
        tag.setPath(outline)
        tag.setBrush(QBrush(QColor(22, 23, 20, 238)))
        color = (DANGER if problem else LIME_TEXT if selected
                 else LIME if state in ("confirmed", "proposed") else _C.section_idle_edge)
        solid = state == "confirmed" and not problem
        pen = QPen(QColor(color), 2 if selected else 1.4, Qt.SolidLine if solid else Qt.DashLine)
        tag.setPen(pen)
        self.scene().addItem(tag)
        self._plate_items.append(tag)


class PlateTool(CanvasTool):
    """Turns drags on the handles into new layouts, and clicks into section picks."""

    def __init__(self, canvas: CropCanvas):
        super().__init__(canvas)
        self._drag = None             # (part, extra, start point, start layout)
        self._bar_start = None        # the bar when a bar drag began

    @staticmethod
    def radius_handle(layout: DishLayout) -> tuple[float, float]:
        spans = layout.spans()
        a, b = spans[0]
        return point_at(layout.cx, layout.cy, (a + b) / 2, layout.r)

    @staticmethod
    def rotation_handle(layout: GridLayout) -> tuple[float, float]:
        t = math.radians(layout.angle)
        distance = layout.height / 2 + max(24.0, layout.height * 0.08)
        return layout.cx + distance * math.sin(t), layout.cy - distance * math.cos(t)

    def _near(self, point: QPointF, x: float, y: float) -> bool:
        return math.hypot(point.x() - x, point.y() - y) <= self.canvas.screen_to_image_distance(HANDLE_PX)

    def _part_at(self, point: QPointF):
        layout = self.canvas.layout_model
        if layout is None:
            return None, None
        bar = self.canvas.bar_model if self.canvas.bar_active else None
        if bar is not None:
            for i, (x, y) in enumerate(bar):
                if self._near(point, x, y):
                    return "bar_end", i
            if self._near(point, (bar[0][0] + bar[1][0]) / 2, (bar[0][1] + bar[1][1]) / 2):
                return "bar_move", None
        if self._near(point, layout.cx, layout.cy):
            return "center", None
        if isinstance(layout, DishLayout):
            for i, angle in enumerate(layout.cuts):
                if self._near(point, *point_at(layout.cx, layout.cy, angle, layout.r)):
                    return ("rotate" if i == 0 else "cut"), i
            if self._near(point, *self.radius_handle(layout)):
                return "radius", None
        else:
            if self._near(point, *self.rotation_handle(layout)):
                return "rotate", None
            if layout.spots and self._near(point, *layout.spot_handle()):
                return "spot", None
            for corner in layout.corners():
                if self._near(point, *corner):
                    return "corner", None
        return None, None

    def press(self, point: QPointF, button=Qt.LeftButton) -> None:
        layout = self.canvas.layout_model
        if layout is None:
            return
        part, extra = self._part_at(point)
        if button == Qt.RightButton:
            if part == "cut":
                self.canvas.cutRemoved.emit(extra)
            return
        if button != Qt.LeftButton:
            return
        if part is None and self.canvas.bar_active:          # a drag draws the bar; a click picks a section
            self._drag = ("bar_new", None, point, layout)
            return
        if part is None:
            self._pick(layout, point)
            return
        self._drag = (part, extra, point, layout)
        self._bar_start = self.canvas.bar_model if part in ("bar_end", "bar_move") else None

    def _pick(self, layout, point: QPointF) -> None:
        section = layout.section_at(point.x(), point.y())
        if section >= 0:
            self.canvas.sectionPicked.emit(section)

    def move(self, point: QPointF) -> None:
        if self._drag is None:
            part, _ = self._part_at(point)
            shapes = {"center": Qt.SizeAllCursor, "rotate": Qt.CrossCursor, "cut": Qt.CrossCursor,
                      "radius": Qt.SizeFDiagCursor, "corner": Qt.SizeFDiagCursor, "spot": Qt.SizeHorCursor,
                      "bar_end": Qt.CrossCursor, "bar_move": Qt.SizeAllCursor}
            default = Qt.CrossCursor if self.canvas.bar_active else Qt.ArrowCursor
            self.canvas.set_tool_cursor(shapes.get(part, default))
            return
        if self._drag[0].startswith("bar"):
            bar = self._dragged_bar(point)
            if bar is not None:
                self.canvas.barEdited.emit(bar, False)
            return
        self.canvas.layoutEdited.emit(self._dragged(point), False)

    def release(self, point: QPointF, button=Qt.LeftButton) -> None:
        if self._drag is None or button != Qt.LeftButton:
            return
        if self._drag[0].startswith("bar"):
            bar = self._dragged_bar(point)
            part, _, start, layout = self._drag
            self._drag = None
            if bar is None:                                   # a click on empty photo: pick its section
                self._pick(layout, start)
            else:
                self.canvas.barEdited.emit(bar, True)
            return
        layout = self._dragged(point)
        self._drag = None
        if isinstance(layout, DishLayout):
            layout = layout.normalized()
        self.canvas.layoutEdited.emit(layout, True)

    def _dragged_bar(self, point: QPointF):
        """The bar a bar drag makes, or None for a new bar not dragged far enough to be one."""
        part, extra, start, _ = self._drag
        if part == "bar_new":
            if math.hypot(point.x() - start.x(), point.y() - start.y()) < self.canvas.screen_to_image_distance(
                    CLICK_PX):
                return None
            return (start.x(), start.y()), (point.x(), point.y())
        (x0, y0), (x1, y1) = self.canvas.bar_model if self._bar_start is None else self._bar_start
        if part == "bar_end":
            return ((point.x(), point.y()), (x1, y1)) if extra == 0 else ((x0, y0), (point.x(), point.y()))
        dx, dy = point.x() - start.x(), point.y() - start.y()
        return (x0 + dx, y0 + dy), (x1 + dx, y1 + dy)

    def _dragged(self, point: QPointF):
        part, extra, start, layout = self._drag
        dx, dy = point.x() - start.x(), point.y() - start.y()
        if part == "center":
            return layout.moved(layout.cx + dx, layout.cy + dy)
        if isinstance(layout, DishLayout):
            if part == "radius":
                return layout.resized(math.hypot(point.x() - layout.cx, point.y() - layout.cy))
            angle = clock_angle(point.x() - layout.cx, point.y() - layout.cy)
            if part == "rotate":
                return layout.rotated(angle - layout.cuts[0])
            return layout.with_cut(extra, angle)
        if part == "rotate":
            return layout.rotated(clock_angle(point.x() - layout.cx, point.y() - layout.cy) - layout.angle)
        if part == "spot":
            return layout.spot_to(point.x(), point.y())
        return layout.corner_to(point.x(), point.y())

    def deactivate(self) -> None:
        self._drag = None
        self._bar_start = None
