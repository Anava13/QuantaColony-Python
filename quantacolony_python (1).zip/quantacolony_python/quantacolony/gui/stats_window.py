"""StatsWindow: the Stats module (view, light palette).

Left: the analyses (built-in and plug-ins). Top left: the variables, which collapse to a
one-line summary. "Color by" is a drop-down; each variable is one row with its slot and a
"levels" button that opens a pop-up of its levels (each shown or hidden, with its color when it
is the color variable). Top right: the normalization, measure and options of the chosen
analysis. Middle: the figure. Bottom:
notes (normalization notes, fit summaries, plug-in problems).
"""

from __future__ import annotations

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure
from PySide6.QtCore import QPoint, Qt, Signal
from PySide6.QtGui import QColor
from PySide6.QtGui import QPalette
from PySide6.QtWidgets import (QAbstractItemView, QColorDialog, QComboBox, QDialog, QFileDialog, QFrame, QGridLayout,
                               QHBoxLayout, QHeaderView, QListWidget, QListWidgetItem, QMainWindow, QPlainTextEdit,
                               QScrollArea, QSizePolicy, QSpinBox, QSplitter, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)

from ..theme import Theme
from ..theme.icons import app_icon
from ..theme.stylesheet import build_light_stylesheet
from .banner import back_button
from .light import L, LevelChips, LightSegmented, RangeSlider, clear_layout, light_button, light_header, light_label
from .dialogs import ERROR, notify


MAX_SEGMENTS = 4                                # more choices than this show as a drop-down
ROW_NAME_WIDTH = 120                            # variable names column in the variables panel

class LevelsPopup(QFrame):
    """The levels of one variable, opened from its row: click a level to hide or show it, a color
    square to change its color. It stays open while levels change (the window refills it)."""

    def __init__(self, parent: QWidget):
        super().__init__(parent, Qt.Popup)
        self.setObjectName("LevelsPopup")
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setStyleSheet(f"QFrame#LevelsPopup {{ background: {L.surface}; border: 1px solid {L.border}; "
                           "border-radius: 8px; }")
        self.variable = ""
        self.column = QVBoxLayout(self)
        self.column.setContentsMargins(14, 12, 14, 12)
        self.column.setSpacing(8)

    def fill(self, variable: str, title: str, levels: list[tuple], summary: str, show_all) -> None:
        self.variable = variable
        clear_layout(self.column)
        head = QHBoxLayout()
        head.addWidget(light_label(title, "field"))
        head.addStretch(1)
        if summary:
            reset = light_button("Show all", "quiet", f"Show every level of {title}")
            reset.clicked.connect(lambda _c=False, h=show_all: h())
            head.addWidget(reset)
        self.column.addLayout(head)
        self.column.addWidget(LevelChips(levels, tooltip=title))
        hint = "Click a level to hide or show it."
        if any(level[3] for level in levels):
            hint += " Click a color square to change its color."
        self.column.addWidget(light_label(hint, "small", wrap=True))
        self.adjustSize()


class StatsWindow(QMainWindow):
    """The Stats module's view. Controllers use only its signals and its set_/show_/ask_ methods."""

    analysisChosen = Signal(str)
    sectionToggled = Signal(str, bool)         # a plot setup section ('compare', 'plates', 'drawing') opened or folded
    helpRequested = Signal()
    saveFigureRequested = Signal()
    saveTableRequested = Signal()
    pluginsFolderRequested = Signal()
    backRequested = Signal()

    def __init__(self, theme: Theme, project_name: str, analyses: list[tuple[str, list[tuple[str, str]]]] = ()):
        """analyses: (section title, [(key, label)]); set_analyses can replace them later."""
        super().__init__()
        self.theme = theme
        self.setObjectName("LightWindow")
        self.setStyleSheet(build_light_stylesheet(theme.style.light, theme.ui_family, theme.brand_family))
        self.setWindowTitle(f"QuantaColony · Stats · {project_name}")
        self.setWindowIcon(app_icon())
        self.resize(1440, 900)

        root = QWidget()
        column = QVBoxLayout(root)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(0)
        self.back_button = back_button()
        header, header_row = light_header(theme, ["Projects", project_name, "Stats"], back=self.back_button)
        self.help_button = light_button("Help", "header")
        header_row.addWidget(self.help_button)
        column.addWidget(header)

        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)
        body.addWidget(self._analysis_list(analyses))
        body.addWidget(self._main_area(), 1)
        column.addLayout(body, 1)
        self.setCentralWidget(root)
        for widget, signal in ((self.help_button, self.helpRequested), (self.back_button, self.backRequested),
                               (self.save_figure_button, self.saveFigureRequested),
                               (self.save_table_button, self.saveTableRequested),
                               (self.plugins_button, self.pluginsFolderRequested)):
            widget.clicked.connect(signal.emit)

    # ----- construction ---------------------------------------------------
    def _analysis_list(self, analyses) -> QFrame:
        side = QFrame(objectName="LightSide")
        side.setFixedWidth(240)
        layout = QVBoxLayout(side)
        layout.setContentsMargins(0, 16, 0, 16)
        layout.setSpacing(0)
        self.analysis_list = QListWidget()
        self.analysis_list.setFocusPolicy(Qt.StrongFocus)
        self._keys: dict[str, QListWidgetItem] = {}
        self._sections: dict[int, dict] = {}            # header row -> {'open': bool, 'rows': [...], 'title': str}
        self.analysis_list.currentItemChanged.connect(
            lambda item, _old: item is not None and item.data(Qt.UserRole) and self.analysisChosen.emit(
                item.data(Qt.UserRole)))
        self.analysis_list.itemClicked.connect(self._toggle_section)
        layout.addWidget(self.analysis_list, 1)
        self.set_analyses(list(analyses))
        self.plugins_button = light_button("Analyses folder…", "quiet",
                                           "Open the folder where your own analysis plug-ins go")
        layout.addWidget(self.plugins_button, 0, Qt.AlignLeft)
        return side

    def _main_area(self) -> QWidget:
        area = QWidget()
        column = QVBoxLayout(area)
        column.setContentsMargins(24, 18, 24, 18)
        column.setSpacing(14)

        top = QHBoxLayout()
        self.title = light_label("", "h1")
        top.addWidget(self.title)
        top.addStretch(1)
        self.save_table_button = light_button("Save table (CSV)", None)
        self.save_figure_button = light_button("Save figure…", "primary")
        top.addWidget(self.save_table_button)
        top.addWidget(self.save_figure_button)
        column.addLayout(top)
        self.description = light_label("", "body", wrap=True)
        column.addWidget(self.description)

        controls = QFrame(objectName="LightPanel")
        controls.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Maximum)   # never taller than its contents
        outer = QVBoxLayout(controls)
        outer.setContentsMargins(16, 8, 16, 10)
        outer.setSpacing(2)
        # the whole plot setup folds to one line
        setup_head = QHBoxLayout()
        setup_head.setSpacing(10)
        self.setup_toggle = light_button("▾  PLOT SETUP", "quiet", "Fold or open the whole plot setup")
        self.setup_toggle.setStyleSheet(f"QPushButton {{ padding: 0; min-height: 0; font-size: 12px; font-weight: 800; "
                                        f"letter-spacing: 1px; color: {L.text}; background: transparent; border: none; "
                                        "text-align: left; }")
        self.setup_toggle.setCursor(Qt.PointingHandCursor)
        self.setup_toggle.setFixedWidth(130)
        self.setup_toggle.clicked.connect(lambda: self.sectionToggled.emit("setup", not self._setup_open))
        setup_head.addWidget(self.setup_toggle)
        self.setup_summary = light_label("", "small", wrap=True)
        self.setup_summary.setStyleSheet(f"color: {L.link}; font-weight: 600;")
        setup_head.addWidget(self.setup_summary, 1)
        outer.addLayout(setup_head)
        self.setup_body = QWidget()
        panel = QVBoxLayout(self.setup_body)
        panel.setContentsMargins(0, 4, 0, 0)
        panel.setSpacing(2)
        outer.addWidget(self.setup_body)
        self._setup_open = True
        self._sections_ui: dict[str, dict] = {}
        # Compare: what each part of the figure stands for (open by default)
        compare = self._section(panel, "compare", "COMPARE", "What each part of the figure stands for")
        self.role_rows = QVBoxLayout()
        self.role_rows.setSpacing(4)
        compare.addLayout(self.role_rows)
        self.pooled_note = light_label("", "small", wrap=True)
        compare.addWidget(self.pooled_note)
        self.color_line = QWidget()
        self.color_row = QHBoxLayout(self.color_line)
        self.color_row.setContentsMargins(0, 0, 0, 0)
        self.color_row.setSpacing(10)
        compare.addWidget(self.color_line)
        self.color_note = light_label("", "small", wrap=True)
        self.color_note.setVisible(False)
        compare.addWidget(self.color_note)
        self.slot_problem = light_label("", None, wrap=True)
        self.slot_problem.setProperty("state", "bad")
        compare.addWidget(self.slot_problem)
        # Plates: which plates go in
        plates = self._section(panel, "plates", "PLATES", "Which plates go into the figure")
        split = QGridLayout()
        split.setHorizontalSpacing(28)
        split.setVerticalSpacing(4)
        left, right = QVBoxLayout(), QVBoxLayout()
        left.setSpacing(4)
        right.setSpacing(6)
        left.addWidget(light_label("LEVELS USED", "section"))
        left.addWidget(light_label("Plates with a level switched off are left out.", "small", wrap=True))
        self.slot_rows = QVBoxLayout()                      # one row per variable: the levels used
        self.slot_rows.setSpacing(4)
        left.addLayout(self.slot_rows)
        left.addStretch(1)
        right.addWidget(light_label("PLATE RULES", "section"))
        self.rule_rows = QVBoxLayout()
        self.rule_rows.setSpacing(6)
        right.addLayout(self.rule_rows)
        right.addStretch(1)
        split.addLayout(left, 0, 0, Qt.AlignTop)
        split.addLayout(right, 0, 1, Qt.AlignTop)
        split.setColumnStretch(0, 1)
        split.setColumnStretch(1, 1)
        plates.addLayout(split)
        # Drawing: how the figure is drawn
        drawing = self._section(panel, "drawing", "DRAWING", "How the figure is drawn")
        self.setting_rows = QVBoxLayout()
        self.setting_rows.setSpacing(6)
        drawing.addLayout(self.setting_rows)
        self.levels_popup = LevelsPopup(self)
        self._rows: dict = {}
        self._role_lines: dict = {}                         # slot title -> LevelChips of its variables
        self._level_buttons: dict = {}                      # variable name -> its levels button
        self._row_widgets: dict = {"rules": {}, "settings": {}}   # row title -> the row's widget
        column.addWidget(controls)

        splitter = QSplitter(Qt.Vertical)
        splitter.setChildrenCollapsible(False)
        self.figure = Figure(figsize=(12, 7), facecolor=self.theme.style.plot.background)
        self.canvas = FigureCanvasQTAgg(self.figure)
        self.figure_scroller = QScrollArea()
        self.figure_scroller.setWidget(self.canvas)
        self.figure_scroller.setWidgetResizable(True)
        light = self.theme.style.light
        self.figure_scroller.setStyleSheet(f"QScrollArea {{ background: {light.surface}; border: 1px solid "
                                           f"{light.border}; border-radius: 6px; }}")
        splitter.addWidget(self.figure_scroller)
        self.notes = QPlainTextEdit()
        self.notes.setReadOnly(True)
        self.notes.setPlaceholderText("Notes about the current analysis appear here.")
        splitter.addWidget(self.notes)
        splitter.setSizes([760, 90])
        column.addWidget(splitter, 1)
        return area

    # ----- updates the controller calls -----------------------------------
    def select_analysis(self, key: str) -> None:
        item = self._keys.get(key)
        if item is None:
            return
        for header_row, record in self._sections.items():            # open the section that holds it
            if self.analysis_list.row(item) in record["rows"] and not record["open"]:
                self._set_section(header_row, True)
        if self.analysis_list.currentItem() is not item:
            self.analysis_list.blockSignals(True)
            self.analysis_list.setCurrentItem(item)
            self.analysis_list.blockSignals(False)

    def set_heading(self, title: str, description: str) -> None:
        self.title.setText(title)
        self.description.setText(description)

    def set_analyses(self, analyses) -> None:
        """Rebuild the analysis list.

        analyses: (top title, [(section title, [(id, name)])]) with collapsible sections, or the
        flat (section title, [(id, name)]) form, which goes under one top heading."""
        if analyses and len(analyses[0]) == 2 and analyses[0][1] and isinstance(analyses[0][1][0][1], str):
            analyses = [("", list(analyses))]            # flat form: one unnamed top heading
        open_before = {record["title"]: record["open"] for record in self._sections.values()}
        self.analysis_list.blockSignals(True)
        self.analysis_list.clear()
        self._keys = {}
        self._sections = {}
        for top, groups in analyses:
            if top:
                heading = QListWidgetItem(top.upper())
                heading.setFlags(Qt.NoItemFlags)
                font = heading.font()
                font.setPixelSize(11)
                font.setBold(True)
                heading.setFont(font)
                heading.setForeground(Qt.gray)
                self.analysis_list.addItem(heading)
            for section, items in groups:
                title = QListWidgetItem()
                title.setFlags(Qt.ItemIsEnabled)         # clickable, never current
                font = title.font()
                font.setPixelSize(11)
                font.setBold(True)
                title.setFont(font)
                title.setForeground(Qt.gray)
                self.analysis_list.addItem(title)
                rows = []
                for key, text in items:
                    item = QListWidgetItem(text)
                    item.setData(Qt.UserRole, key)
                    self.analysis_list.addItem(item)
                    self._keys[key] = item
                    rows.append(self.analysis_list.row(item))
                record = {"open": open_before.get(section, False), "rows": rows, "title": section}
                self._sections[self.analysis_list.row(title)] = record
                self._set_section(self.analysis_list.row(title), record["open"])
        self.analysis_list.blockSignals(False)

    def _set_section(self, header_row: int, open_: bool) -> None:
        record = self._sections[header_row]
        record["open"] = open_
        self.analysis_list.item(header_row).setText(("▾  " if open_ else "▸  ") + record["title"].upper())
        for row in record["rows"]:
            self.analysis_list.item(row).setHidden(not open_)

    def _toggle_section(self, item) -> None:
        row = self.analysis_list.row(item)
        if row in self._sections:
            self._set_section(row, not self._sections[row]["open"])

    def set_color_by(self, options: list[tuple], note: str) -> None:
        """options: (text, chosen, handler) for "Analysis colors" and each variable; note: why the chosen
        variable cannot color this analysis ('' when it can)."""
        clear_layout(self.color_row)
        caption = light_label("Color by", "small")
        caption.setFixedWidth(ROW_NAME_WIDTH)
        self.color_row.addWidget(caption)
        menu = self._menu(options, True, "Color by")
        menu.setMinimumWidth(200)
        self.color_row.addWidget(menu)
        self.color_row.addStretch(1)
        self.color_note.setText(note)
        self.color_note.setVisible(bool(note))

    def set_roles(self, roles: list[tuple], pooled: str, problem: str) -> None:
        """roles: (title, description, chips) per part of the plot a variable can split it into; chips:
        (variable, in this role, handler, allowed). pooled: the sentence on variables that split nothing."""
        clear_layout(self.role_rows)
        self._role_lines = {}
        for title, description, chips in roles:
            line = QHBoxLayout()
            line.setSpacing(10)
            caption = light_label(title, None)
            caption.setFixedWidth(ROW_NAME_WIDTH)
            caption.setToolTip(description)
            line.addWidget(caption)
            widget = LevelChips([(text, on, handler, None, None, allowed) for text, on, handler, allowed in chips],
                                tooltip=title, off_color=L.text_secondary)
            self._role_lines[title] = widget
            line.addWidget(widget)
            line.addStretch(1)
            self.role_rows.addLayout(line)
            if description:
                note = light_label(description, "small", wrap=True)
                note.setContentsMargins(ROW_NAME_WIDTH + 10, 0, 0, 4)
                self.role_rows.addWidget(note)
        self.pooled_note.setText(pooled)
        self.pooled_note.setVisible(bool(pooled))
        self.slot_problem.setText(problem)
        self.slot_problem.setVisible(bool(problem))

    def set_slots(self, rows: list[tuple], problem: str | None = None) -> None:
        """rows: (variable name, its kind, level options: (level, shown, toggle handler, color or None,
        color handler or None), button text, filtered, show-all handler). One line per variable; its
        levels open in a pop-up from its button."""
        clear_layout(self.slot_rows)
        self._rows = {}
        self._level_buttons = {}
        for name, kind, levels, text, filtered, show_all in rows:
            summary = text if filtered else ""
            self._rows[name] = (levels, summary, show_all)
            line = QHBoxLayout()
            line.setSpacing(10)
            caption = light_label(name, None)
            caption.setFixedWidth(ROW_NAME_WIDTH)
            caption.setToolTip(f"{name} is a {kind} variable")
            caption.setText(caption.fontMetrics().elidedText(name, Qt.ElideRight, ROW_NAME_WIDTH))
            line.addWidget(caption)
            colored = any(level[3] for level in levels)
            button = light_button(f"{text}{'  ●' if colored else ''}  ▾", None,
                                  f"Choose which levels of {name} are used{' and their colors' if colored else ''}")
            if filtered:
                button.setStyleSheet(f"QPushButton {{ color: {L.link}; font-weight: 600; }}")
            button.setFixedHeight(28)
            button.clicked.connect(lambda _c=False, n=name, b=button: self.open_levels(n, b))
            self._level_buttons[name] = button
            line.addWidget(button)
            line.addStretch(1)
            self.slot_rows.addLayout(line)
        if self.levels_popup.isVisible() and self.levels_popup.variable in self._rows:
            levels, summary, show_all = self._rows[self.levels_popup.variable]
            self.levels_popup.fill(self.levels_popup.variable, self.levels_popup.variable, levels, summary, show_all)
        elif self.levels_popup.isVisible():
            self.levels_popup.close()
        if problem is not None:
            self.slot_problem.setText(problem)
            self.slot_problem.setVisible(bool(problem))

    def open_levels(self, name: str, anchor: QWidget | None = None) -> None:
        """The levels pop-up of one variable, under its button."""
        if name not in self._rows:
            return
        levels, summary, show_all = self._rows[name]
        self.levels_popup.fill(name, name, levels, summary, show_all)
        if anchor is not None:
            self.levels_popup.move(anchor.mapToGlobal(anchor.rect().bottomLeft()) + QPoint(0, 4))
        self.levels_popup.show()

    def _section(self, panel, key: str, title: str, question: str) -> QVBoxLayout:
        """One folding section of the plot setup: a header line (title, the question it answers, and a one-line
        summary of its choices while folded) and a body. Returns the body's layout."""
        head_widget = QWidget()
        head = QHBoxLayout(head_widget)
        head.setContentsMargins(0, 4, 0, 4)
        head.setSpacing(10)
        toggle = light_button(f"▾  {title}", "quiet", f"Fold or open {title.title()}")
        toggle.setStyleSheet(f"QPushButton {{ padding: 0; min-height: 0; font-size: 11px; font-weight: 700; "
                             f"letter-spacing: 1px; color: {L.text}; background: transparent; border: none; "
                             "text-align: left; }")
        toggle.setCursor(Qt.PointingHandCursor)
        toggle.setFixedWidth(118)
        toggle.clicked.connect(lambda _c=False, k=key: self.sectionToggled.emit(k, not self._sections_ui[k]["open"]))
        head.addWidget(toggle)
        ask = light_label(question, "small")
        head.addWidget(ask)
        summary = light_label("", "small", wrap=True)
        summary.setStyleSheet(f"color: {L.link}; font-weight: 600;")
        head.addWidget(summary, 1)
        if self._sections_ui:
            line = QFrame()
            line.setFrameShape(QFrame.HLine)
            line.setStyleSheet(f"color: {L.border};")
            panel.addWidget(line)
        panel.addWidget(head_widget)
        body_widget = QWidget()
        body = QVBoxLayout(body_widget)
        body.setContentsMargins(0, 0, 0, 8)
        body.setSpacing(6)
        panel.addWidget(body_widget)
        self._sections_ui[key] = {"open": True, "toggle": toggle, "title": title, "summary": summary,
                                  "body": body_widget, "head": head_widget, "ask": ask}
        return body

    def set_sections(self, opened: dict, summaries: dict) -> None:
        """opened: section key -> open ('setup': the whole plot setup); summaries: section key -> its one-line
        summary (shown while folded)."""
        self._setup_open = bool(opened.get("setup", True))
        self.setup_toggle.setText(("▾  " if self._setup_open else "▸  ") + "PLOT SETUP")
        self.setup_body.setVisible(self._setup_open)
        self.setup_summary.setText("   ·   ".join(summaries.get(k, "") for k in ("compare", "plates", "drawing")
                                                if summaries.get(k)))
        self.setup_summary.setVisible(not self._setup_open)
        for key, ui in self._sections_ui.items():
            is_open = bool(opened.get(key, key == "compare"))
            ui["open"] = is_open
            ui["toggle"].setText(("▾  " if is_open else "▸  ") + ui["title"])
            ui["summary"].setText(summaries.get(key, ""))
            ui["summary"].setVisible(not is_open)
            ui["ask"].setVisible(is_open)
            ui["body"].setVisible(is_open)

    def open_section(self, key: str) -> None:
        """Open a folded section (the tutorial, pointing at a control inside it)."""
        if not self._setup_open:
            self.sectionToggled.emit("setup", True)
        if key in self._sections_ui and not self._sections_ui[key]["open"]:
            self.sectionToggled.emit(key, True)

    # ----- where things are (the tutorial points at them) ------------------------------------
    def locate(self, kind: str, *args, reveal: bool = True):
        """(widget, rectangle inside it) holding one control, or None.

        kinds: analysis (id), role (slot title, variable name), color, levels (variable name), rule (title),
        setting (title), button (text), section (key). reveal: open the analysis group or setup section that
        hides the control; without it a folded group or section is returned in its place."""
        from PySide6.QtWidgets import QPushButton
        if kind == "analysis":
            item = self._keys.get(args[0])
            if item is None:
                return None
            for header_row, record in self._sections.items():
                if self.analysis_list.row(item) in record["rows"] and not record["open"]:
                    if not reveal:
                        header = self.analysis_list.item(header_row)
                        return self.analysis_list.viewport(), self.analysis_list.visualItemRect(header)
                    self._set_section(header_row, True)
            self.analysis_list.scrollToItem(item)
            return self.analysis_list.viewport(), self.analysis_list.visualItemRect(item)
        if kind == "section":
            if not self._setup_open:
                return self.setup_toggle, self.setup_toggle.rect()
            ui = self._sections_ui.get(args[0])
            return (ui["head"], ui["head"].rect()) if ui else None
        if kind == "button":
            for button in self.findChildren(QPushButton):
                if button.text() == args[0] and not button.isHidden():
                    found = button
                    break
            else:
                return None
            section = next((k for k, ui in self._sections_ui.items() if ui["body"].isAncestorOf(found)), None)
        else:
            section = {"role": "compare", "lit": "compare", "color": "compare", "levels": "plates", "rule": "plates",
                       "setting": "drawing"}.get(kind)
        if section is None:
            return None
        if not self._setup_open and not reveal:
            return self.setup_toggle, self.setup_toggle.rect()
        if not self._setup_open or not self._sections_ui[section]["open"]:
            if not reveal:
                return self.locate("section", section)
            self.open_section(section)
        if kind == "button":
            return found, found.rect()
        if kind == "color":
            return self.color_line, self.color_line.rect()
        if kind == "lit":                               # the chip that places a variable, to switch it off
            for chips in self._role_lines.values():
                button = next((b for b in chips.toggles if b.text() == args[0] and b.isChecked()), None)
                if button is not None:
                    return button, button.rect()
            return self.locate("section", "compare")
        if kind == "role":
            chips = self._role_lines.get(args[0])
            if chips is None:
                return None
            button = next((b for b in chips.toggles if b.text() == args[1]), None)
            return (button, button.rect()) if button is not None else (chips, chips.rect())
        if kind == "levels":
            button = self._level_buttons.get(args[0])
            return (button, button.rect()) if button is not None else None
        widget = self._row_widgets["rules" if kind == "rule" else "settings"].get(args[0])
        return (widget, widget.rect()) if widget is not None else None

    def set_plate_rules(self, rows: list[tuple]) -> None:
        """Plate rules (touching colonies, overplated plates, one plate per group): rows as in set_settings."""
        self._fill_rows(self.rule_rows, rows, "rules")

    def set_settings(self, rows: list[tuple]) -> None:
        """rows: (title, segmented options, enabled, note[, buttons]) for normalization, measure and analysis
        options; buttons: (text, handler) shown after the choices."""
        self._fill_rows(self.setting_rows, rows, "settings")

    def _fill_rows(self, layout, rows: list[tuple], kind: str) -> None:
        clear_layout(layout)
        self._row_widgets[kind] = {}
        for title, options, enabled, note, *rest in rows:
            holder = QWidget()
            self._row_widgets[kind][title] = holder
            line = QHBoxLayout(holder)
            line.setContentsMargins(0, 0, 0, 0)
            line.setSpacing(10)
            caption = light_label(title, "small")
            caption.setFixedWidth(96)
            line.addWidget(caption)
            if len(options) > MAX_SEGMENTS:                  # a long list of choices: a drop-down keeps the row short
                line.addWidget(self._menu(options, enabled, title))
            elif options:
                line.addWidget(LightSegmented(options, height=26, enabled=enabled, tooltip=title))
            for text, handler in (rest[0] if rest else []):
                button = light_button(text, None, f"{title}: {text}")
                button.setFixedHeight(28)
                button.clicked.connect(lambda _c=False, h=handler: h())
                line.addWidget(button)
            line.addStretch(1)
            layout.addWidget(holder)
            if note:
                label = light_label(note, "small", wrap=True)
                label.setContentsMargins(106, 0, 0, 0)
                layout.addWidget(label)

    @staticmethod
    def _menu(options: list[tuple], enabled: bool, title: str) -> QComboBox:
        menu = QComboBox()
        menu.setToolTip(title)
        menu.setMinimumWidth(260)
        for option in options:
            menu.addItem(option[0])
        menu.setCurrentIndex(next((i for i, option in enumerate(options) if option[1]), 0))
        menu.setEnabled(enabled)
        menu.activated.connect(lambda index: options[index][2]())
        return menu

    def show_figure(self, figure: Figure, fit_height: bool = False) -> None:
        """Show a figure filling the view, or (fit_height) at the view's height keeping its own proportions,
        scrolling sideways when it is wider than the view."""
        size = None
        if fit_height:
            # Same inches at a screen dpi that fits the height, so the figure keeps its own layout. The dpi is set
            # before the canvas exists: the Qt canvas resets a figure's dpi to the one it was created with.
            height = max(380, self.figure_scroller.viewport().height() - 14)
            inches_wide, inches_high = figure.get_size_inches()
            dpi = height / inches_high / self.devicePixelRatioF()
            figure.set_dpi(dpi)
            figure._original_dpi = dpi
            size = (int(round(inches_wide * dpi)), int(round(inches_high * dpi)))
        if figure is not self.figure:
            self.canvas.setParent(None)
            self.canvas.deleteLater()
            self.figure = figure
            self.canvas = FigureCanvasQTAgg(figure)
            self.figure_scroller.setWidget(self.canvas)
        self.figure_scroller.setWidgetResizable(size is None)
        if size is not None:
            self.canvas.setFixedSize(*size)
        else:
            self.canvas.setMinimumSize(0, 0)
            self.canvas.setMaximumSize(16777215, 16777215)
        self.canvas.draw_idle()

    def set_notes(self, text: str) -> None:
        self.notes.setPlainText(text)

    def add_note_above(self, text: str) -> None:
        self.notes.setPlainText(text + "\n\n" + self.notes.toPlainText())

    def set_busy(self, busy: bool, message: str = "") -> None:
        for widget in (self.save_table_button, self.save_figure_button, self.analysis_list):
            widget.setEnabled(not busy)
        if busy:
            self.set_notes(message)

    def start_progress(self, title: str, text: str, total: int):
        """A progress dialog; returns progress(done, total) -> False once the user stops it."""
        from PySide6.QtWidgets import QApplication, QProgressDialog
        self._progress = QProgressDialog(text, "Stop", 0, max(total, 1), self)
        self._progress.setWindowTitle(title)
        self._progress.setWindowModality(Qt.WindowModal)
        self._progress.setMinimumDuration(400)

        def progress(done: int, total: int) -> bool:
            self._progress.setMaximum(max(total, 1))
            self._progress.setValue(done)
            QApplication.processEvents()
            return not self._progress.wasCanceled()

        return progress

    def end_progress(self) -> None:
        if getattr(self, "_progress", None) is not None:
            self._progress.close()
            self._progress = None

    def set_exports(self, table: bool) -> None:
        self.save_table_button.setEnabled(table)

    def ask_color(self, current: str, title: str) -> str:
        """A color from the color picker as '#rrggbb', or '' when cancelled."""
        color = QColorDialog.getColor(QColor(current), self, title)
        return color.name() if color.isValid() else ""

    def ask_figure_path(self, start: str) -> str:
        path, _ = QFileDialog.getSaveFileName(self, "Save figure", start,
                                              "PNG image (*.png);;PDF (*.pdf);;SVG (*.svg)")
        return path

    def ask_number(self, title: str, value: float):
        """A typed number, or None when cancelled."""
        from PySide6.QtWidgets import QInputDialog
        number, ok = QInputDialog.getDouble(self, title, title, value, 0.0, 1e7, 1)
        return number if ok else None

    def ask_table_path(self, start: str) -> str:
        path, _ = QFileDialog.getSaveFileName(self, "Save table", start, "CSV (*.csv)")
        return path

    # ----- plate selection ---------------------------------------------------
    def show_selection(self, view: dict) -> None:
        """Open (or refill) the plate selection window. view: see SelectionDialog.fill."""
        if getattr(self, "selection_dialog", None) is None:
            self.selection_dialog = SelectionDialog(self)
        self.selection_dialog.fill(view)
        self.selection_dialog.show()
        self.selection_dialog.raise_()

    def refill_selection(self, view: dict) -> None:
        """Refill the plate selection window when it is open."""
        dialog = getattr(self, "selection_dialog", None)
        if dialog is not None and dialog.isVisible():
            dialog.fill(view)

    def show_plates(self, view: dict) -> None:
        """Open (or refill) the plate list. view: see PlatesDialog.fill."""
        if getattr(self, "plates_dialog", None) is None:
            self.plates_dialog = PlatesDialog(self)
        self.plates_dialog.fill(view)
        self.plates_dialog.show()
        self.plates_dialog.raise_()

    def refill_plates(self, view: dict) -> None:
        dialog = getattr(self, "plates_dialog", None)
        if dialog is not None and dialog.isVisible():
            dialog.fill(view)

    def close_selection(self) -> None:
        dialog = getattr(self, "selection_dialog", None)
        if dialog is not None:
            dialog.close()

    def report(self, title: str, text: str, kind: str = ERROR) -> None:
        """A message with the sound of its kind (see gui.dialogs): ERROR, WARNING, INFO or SUCCESS."""
        notify(self, kind, title, text)

    def open_folder(self, folder: str) -> None:
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        QDesktopServices.openUrl(QUrl.fromLocalFile(folder))


def _layout_spot(layout, owner):
    """A layout's area inside its widget (layouts are not widgets; the tutorial points at their rectangle)."""
    return owner, layout.geometry()


class SelectionDialog(QDialog):
    """The plate selection: which variables to match within, the colony-count target, and one row
    per group with its plate. Each row's menu keeps the automatic choice, leaves the group empty, or
    pins one of the group's plates. The controller refills it after every change."""

    COLUMNS = ("Group", "Plate", "Colonies", "From target", "Capture", "Pool", "Status", "Choice", "Notes")
    NOTES, CHOICE = 8, 7

    def __init__(self, parent: QWidget):
        super().__init__(parent)
        self.setObjectName("LightWindow")
        self.setAttribute(Qt.WA_StyledBackground, True)
        palette = self.palette()
        for role, color in ((QPalette.Window, L.page), (QPalette.WindowText, L.text), (QPalette.Base, L.surface),
                            (QPalette.Text, L.text)):
            palette.setColor(role, QColor(color))
        self.setPalette(palette)
        self.setStyleSheet(parent.styleSheet() + f"\nQDialog#LightWindow {{ background: {L.page}; }}")
        self.setWindowTitle("Plate selection")
        self.resize(1320, 760)
        column = QVBoxLayout(self)
        column.setContentsMargins(22, 18, 22, 18)
        column.setSpacing(10)
        column.addWidget(light_label("One plate per index, matched on colony count", "h2"))
        column.addWidget(light_label(
            "With every variable under Match within, each group is one index and keeps the replicate plate whose "
            "colony count is closest to the target. Leave a variable out to choose across its levels too (leave "
            "Density out to match counts across the density tiers). A plate can be chosen only when all of its "
            "levels are used and highlighted under Choose from, its capture ratio is at least the separable "
            "floor, its colony count lies inside the colony window, and it is not left out by hand. The window "
            "and the target are separate: with a fixed target, the window changes only which plates can be "
            "chosen. Choose a plate by hand, or leave a group empty, from a row's menu.", "small", wrap=True))
        self.match_row = QHBoxLayout()
        self.match_row.setSpacing(10)
        column.addLayout(self.match_row)
        self.choose_rows = QVBoxLayout()               # levels the pool is drawn from, per other variable
        self.choose_rows.setSpacing(4)
        column.addLayout(self.choose_rows)
        window_row = QHBoxLayout()
        window_row.setSpacing(10)
        caption = light_label("Colonies", "small")
        caption.setFixedWidth(110)
        window_row.addWidget(caption)
        self.window_low = QSpinBox()
        self.window_low.setRange(1, 1_000_000)
        self.window_low.setFixedWidth(90)
        self.window_low.setToolTip("Fewest colonies a plate can have and still be chosen")
        window_row.addWidget(self.window_low)
        self.window_slider = RangeSlider()
        self.window_slider.setToolTip("Drag either end: plates with a colony count outside the range are not chosen "
                                      "(log scale; the right end of the track means no upper limit)")
        window_row.addWidget(self.window_slider, 1)
        self.window_high = QSpinBox()
        self.window_high.setRange(0, 1_000_000)
        self.window_high.setSpecialValueText("No limit")
        self.window_high.setFixedWidth(90)
        self.window_high.setToolTip("Most colonies a plate can have and still be chosen (0: no limit)")
        window_row.addWidget(self.window_high)
        self.window_text = light_label("", "small")
        window_row.addWidget(self.window_text)
        column.addLayout(window_row)
        self._window_row = window_row
        self._set_window = None
        self.window_slider.rangeChosen.connect(lambda low, high: self._set_window and self._set_window(low, high or None))
        self.window_low.editingFinished.connect(self._window_typed)
        self.window_high.editingFinished.connect(self._window_typed)
        target_row = QHBoxLayout()
        target_row.setSpacing(10)
        caption = light_label("Target", "small")
        caption.setFixedWidth(110)
        target_row.addWidget(caption)
        self.target_choice = QHBoxLayout()
        target_row.addLayout(self.target_choice)
        self.target_value = QSpinBox()
        self.target_value.setRange(1, 1_000_000)
        self.target_value.setFixedWidth(110)
        self.target_value.setToolTip("Fixed colony-count target")
        self.target_value.editingFinished.connect(lambda: self._set_fixed and self._set_fixed(self.target_value.value()))
        target_row.addWidget(self.target_value)
        target_row.addStretch(1)
        column.addLayout(target_row)
        self._target_row = target_row
        self.summary = light_label("", "body", wrap=True)
        column.addWidget(self.summary)
        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(self.COLUMNS)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionMode(QAbstractItemView.NoSelection)
        self.table.setWordWrap(False)
        header = self.table.horizontalHeader()
        for i in range(self.CHOICE):
            header.setSectionResizeMode(i, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.Interactive)          # plate names can be long
        header.resizeSection(1, 250)
        self.table.setTextElideMode(Qt.ElideMiddle)
        header.setSectionResizeMode(self.CHOICE, QHeaderView.Fixed)
        header.resizeSection(self.CHOICE, 210)
        header.setStretchLastSection(True)                  # Notes: why a group is empty, filters a pinned plate fails
        column.addWidget(self.table, 1)
        column.addWidget(light_label("Why groups are empty", "small"))
        self.details = QPlainTextEdit()
        self.details.setReadOnly(True)
        self.details.setFixedHeight(130)
        column.addWidget(self.details)
        buttons = QHBoxLayout()
        self.reset_button = light_button("Reset to automatic", None, "Forget plates chosen by hand and groups left empty")
        self.save_button = light_button("Save table (CSV)", None)
        self.close_button = light_button("Close", "primary")
        self.close_button.clicked.connect(self.close)
        buttons.addWidget(self.reset_button)
        buttons.addStretch(1)
        buttons.addWidget(self.save_button)
        buttons.addWidget(self.close_button)
        column.addLayout(buttons)
        self._set_fixed = None
        self._actions = {}
        self.reset_button.clicked.connect(lambda: self._actions.get("reset", lambda: None)())
        self.save_button.clicked.connect(lambda: self._actions.get("save", lambda: None)())

    def _window_typed(self) -> None:
        """A colony window typed into either box (also fired when a box loses focus as the dialog closes)."""
        try:
            low, high = self.window_low.value(), self.window_high.value() or None
        except RuntimeError:                                  # a box already deleted with the dialog
            return
        if self._set_window:
            self._set_window(low, high)

    def fill(self, view: dict) -> None:
        """view: matched [(name, on, toggle)], target (fixed: bool, value, use median, set fixed(value)),
        summary text, rows [(cells, problem: bool, choices [(text, current, handler)])], reset, save."""
        clear_layout(self.match_row)
        caption = light_label("Match within", "small")
        caption.setFixedWidth(110)
        self.match_row.addWidget(caption)
        self.match_row.addWidget(LevelChips([(name, on, toggle, None, None) for name, on, toggle in view["matched"]],
                                            tooltip="Match within"))
        self.match_row.addStretch(1)
        clear_layout(self.choose_rows)
        for i, (name, levels) in enumerate(view.get("choose_from", [])):
            line = QHBoxLayout()
            line.setSpacing(10)
            caption = light_label("Choose from" if i == 0 else "", "small")
            caption.setFixedWidth(110)
            line.addWidget(caption)
            label = light_label(name, None)
            label.setFixedWidth(90)
            line.addWidget(label)
            line.addWidget(LevelChips([(text, on, toggle, None, None) for text, on, toggle in levels],
                                      tooltip=f"Choose from {name}"))
            line.addStretch(1)
            self.choose_rows.addLayout(line)
        if view.get("choose_from"):
            self.choose_rows.addWidget(light_label(
                "Only plates with a highlighted level can be chosen. The others are still drawn faded where "
                "the analysis draws every plate (mixture model).", "small", wrap=True))
        if "window" in view:
            low, high, top, set_window = view["window"]
            self._set_window = set_window
            for widget, value in ((self.window_low, low), (self.window_high, high or 0)):
                widget.blockSignals(True)
                widget.setValue(value)
                widget.blockSignals(False)
            self.window_slider.set_range(low, high, top)
            from ..core.selection import window_text
            self.window_text.setText(window_text((low, high)))
        mode, value, use_median, set_fixed, use_fit = view["target"]
        fixed = mode == "fixed"
        clear_layout(self.target_choice)
        self._set_fixed = set_fixed
        self.target_choice.addWidget(LightSegmented(
            [("Least total deviation", mode == "fit", use_fit),
             ("Median of eligible plates", mode == "median", use_median),
             ("Fixed", fixed, lambda: set_fixed(self.target_value.value()))], height=26,
            tooltip="Target. Least total deviation: the count that keeps the chosen plates, summed over every "
                    "group, closest to one shared count"))
        self.target_value.blockSignals(True)
        self.target_value.setValue(int(round(value)) if value == value else 1)
        self.target_value.blockSignals(False)
        self.target_value.setEnabled(fixed)
        self.summary.setText(view["summary"])
        self.details.setPlainText(view.get("details", "") or "Every group has a plate.")
        self._actions = {"reset": view["reset"], "save": view["save"]}
        rows = view["rows"]
        self.table.setRowCount(len(rows))
        for r, (cells, problem, choices) in enumerate(rows):
            for c, text in enumerate(cells):
                c = c if c < self.CHOICE else self.NOTES
                item = QTableWidgetItem(str(text))
                if problem:
                    item.setForeground(QColor(L.danger_text))
                item.setToolTip(str(text))                   # plate names and notes can be cut short
                self.table.setItem(r, c, item)
            self.table.setCellWidget(r, self.CHOICE, self._choice_menu(choices))


    @staticmethod
    def _choice_menu(choices: list[tuple]) -> QComboBox:
        menu = QComboBox()
        menu.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)   # long plate names: the list widens
        menu.setMinimumContentsLength(16)
        for text, _current, _handler in choices:
            menu.addItem(text)
        menu.view().setMinimumWidth(menu.view().sizeHintForColumn(0) + 24)
        menu.setCurrentIndex(next((i for i, choice in enumerate(choices) if choice[1]), 0))
        menu.activated.connect(lambda index: choices[index][2]())
        return menu


class NumberItem(QTableWidgetItem):
    """A table cell that sorts by its number, not its text (blank cells sort first)."""

    def __init__(self, text: str, number: float):
        super().__init__(text)
        self.number = number if number == number else float("-inf")

    def __lt__(self, other) -> bool:
        return self.number < getattr(other, "number", float("-inf"))


def _selection_locate(self, key: str):
    """The tutorial's spots in the selection window: match, window, target."""
    layout = {"match": self.match_row, "window": self._window_row, "target": self._target_row}.get(key)
    return _layout_spot(layout, self) if layout is not None else None


SelectionDialog.locate = _selection_locate


class PlatesDialog(QDialog):
    """Every plate in one table that filters and sorts, with two lists: the long list (every plate) and
    the short list (the plates ticked under Short). Use leaves a plate out by hand. The Long / Short
    switch shows either list in the table; "Plot the short list only" makes every analysis use the short
    list. Rows are keyed by index id, so sorting never mixes up which tick belongs to which plate."""

    COLUMNS = ("Use", "Short", "Plate", "Levels", "Colonies", "Capture", "Used", "Why not used")
    USE, SHORT, PLATE, COLONIES, CAPTURE = 0, 1, 2, 4, 5

    def __init__(self, parent: QWidget):
        super().__init__(parent)
        from PySide6.QtWidgets import QCheckBox, QLineEdit
        self.setObjectName("LightWindow")
        self.setAttribute(Qt.WA_StyledBackground, True)
        palette = self.palette()
        for role, color in ((QPalette.Window, L.page), (QPalette.WindowText, L.text), (QPalette.Base, L.surface),
                            (QPalette.Text, L.text)):
            palette.setColor(role, QColor(color))
        self.setPalette(palette)
        self.setStyleSheet(parent.styleSheet() + f"\nQDialog#LightWindow {{ background: {L.page}; }}")
        self.setWindowTitle("Plates")
        self.resize(1240, 760)
        column = QVBoxLayout(self)
        column.setContentsMargins(22, 18, 22, 18)
        column.setSpacing(10)
        column.addWidget(light_label("Plates", "h2"))
        column.addWidget(light_label(
            "A plate is used when every one of its levels is used (Plates used), it is not overplated while "
            "overplated plates are left out, and Use is ticked. Untick Use to leave a plate out by hand. Tick "
            "Short to put a plate on the short list; with Plot the short list only, every analysis uses the "
            "short list and nothing else. Type in Filter to find plates (every word must appear in the row); "
            "click a column title to sort.", "small", wrap=True))
        bar = QHBoxLayout()
        bar.setSpacing(10)
        self.list_switch = QHBoxLayout()
        bar.addLayout(self.list_switch)
        bar.addWidget(light_label("Filter", "small"))
        self.filter = QLineEdit()
        self.filter.setPlaceholderText("plate name, level, why not used…")
        self.filter.setClearButtonEnabled(True)
        self.filter.setMinimumWidth(260)
        self.filter.textChanged.connect(lambda _text: self._apply_filter())
        bar.addWidget(self.filter, 1)
        self.plot_short = QCheckBox("Plot the short list only")
        self.plot_short.setToolTip("Every analysis uses only the short-listed plates (Plate rules: List)")
        self.plot_short.clicked.connect(lambda on: self._actions["use_short"](bool(on)))
        bar.addWidget(self.plot_short)
        column.addLayout(bar)
        self.summary = light_label("", "body")
        column.addWidget(self.summary)
        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(self.COLUMNS)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionMode(QAbstractItemView.NoSelection)
        self.table.setWordWrap(False)
        self.table.setTextElideMode(Qt.ElideMiddle)
        header = self.table.horizontalHeader()
        for i in range(len(self.COLUMNS) - 1):
            header.setSectionResizeMode(i, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(self.PLATE, QHeaderView.Interactive)
        header.resizeSection(self.PLATE, 280)
        header.setStretchLastSection(True)
        self.table.itemChanged.connect(self._ticked)
        column.addWidget(self.table, 1)
        buttons = QHBoxLayout()
        self.add_shown = light_button("Add shown to short list", None, "Every row the table shows goes on the short list")
        self.remove_shown = light_button("Remove shown from short list", None,
                                         "Every row the table shows comes off the short list")
        self.clear_short = light_button("Clear short list", "quiet")
        self.add_shown.clicked.connect(lambda: self._actions["add"](self.shown_ids()))
        self.remove_shown.clicked.connect(lambda: self._actions["remove"](self.shown_ids()))
        self.clear_short.clicked.connect(lambda: self._actions["clear"]())
        for widget in (self.add_shown, self.remove_shown, self.clear_short):
            buttons.addWidget(widget)
        buttons.addStretch(1)
        close = light_button("Close", "primary")
        close.clicked.connect(self.close)
        buttons.addWidget(close)
        column.addLayout(buttons)
        self.showing_short = False                 # the table shows the short list (True) or every plate
        self._toggles, self._rows = {}, []
        self._actions = {"use_short": lambda _on: None, "add": lambda _ids: None, "remove": lambda _ids: None,
                         "clear": lambda: None}

    def fill(self, view: dict) -> None:
        """view: summary; rows (index id, plate, levels, colonies, capture, used, use ticked, why not, use toggle,
        short ticked, short toggle, colony count, capture ratio); short (count, in use, set in use(on),
        add(ids), remove(ids), clear())."""
        self.summary.setText(view["summary"])
        self._rows = view["rows"]
        count, in_use, set_use, add, remove, clear = view["short"]
        self._actions = {"use_short": set_use, "add": add, "remove": remove, "clear": clear}
        if not count:
            self.showing_short = False
        self._fill_switch()
        self.plot_short.blockSignals(True)
        self.plot_short.setChecked(in_use)
        self.plot_short.setEnabled(bool(count))
        self.plot_short.blockSignals(False)
        self.clear_short.setEnabled(bool(count))
        self._toggles = {}
        ids = [row[0] for row in self._rows]
        if ids and sorted(ids) == sorted(getattr(self, "_filled_ids", [])) and self.table.rowCount() == len(ids):
            self._update_rows()                                 # the same plates: change only what changed
            return
        self._filled_ids = ids
        self.table.setUpdatesEnabled(False)
        self.table.blockSignals(True)
        self.table.setSortingEnabled(False)                      # fill unsorted, then sort by the chosen column
        self.table.setRowCount(len(self._rows))
        for r, row in enumerate(self._rows):
            (index_id, plate, levels, colonies, capture, used, ticked, why, use_toggle, short, short_toggle,
             count_value, ratio_value) = row
            self._toggles[(index_id, self.USE)] = use_toggle
            self._toggles[(index_id, self.SHORT)] = short_toggle
            for c, on in ((self.USE, ticked), (self.SHORT, short)):
                box = QTableWidgetItem()
                box.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
                box.setCheckState(Qt.Checked if on else Qt.Unchecked)
                box.setData(Qt.UserRole, index_id)
                self.table.setItem(r, c, box)
            cells = {self.PLATE: QTableWidgetItem(str(plate)), 3: QTableWidgetItem(str(levels)),
                     self.COLONIES: NumberItem(str(colonies), count_value),
                     self.CAPTURE: NumberItem(str(capture), ratio_value),
                     6: QTableWidgetItem("yes" if used else "no"), 7: QTableWidgetItem(str(why))}
            for c, item in cells.items():
                item.setToolTip(item.text())
                item.setData(Qt.UserRole, index_id)
                if not used:
                    item.setForeground(QColor(L.text_secondary))
                self.table.setItem(r, c, item)
        self.table.setSortingEnabled(True)
        self.table.blockSignals(False)
        header = self.table.horizontalHeader()                   # fit the columns once, then leave them alone
        self.table.resizeColumnsToContents()
        header.resizeSection(self.PLATE, 280)
        for i in range(len(self.COLUMNS) - 1):
            header.setSectionResizeMode(i, QHeaderView.Interactive)
        self.table.setUpdatesEnabled(True)
        self._apply_filter()

    def _update_rows(self) -> None:
        """Refill in place: tick boxes, the Used and Why columns and their colors, for rows already shown."""
        where = {}
        for r in range(self.table.rowCount()):
            item = self.table.item(r, self.USE)
            if item is not None:
                where[int(item.data(Qt.UserRole))] = r
        self.table.setUpdatesEnabled(False)
        self.table.blockSignals(True)
        sorting = self.table.isSortingEnabled()
        self.table.setSortingEnabled(False)                      # rows keep their places while cells change
        for row in self._rows:
            (index_id, plate, levels, colonies, capture, used, ticked, why, use_toggle, short, short_toggle,
             count_value, ratio_value) = row
            self._toggles[(index_id, self.USE)] = use_toggle
            self._toggles[(index_id, self.SHORT)] = short_toggle
            r = where.get(int(index_id))
            if r is None:
                continue
            for c, on in ((self.USE, ticked), (self.SHORT, short)):
                state = Qt.Checked if on else Qt.Unchecked
                if self.table.item(r, c).checkState() != state:
                    self.table.item(r, c).setCheckState(state)
            for c, text in ((6, "yes" if used else "no"), (7, str(why))):
                item = self.table.item(r, c)
                if item.text() != text:
                    item.setText(text)
                    item.setToolTip(text)
            color = QColor(L.text) if used else QColor(L.text_secondary)
            for c in (self.PLATE, 3, self.COLONIES, self.CAPTURE, 6, 7):
                item = self.table.item(r, c)
                if item.foreground().color() != color:
                    item.setForeground(color)
        self.table.setSortingEnabled(sorting)
        self.table.blockSignals(False)
        self.table.setUpdatesEnabled(True)
        self._apply_filter()

    def _fill_switch(self) -> None:
        """The Long / Short switch, with each list's size."""
        count = sum(1 for row in self._rows if row[9])
        clear_layout(self.list_switch)
        self.list_switch.addWidget(LightSegmented(
            [(f"Long list ({len(self._rows)})", not self.showing_short, lambda: self.show_list(False)),
             (f"Short list ({count})", self.showing_short, lambda: self.show_list(True), bool(count))],
            height=26, tooltip="Show in the table"))

    def show_list(self, short: bool) -> None:
        """Show the short list (True) or every plate (False) in the table; plotting is unchanged."""
        self.showing_short = short
        self._fill_switch()
        self._apply_filter()

    def _apply_filter(self) -> None:
        """Hide the rows the filter words or the list switch leave out."""
        words = [w for w in self.filter.text().lower().split() if w]
        for r in range(self.table.rowCount()):
            text = " ".join((self.table.item(r, c).text() if self.table.item(r, c) else "")
                            for c in range(self.PLATE, len(self.COLUMNS))).lower()
            box = self.table.item(r, self.SHORT)
            short = box is not None and box.checkState() == Qt.Checked
            self.table.setRowHidden(r, any(w not in text for w in words) or (self.showing_short and not short))

    def locate(self, prefix: str):
        """The tutorial's spot: the Use box of the first shown plate whose name starts with prefix."""
        for r in range(self.table.rowCount()):
            item = self.table.item(r, self.PLATE)
            if item is not None and item.text().startswith(prefix) and not self.table.isRowHidden(r):
                use = self.table.item(r, self.USE) or item
                self.table.scrollToItem(use)
                return self.table.viewport(), self.table.visualItemRect(use)
        return self.table, self.table.rect()

    def shown_ids(self) -> list[int]:
        """Index ids of the rows the filter and the list switch show."""
        return [int(self.table.item(r, self.SHORT).data(Qt.UserRole)) for r in range(self.table.rowCount())
                if not self.table.isRowHidden(r) and self.table.item(r, self.SHORT) is not None]

    def _ticked(self, item) -> None:
        if item.column() not in (self.USE, self.SHORT):
            return
        toggle = self._toggles.get((item.data(Qt.UserRole), item.column()))
        if toggle is not None:
            from PySide6.QtCore import QTimer
            QTimer.singleShot(0, toggle)                         # the table is refilled; not inside its own signal
