"""ColonyDetectionWindow: the Colony Detection screen (view).

Layout, top to bottom: top bar, then three columns (mode list and settings |
plate | summary and activity), then a status bar. Both side columns collapse:
the left one to a rail of mode icons, the right one fully. The window only
builds widgets and shows what the controller passes it; every user action
reaches the controller through Qt signals.

Side panels show only what applies right now: the controller reports the
interaction state (selection, drawn circles, region) and the window shows or
hides the matching controls.
"""

from __future__ import annotations

from PySide6.QtCore import QEasingCurve, QPointF, QSize, Qt, QTimer, QVariantAnimation, Signal
from PySide6.QtGui import QColor, QFont, QFontMetricsF, QKeySequence, QPainter, QPixmap, QShortcut
from PySide6.QtWidgets import (QButtonGroup, QFrame, QGridLayout, QHBoxLayout, QLabel, QMainWindow, QPushButton, QScrollArea, QStackedWidget, QVBoxLayout, QWidget)

from ..core.params import (CIRCULAR, DARK, IRREGULAR, LIGHT, PARAM_SPECS, THRESHOLD_MAX, THRESHOLD_MIN,
                           THRESHOLD_STEP, DetectionParams, level_from_threshold, threshold_from_level)
from ..theme import Theme
from ..theme.icons import app_icon, icon_pixmap, logo_pixmap
from .banner import BANNER_HEIGHT, BANNER_MARGIN, back_button
from .canvas import DetectCanvas
from .modes import AUTOMATIC, GROUP_TITLES, MANUAL, MODE_ORDER, MODES, ModeSpec
from .widgets import (ActivityFeed, Dot, Field, GestureRow, HintCard, LegendDot, ModeButton, ParameterRow,
                      ToggleSwitch, button, divider, label, Collapsible, one_open)
from .dialogs import ERROR, QUESTION, SUCCESS, notify, show_message

THRESHOLD_CAPTIONS = {DARK: "Pixels at or below this brightness (0 black, 1 white) count as colony.",
                      LIGHT: "Pixels at or above this brightness (0 black, 1 white) count as colony."}


class IndexPopup(QFrame):
    """Drops down from the image name: the index board with its view controls."""

    def __init__(self, colors, parent=None):
        super().__init__(parent, Qt.Popup)
        from .index_board import IndexBoard
        self.colors = c = colors
        self.setObjectName("IndexPopup")
        self.setStyleSheet(f"QFrame#IndexPopup {{ background: {c.panel}; border: 1px solid {c.track_off};"
                           " border-radius: 8px; }")
        self.setFixedWidth(560)
        column = QVBoxLayout(self)
        column.setContentsMargins(16, 14, 16, 14)
        column.setSpacing(10)
        head = QHBoxLayout()
        head.addWidget(label("Indices", "label"))
        head.addStretch(1)
        self.summary = label("", "caption")
        head.addWidget(self.summary)
        column.addLayout(head)
        self.view_rows = QVBoxLayout()
        self.view_rows.setSpacing(4)
        column.addLayout(self.view_rows)
        self.page_rows = QVBoxLayout()
        self.page_rows.setSpacing(4)
        column.addLayout(self.page_rows)
        self.board = IndexBoard(c)
        column.addWidget(self.board)
        legend = QHBoxLayout()
        legend.setSpacing(12)
        for text, swatch, border in (("Detected", c.accent, c.accent), ("Not detected yet", c.board_waiting_fill, c.accent),
                                     ("To review", c.board_review_fill, c.board_review_edge), ("No region", c.window, c.border)):
            chip = QLabel()
            chip.setFixedSize(12, 12)
            chip.setStyleSheet(f"background: {swatch}; border: 1px solid {border}; border-radius: 2px;")
            legend.addWidget(chip)
            legend.addWidget(label(text, "caption"))
        legend.addStretch(1)
        column.addLayout(legend)
        self.note = label("", "caption", wrap=True)
        column.addWidget(self.note)

    def set_content(self, summary: str, view_rows, page_rows, board, note: str) -> None:
        from .index_board import Segmented
        from .light import clear_layout
        self.summary.setText(summary)
        for target, rows in ((self.view_rows, view_rows), (self.page_rows, page_rows)):
            clear_layout(target)
            for name, options in rows:
                line = QHBoxLayout()
                line.addWidget(label(name, "caption"))
                line.addStretch(1)
                control = Segmented(options, self.colors, height=24, tooltip=name)
                control.setFixedWidth(260 if target is self.view_rows else 320)
                line.addWidget(control)
                target.addLayout(line)
        self.board.set_board(board)
        self.note.setText(note)
        self.adjustSize()


class ColonyDetectionWindow(QMainWindow):
    """Colony Detection's view. Controllers use only its signals and its set_/show_/ask_ methods, so the
    layout and widgets can change freely as long as these keep their names and meanings."""

    # ----- what the user asks for (the controller connects to these) -----------
    modeChosen = Signal(str)                   # mode key
    settingEdited = Signal(str, object)        # field name, value (level already carries the colony color)
    shapeChosen = Signal(str)                  # 'Irregular' / 'Circular'
    estimateRequested = Signal()
    newImageStartChosen = Signal(str)          # 'estimate' / 'last image': how new images choose their settings
    deleteRequested = Signal()
    addRequested = Signal()
    clearRequested = Signal()                  # Esc and every Clear button
    contourToggled = Signal(bool)
    growthToggled = Signal(bool)
    undoRequested = Signal()
    redoRequested = Signal()
    finishRequested = Signal()
    helpRequested = Signal()
    previousRequested = Signal()
    nextRequested = Signal()
    boardRequested = Signal()
    indexChosen = Signal(int)                  # from the index board
    pointerMoved = Signal(float, float)        # image coordinates

    def __init__(self, theme: Theme, nominal_display: str, ordinal_display: str):
        super().__init__()
        self.theme = theme
        self.colors = theme.style.colors
        self.setWindowTitle("QuantaColony · Colony Detection")
        self.setWindowIcon(app_icon())
        self.resize(*theme.style.layout.window_size)
        self._spec: ModeSpec = MODES[MODE_ORDER[0]]
        self._state = {"selected": 0, "box": False, "pending": 0, "region": False, "candidates": None}
        self._animations: dict[str, QVariantAnimation] = {}
        self.left_collapsed = False
        self.right_collapsed = False

        root = QWidget(objectName="Root")
        column = QVBoxLayout(root)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(0)
        column.addWidget(self._build_top_bar(nominal_display, ordinal_display))
        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)
        self.left_sidebar = self._build_left_sidebar()
        self.right_sidebar = self._build_right_sidebar()
        body.addWidget(self.left_sidebar)
        body.addWidget(self._build_canvas_area(), 1)
        body.addWidget(self.right_sidebar)
        column.addLayout(body, 1)
        column.addWidget(self._build_status_bar())

        # A scroll area lets the window shrink below the layout's size on small displays
        scroller = QScrollArea()
        scroller.setWidget(root)
        scroller.setWidgetResizable(True)
        scroller.setFrameShape(QFrame.NoFrame)
        self.setCentralWidget(scroller)
        root.setMinimumSize(1100, 700)

        self._status_timer = QTimer(self)
        self._status_timer.setSingleShot(True)
        self._status_timer.timeout.connect(lambda: self.status_text.setText("Ready"))
        self._wire_controls()

    # =====================================================================
    # construction
    # =====================================================================
    def _build_top_bar(self, nominal_display: str, ordinal_display: str) -> QFrame:
        c = self.colors
        bar = QFrame(objectName="TopBar")
        bar.setFixedHeight(BANNER_HEIGHT)
        row = QHBoxLayout(bar)
        row.setContentsMargins(BANNER_MARGIN, 0, 16, 0)
        row.setSpacing(16)

        brand = QHBoxLayout()
        brand.setSpacing(10)
        self.back_button = back_button()
        self.back_button.setToolTip("Back to the project page (unsaved edits are asked about)")
        self.back_button.clicked.connect(self.close)              # closing a module returns to its project page
        brand.addWidget(self.back_button)
        brand.addSpacing(6)
        self.left_toggle = button(variant="ghost", icon="panel_left", colors=c, icon_color=c.text_muted,
                                  tooltip="Hide the mode panel ([)", fixed=(34, 34))
        brand.addWidget(self.left_toggle)
        brand.addSpacing(2)
        logo = QLabel()
        logo.setPixmap(logo_pixmap(30))
        logo.setAccessibleName("QuantaColony logo")
        brand.addWidget(logo)
        wordmark = QLabel()
        wordmark.setPixmap(self._wordmark_pixmap("QuantaColony"))
        wordmark.setAccessibleName("QuantaColony")
        brand.addWidget(wordmark)
        brand.addWidget(divider(vertical=True, length=20))
        brand.addWidget(label("Colony Detection", "muted"))
        row.addLayout(brand)
        row.addStretch(1)

        self.prev_button = button(variant="icon", icon="chevron_left", colors=c, icon_color=c.text_faint,
                                  icon_size=16, tooltip="Previous image", fixed=(32, 32))
        self.image_picker = QPushButton(objectName="ImagePicker")
        self.image_picker.setCursor(Qt.PointingHandCursor)
        self.image_picker.setFixedHeight(36)
        picker = QHBoxLayout(self.image_picker)
        picker.setContentsMargins(8, 0, 10, 0)
        picker.setSpacing(10)
        tile = QLabel()
        tile.setFixedSize(22, 22)
        tile.setAlignment(Qt.AlignCenter)
        tile.setStyleSheet(f"background: {c.raised}; border-radius: 6px;")
        tile.setPixmap(icon_pixmap("plate", c.text_muted, 14))
        picker.addWidget(tile)
        self.nominal_label = label(nominal_display)
        self.nominal_label.setStyleSheet("font-weight: 500;")
        picker.addWidget(self.nominal_label)
        self.ordinal_chip = label(ordinal_display, "chipNeutral")
        self.ordinal_chip.setFixedHeight(22)
        picker.addWidget(self.ordinal_chip)
        chevron = QLabel()
        chevron.setPixmap(icon_pixmap("chevron_down", c.text_faint, 16))
        picker.addWidget(chevron)
        for child in (tile, self.nominal_label, self.ordinal_chip, chevron):
            child.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.image_picker.setMinimumWidth(self.nominal_label.sizeHint().width()
                                          + self.ordinal_chip.sizeHint().width() + 90)
        self.image_picker.setAccessibleName(f"Image: {nominal_display}, {ordinal_display}")
        self.next_button = button(variant="icon", icon="chevron_right", colors=c, icon_color=c.text_faint,
                                  icon_size=16, tooltip="Next image", fixed=(32, 32))
        nav = QHBoxLayout()
        nav.setSpacing(6)
        for widget in (self.prev_button, self.image_picker, self.next_button):
            nav.addWidget(widget)
        row.addLayout(nav)
        row.addStretch(1)

        self.right_toggle = button(variant="ghost", icon="panel_right", colors=c, icon_color=c.text_muted,
                                   tooltip="Hide the summary panel (])", fixed=(34, 34))
        row.addWidget(self.right_toggle)
        history = QFrame(objectName="ButtonGroup")
        history.setFixedHeight(38)
        history_row = QHBoxLayout(history)
        history_row.setContentsMargins(3, 3, 3, 3)
        history_row.setSpacing(0)
        self.undo_button = button(variant="ghost", icon="undo", colors=c, tooltip="Undo (Ctrl+Z)", fixed=(34, 30))
        self.redo_button = button(variant="ghost", icon="redo", colors=c, tooltip="Redo (Ctrl+Y)", fixed=(34, 30))
        history_row.addWidget(self.undo_button)
        history_row.addWidget(self.redo_button)
        row.addWidget(history)
        self.help_button = button(variant="icon", icon="help", colors=c, icon_color=c.text_muted,
                                  icon_size=18, tooltip="Help", fixed=(38, 38))
        row.addWidget(self.help_button)
        self.finish_button = button("Finish image", "primary", icon="check", colors=c,
                                    icon_color=c.accent_ink, stroke=2.4)
        self.finish_button.setObjectName("TopPrimary")
        self.finish_button.setToolTip("Save this image's colonies (I'm Satisfied)")
        row.addWidget(self.finish_button)
        return bar

    def _wordmark_pixmap(self, text: str) -> QPixmap:
        """Raleway ExtraBold drawn directly: the variable font's weight axis must be set
        on the QFont itself, which style sheets cannot do."""
        font = QFont(self.theme.brand_family)
        font.setPixelSize(17)
        font.setVariableAxis(QFont.Tag("wght"), 800)
        font.setLetterSpacing(QFont.AbsoluteSpacing, 0.2)
        metrics = QFontMetricsF(font)
        ratio = 2.0
        width, height = metrics.horizontalAdvance(text) + 2, metrics.height() + 2
        pixmap = QPixmap(int(width * ratio), int(height * ratio))
        pixmap.fill(Qt.transparent)
        pixmap.setDevicePixelRatio(ratio)
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.TextAntialiasing)
        painter.setFont(font)
        painter.setPen(QColor(self.colors.accent))      # wordmark in logo lime
        painter.drawText(QPointF(1, metrics.ascent() + 1), text)
        painter.end()
        return pixmap

    def _build_left_sidebar(self) -> QFrame:
        """Step 1 and Step 2 as collapsible groups, one open at a time, as in the browser study. Step 1 holds
        Detect automatically and the detection settings (five collapsible sections, one open at a time);
        Step 2 holds the four manual tools and the panel of the chosen tool. While Detect in a region is on,
        the settings sit under its panel (they apply inside its box)."""
        c = self.colors
        side = QFrame(objectName="LeftSidebar")
        side.setFixedWidth(self.theme.style.layout.sidebar_width + 10)
        self._left_column = QVBoxLayout(side)
        self._left_column.setContentsMargins(16, 20, 16, 20)
        self._left_column.setSpacing(0)

        self.mode_group = QButtonGroup(self)
        self.mode_group.setExclusive(True)
        self.mode_buttons: dict[str, ModeButton] = {}
        self.groups: dict[str, Collapsible] = {}
        content = QWidget()
        rail = QVBoxLayout(content)
        rail.setContentsMargins(0, 0, 0, 0)
        rail.setSpacing(4)
        for group, key in ((AUTOMATIC, "grp-auto"), (MANUAL, "grp-manual")):
            box = Collapsible(key, GROUP_TITLES[group], "group")
            self.groups[group] = box
            for mode in MODE_ORDER:
                spec = MODES[mode]
                if spec.group != group:
                    continue
                mode_button = ModeButton(spec.icon, spec.label, spec.shortcut, c)
                self.mode_group.addButton(mode_button)
                self.mode_buttons[mode] = mode_button
                box.body_layout.addWidget(mode_button)
            rail.addWidget(box)
        rail.addStretch(1)
        one_open(self.groups.values())

        auto = self.groups[AUTOMATIC].body_layout
        self.settings_moved = label("While Detect in a region is on, these settings sit under it and apply "
                                    "inside its box.", "caption", wrap=True)
        auto.addWidget(self.settings_moved)
        self.parameter_page = self._build_parameter_panel()
        auto.addWidget(self.parameter_page)

        self.panels = QWidget()                      # the chosen manual tool's panel
        panel_column = QVBoxLayout(self.panels)
        panel_column.setContentsMargins(0, 10, 0, 0)
        panel_column.setSpacing(0)
        self.panel_pages = {
            "delete_one": self._build_delete_one_panel(),
            "delete_region": self._build_delete_region_panel(),
            "add_one": self._build_add_one_panel(),
            "region": self._build_region_panel(),
        }
        for page in self.panel_pages.values():
            panel_column.addWidget(page)
        self.groups[MANUAL].body_layout.addWidget(self.panels)
        self.groups[AUTOMATIC].set_open(True)

        # The column scrolls when the window is too short to show it all
        self.panel_scroller = QScrollArea()
        self.panel_scroller.setWidget(content)
        self.panel_scroller.setWidgetResizable(True)
        self.panel_scroller.setFrameShape(QFrame.NoFrame)
        self.panel_scroller.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._left_column.addWidget(self.panel_scroller, 1)
        return side

    def sections(self) -> dict[str, Collapsible]:
        """Every collapsible group and settings section by the id the guide's tasks use."""
        out = {box.key: box for box in self.groups.values()}
        out.update(self.setting_sections)
        return out

    def open_sections(self) -> list[str]:
        """The ids of the open groups and sections, as the browser study reports them to the guide."""
        return [key for key, box in self.sections().items() if box.is_open()]

    def close_sections(self) -> None:
        """Every group and section closed, as the browser study's page starts."""
        for box in self.sections().values():
            box.set_open(False)

    def _build_parameter_panel(self) -> QWidget:
        c = self.colors
        page = QWidget()
        column = QVBoxLayout(page)
        column.setContentsMargins(0, 10, 0, 0)
        column.setSpacing(14)

        # Everything that sets detection: under Step 1, or under Detect in a region once its box exists
        self.parameter_controls = QWidget()
        controls = QVBoxLayout(self.parameter_controls)
        controls.setContentsMargins(0, 0, 0, 0)
        controls.setSpacing(6)
        column.addWidget(self.parameter_controls)
        self.setting_sections: dict[str, Collapsible] = {}

        def section(key: str, title: str) -> QVBoxLayout:
            box = Collapsible(key, title, "sec")
            self.setting_sections[key] = box
            controls.addWidget(box)
            return box.body_layout

        appearance = section("sec-appearance", "Colony appearance")
        appearance.addWidget(label("Colony color", "section"))
        polarity_frame = QFrame(objectName="Segmented")
        polarity_row = QHBoxLayout(polarity_frame)
        polarity_row.setContentsMargins(4, 4, 4, 4)
        polarity_row.setSpacing(4)
        self.polarity_group = QButtonGroup(self)
        self.polarity_buttons: dict[str, QPushButton] = {}
        for key, text, tip in ((DARK, "Dark", "Colonies are darker than the agar"),
                               (LIGHT, "Light", "Colonies are lighter than the agar")):
            segment = button(text, "segment", tooltip=tip)
            segment.setCheckable(True)
            self.polarity_group.addButton(segment)
            self.polarity_buttons[key] = segment
            polarity_row.addWidget(segment)
        appearance.addWidget(polarity_frame)
        appearance.addWidget(label("Colony shape", "section"))
        segmented = QFrame(objectName="Segmented")
        segment_row = QHBoxLayout(segmented)
        segment_row.setContentsMargins(4, 4, 4, 4)
        segment_row.setSpacing(4)
        self.shape_group = QButtonGroup(self)
        self.shape_buttons: dict[str, QPushButton] = {}
        for kind in (IRREGULAR, CIRCULAR):
            segment = button(kind, "segment")
            segment.setCheckable(True)
            self.shape_group.addButton(segment)
            self.shape_buttons[kind] = segment
            segment_row.addWidget(segment)
        appearance.addWidget(segmented)
        self.shape_hint = label("Circular fits a circle to each colony and errs toward missed colonies. Irregular "
                                "follows each colony's edge and errs toward false detections.", "caption", wrap=True)
        appearance.addWidget(self.shape_hint)
        # Largest object is a Circular setting; with Irregular it follows Max radius (controller)
        self.largest_row = QWidget()
        largest_column = QVBoxLayout(self.largest_row)
        largest_column.setContentsMargins(0, 0, 0, 0)
        largest_column.setSpacing(4)
        largest = QHBoxLayout()
        largest.addWidget(label("Largest object", "label"))
        largest.addStretch(1)
        maxpix = PARAM_SPECS["maxpix"]
        self.maxpix_field = Field("", "px", maxpix.minimum, maxpix.maximum, maxpix.step, 0,
                                  "Largest object in pixels", field_width=56)
        self.maxpix_field.setFixedHeight(32)
        largest.addWidget(self.maxpix_field)
        largest_column.addLayout(largest)
        largest_column.addWidget(label("Circular only: blobs covering more pixels than this are left out before "
                                       "circles are fitted.", "caption", wrap=True))
        appearance.addWidget(self.largest_row)

        sense = PARAM_SPECS["sense"]
        self.level_row = ParameterRow("Threshold", THRESHOLD_MIN, THRESHOLD_MAX, THRESHOLD_STEP, 2,
                                      THRESHOLD_CAPTIONS[DARK])
        section("sec-threshold", "Brightness threshold").addWidget(self.level_row)

        radius_grid = QHBoxLayout()
        radius_grid.setSpacing(8)
        rmin, rmax = PARAM_SPECS["rmin"], PARAM_SPECS["rmax"]
        self.rmin_field = Field("Min", "px", rmin.minimum, rmin.maximum, rmin.step, 0, "Minimum radius in pixels",
                                steppers=c)
        self.rmax_field = Field("Max", "px", rmax.minimum, rmax.maximum, rmax.step, 0, "Maximum radius in pixels",
                                steppers=c)
        radius_grid.addWidget(self.rmin_field)
        radius_grid.addWidget(self.rmax_field)
        size = section("sec-size", "Colony size")
        size.addWidget(label("Colony radius", "label"))
        size.addLayout(radius_grid)

        self.sense_row = ParameterRow("Sensitivity", sense.minimum, sense.maximum, sense.step, 3)
        section("sec-sensitivity", "Sensitivity").addWidget(self.sense_row)

        split = section("sec-split", "Touching colonies")
        self.split_card = self.setting_sections["sec-split"]
        split_top = QHBoxLayout()
        split_top.setSpacing(12)
        split_texts = QVBoxLayout()
        split_texts.setSpacing(2)
        split_title = label("Split touching colonies")
        split_title.setStyleSheet("font-weight: 600;")
        split_texts.addWidget(split_title)
        split_texts.addWidget(label("Cut blobs of touching colonies apart; the pieces are marked as split",
                                    "caption", wrap=True))
        split_top.addLayout(split_texts, 1)
        self.split_switch = ToggleSwitch(c, "Split touching colonies")
        split_top.addWidget(self.split_switch)
        split.addLayout(split_top)
        elongation, pinch = PARAM_SPECS["split_elongation"], PARAM_SPECS["split_pinch"]
        self.split_elongation_row = ParameterRow(elongation.label, elongation.minimum, elongation.maximum,
                                                 elongation.step, elongation.decimals,
                                                 "Blobs more elongated than this are tried (0 round, 1 a line)")
        self.split_pinch_row = ParameterRow(pinch.label, pinch.minimum, pinch.maximum, pinch.step, pinch.decimals,
                                            "How much a blob must narrow between two colonies to be cut")
        split.addWidget(self.split_elongation_row)
        split.addWidget(self.split_pinch_row)
        one_open(self.setting_sections.values())

        self.auto_button = button("Estimate settings", None, icon="wand", colors=c,
                                  icon_color=c.accent_text, icon_size=16,
                                  tooltip="Set the brightness threshold, colony color and radius range from "
                                          "this image, then rerun detection (undoable)")
        column.addWidget(self.auto_button)
        self.start_row = QWidget()
        start_line = QHBoxLayout(self.start_row)
        start_line.setContentsMargins(2, 4, 2, 4)
        start_line.setSpacing(10)
        start_texts = QVBoxLayout()
        start_texts.setSpacing(2)
        start_title = label("Estimate every new image", None)
        start_title.setStyleSheet("font-weight: 600;")
        start_texts.addWidget(start_title)
        start_texts.addWidget(label("Each new image starts from settings estimated from that image",
                                    "caption", wrap=True))
        start_line.addLayout(start_texts, 1)
        self.start_switch = ToggleSwitch(c, "Estimate every new image")
        self.start_switch.setToolTip("On: every new image starts from its own estimate (project defaults for "
                                     "sensitivity, shape and splitting). Off: from the last image you finished.")
        start_line.addWidget(self.start_switch, 0, Qt.AlignTop)
        column.addWidget(self.start_row)
        self.detect_hint = HintCard("", c)
        self.set_new_image_start("last image")
        column.addWidget(self.detect_hint)
        return page

    def _build_region_panel(self) -> QWidget:
        """Detect in a region: the instruction until a box exists, then the settings and the actions."""
        c = self.colors
        page = QWidget()
        column = QVBoxLayout(page)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(12)
        self.region_intro = HintCard("Drag a box on the plate around the colonies to detect. "
                                     "Detection settings appear once the region is drawn.", c, icon="region_plus")
        column.addWidget(self.region_intro)
        self.region_hint = HintCard("These settings apply inside the box only. The whole-image "
                                    "settings stay as they are. Drag a new box to move the region.", c)
        column.addWidget(self.region_hint)
        self.region_settings = QVBoxLayout()           # the Step 1 settings move here while this tool is on
        self.region_settings.setContentsMargins(0, 0, 0, 0)
        column.addLayout(self.region_settings)
        self.region_add_button = button("Add detected colonies", "primary", icon="plus", colors=c,
                                        icon_color=c.accent_ink, icon_size=16, stroke=2.4)
        self.region_clear_button = button("Clear region (Esc)")
        column.addWidget(self.region_add_button)
        column.addWidget(self.region_clear_button)
        return page

    def _place_settings(self, in_region: bool) -> None:
        """The settings under Detect in a region while it is on, otherwise under Step 1."""
        home = self.region_settings if in_region else self.parameter_page.layout()
        if self.parameter_controls.parentWidget() is not (self.panel_pages["region"] if in_region
                                                          else self.parameter_page):
            if in_region:
                home.addWidget(self.parameter_controls)
            else:
                home.insertWidget(0, self.parameter_controls)


    def _count_card(self, title: str) -> tuple[QFrame, QLabel]:
        card = QFrame(objectName="CountCard")
        row = QHBoxLayout(card)
        row.setContentsMargins(14, 12, 14, 12)
        row.addWidget(label(title, "secondary"))
        row.addStretch(1)
        count = label("0", "countDanger")
        row.addWidget(count)
        return card, count

    @staticmethod
    def _action_group() -> tuple[QWidget, QVBoxLayout]:
        """Controls shown only once there is something to act on."""
        group = QWidget()
        column = QVBoxLayout(group)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(14)
        return group, column

    def _build_delete_one_panel(self) -> QWidget:
        c = self.colors
        page = QWidget()
        column = QVBoxLayout(page)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(14)
        column.addWidget(label("Click detections to select them. Click again to deselect.", "secondary", wrap=True))
        self.delete_one_actions, actions = self._action_group()
        card, self.selected_count_label = self._count_card("Selected")
        actions.addWidget(card)
        self.delete_one_button = button("Delete colonies", "danger", icon="trash", colors=c,
                                        icon_color=c.danger_ink, icon_size=16, stroke=2.2)
        actions.addWidget(self.delete_one_button)
        self.clear_selection_button = button("Clear selection (Esc)")
        actions.addWidget(self.clear_selection_button)
        column.addWidget(self.delete_one_actions)
        column.addStretch(1)
        return page

    def _build_delete_region_panel(self) -> QWidget:
        c = self.colors
        page = QWidget()
        column = QVBoxLayout(page)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(14)
        column.addWidget(label("Drag a box around false detections. Every colony whose center falls "
                               "inside is selected.", "secondary", wrap=True))
        self.delete_region_actions, actions = self._action_group()
        card, self.region_count_label = self._count_card("Selected in box")
        actions.addWidget(card)
        self.delete_region_button = button("Delete colonies", "danger", icon="trash", colors=c,
                                           icon_color=c.danger_ink, icon_size=16, stroke=2.2)
        actions.addWidget(self.delete_region_button)
        self.clear_box_button = button("Clear box (Esc)")
        actions.addWidget(self.clear_box_button)
        column.addWidget(self.delete_region_actions)
        column.addStretch(1)
        return page

    def _build_add_one_panel(self) -> QWidget:
        c = self.colors
        page = QWidget()
        column = QVBoxLayout(page)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(14)
        snap = QFrame(objectName="CountCard")
        snap_row = QHBoxLayout(snap)
        snap_row.setContentsMargins(14, 12, 14, 12)
        snap_row.setSpacing(12)
        texts = QVBoxLayout()
        texts.setSpacing(2)
        snap_title = label("Snap to colony edge")
        snap_title.setStyleSheet("font-weight: 600;")
        texts.addWidget(snap_title)
        texts.addWidget(label("Fit circles to the colony inside", "caption", wrap=True))
        snap_row.addLayout(texts, 1)
        self.contour_switch = ToggleSwitch(c, "Snap to colony edge")
        snap_row.addWidget(self.contour_switch)
        column.addWidget(snap)

        column.addWidget(GestureRow("draw_circle", "Drag across a colony, edge to edge, to draw", c))
        self.add_one_actions, actions = self._action_group()
        actions.setSpacing(10)
        for icon_name, text in (("move", "Drag inside a circle to move it"),
                                ("resize", "Drag its edge to resize"),
                                ("mouse_right", "Right-click a circle to remove it")):
            actions.addWidget(GestureRow(icon_name, text, c))
        actions.addSpacing(4)
        self.add_one_button = button("Add colonies", "primary", icon="plus", colors=c,
                                     icon_color=c.accent_ink, icon_size=16, stroke=2.4)
        actions.addWidget(self.add_one_button)
        column.addWidget(self.add_one_actions)
        column.addStretch(1)
        return page

    def _build_canvas_area(self) -> QWidget:
        c = self.colors
        area = QWidget(objectName="CanvasArea")
        area.setMinimumWidth(480)
        layout = QVBoxLayout(area)
        layout.setContentsMargins(0, 0, 0, 0)
        self.canvas = DetectCanvas(self.theme.style.colony, frame_color=c.border)
        layout.addWidget(self.canvas)

        # Floating chips and toolbar, positioned in _place_overlays
        self.mode_chip = QFrame(area, objectName="Chip")
        chip_row = QHBoxLayout(self.mode_chip)
        chip_row.setContentsMargins(12, 0, 14, 0)
        chip_row.setSpacing(8)
        chip_row.addWidget(Dot(c.accent))
        self.mode_chip_label = QLabel()
        chip_row.addWidget(self.mode_chip_label)
        self.mode_chip.setFixedHeight(32)

        self.legend = QFrame(area, objectName="Chip")
        self.legend.setProperty("legend", True)
        legend_row = QHBoxLayout(self.legend)
        legend_row.setContentsMargins(12, 0, 12, 0)
        legend_row.setSpacing(14)
        colony = self.theme.style.colony
        self.legend_items: dict[str, QWidget] = {}
        for key, color, text, dashed in (("detected", colony.detected, "Detected", False),
                                         ("split", colony.split, "Split apart", False),
                                         ("added", colony.manual, "Added", False),
                                         ("pending", colony.candidate, "To add", True),
                                         ("selected", colony.selected, "Selected", False)):
            item = QWidget()
            item_row = QHBoxLayout(item)
            item_row.setContentsMargins(0, 0, 0, 0)
            item_row.setSpacing(6)
            item_row.addWidget(LegendDot(color, dashed))
            legend_text = QLabel(text)
            legend_text.setStyleSheet("font-size: 12px;")
            item_row.addWidget(legend_text)
            legend_row.addWidget(item)
            self.legend_items[key] = item
        self.legend.setFixedHeight(32)

        self.zoom_toolbar = QFrame(area, objectName="Toolbar")
        tools = QHBoxLayout(self.zoom_toolbar)
        tools.setContentsMargins(4, 4, 4, 4)
        tools.setSpacing(2)
        self.zoom_out_button = button(variant="toolbar", icon="minus", colors=c, icon_size=16,
                                      tooltip="Zoom out", fixed=(34, 34))
        self.zoom_label = QLabel("100%")
        self.zoom_label.setFixedWidth(52)
        self.zoom_label.setAlignment(Qt.AlignCenter)
        self.zoom_in_button = button(variant="toolbar", icon="plus", colors=c, icon_size=16,
                                     tooltip="Zoom in", fixed=(34, 34))
        self.fit_button = button(variant="toolbar", icon="fit", colors=c, icon_size=16,
                                 tooltip="Fit plate to view (double-click)", fixed=(34, 34))
        self.pan_button = button(variant="toolbar", icon="hand", colors=c, icon_size=16,
                                 tooltip="Pan (or hold Space and drag)", fixed=(34, 34))
        self.pan_button.setCheckable(True)
        for widget in (self.zoom_out_button, self.zoom_label, self.zoom_in_button):
            tools.addWidget(widget)
        separator = divider(vertical=True, length=20)
        tools.addSpacing(4)
        tools.addWidget(separator)
        tools.addSpacing(4)
        tools.addWidget(self.fit_button)
        tools.addWidget(self.pan_button)

        original_resize = area.resizeEvent

        def resize_and_place(event) -> None:
            original_resize(event)
            self._place_overlays(area)

        area.resizeEvent = resize_and_place
        return area

    def _place_overlays(self, area: QWidget) -> None:
        for widget in (self.mode_chip, self.legend, self.zoom_toolbar):
            widget.adjustSize()
            widget.raise_()
        self.mode_chip.move(16, 16)
        self.legend.move(area.width() - self.legend.width() - 16, 16)
        self.zoom_toolbar.move((area.width() - self.zoom_toolbar.width()) // 2,
                               area.height() - self.zoom_toolbar.height() - 20)

    def _build_right_sidebar(self) -> QFrame:
        c = self.colors
        side = QFrame(objectName="RightSidebar")
        side.setFixedWidth(self.theme.style.layout.sidebar_width)
        column = QVBoxLayout(side)
        column.setContentsMargins(16, 20, 16, 16)
        column.setSpacing(16)

        card = QFrame(objectName="Card")
        card_column = QVBoxLayout(card)
        card_column.setContentsMargins(16, 16, 16, 16)
        card_column.setSpacing(14)
        count_row = QHBoxLayout()
        count_row.setSpacing(8)
        self.count_label = label("0", "bigNumber")
        count_row.addWidget(self.count_label, 0, Qt.AlignBaseline)
        count_row.addWidget(label("colonies", "muted"), 0, Qt.AlignBaseline)
        count_row.addStretch(1)
        card_column.addLayout(count_row)
        pills = QHBoxLayout()
        pills.setSpacing(6)
        self.auto_pill = label("Automatic 0", "pillInfo")
        self.added_pill = label("Added 0", "pillAccent")
        for pill in (self.auto_pill, self.added_pill):
            pill.setFixedHeight(24)
        pills.addWidget(self.auto_pill)
        pills.addWidget(self.added_pill)
        pills.addStretch(1)
        card_column.addLayout(pills)
        card_column.addWidget(divider())
        stats = QGridLayout()
        stats.setHorizontalSpacing(12)
        stats.setVerticalSpacing(12)
        self.stat_values: dict[str, QLabel] = {}
        for index, (key, title) in enumerate((("mean", "Mean radius"), ("median", "Median radius"),
                                              ("range", "Radius range"), ("scale", "Scale"))):
            cell = QVBoxLayout()
            cell.setSpacing(2)
            cell.addWidget(label(title, "caption"))
            value = label("–", "statValue")
            cell.addWidget(value)
            self.stat_values[key] = value
            stats.addLayout(cell, index // 2, index % 2)
        card_column.addLayout(stats)
        card_column.addWidget(divider())
        growth_row = QHBoxLayout()
        growth_text = QVBoxLayout()
        growth_text.setSpacing(2)
        growth_text.addWidget(label("Growth coverage", "caption"))
        self.growth_value = label("–", "statValue")
        self.growth_value.setToolTip("Share of this index's growable area covered by growth, learned from the "
                                     "colonies you marked; colony coverage counts only the marked colonies")
        growth_text.addWidget(self.growth_value)
        growth_row.addLayout(growth_text, 1)
        growth_row.addWidget(label("Show", "caption"))
        self.growth_switch = ToggleSwitch(c, "Show growth on the image")
        self.growth_switch.setToolTip("Tint every pixel found as growth (amber outside the marked colonies)")
        growth_row.addWidget(self.growth_switch)
        card_column.addLayout(growth_row)
        column.addWidget(card)

        header = QHBoxLayout()
        activity_title = label("Activity", "label")
        activity_title.setStyleSheet("font-size: 13px; font-weight: 600;")
        header.addWidget(activity_title)
        header.addStretch(1)
        self.clear_activity_button = button("Clear", "link")
        header.addWidget(self.clear_activity_button)
        column.addLayout(header)
        self.activity = ActivityFeed(c)
        column.addWidget(self.activity, 1)
        return side

    def _build_status_bar(self) -> QFrame:
        c = self.colors
        bar = QFrame(objectName="StatusBar")
        bar.setFixedHeight(self.theme.style.layout.status_bar_height)
        row = QHBoxLayout(bar)
        row.setContentsMargins(16, 0, 16, 0)
        row.setSpacing(18)
        ready = QHBoxLayout()
        ready.setSpacing(6)
        ready.addWidget(Dot(c.accent, 7))
        self.status_text = label("Ready", "status")
        ready.addWidget(self.status_text)
        row.addLayout(ready)
        self.pointer_label = label("", "status")
        self.size_label = label("", "status")
        self.zoom_status_label = label("", "status")
        for widget in (self.pointer_label, self.size_label, self.zoom_status_label):
            row.addWidget(widget)
        row.addStretch(1)
        self.undo_steps_label = label("", "status")
        row.addWidget(self.undo_steps_label)
        self.report_button = button("Report a bug", "link")
        self.report_button.setStyleSheet(f"color: {c.accent_text};")
        row.addWidget(self.report_button)
        return bar

    # =====================================================================
    # view updates the controller calls
    # =====================================================================
    def update_mode_specific_view(self, spec: ModeSpec) -> None:
        changed = spec.key != self._spec.key
        self._spec = spec
        button_for_mode = self.mode_buttons[spec.key]
        if not button_for_mode.isChecked():
            button_for_mode.setChecked(True)
        if changed and any(box.is_open() for box in self.groups.values()):
            self.groups[spec.group].set_open(True)       # the tool's group open, the other closed
        for key, item in self.legend_items.items():
            item.setVisible({"selected": spec.panel in ("delete_one", "delete_region"),
                             "pending": spec.panel == "add_one" or spec.region_parameters}.get(key, True))
        self._refresh_panel_state()

    def set_interaction_state(self, selected: int, box: bool, pending: int, region: bool,
                              candidates: int | None) -> None:
        """What the user has started in the current mode; decides which controls show."""
        self._state = {"selected": selected, "box": box, "pending": pending, "region": region,
                       "candidates": candidates}
        self.set_selection_count(selected)
        self.set_pending_count(pending)
        self.set_region_candidates(candidates)
        self._refresh_panel_state()

    def _refresh_panel_state(self) -> None:
        spec, state = self._spec, self._state
        region_mode = spec.region_parameters
        automatic = spec.group == AUTOMATIC
        shown = not self.left_collapsed
        self._place_settings(region_mode)
        self.settings_moved.setVisible(region_mode and shown)
        self.parameter_page.setVisible(automatic and shown)
        self.panels.setVisible(not automatic and shown)
        current = "region" if region_mode else spec.panel
        for name, page in self.panel_pages.items():
            page.setVisible(name == current)
        self.region_intro.setVisible(region_mode and not state["region"])
        self.parameter_controls.setVisible(not region_mode or state["region"])
        self.region_hint.setVisible(region_mode and state["region"])
        self.region_add_button.setVisible(region_mode and state["region"])
        self.region_clear_button.setVisible(region_mode and state["region"])
        self.delete_one_actions.setVisible(state["selected"] > 0)
        self.delete_region_actions.setVisible(state["box"])
        self.add_one_actions.setVisible(state["pending"] > 0)
        active = {"delete_one": state["selected"] > 0, "delete_region": state["box"],
                  "add_one": state["pending"] > 0}.get(spec.panel, region_mode and state["region"])
        self.mode_chip_label.setText(spec.hint_active if active else spec.hint)
        self._place_overlays(self.canvas.parentWidget())

    # ----- collapsing the side columns -----------------------------------
    def set_left_collapsed(self, collapsed: bool, animate: bool = True) -> None:
        """Collapse the left column to a rail of mode icons, or expand it again."""
        self.left_collapsed = collapsed
        layout = self.theme.style.layout
        target = layout.rail_width if collapsed else layout.sidebar_width + 10
        self.left_toggle.setToolTip("Show the mode panel ([)" if collapsed else "Hide the mode panel ([)")

        def apply_content() -> None:
            margin = 11 if collapsed else 16
            self._left_column.setContentsMargins(margin, 20, margin, 20)
            for box in self.groups.values():
                box.set_rail(collapsed)
            self._refresh_panel_state()
            for mode_button in self.mode_buttons.values():
                mode_button.set_compact(collapsed)

        if collapsed:
            apply_content()                         # hide text first, then narrow
            self._animate_width("left", self.left_sidebar, target, animate)
        else:
            self._animate_width("left", self.left_sidebar, target, animate, apply_content)

    def set_right_collapsed(self, collapsed: bool, animate: bool = True) -> None:
        """Hide or show the summary and activity column."""
        self.right_collapsed = collapsed
        self.right_toggle.setToolTip("Show the summary panel (])" if collapsed else "Hide the summary panel (])")
        if collapsed:
            self._animate_width("right", self.right_sidebar, 0, animate, self.right_sidebar.hide)
        else:
            self.right_sidebar.show()
            self._animate_width("right", self.right_sidebar, self.theme.style.layout.sidebar_width, animate)

    def _animate_width(self, key: str, widget: QWidget, target: int, animate: bool, finished=None) -> None:
        previous = self._animations.pop(key, None)
        if previous is not None:
            previous.stop()
        if not animate:
            widget.setFixedWidth(target)
            if finished:
                finished()
            return
        animation = QVariantAnimation(self)
        animation.setDuration(180)
        animation.setEasingCurve(QEasingCurve.OutCubic)
        animation.setStartValue(widget.width())
        animation.setEndValue(target)
        animation.valueChanged.connect(lambda value: widget.setFixedWidth(int(value)))
        if finished:
            animation.finished.connect(finished)
        self._animations[key] = animation
        animation.start()

    def set_spinner_values(self, params: DetectionParams) -> None:
        polarity, threshold = threshold_from_level(params.level)
        self.set_polarity(polarity)
        self.level_row.set_value(threshold)
        self.sense_row.set_value(params.sense)
        self.rmin_field.set_value(params.rmin)
        self.rmax_field.set_value(params.rmax)
        self.maxpix_field.set_value(params.maxpix)
        self.split_switch.blockSignals(True)
        self.split_switch.setChecked(bool(params.split))
        self.split_switch.blockSignals(False)
        self.split_elongation_row.set_value(params.split_elongation)
        self.split_pinch_row.set_value(params.split_pinch)
        self._show_split_rows(bool(params.split))
        self.split_card.setVisible(params.detection_type != CIRCULAR)       # splitting is for irregular detection
        self.largest_row.setVisible(params.detection_type == CIRCULAR)
        for kind, segment in self.shape_buttons.items():
            segment.blockSignals(True)
            segment.setChecked(kind == params.detection_type)
            segment.blockSignals(False)

    def ask_unadded(self, drawn: int, region: int, before: str) -> str:
        """Outlines drawn or found but not added: 'add', 'discard' or 'back' (before: 'finish' or 'mode')."""
        n = drawn + region
        what = (f"{drawn} drawn circle{'s' if drawn != 1 else ''}" if drawn
                else f"{region} outline{'s' if region != 1 else ''} found in the region")
        verb = "is" if n == 1 else "are"
        pronoun = "it" if n == 1 else "them"
        action = "finish this image" if before == "finish" else "change tools"
        choice = show_message(self, QUESTION, "Outlines not added",
                              f"{what[0].upper() + what[1:]} {verb} not added to the colonies yet, so {pronoun} "
                              f"{'does' if n == 1 else 'do'} not count. Add {pronoun} to the accepted detections "
                              f"before you {action}?",
                              [("back", "Go back"), ("discard", f"Discard {pronoun}"),
                               ("add", f"Add {pronoun} to the colonies")], default="add")
        return choice or "back"

    def ask_all_detected(self, count: int) -> str:
        """'stats', 'project' or 'stay' once every index is detected."""
        noun = "The index is" if count == 1 else f"All {count} indices are"
        choice = show_message(self, SUCCESS, f"{noun} detected",
                              "Every result is saved in the project. Open Stats to analyze the colonies, "
                              "or go back to the project page.",
                              [("stay", "Stay here"), ("project", "Back to project"), ("stats", "Go to Stats")],
                              default="stats")
        return choice or "stay"

    # ----- the window's own wiring: widgets to signals, view-only controls -------
    def _wire_controls(self) -> None:
        for key, mode_button in self.mode_buttons.items():
            mode_button.clicked.connect(lambda _checked=False, k=key: self.modeChosen.emit(k))
        for number, key in enumerate(MODE_ORDER, start=1):
            QShortcut(QKeySequence(str(number)), self, activated=lambda k=key: self.modeChosen.emit(k))
        self.level_row.valueEdited.connect(lambda _v: self.settingEdited.emit("level", self.level_value()))
        for segment in self.polarity_buttons.values():
            segment.clicked.connect(self._polarity_clicked)
        self.sense_row.valueEdited.connect(lambda v: self.settingEdited.emit("sense", v))
        self.rmin_field.valueEdited.connect(lambda v: self.settingEdited.emit("rmin", v))
        self.rmax_field.valueEdited.connect(lambda v: self.settingEdited.emit("rmax", v))
        self.maxpix_field.valueEdited.connect(lambda v: self.settingEdited.emit("maxpix", v))
        self.split_switch.toggled.connect(self._split_toggled)
        self.split_elongation_row.valueEdited.connect(lambda v: self.settingEdited.emit("split_elongation", v))
        self.split_pinch_row.valueEdited.connect(lambda v: self.settingEdited.emit("split_pinch", v))
        for kind, segment in self.shape_buttons.items():
            segment.clicked.connect(lambda _checked=False, k=kind: self.shapeChosen.emit(k))
        self.auto_button.clicked.connect(self.estimateRequested.emit)
        self.start_switch.toggled.connect(
            lambda on: self.newImageStartChosen.emit("estimate" if on else "last image"))
        for widget in (self.delete_one_button, self.delete_region_button):
            widget.clicked.connect(self.deleteRequested.emit)
        for widget in (self.add_one_button, self.region_add_button):
            widget.clicked.connect(self.addRequested.emit)
        for widget in (self.clear_selection_button, self.clear_box_button, self.region_clear_button):
            widget.clicked.connect(self.clearRequested.emit)
        self.contour_switch.toggled.connect(self.contourToggled.emit)
        self.growth_switch.toggled.connect(self.growthToggled.emit)
        self.undo_button.clicked.connect(self.undoRequested.emit)
        self.redo_button.clicked.connect(self.redoRequested.emit)
        self.finish_button.clicked.connect(self.finishRequested.emit)
        self.help_button.clicked.connect(self.helpRequested.emit)
        self.prev_button.clicked.connect(self.previousRequested.emit)
        self.next_button.clicked.connect(self.nextRequested.emit)
        self.image_picker.clicked.connect(self.boardRequested.emit)
        self.index_popup().board.cellClicked.connect(lambda target: self.indexChosen.emit(target[0]))
        self.canvas.pointerMoved.connect(self.pointerMoved.emit)
        for keys, signal in ((QKeySequence.Undo, self.undoRequested), (QKeySequence.Redo, self.redoRequested),
                             (QKeySequence("Ctrl+Y"), self.redoRequested), (QKeySequence("Escape"), self.clearRequested),
                             (QKeySequence(Qt.Key_PageUp), self.previousRequested),
                             (QKeySequence(Qt.Key_PageDown), self.nextRequested)):
            QShortcut(keys, self, activated=signal.emit)
        # view-only controls: the controller never needs to know about these
        self.left_toggle.clicked.connect(lambda: self.set_left_collapsed(not self.left_collapsed))
        self.right_toggle.clicked.connect(lambda: self.set_right_collapsed(not self.right_collapsed))
        QShortcut(QKeySequence("["), self, activated=lambda: self.set_left_collapsed(not self.left_collapsed))
        QShortcut(QKeySequence("]"), self, activated=lambda: self.set_right_collapsed(not self.right_collapsed))
        self.clear_activity_button.clicked.connect(self.activity.clear)
        self.report_button.setEnabled(False)
        self.zoom_in_button.clicked.connect(self.canvas.zoom_in)
        self.zoom_out_button.clicked.connect(self.canvas.zoom_out)
        self.fit_button.clicked.connect(self.canvas.reset_axes_view)
        self.pan_button.toggled.connect(self.canvas.set_pan_mode)
        self.canvas.zoomChanged.connect(lambda scale: self.set_zoom(scale * 100))

    def _show_split_rows(self, shown: bool) -> None:
        self.split_elongation_row.setVisible(shown)
        self.split_pinch_row.setVisible(shown)

    def _split_toggled(self, on: bool) -> None:
        self._show_split_rows(on)
        self.settingEdited.emit("split", bool(on))

    def _polarity_clicked(self) -> None:
        """Colonies darker or lighter than the agar: keeps the threshold shown, flips the stored level."""
        self.set_polarity(self.polarity())
        self.settingEdited.emit("level", self.level_value())

    # ----- what the controller reads and sets -------------------------------------
    def settings(self) -> dict:
        """The detection settings as the controls show them."""
        return {"level": self.level_value(), "sense": self.sense_row.value(), "rmin": self.rmin_field.value(),
                "rmax": self.rmax_field.value(), "maxpix": self.maxpix_field.value(),
                "split": self.split_switch.isChecked(), "split_elongation": self.split_elongation_row.value(),
                "split_pinch": self.split_pinch_row.value(),
                "detection_type": CIRCULAR if self.shape_buttons[CIRCULAR].isChecked() else IRREGULAR}

    def growth_shown(self) -> bool:
        return self.growth_switch.isChecked()

    def set_growth_shown(self, shown: bool) -> None:
        self.growth_switch.setChecked(shown)

    def set_navigation(self, enabled: bool, can_step: bool) -> None:
        """Index board and previous / next: enabled at all, and whether there is another index to step to."""
        self.image_picker.setEnabled(enabled)
        self.prev_button.setEnabled(enabled and can_step)
        self.next_button.setEnabled(enabled and can_step)

    def set_tool(self, tool) -> None:
        """The interaction tool the canvas forwards mouse events to (None: no tool)."""
        self.canvas.tool = tool

    def tool_surface(self):
        """What interaction tools draw previews on and read coordinates from."""
        return self.canvas

    def show_image(self, image) -> None:
        self.canvas.set_image(image)
        rows, cols = image.shape[:2]
        self.set_image_size(cols, rows)

    def draw_colonies(self, colonies, **state) -> None:
        self.canvas.render_colonies(colonies, **state)

    def board_open(self) -> bool:
        return self.index_popup().isVisible()

    def set_board(self, summary: str, view_rows, page_rows, board, note: str) -> None:
        self.index_popup().set_content(summary, view_rows, page_rows, board, note)

    def hide_board(self) -> None:
        self.index_popup().hide()

    def set_close_guard(self, guard) -> None:
        """guard() -> True when the window may close (asks about unsaved edits)."""
        self.close_guard = guard

    def report(self, title: str, text: str, kind: str = ERROR) -> None:
        """A message with the sound of its kind (see gui.dialogs): ERROR, WARNING, INFO or SUCCESS."""
        notify(self, kind, title, text)

    def set_polarity(self, polarity: str) -> None:
        for key, segment in self.polarity_buttons.items():
            segment.blockSignals(True)
            segment.setChecked(key == polarity)
            segment.blockSignals(False)
        self.level_row.set_caption(THRESHOLD_CAPTIONS[polarity])

    def polarity(self) -> str:
        return LIGHT if self.polarity_buttons[LIGHT].isChecked() else DARK

    def level_value(self) -> float:
        """The stored brightness level from the colony color and the threshold shown."""
        return level_from_threshold(self.polarity(), self.level_row.value())

    def set_summary(self, summary: dict) -> None:
        self.count_label.setText(str(summary["total"]))
        self.auto_pill.setText(f"Automatic {summary['automatic']}")
        self.added_pill.setText(f"Added {summary['added']}")
        unit = summary.get("unit", "µm")
        digits = ",.0f" if unit == "µm" else ",.1f"
        if summary["mean_um"] is None:
            for key in ("mean", "median", "range"):
                self.stat_values[key].setText("–")
        else:
            self.stat_values["mean"].setText(f"{summary['mean_um']:{digits}} {unit}")
            self.stat_values["median"].setText(f"{summary['median_um']:{digits}} {unit}")
            self.stat_values["range"].setText(f"{summary['min_um']:{digits}}–{summary['max_um']:{digits}} {unit}")
        self.stat_values["scale"].setText(f"{summary['um_per_px']:.1f} µm/px" if summary["um_per_px"]
                                          else "No scale (pixels)")

    def set_growth(self, metrics: dict | None) -> None:
        """Growth and colony coverage of the current colonies, or None when not measured yet."""
        if metrics is None or metrics.get("growth_coverage") is None:
            self.growth_value.setText("–")
            return
        self.growth_value.setText(f"{metrics['growth_coverage']:.1%} · colonies {metrics['colony_coverage']:.1%}")

    def show_growth(self, growth, colonies) -> None:
        """Tint growth on the image (None removes the tint)."""
        if growth is None:
            self.canvas.set_overlay(None)
            return
        import numpy as np
        from PySide6.QtGui import QColor
        rgba = np.zeros(growth.shape + (4,), dtype=np.uint8)
        for mask, name, alpha in ((growth & ~colonies, self.theme.style.colony.growth, 150),
                                  (colonies & growth, self.theme.style.colony.detected, 70)):
            color = QColor(name)
            rgba[mask] = (color.red(), color.green(), color.blue(), alpha)
        self.canvas.set_overlay(rgba)

    def set_selection_count(self, count: int) -> None:
        noun = "colony" if count == 1 else "colonies"
        for count_label, delete_button in ((self.selected_count_label, self.delete_one_button),
                                           (self.region_count_label, self.delete_region_button)):
            count_label.setText(str(count))
            delete_button.setText(f"Delete {count} {noun}" if count else "Delete colonies")
            delete_button.setEnabled(count > 0)
        self.clear_selection_button.setEnabled(count > 0)

    def set_pending_count(self, count: int) -> None:
        noun = "colony" if count == 1 else "colonies"
        self.add_one_button.setText(f"Add {count} {noun}" if count else "Add colonies")
        self.add_one_button.setEnabled(count > 0)

    def set_region_candidates(self, count: int | None) -> None:
        if count is None:
            self.region_add_button.setText("Add detected colonies")
            self.region_add_button.setEnabled(False)
        else:
            noun = "colony" if count == 1 else "colonies"
            self.region_add_button.setText(f"Add {count} {noun}")
            self.region_add_button.setEnabled(count > 0)

    def set_history(self, can_undo: bool, can_redo: bool, undo_steps: int) -> None:
        self.undo_button.setEnabled(can_undo)
        self.redo_button.setEnabled(can_redo)
        self.undo_steps_label.setText(f"{undo_steps} undo step{'s' if undo_steps != 1 else ''}")

    def add_activity(self, kind: str, title: str, detail: str = "") -> None:
        self.activity.add_entry(kind, title, detail)

    def set_new_image_start(self, mode: str) -> None:
        """Show how new images choose their starting settings ('estimate' or 'last image')."""
        self.start_switch.blockSignals(True)
        self.start_switch.setChecked(mode == "estimate")
        self.start_switch.blockSignals(False)
        start = ("settings estimated from that image" if mode == "estimate"
                 else "the settings of the last image you finished")
        self.detect_hint.text.setText("Each change reruns detection on the whole image. Undo restores the "
                                      f"previous result. A new image starts from {start}.")

    def show_status(self, text: str, timeout_ms: int = 4000) -> None:
        self.status_text.setText(text)
        self._status_timer.start(timeout_ms)

    def set_image_size(self, cols: int, rows: int) -> None:
        self.size_label.setText(f"{cols} × {rows} px")

    def set_pointer(self, x: float, y: float, inside: bool) -> None:
        # 1-based pixel numbers, as in MATLAB and in image viewers
        self.pointer_label.setText(f"x {round(x) + 1} · y {round(y) + 1}" if inside else "")

    def set_zoom(self, percent: float) -> None:
        text = f"{percent:.0f}%"
        self.zoom_label.setText(text)
        self.zoom_status_label.setText(f"Zoom {text}")

    def set_image_label(self, nominal_display: str, ordinal_display: str, position: str) -> None:
        """Name of the open index in the top bar; position like '3 of 96'."""
        self.nominal_label.setText(nominal_display)
        self.ordinal_chip.setText(ordinal_display)
        self.ordinal_chip.setVisible(bool(ordinal_display))
        self.image_picker.setMinimumWidth(self.nominal_label.sizeHint().width()
                                          + self.ordinal_chip.sizeHint().width() + 90)
        self.image_picker.setAccessibleName(f"Image {position}: {nominal_display}, {ordinal_display}")
        self.image_picker.setToolTip(f"Index {position}. Click to choose another index.")

    def index_popup(self) -> IndexPopup:
        if getattr(self, "_index_popup", None) is None:
            self._index_popup = IndexPopup(self.colors, self)
        return self._index_popup

    def show_index_popup(self) -> None:
        popup = self.index_popup()
        below = self.image_picker.mapToGlobal(self.image_picker.rect().bottomLeft())
        center = below.x() + self.image_picker.width() // 2 - popup.width() // 2
        popup.move(max(0, center), below.y() + 6)
        popup.show()

    def ask_save_before_leaving(self, name: str) -> str:
        """'save', 'discard' or 'cancel' for an index with edits that are not saved."""
        choice = show_message(self, QUESTION, "Save this image?",
                              f"{name} has changes that are not saved to the project.",
                              [("cancel", "Cancel"), ("discard", "Discard changes"), ("save", "Save")], default="save")
        return choice or "cancel"

    def closeEvent(self, event) -> None:
        guard = getattr(self, "close_guard", None)
        if guard is not None and not guard():
            event.ignore()
            return
        super().closeEvent(event)

    def fit_to_screen(self) -> None:
        """Open at the design size when it fits, otherwise fill the screen's usable area."""
        available = self.screen().availableGeometry()
        width, height = self.theme.style.layout.window_size
        frame_margin = 40                        # title bar and borders drawn by the system
        if width <= available.width() and height + frame_margin <= available.height():
            self.resize(width, height)
            self.move(available.center() - self.rect().center())
        else:
            self.setGeometry(available.adjusted(0, frame_margin, 0, 0))
            self.showMaximized()

    def sizeHint(self) -> QSize:
        return QSize(*self.theme.style.layout.window_size)
