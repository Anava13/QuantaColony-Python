"""Shared pieces of the light screens (home page, project page, Stats): header bar,
segmented control, labels and buttons styled by build_light_stylesheet."""

from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QFontMetricsF, QPainter, QPainterPath, QPixmap
from PySide6.QtWidgets import (QComboBox, QFrame, QGridLayout, QHBoxLayout, QLabel, QPushButton, QSpinBox, QVBoxLayout,
                               QWidget)

from ..theme.icons import logo_pixmap
from ..theme.tokens import get_quanta_colony_style

L = get_quanta_colony_style().light


def light_label(text: str = "", role: str | None = None, wrap: bool = False) -> QLabel:
    widget = QLabel(text)
    if role:
        widget.setProperty("role", role)
    widget.setWordWrap(wrap)
    return widget


def light_button(text: str, variant: str | None = None, tooltip: str = "") -> QPushButton:
    widget = QPushButton(text)
    if variant:
        widget.setProperty("variant", variant)
    widget.setCursor(Qt.PointingHandCursor)
    if tooltip:
        widget.setToolTip(tooltip)
    return widget


class LightSpinBox(QSpinBox):
    """Whole-number box: type a value, or step it with the arrows or the arrow keys.

    A typed value is sent once, on Enter or when the box loses focus (no signal per keystroke). The mouse
    wheel changes the value only while the box has focus, so scrolling a page over it leaves it alone."""

    def __init__(self, value: int, minimum: int, maximum: int, accessible_name: str, width: int = 76):
        super().__init__()
        self.setRange(minimum, maximum)
        self.setValue(value)
        self.setKeyboardTracking(False)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setAccessibleName(accessible_name)
        self.setFixedWidth(width)

    def wheelEvent(self, event) -> None:  # noqa: N802 (Qt naming)
        if self.hasFocus():
            super().wheelEvent(event)
        else:
            event.ignore()                       # the page scrolls instead


class LightComboBox(QComboBox):
    """Combo box that changes with the mouse wheel only while it has focus (scrolling a page over it
    leaves its value alone)."""

    def __init__(self):
        super().__init__()
        self.setFocusPolicy(Qt.StrongFocus)

    def wheelEvent(self, event) -> None:  # noqa: N802 (Qt naming)
        if self.hasFocus():
            super().wheelEvent(event)
        else:
            event.ignore()


def set_state(widget: QWidget, state: str) -> None:
    """Restyle a label by its state property ('done', 'warn', 'idle', ...)."""
    widget.setProperty("state", state)
    widget.style().unpolish(widget)
    widget.style().polish(widget)


def wordmark(theme, text: str = "QuantaColony", size: int = 16) -> QPixmap:
    font = QFont(theme.brand_family)
    font.setPixelSize(size)
    font.setVariableAxis(QFont.Tag("wght"), 800)
    metrics = QFontMetricsF(font)
    pixmap = QPixmap(int((metrics.horizontalAdvance(text) + 2) * 2), int((metrics.height() + 2) * 2))
    pixmap.fill(Qt.transparent)
    pixmap.setDevicePixelRatio(2.0)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.TextAntialiasing)
    painter.setFont(font)
    painter.setPen(QColor(theme.style.colors.accent))
    painter.drawText(QPointF(1, metrics.ascent() + 1), text)
    painter.end()
    return pixmap


def light_header(theme, crumbs: list[str], back=None) -> tuple[QFrame, QHBoxLayout]:
    """Dark top bar: (a back button,) logo, wordmark, then the location ('Projects', a project name,
    a module). Returns the bar and the layout the caller adds right-side buttons to. Its height and
    left margin match the modules' top bars, so a back button sits at the same place everywhere."""
    from .banner import BANNER_HEIGHT, BANNER_MARGIN
    bar = QFrame(objectName="LightHeader")
    bar.setFixedHeight(BANNER_HEIGHT)
    row = QHBoxLayout(bar)
    row.setContentsMargins(BANNER_MARGIN, 0, 20, 0)
    row.setSpacing(10)
    if back is not None:
        row.addWidget(back)
        row.addSpacing(6)
    logo = QLabel()
    logo.setPixmap(logo_pixmap(26))
    row.addWidget(logo)
    mark = QLabel()
    mark.setPixmap(wordmark(theme))
    row.addWidget(mark)
    for i, crumb in enumerate(crumbs):
        row.addWidget(light_label("/", "headerMuted"))
        row.addWidget(light_label(crumb, "header" if i == len(crumbs) - 1 else "headerMuted"))
    row.addStretch(1)
    return bar, row


class LightSegmented(QFrame):
    """Joined buttons on the light palette; the pressed one is filled with the accent."""

    def __init__(self, options: list[tuple], height: int = 28, enabled: bool = True, tooltip: str = ""):
        """options: (text, pressed, handler) or (text, pressed, handler, enabled)."""
        super().__init__()
        self.setObjectName("LightSegmented")
        row = QHBoxLayout(self)
        row.setContentsMargins(1, 1, 1, 1)
        row.setSpacing(0)
        self.setFixedHeight(height + 2)
        self.buttons = []
        for option in options:
            text, on, handler = option[:3]
            widget = QPushButton(text)
            widget.setCheckable(True)
            widget.setChecked(on)
            widget.setEnabled(enabled and (option[3] if len(option) > 3 else True))
            widget.setCursor(Qt.PointingHandCursor)
            widget.setFixedHeight(height)
            widget.setMinimumWidth(widget.fontMetrics().horizontalAdvance(text) + 26)
            widget.setStyleSheet(
                "QPushButton { border: none; border-radius: 3px; padding: 0 10px; min-height: 0;"
                f" font-size: 13px; font-weight: 500; background: transparent; color: {L.text_secondary}; }}"
                f" QPushButton:checked {{ background: {L.accent}; color: {L.accent_ink}; font-weight: 600; }}"
                f" QPushButton:hover:!checked {{ background: {L.button}; }}"
                f" QPushButton:disabled {{ color: {L.disabled_text}; }}"
                f" QPushButton:checked:disabled {{ background: {L.disabled_fill}; }}")
            if tooltip:
                widget.setToolTip(f"{tooltip}: {text}")
            widget.clicked.connect(lambda _c=False, h=handler: h())
            row.addWidget(widget)
            self.buttons.append(widget)
        self.setStyleSheet(f"QFrame#LightSegmented {{ background: {L.surface}; border: 1px solid {L.field_border};"
                           " border-radius: 4px; }")


class LevelChips(QWidget):
    """The levels of one variable as chips that each turn on or off, wrapping after PER_LINE.
    A chip given a color shows a swatch in front of its name; clicking the swatch calls its handler."""

    PER_LINE = 6

    def __init__(self, options: list[tuple], tooltip: str = "", off_color: str | None = None):
        """options: (text, shown, toggle handler, color or None, color handler or None[, enabled]).
        off_color: text color of a chip that is off (default: dimmed, for a level switched off)."""
        super().__init__()
        grid = QGridLayout(self)
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(4)
        grid.setVerticalSpacing(4)
        self.toggles, self.swatches = [], []
        for i, (text, shown, toggle, color, pick, *more) in enumerate(options):
            enabled = more[0] if more else True
            chip = QFrame(objectName="LevelChip")
            chip.setStyleSheet(f"QFrame#LevelChip {{ background: {L.surface}; border: 1px solid {L.field_border};"
                               " border-radius: 4px; }")
            row = QHBoxLayout(chip)
            row.setContentsMargins(4 if color else 1, 1, 1, 1)
            row.setSpacing(4)
            if color:
                swatch = QPushButton()
                swatch.setFixedSize(16, 16)
                swatch.setCursor(Qt.PointingHandCursor)
                swatch.setToolTip(f"Color of {text} ({color}): click to change")
                swatch.setStyleSheet(f"QPushButton {{ background: {color}; border: 1px solid {L.field_border};"
                                     " border-radius: 3px; min-height: 0; padding: 0; }")
                swatch.clicked.connect(lambda _c=False, h=pick: h())
                row.addWidget(swatch)
                self.swatches.append(swatch)
            button = QPushButton(text)
            button.setCheckable(True)
            button.setChecked(shown)
            button.setEnabled(enabled)
            button.setCursor(Qt.PointingHandCursor)
            button.setFixedHeight(24)
            button.setMinimumWidth(button.fontMetrics().horizontalAdvance(text) + 22)
            button.setToolTip(f"{tooltip}: {'hide' if shown else 'show'} {text}" if tooltip else text)
            button.setStyleSheet(
                "QPushButton { border: none; border-radius: 3px; padding: 0 8px; min-height: 0;"
                f" font-size: 13px; font-weight: 500; background: transparent; color: {off_color or L.disabled_text}; }}"
                f" QPushButton:checked {{ background: {L.accent}; color: {L.accent_ink}; font-weight: 600; }}"
                f" QPushButton:hover:!checked {{ background: {L.button}; color: {L.text_secondary}; }}"
                f" QPushButton:disabled {{ color: {L.disabled_text}; text-decoration: line-through; }}")
            button.clicked.connect(lambda _c=False, h=toggle: h())
            row.addWidget(button)
            self.toggles.append(button)
            grid.addWidget(chip, i // self.PER_LINE, i % self.PER_LINE)
        grid.setColumnStretch(min(len(options), self.PER_LINE), 1)


class RangeSlider(QWidget):
    """Two handles on one track, for a range of counts on a log scale (1 to `top`). The high handle
    at the right end of the track means no upper limit. rangeChosen(low, high) fires when a handle is
    released; high is 0 for no limit (Qt signals carry no None)."""

    rangeChosen = Signal(int, int)
    HANDLE = 8                                          # handle radius, px

    def __init__(self, top: int = 1000, parent=None):
        super().__init__(parent)
        self.top = max(10, int(top))
        self.low, self.high = 1, None
        self._dragging = None
        self.setFixedHeight(28)
        self.setMinimumWidth(220)
        self.setCursor(Qt.PointingHandCursor)

    def set_range(self, low: int, high: int | None, top: int | None = None) -> None:
        if top is not None:
            self.top = max(10, int(top))
        self.low = max(1, min(int(low), self.top))
        self.high = None if high is None or high >= self.top else max(self.low, int(high))
        self.update()

    def _x(self, value: float) -> float:
        span = self.width() - 2 * self.HANDLE
        return self.HANDLE + span * math.log(max(value, 1)) / math.log(self.top)

    def _value(self, x: float) -> int:
        span = max(1.0, self.width() - 2 * self.HANDLE)
        share = min(max((x - self.HANDLE) / span, 0.0), 1.0)
        return max(1, int(round(math.exp(share * math.log(self.top)))))

    def paintEvent(self, event) -> None:  # noqa: N802 (Qt naming)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        y = self.height() / 2
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor(L.field_border))
        painter.drawRoundedRect(QRectF(self.HANDLE, y - 2, self.width() - 2 * self.HANDLE, 4), 2, 2)
        x0, x1 = self._x(self.low), self._x(self.high if self.high is not None else self.top)
        painter.setBrush(QColor(L.accent))
        painter.drawRoundedRect(QRectF(x0, y - 2, x1 - x0, 4), 2, 2)
        for x in (x0, x1):
            painter.setBrush(QColor(L.surface))
            painter.setPen(QColor(L.link))
            painter.drawEllipse(QPointF(x, y), self.HANDLE - 1, self.HANDLE - 1)

    def mousePressEvent(self, event) -> None:  # noqa: N802
        x = event.position().x()
        x0, x1 = self._x(self.low), self._x(self.high if self.high is not None else self.top)
        self._dragging = "low" if abs(x - x0) <= abs(x - x1) and not (x > x1) else "high"
        self.mouseMoveEvent(event)

    def mouseMoveEvent(self, event) -> None:  # noqa: N802
        if self._dragging is None:
            return
        value = self._value(event.position().x())
        if self._dragging == "low":
            self.low = min(value, self.high if self.high is not None else self.top)
        else:
            self.high = None if value >= self.top else max(value, self.low)
        self.update()

    def mouseReleaseEvent(self, event) -> None:  # noqa: N802
        if self._dragging is not None:
            self._dragging = None
            self.rangeChosen.emit(self.low, self.high or 0)


def clear_layout(layout) -> None:
    while layout.count():
        item = layout.takeAt(0)
        widget = item.widget()
        if widget is not None:
            widget.hide()
            widget.setParent(None)
            widget.deleteLater()
        elif item.layout() is not None:
            clear_layout(item.layout())


# =========================================================================
# progress and summary numbers (home page, project page)
# =========================================================================
def paint_progress(painter: QPainter, rect: QRectF, parts: list[tuple[int, str]], total: int, track: str,
                   radius: float = 3.0) -> None:
    """A horizontal bar: one colored part per (count, color), in order, out of total."""
    painter.save()
    painter.setRenderHint(QPainter.Antialiasing)
    painter.setPen(Qt.NoPen)
    painter.setBrush(QColor(track))
    painter.drawRoundedRect(rect, radius, radius)
    if total > 0:
        painter.setClipRect(rect)
        clip = QPainterPath()
        clip.addRoundedRect(rect, radius, radius)
        painter.setClipPath(clip)
        x = rect.left()
        for count, color in parts:
            if count <= 0:
                continue
            width = rect.width() * min(count, total) / total
            painter.setBrush(QColor(color))
            painter.drawRect(QRectF(x, rect.top(), width, rect.height()))
            x += width
    painter.restore()


class ProgressBar(QWidget):
    """Colored progress parts out of a total, with no text of its own."""

    def __init__(self, track: str, height: int = 8, parent=None):
        super().__init__(parent)
        self.track = track
        self.parts: list[tuple[int, str]] = []
        self.total = 0
        self.setFixedHeight(height)
        self.setMinimumWidth(60)

    def set_parts(self, parts: list[tuple[int, str]], total: int) -> None:
        self.parts, self.total = parts, total
        self.update()

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        paint_progress(painter, QRectF(self.rect()), self.parts, self.total, self.track, self.height() / 2)
        painter.end()


class Tile(QFrame):
    """One summary number with its label under it."""

    def __init__(self, caption: str):
        super().__init__(objectName="Tile")
        column = QVBoxLayout(self)
        column.setContentsMargins(12, 9, 12, 9)
        column.setSpacing(1)
        self.number = light_label("–", "tileNumber")
        self.caption = light_label(caption, "tileLabel", wrap=True)
        column.addWidget(self.number)
        column.addWidget(self.caption)

    def set(self, number: str, caption: str | None = None) -> None:
        self.number.setText(number)
        if caption is not None:
            self.caption.setText(caption)


def tile_grid(captions: list[str], columns: int) -> tuple[QGridLayout, list[Tile]]:
    grid = QGridLayout()
    grid.setHorizontalSpacing(8)
    grid.setVerticalSpacing(8)
    tiles = [Tile(caption) for caption in captions]
    for i, tile in enumerate(tiles):
        grid.addWidget(tile, i // columns, i % columns)
    for c in range(columns):
        grid.setColumnStretch(c, 1)
    return grid, tiles


def panel_head(title: str) -> tuple[QFrame, QHBoxLayout]:
    """Title strip at the top of a white panel; returns the strip and its row for extra widgets."""
    head = QFrame(objectName="PanelHead")
    row = QHBoxLayout(head)
    row.setContentsMargins(20, 10, 14, 10)
    row.addWidget(light_label(title, "section"))
    row.addStretch(1)
    return head, row
