"""Annotations editor: every photo's annotation values in one table, with declaration controls.

Opened from the project page. Rows are photos (every plate of a photo inherits its values;
a value set per plate elsewhere wins and is shown in the Plates column tooltip). Edits are
written through the DataManager when OK is clicked; nothing is written on Cancel.
"""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QComboBox, QDialog, QDialogButtonBox, QHBoxLayout, QLabel, QLineEdit, QMessageBox,
                               QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout)

from ..core.new_project import ANNOTATION_KINDS
from ..data import DataManager
from ..data.store.annotations import AnnotationProblem


class AnnotationsDialog(QDialog):
    """Edit annotation declarations and per-photo values for the open project."""

    def __init__(self, manager: DataManager, parent=None):
        super().__init__(parent)
        self.manager = manager
        self.setWindowTitle("Annotations")
        self.resize(760, 520)
        self._new_specs: list = []                      # (name, kind, unit, choices) declared this session
        column = QVBoxLayout(self)
        column.addWidget(QLabel("Annotations travel with the plates without entering the design. Values are "
                                "entered per photo; every plate of the photo inherits them."))
        self.table = QTableWidget()
        column.addWidget(self.table, 1)

        add_row = QHBoxLayout()
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("New annotation name")
        self.kind_box = QComboBox()
        for value, label in ANNOTATION_KINDS:
            self.kind_box.addItem(label, value)
        self.detail_edit = QLineEdit()
        self.detail_edit.setPlaceholderText("Unit (optional)")
        self.kind_box.currentIndexChanged.connect(self._detail_placeholder)
        add_button = QPushButton("Add annotation")
        add_button.clicked.connect(self._add_annotation)
        for widget in (self.name_edit, self.kind_box, self.detail_edit, add_button):
            add_row.addWidget(widget)
        add_row.setStretch(0, 2)
        add_row.setStretch(2, 2)
        column.addLayout(add_row)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._save)
        buttons.rejected.connect(self.reject)
        column.addWidget(buttons)
        self._load()

    # ----- loading ---------------------------------------------------------
    def _load(self) -> None:
        self.specs = self.manager.annotation_specs()
        self.photos = self.manager.crop_packet().photos
        values = self.manager.photo_annotations()
        self.table.clear()
        self.table.setRowCount(len(self.photos))
        self.table.setColumnCount(len(self.specs))
        headers = []
        for spec in self.specs:
            unit = f" ({spec['unit']})" if spec["unit"] else ""
            headers.append(f"{spec['display_name']}{unit}")
        self.table.setHorizontalHeaderLabels(headers)
        self.table.setVerticalHeaderLabels([p.file_name for p in self.photos])
        if self.specs:
            self.table.horizontalHeader().setStretchLastSection(True)
        for row, photo in enumerate(self.photos):
            for column, spec in enumerate(self.specs):
                text = values.get(photo.photo_id, {}).get(spec["name"], "")
                item = QTableWidgetItem(str(text))
                if spec["kind"] == "choice":
                    item.setToolTip("One of: " + ", ".join(spec["choices"]))
                self.table.setItem(row, column, item)

    def _detail_placeholder(self) -> None:
        kind = self.kind_box.currentData()
        self.detail_edit.setPlaceholderText(
            {"number": "Unit (optional)", "choice": "Choices, comma separated", "text": ""}.get(kind, ""))

    # ----- declaring -------------------------------------------------------
    def _add_annotation(self) -> None:
        from ..data.packets import AnnotationSpec
        name = self.name_edit.text().strip()
        kind = self.kind_box.currentData()
        detail = self.detail_edit.text().strip()
        if not name:
            QMessageBox.warning(self, "Annotations", "The annotation needs a name.")
            return
        key = "".join(c if c.isalnum() else "_" for c in name.lower()).strip("_") or "annotation"
        taken = {s["name"] for s in self.specs}
        base = key
        n = 2
        while key in taken:
            key, n = f"{base}_{n}", n + 1
        choices = tuple(c.strip() for c in detail.split(",") if c.strip()) if kind == "choice" else ()
        if kind == "choice" and len(choices) < 2:
            QMessageBox.warning(self, "Annotations", "A choice annotation needs at least two choices, "
                                "comma separated.")
            return
        try:
            self.manager.add_annotation(AnnotationSpec(key, kind, name, detail if kind == "number" else "",
                                                       choices))
        except AnnotationProblem as error:
            QMessageBox.warning(self, "Annotations", str(error))
            return
        self.name_edit.clear()
        self.detail_edit.clear()
        self._keep_edits_and_reload()

    def _keep_edits_and_reload(self) -> None:
        kept = self._table_values()
        self._load()
        for row, photo in enumerate(self.photos):
            for column, spec in enumerate(self.specs):
                if (photo.photo_id, spec["name"]) in kept:
                    self.table.item(row, column).setText(kept[(photo.photo_id, spec["name"])])

    def _table_values(self) -> dict:
        values = {}
        for row, photo in enumerate(self.photos):
            for column, spec in enumerate(self.specs):
                item = self.table.item(row, column)
                if item is not None:
                    values[(photo.photo_id, spec["name"])] = item.text().strip()
        return values

    # ----- saving ----------------------------------------------------------
    def _save(self) -> None:
        values = self._table_values()
        per_photo: dict[int, dict] = {}
        for (photo_id, name), text in values.items():
            per_photo.setdefault(photo_id, {})[name] = text
        try:
            for photo_id, entries in per_photo.items():
                self.manager.set_photo_annotations(photo_id, entries)
        except AnnotationProblem as error:
            QMessageBox.warning(self, "Annotations", str(error))
            return
        self.accept()
