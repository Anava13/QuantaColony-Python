"""Print-ready pages for exported PDFs (Qt-free): the dissertation page format.

US Letter with margins of 1.5 in on the top and left and 1 in on the bottom and right, so the text block is
6.0 x 8.5 in. A figure no wider than 6.0 in sits upright in the text block. A wider figure (up to 8.5 x 6.0
in) is a landscape page: the sheet is turned so the top of the figure faces the binding edge, which places
the margins at 1.5 in on the top and right of the landscape sheet and 1 in on the bottom and left.

Every figure is drawn at its printed size in Latin Modern Roman with every font embedded, so the sizes in
the file are the printed sizes. A footer band at the bottom of the text block names the project, the page
and the date. check_page reports labels below 7 pt, text past the figure's edges and text over other text.
"""

from __future__ import annotations

import io
from dataclasses import dataclass, field, replace

import numpy as np

from ..dissertation import style as S

LETTER = (8.5, 11.0)
LEFT, TOP, RIGHT, BOTTOM = 1.5, 1.5, 1.0, 1.0                  # portrait margins (in)
BLOCK_PORTRAIT = (6.0, 8.5)
BLOCK_LANDSCAPE = (8.5, 6.0)
FOOTER_H = 0.38                                                  # footer band inside the text block (in)
FIGURE_LANDSCAPE = (BLOCK_LANDSCAPE[0], BLOCK_LANDSCAPE[1] - FOOTER_H)
PRINT_FONT = 9.5                                                 # style font size: the smallest derived size is 7 pt


@dataclass
class PageCheck:
    title: str
    width_in: float
    height_in: float
    min_pt: float
    outside: list = field(default_factory=list)
    overlaps: list = field(default_factory=list)

    @property
    def fits(self) -> bool:
        """Inside the text block: upright up to 6.0 x 8.5 in, turned up to 8.5 x 6.0 in (less the footer)."""
        if self.width_in <= BLOCK_PORTRAIT[0] + 1e-6:
            return self.height_in <= BLOCK_PORTRAIT[1] - FOOTER_H + 1e-6
        return self.width_in <= BLOCK_LANDSCAPE[0] + 1e-6 and self.height_in <= BLOCK_LANDSCAPE[1] - FOOTER_H + 1e-6

    @property
    def passed(self) -> bool:
        return self.fits and self.min_pt >= S.MIN_PT - 1e-6 and not self.outside and not self.overlaps


def print_style(style):
    """MODEL: the plot style for a printed page (terminal)."""
    return replace(style, font_size=PRINT_FONT, font_family=S.FAMILY, print_mode=True)


def house():
    """The dissertation rc settings (Latin Modern Roman, embedded TrueType fonts, print sizes)."""
    return S.house()


def italicize(figure) -> None:
    """VIEW: gene and allele names in italics in every text of the figure (terminal).

    Fixed tick labels are rewritten through their formatter; every other text in place."""
    from matplotlib.text import Text
    from matplotlib.ticker import FixedFormatter
    for ax in figure.axes:
        for axis in (ax.xaxis, ax.yaxis):
            formatter = axis.get_major_formatter()
            if isinstance(formatter, FixedFormatter):
                formatter.seq = [S.label(str(t)) if "$" not in str(t) else str(t) for t in formatter.seq]
    for text in figure.findobj(Text):
        value = text.get_text()
        if value and "$" not in value and "\n" not in value:
            labelled = S.label(value)
            if labelled != value:
                text.set_text(labelled)
                text.set_parse_math(True)
        elif value and "$" not in value:
            labelled = "\n".join(S.label(line) for line in value.split("\n"))
            if labelled != value:
                text.set_text(labelled)
                text.set_parse_math(True)


def raise_small_text(figure, minimum: float = S.MIN_PT) -> None:
    """VIEW: every text drawn smaller than the minimum is set to the minimum (terminal)."""
    from matplotlib.text import Text
    for text in figure.findobj(Text):
        if text.get_fontsize() < minimum:
            text.set_fontsize(minimum)
    for ax in figure.axes:
        for axis in (ax.xaxis, ax.yaxis):
            for tick in axis.get_major_ticks() + axis.get_minor_ticks():
                for label in (tick.label1, tick.label2):
                    if label.get_fontsize() < minimum:
                        label.set_fontsize(minimum)


def check_page(figure, title: str) -> PageCheck:
    """MODEL: the page's size, smallest label, text past its edges and text over other text (terminal)."""
    report = S.check(figure)
    return PageCheck(title, figure.get_figwidth(), figure.get_figheight(), report["min_pt"], report["outside"],
                     report["overlaps"])


def footer_figure(width: float, text: str):
    """VIEW: the footer band: one figure FOOTER_H tall holding the footer text (terminal)."""
    from matplotlib.figure import Figure
    figure = Figure(figsize=(width, FOOTER_H), facecolor="white")
    figure.text(0.0, 0.1, text, ha="left", va="bottom", fontsize=S.MIN_PT, color="#555555", wrap=True)
    return figure


def to_pdf_page(figure):
    """MODEL: a figure as a one-page PDF (pypdf page), its size the figure's (terminal)."""
    from pypdf import PdfReader
    buffer = io.BytesIO()
    figure.savefig(buffer, format="pdf", facecolor="white")
    buffer.seek(0)
    return PdfReader(buffer).pages[0]


def landscape(figure) -> bool:
    return figure.get_figwidth() > BLOCK_PORTRAIT[0] + 1e-6


def compose(figure_page, footer_page, wide: bool):
    """MODEL: one Letter page with the figure and its footer inside the text block (terminal).

    Portrait: the block starts 1.5 in from the left; the footer sits on the 1 in bottom margin line and the
    figure above it, top-aligned at 1.5 in. Landscape: the sheet is 11 x 8.5 in, the block 1 in from the left
    and bottom."""
    from pypdf import PageObject, Transformation
    point = 72.0
    if wide:
        sheet_w, sheet_h, x0, y0, block_h = LETTER[1], LETTER[0], 1.0, BOTTOM, BLOCK_LANDSCAPE[1]
    else:
        sheet_w, sheet_h, x0, y0, block_h = LETTER[0], LETTER[1], LEFT, BOTTOM, BLOCK_PORTRAIT[1]
    page = PageObject.create_blank_page(width=sheet_w * point, height=sheet_h * point)
    figure_h = float(figure_page.mediabox.height) / point
    top = y0 + block_h                                           # the block's top edge
    page.merge_transformed_page(figure_page, Transformation().translate(x0 * point, (top - figure_h) * point))
    page.merge_transformed_page(footer_page, Transformation().translate(x0 * point, y0 * point))
    return page


def write_pages(pages, path) -> None:
    """VIEW: the pages as one PDF with no passwords or encryption (terminal)."""
    from pypdf import PdfWriter
    writer = PdfWriter()
    for page in pages:
        writer.add_page(page)
    with open(path, "wb") as handle:
        writer.write(handle)


# ----- fitting a drawn figure to its page ------------------------------------------------------------
def _drawn_texts(figure, renderer):
    """(text, display box) of every text that is drawn: visible, non-empty, and for tick labels inside the view."""
    from matplotlib.text import Text
    hidden = set()
    for ax in figure.axes:
        for axis in (ax.xaxis, ax.yaxis):
            drawn = {id(t) for t in axis._update_ticks()} if ax.axison and ax.get_visible() else set()
            for tick in axis.get_major_ticks() + axis.get_minor_ticks():
                if id(tick) not in drawn:
                    hidden.update((id(tick.label1), id(tick.label2)))
    out = []
    for text in figure.findobj(Text):
        if id(text) in hidden or not text.get_visible() or not text.get_text().strip():
            continue
        artist_axes = text.axes
        if artist_axes is not None and not artist_axes.get_visible():
            continue
        out.append((text, text.get_window_extent(renderer)))
    return out


def _tick_labels(figure) -> set:
    ids = set()
    for ax in figure.axes:
        for axis in (ax.xaxis, ax.yaxis):
            for tick in axis.get_major_ticks() + axis.get_minor_ticks():
                ids.update((id(tick.label1), id(tick.label2)))
    return ids


def _pull_inside(figure, texts, pad: float = 2.0) -> bool:
    """VIEW: rescale every axes so text past the figure's edges comes inside; figure-level text that
    overflows moves inward (terminal). Returns True when anything moved."""
    width, height = figure.bbox.width, figure.bbox.height
    left = max([0.0] + [pad - box.x0 for _, box in texts])
    right = max([0.0] + [box.x1 - (width - pad) for _, box in texts])
    bottom = max([0.0] + [pad - box.y0 for _, box in texts])
    top = max([0.0] + [box.y1 - (height - pad) for _, box in texts])
    if max(left, right, bottom, top) < 0.5:
        return False
    sx = max(0.3, (width - left - right) / width)
    sy = max(0.3, (height - bottom - top) / height)
    for ax in figure.axes:
        box = ax.get_position()
        ax.set_position([left / width + box.x0 * sx, bottom / height + box.y0 * sy, box.width * sx, box.height * sy])
    for text in figure.texts:                                  # figure-level text keeps its anchor, inside the page
        x, y = text.get_position()
        text.set_position((left / width + x * sx, bottom / height + y * sy))
    for legend in figure.legends:
        anchor = legend.get_bbox_to_anchor()
        if anchor is not None:
            box = anchor.transformed(figure.transFigure.inverted())
            legend.set_bbox_to_anchor((left / width + box.x0 * sx, bottom / height + box.y0 * sy,
                                       box.width * sx, box.height * sy), transform=figure.transFigure)
    return True


def _wrap(text, width_px: float, renderer) -> bool:
    """VIEW: break a text at spaces until it is no wider than width_px (terminal). True when it changed."""
    import re
    value = text.get_text()
    if "$" in value and value.count("$") % 2:
        return False
    words = re.split(r"(?<!\$) (?![^$]*\$(?:[^$]*\$[^$]*\$)*[^$]*$)", value.replace("\n", " "))
    if len(words) < 2:
        return False
    best = value
    for lines in range(2, len(words) + 1):                    # fewest lines that fit
        per = int(np.ceil(len(words) / lines))
        candidate = "\n".join(" ".join(words[k:k + per]) for k in range(0, len(words), per))
        text.set_text(candidate)
        if text.get_window_extent(renderer).width <= width_px:
            return candidate != value
        best = candidate
    text.set_text(best)
    return best != value


def _stagger(text, box_a, box_b, figure) -> None:
    """VIEW: move text (box_b) clear of box_a, upward in the upper half of the figure and downward in the
    lower half (terminal)."""
    up = (box_b.y0 + box_b.y1) / 2 >= figure.bbox.height / 2
    shift = (box_a.y1 - box_b.y0 + 2.0) if up else -(box_b.y1 - box_a.y0 + 2.0)
    x, y = text.get_position()
    transform = text.get_transform()
    display = transform.transform((x, y))
    text.set_position(tuple(transform.inverted().transform((display[0], display[1] + shift))))


def _thin_ticks(figure, renderer) -> bool:
    """VIEW: on an axis whose tick labels overlap, keep every second label (repeatedly) (terminal)."""
    changed = False
    for ax in figure.axes:
        if not ax.get_visible():
            continue
        for axis in (ax.xaxis, ax.yaxis):
            ticks = [t for t in axis._update_ticks() if t.label1.get_visible() and t.label1.get_text()]
            boxes = [t.label1.get_window_extent(renderer) for t in ticks]
            clash = any(a.overlaps(b) for a, b in zip(boxes, boxes[1:]))
            if clash and len(ticks) > 2:
                keep = ticks[::2]
                for tick in ticks:
                    if tick not in keep:
                        tick.label1.set_visible(False)
                changed = True
    return changed


def fit_to_page(figure, rounds: int = 8) -> None:
    """VIEW SUB-CONTROLLER: bring a drawn figure inside its page with no text over other text.

    Each round: overlapping tick labels are thinned, colliding multi-word labels are wrapped to the space
    between their anchors, and text past the figure's edges is pulled inside by shrinking the axes."""
    if figure.get_layout_engine() is not None:
        figure.draw_without_rendering()
        figure.set_layout_engine("none")
    ticks = None
    for _ in range(rounds):
        figure.draw_without_rendering()
        renderer = figure._get_renderer()
        ticks = _tick_labels(figure)
        changed = _thin_ticks(figure, renderer)
        texts = _drawn_texts(figure, renderer)
        labels = [(t, b) for t, b in texts if id(t) not in ticks]
        for i, (a, ba) in enumerate(labels):
            for b, bb in labels[i + 1:]:
                if not ba.overlaps(bb):
                    continue
                ax_, bx_ = (ba.x0 + ba.x1) / 2, (bb.x0 + bb.x1) / 2
                room = max(abs(ax_ - bx_) - 4.0, 20.0)
                wrapped = _wrap(a, room, renderer) | _wrap(b, room, renderer)
                changed |= wrapped
                if not wrapped:                                # wrapping cannot separate them: move one clear
                    _stagger(b, a.get_window_extent(renderer), b.get_window_extent(renderer), figure)
                    changed = True
        figure.draw_without_rendering()
        changed |= _pull_inside(figure, _drawn_texts(figure, figure._get_renderer()))
        if not changed:
            break
