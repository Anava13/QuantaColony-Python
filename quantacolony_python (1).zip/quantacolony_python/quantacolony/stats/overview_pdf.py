"""Overview PDF of a project's analyses (Qt-free): one page per chosen analysis.

Pages follow the dissertation format (stats.print_pages): US Letter, the figure drawn at its printed size
inside the text block (landscape pages turned so the figure's top faces the binding), Latin Modern Roman
with every font embedded, every label at least 7 pt, and a footer band naming the project and analysis.
Each page is checked for text below 7 pt, past its edges or over other text; export_overview_pdf collects
those checks in `checks` when given a list.

Measurement fidelity opens the document. Each page is the analysis exactly as Stats draws
it, built from the project's saved Stats choices (slot assignments, hidden levels, colors,
normalization, options, overplated and touching rules). Plate selection (one plate per
group) is a Stats viewing rule and is not applied here; a note on the page says so when it
was on. An analysis whose choices cannot be drawn gets a page saying why, so a toggled
analysis always accounts for itself.
"""

from __future__ import annotations

import datetime
from pathlib import Path

from ..analyses import data as ad
from ..analyses.api import PlotStyle
from ..analyses.common import show_message
from ..analyses.registry import load_analyses, sections
from ..core.growth import SEPARABLE_CAPTURE_RATIO
from ..theme.tokens import get_quanta_colony_style

FIDELITY = "fidelity"
SLOW = ("subpopulations", "component_locations")      # mixture fits: off by default in the toggle list


def _plate_picture(manager, index_id: int):
    """(cropped photo, region mask, colonies in crop coordinates, px per mm) of one plate."""
    from ..core.colony_set import ColonySet
    packet = manager.checkout_image(int(index_id))
    colonies = packet.saved.colonies if packet.saved is not None else ColonySet.empty()
    return (packet.record.image, packet.record.mask, colonies,
                float(packet.record.px_per_mm) if packet.record.px_per_mm else float("nan"))


def pdf_style() -> PlotStyle:
    """The theme's plot colors, without Qt."""
    style = get_quanta_colony_style()
    p = style.plot
    return PlotStyle(ink=p.ink, muted=p.muted, grid=p.grid, spine=p.spine, background=p.background,
                     panel_edge=p.panel_edge, bar=p.bar, empty_cell=p.empty_cell, marker_fill=p.marker_fill,
                     group_colors=tuple(p.group_colors), step_colormap=p.step_colormap,
                     zone_colors=tuple(p.zone_colors), font_size=float(style.fonts.small - 2))


def overview_choices(manager) -> list[tuple[str, str, bool]]:
    """(analysis id, name, ticked by default) in page order: fidelity first, then the Stats menu order."""
    report = load_analyses(manager.analyses_folder())
    ordered = []
    for _, entries in sections(report):
        ordered.extend(entries)
    choices = [(FIDELITY, report.analyses[FIDELITY].name, True)] if FIDELITY in report.analyses else []
    for analysis_id, name in ordered:
        if analysis_id != FIDELITY:
            choices.append((analysis_id, name, analysis_id not in SLOW))
    return choices


def export_overview_pdf(manager, path: Path, analysis_ids: list[str], progress=None, checks: list | None = None) -> Path:
    """Write the PDF. progress(done, total) is called per step; returning False stops coverage
    measuring early (those measures are then blank, as in Stats). checks, when given, receives one
    print_pages.PageCheck per page."""
    from matplotlib.figure import Figure

    from . import print_pages as P
    with P.house():
        return _export(manager, path, analysis_ids, progress, checks, Figure, P)


def _export(manager, path, analysis_ids, progress, checks, Figure, P) -> Path:
    report = load_analyses(manager.analyses_folder())
    chosen = [a for a in analysis_ids if a in report.analyses]
    chosen.sort(key=lambda a: a != FIDELITY)                      # fidelity first, otherwise the given order
    style = P.print_style(pdf_style())
    prefs = manager.module_preferences("stats")
    colonies = manager.colony_table()
    needs_coverage = any(report.analyses[a].unit == "index" for a in chosen) or prefs.get("leave_out_overplated")
    indices = manager.index_table(coverage=needs_coverage, progress=progress)
    plate_info = manager.plate_details()
    variables = list(colonies.variables)
    names = {v.name for v in variables}
    hidden = {k: list(v) for k, v in dict(prefs.get("hidden_levels", {})).items() if k in names}
    scheme = prefs.get("scheme", ad.RAW)
    no_touching = bool(prefs.get("leave_out_touching", False))
    by_hand = [int(i) for i in prefs.get("left_out_by_hand", [])]
    left_out = list(by_hand)
    short = {int(i) for i in prefs.get("short_list", [])}
    if prefs.get("use_short_list") and short:                # the short list in use: every other plate is left out
        left_out += [int(i) for i in indices.index_ids if int(i) not in short]
    overplated_note = ""
    if prefs.get("leave_out_overplated"):
        ratios = indices.measures.get("capture_ratio")
        if ratios is not None:
            import numpy as np
            overplated = [int(i) for i, r in zip(indices.index_ids, ratios)
                          if np.isfinite(r) and r < SEPARABLE_CAPTURE_RATIO]
            left_out = sorted(set(left_out) | set(overplated))
            if overplated:
                overplated_note = (f"Left out as overplated (capture ratio below "
                                   f"{SEPARABLE_CAPTURE_RATIO:.0%}): {len(overplated)} plates.")
    selection_note = ("Plate selection (one plate per group) is a Stats viewing rule; this PDF draws "
                      "every used plate." if dict(prefs.get("plate_selection") or {}).get("on") else "")
    color_by = prefs.get("color_by", "") if prefs.get("color_by", "") in names else ""
    level_colors = {k: dict(v) for k, v in dict(prefs.get("level_colors", {})).items() if k in names}

    project_name = manager.project_info().name
    stamp = datetime.date.today().isoformat()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    written = 0
    pages = []
    if True:
        for step, analysis_id in enumerate(chosen):
            analysis = report.analyses[analysis_id]
            if hasattr(analysis, "reset_cache") and step == 0:
                analysis.reset_cache()
            assignment = ad.merge_assignment(analysis, variables, dict(prefs.get("assignments", {})
                                                                       ).get(analysis_id))
            figure = Figure(figsize=P.FIGURE_LANDSCAPE, facecolor=style.background)
            problem = ad.assignment_problem(analysis, variables, assignment)
            rows = len(indices) if analysis.unit == "index" else len(colonies)
            page_style = style
            if color_by and not ad.color_problem(analysis, variables, assignment, color_by):
                import dataclasses
                variable = next(v for v in variables if v.name == color_by)
                colors = ad.level_colors(variable, style, level_colors.get(color_by))
                page_style = dataclasses.replace(style, color_variable=color_by,
                                                 level_colors=tuple(colors.items()))
            drawn = None
            notes = []
            if not rows:
                show_message(figure, "No detected colonies yet.", style)
            elif problem:
                show_message(figure, problem, style)
            else:
                measures = ad.measures_for(analysis, indices)
                measure = dict(prefs.get("measures", {})).get(analysis_id, "")
                measure = measure if measure in measures else (next(iter(measures)) if measures else "")
                data = ad.build_data(analysis, colonies, indices, assignment, scheme, measure, hidden,
                                     left_out, no_touching, plate_info=plate_info)
                if getattr(analysis, "needs_images", False):
                    import dataclasses
                    data = dataclasses.replace(data, images=lambda index_id: _plate_picture(manager, index_id))
                deeper = analysis.problem(data)
                if deeper:
                    show_message(figure, deeper, style)
                else:
                    values = {o.key: o.initial for o in analysis.options}           # level choices are checked in compute
                    values.update({k: v for k, v in dict(prefs.get("option_values", {})
                                                         ).get(analysis_id, {}).items() if k in values})
                    try:
                        result = analysis.compute(data, values)
                        if analysis_id == FIDELITY:                  # the dissertation's fidelity layout
                            from ..dissertation import figures as F
                            drawn = F.fidelity_figure(result, per_plate_n=bool(result.get("per_plate")))
                        else:
                            drawn = analysis.draw(figure, result, page_style)
                        notes = [n for n in analysis.notes(result) if n]
                    except Exception as error:                       # a broken analysis gets its message page
                        figure = Figure(figsize=P.FIGURE_LANDSCAPE, facecolor=style.background)
                        show_message(figure, f"{analysis.name} could not be drawn "
                                             f"({type(error).__name__}: {error}).", style)
                        drawn = None
                        notes = []
            drawn_pages = drawn if isinstance(drawn, list) else [drawn if drawn is not None else figure]
            notes = [n for n in notes if "\n" not in n.strip() and len(n) <= 240]   # console tables stay out
            notes = notes + [n for n in (overplated_note, selection_note) if n]
            for k, page in enumerate(drawn_pages):
                part = f" ({k + 1} of {len(drawn_pages)})" if len(drawn_pages) > 1 else ""
                footer = f"{project_name} · {analysis.name}{part} · QuantaColony · {stamp}"
                if notes:
                    footer = "\n".join(["  ".join(notes)[:300].replace("★", "Star:"), footer])
                P.italicize(page)
                P.raise_small_text(page)
                P.fit_to_page(page)
                if checks is not None:
                    checks.append(P.check_page(page, analysis.name + part))
                pages.append(P.compose(P.to_pdf_page(page), P.to_pdf_page(P.footer_figure(page.get_figwidth(), footer)),
                                       P.landscape(page)))
            written += 1
            if progress is not None:
                progress(step + 1, len(chosen))
    if not written:
        path.unlink(missing_ok=True)
        raise ValueError("No analysis was chosen")
    P.write_pages(pages, path)
    return path
