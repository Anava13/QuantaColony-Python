"""Every number the dissertation chapters quote, printed against the value Python computes (model -> CSV).

One row per value: where it appears, the statement, the printed value, the value from the current
analysis, its unit, the project and analysis it comes from, and whether the two differ.

Each row has a named key, part.section.statement (for example rescue.selection.target_colony_count). The
key is built from the row's statement, so it stays the same between exports, and the part prefix keeps the
keys of different parts apart when their .tex files are loaded together. Each part (Crowding, Rescue,
QuantaColony Validation) gets its own CSV and .tex.
"""

from __future__ import annotations

import csv
import re
from pathlib import Path

import numpy as np

from .model import GENOTYPES, PASSAGES, SMALL, eligible_main, selected

COLUMNS = ("key", "part", "label", "figure_or_table", "statement", "printed", "python", "unit", "changed",
           "project", "analysis", "settings", "note")
PARTS = {"crowding": "Crowding", "rescue": "Rescue", "validation": "QuantaColony_Validation",
         "quantacolony": "QuantaColony"}                                                    # part -> folder
MISSING = "--"
CROWDING_LABELS = ("ch:crowding-control", "sec:val", "sec:count", "sec:confluency_edge", "sec:test")
SECTION = {"ch:crowding-control": "intro", "sec:val (growth coverage)": "growth_coverage", "sec:count": "count",
           "sec:confluency_edge": "table", "sec:test": "test", "ch:fate-test": "fate_test",
           "sec:colony-type": "colony_type", "sec:fate-double": "fate_double", "sec:rescue-selection": "selection",
           "sec:rescue-fidelity": "fidelity", "sec:rescue-series": "series", "sec:dbf4-signature": "dbf4_signature",
           "sec:mixture-structure": "mixture", "sec:small-share": "small_share", "captions": "captions",
           "from crowding": "from_crowding"}
SEL = "one plate per genotype x passage; 6-day Standard (Main); >=50 colonies; capture ratio >=25%; target: least total deviation"
NAMES = {"wild_type": "wild type", "dbf4-1": "dbf4-1", "cdc13-2": "cdc13-2", "dbf4-1_cdc13-2": "dbf4-1 cdc13-2"}


def _n(value, digits=0):
    if value is None or (isinstance(value, float) and not np.isfinite(value)):
        return ""
    if isinstance(value, str):
        return value
    return f"{value:.{digits}f}" if digits else f"{round(value):.0f}"


def _pct(value, digits=0):
    return _n(None if value is None else 100 * value, digits)


def _span(values, digits=0, pct=False):
    values = [v * (100 if pct else 1) for v in values if v is not None and np.isfinite(v)]
    if not values:
        return ""
    lo, hi = min(values), max(values)
    return _n(lo, digits) if abs(hi - lo) < 10 ** -digits else f"{_n(lo, digits)} to {_n(hi, digits)}"


def part_of(label: str) -> str:
    if label.startswith("validation"):
        return "validation"
    if label.startswith("quantacolony"):
        return "quantacolony"
    return "crowding" if label.startswith(CROWDING_LABELS) else "rescue"


def slug(text: str) -> str:
    text = text.replace("µm", "um").replace("Δ", "delta").replace("%", "pct").replace("+", " plus ")
    return re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")


class Rows:
    def __init__(self):
        self.rows = []
        self.keys = set()

    def add(self, label, fig, statement, printed, python, unit="", project="Rescue", analysis="", settings="", note="",
            key=None):
        printed, python = str(printed), str(python)
        changed = "" if not python or not printed else ("no" if _same(printed, python) else "yes")
        part = part_of(label)
        section = SECTION.get(label, slug(label.replace("validation", "")) or "general")
        key = key or f"{part}.{section}.{slug(statement)}"
        base, n = key, 2
        while key in self.keys:                       # a repeated statement in one section: _2, _3 ...
            key, n = f"{base}_{n}", n + 1
        self.keys.add(key)
        self.rows.append([key, part, label, fig, statement, printed, python, unit, changed, project, analysis,
                          settings, note])


def _same(a: str, b: str) -> bool:
    norm = lambda s: s.replace("~", "").replace(",", "").replace("%", "").replace(" ", "").replace("≤", "<=").lower()
    if norm(a) == norm(b):
        return True
    try:
        return abs(float(norm(a)) - float(norm(b))) < 1e-9
    except ValueError:
        return False


def latex_p(p: float) -> str:
    """A p-value as LaTeX math text: 0.04, or 4 \\times 10^{-6} below 0.001."""
    if p is None or not np.isfinite(p):
        return MISSING
    if p >= 0.001:
        return f"{p:.2g}" if p < 0.01 else f"{p:.2f}"
    mantissa, exponent = f"{p:.0e}".split("e")
    return f"{mantissa} \\times 10^{{{int(exponent)}}}"


def build(C, R, within, robust, A=None, H=None, fidelity=None, methods=None) -> list[list]:
    """fidelity: {"Crowding": result, "Anbalagan": result, "Historical": result} of the validation figures;
    methods: what the QuantaColony methods chapter needs (export_dissertation gathers it)."""
    rows = Rows()
    add = rows.add
    crowd = {int(float(p.levels["dilution_level"])): p for p in C.plates.values()}

    # ---------------- crowding control ----------------------------------------------------
    fig = "fig:representative_plates"
    for dil, n, med, hce in ((500, 415, 601, 76800), (16000, 70, 1185, 2400)):
        p = crowd[dil]
        add("ch:crowding-control", fig, f"Crowding Dataset {dil}X: colony count", n, p.count, "colonies", "Crowding", "plate_metrics")
        add("ch:crowding-control", fig, f"Crowding Dataset {dil}X: median radius", med, _n(p.median), "um", "Crowding", "box")
        add("ch:crowding-control", fig, f"Crowding Dataset {dil}X: HCE", hce, _n(p.hce), "cells", "Crowding", "annotation")
    for (g, ps), n, med in ((("wild_type", "1"), 132, 988), (("cdc13-2", "3"), 139, 402)):
        p = selected(R, g, ps)
        add("ch:crowding-control", fig, f"Rescue Dataset {NAMES[g]} P{ps}: colony count", n, p.count, "colonies", "Rescue", "selection", SEL)
        add("ch:crowding-control", fig, f"Rescue Dataset {NAMES[g]} P{ps}: median radius", med, _n(p.median), "um", "Rescue", "selection", SEL)
    p = crowd[500]
    add("sec:val (growth coverage)", "fig:foreground_overlay", "500X: growth coverage", 29, _pct(p.growth), "%", "Crowding", "plate_metrics")
    colony_cov = _colony_coverage(C, p)
    add("sec:val (growth coverage)", "fig:foreground_overlay", "500X: colony coverage", 8.3, _pct(colony_cov, 1), "%", "Crowding", "plate_metrics")
    add("sec:val (growth coverage)", "fig:foreground_overlay", "500X: growth not resolved as colonies", 20.7, _pct(p.growth - colony_cov, 1), "%", "Crowding", "plate_metrics")
    add("sec:val (growth coverage)", "fig:foreground_overlay", "500X: capture ratio", 28.6, _pct(p.capture, 1), "%", "Crowding", "plate_metrics",
        note="capture ratio = growth in pieces holding one colony / all growth")
    p = crowd[100]
    add("sec:count", "", "100X: capture ratio", 12.9, _pct(p.capture, 1), "%", "Crowding", "plate_metrics")
    add("sec:count", "", "100X: colony coverage", 5.2, _pct(_colony_coverage(C, p), 1), "%", "Crowding", "plate_metrics")
    add("sec:count", "", "100X: growth coverage", 40.1, _pct(p.growth, 1), "%", "Crowding", "plate_metrics")
    printed = {100: (293, 40.1, 12.9, 571.5), 500: (415, 29.0, 28.6, 600.8), 1000: (319, 21.9, 37.3, 692.0),
               2000: (255, 19.0, 49.4, 851.1), 4000: (174, 22.2, 46.1, 1095.7), 8000: (168, 11.6, 65.4, 946.6),
               16000: (70, 9.2, 51.4, 1185.3), 32000: (73, 8.6, 84.4, 1442.8), 64000: (45, 6.7, 71.2, 1506.3),
               128000: (23, 4.4, 67.6, 1682.3)}
    for dil, (n, gc, cr, med) in printed.items():
        p = crowd[dil]
        add("sec:confluency_edge", "tab:part2", f"{dil}X: HCE", _n(p.hce), _n(p.hce), "cells", "Crowding", "annotation")
        add("sec:confluency_edge", "tab:part2", f"{dil}X: colony count", n, p.count, "colonies", "Crowding", "plate_metrics")
        add("sec:confluency_edge", "tab:part2", f"{dil}X: growth coverage", gc, _pct(p.growth, 1), "%", "Crowding", "plate_metrics")
        add("sec:confluency_edge", "tab:part2", f"{dil}X: capture ratio", cr, _pct(p.capture, 1), "%", "Crowding", "plate_metrics")
        add("sec:confluency_edge", "tab:part2", f"{dil}X: median radius", med, _n(p.median, 1), "um", "Crowding", "box")
    fits = within["fits"]
    add("sec:test", "", "plates in the pooled fit", 100, within["plates"], "plates", "Crowding + Rescue", "within-state test")
    add("sec:test", "", "contributing states", 20, within["states"], "states", "Crowding + Rescue", "within-state test")
    add("sec:test", "", "Crowding Dataset plates in the fit", "9 of 10", f"{within['by_project'].get('Crowding', 0)} of {len(C.plates)}", "", "Crowding", "within-state test")
    add("sec:test", "", "colonies in the per-colony crowding fit", "19,187", f"{within['colonies']:,}", "colonies", "Crowding + Rescue", "within-state test")
    for name, printed_text, printed_caption in (("HCE", 0.310, 0.345), ("Colony count", 0.562, 0.561), ("Growth coverage", 0.344, 0.336)):
        add("sec:test", "fig:within_state_predictors", f"{name} within-state R2 (text)", f"{printed_text:.3f}", f"{fits[name].r2:.3f}", "", "Crowding + Rescue", "within-state test")
        add("sec:test", "fig:within_state_predictors", f"{name} within-state R2 (caption)", f"{printed_caption:.3f}", f"{fits[name].r2:.3f}", "", "Crowding + Rescue", "within-state test")
    if "Crowding score" in fits:
        add("sec:test", "fig:within_state_predictors", "crowding score R2", "0.000", f"{fits['Crowding score'].r2:.3f}", "", "Crowding + Rescue", "within-state test (per colony)")
    common = within["commonality"]
    for statement, printed_value, key in (("joint fit R2", 0.566, "Colony count and growth coverage together"),
                                          ("colony count beyond growth coverage", 0.222, "Colony count, beyond growth coverage"),
                                          ("growth coverage beyond colony count", 0.003, "Growth coverage, beyond colony count"),
                                          ("shared between the two", 0.341, "Shared between the two")):
        add("sec:test", "tab:commonality", statement, f"{printed_value:.3f}", f"{common[key]:.3f}", "", "Crowding + Rescue", "commonality")
    add("sec:test", "", "within-state slope, log radius on log colony count", "-0.26", f"{fits['Colony count'].slope:.2f}", "", "Crowding + Rescue", "within-state test")

    # ---------------- fate test ------------------------------------------------------------
    from .model import density_peaks
    for g, printed_peaks in (("cdc13-2", "290 and 577"), ("dbf4-1_cdc13-2", "334 and 717")):
        p = selected(R, g, "3")
        peaks = density_peaks(p.radii_um)[2]
        add("ch:fate-test", "fig:bimodality", f"{NAMES[g]} P3 density modes", printed_peaks, " and ".join(f"{v:.0f}" for v in peaks), "um",
            "Rescue", "density (log radius, peaks)", SEL)
    enrich = lambda g, s: sorted(R.where(genotype=g, passage="4", series=s), key=lambda p: p.index_id)
    big_c, small_c, small_d, big_d = enrich("cdc13-2", "large_enriched"), enrich("cdc13-2", "small_enriched"), \
        enrich("dbf4-1_cdc13-2", "small_enriched"), enrich("dbf4-1_cdc13-2", "large_enriched")
    add("sec:colony-type", "fig:enrichment_p4", "cdc13-2 large-enriched colony counts", "119 and 125", " and ".join(str(p.count) for p in big_c), "colonies", "Rescue", "plate_metrics")
    add("sec:colony-type", "fig:enrichment_p4", "cdc13-2 large-enriched medians", "~700 and ~750", " and ".join(_n(p.median) for p in big_c), "um", "Rescue", "box")
    add("sec:colony-type", "fig:enrichment_p4", "cdc13-2 small-enriched colonies founded", 0, " and ".join(str(p.count) for p in small_c) or "0", "colonies", "Rescue", "plate_metrics")
    std_c = [p for p in R.where(genotype="cdc13-2", passage="4", series="main")]
    add("sec:colony-type", "", "cdc13-2 standard P4 colonies", 3, " and ".join(str(p.count) for p in std_c), "colonies", "Rescue", "plate_metrics")
    add("sec:fate-double", "fig:enrichment_p4", "double small-enriched colony counts", "70 and 74", " and ".join(str(p.count) for p in small_d), "colonies", "Rescue", "plate_metrics")
    radii = np.concatenate([p.radii_um for p in small_d]) if small_d else np.zeros(0)
    add("sec:fate-double", "fig:enrichment_p4", "double small-enriched size range", "~240 to >3000", f"{radii.min():.0f} to {radii.max():.0f}" if radii.size else "", "um", "Rescue", "colony radii")
    add("sec:fate-double", "fig:enrichment_p4", "double small-enriched medians", "~620 and ~1280", " and ".join(_n(p.median) for p in small_d), "um", "Rescue", "box",
        note="source FLAG: the defense deck gives ~640 and ~1290")
    add("sec:fate-double", "", "share above 1100 um on the two small-enriched double plates", "10 and 68",
        " and ".join(_pct(p.share_above(1100)) for p in sorted(small_d, key=lambda p: p.median)), "%", "Rescue", "threshold_share (above 1100, colonies)")
    add("sec:fate-double", "", "double large-enriched colony count", 33, " and ".join(str(p.count) for p in big_d), "colonies", "Rescue", "plate_metrics")
    add("sec:fate-double", "", "double large-enriched median", "~2200", " and ".join(_n(p.median) for p in big_d), "um", "Rescue", "box")

    # ---------------- selection --------------------------------------------------------------
    target = R.extra["target"]
    add("sec:rescue-selection", "", "eligible plates", 87, R.extra["eligible"], "plates", "Rescue", "selection", SEL)
    add("sec:rescue-selection", "", "target colony count", 139, _n(target), "colonies", "Rescue", "selection", SEL, note=R.extra["target_rule"])
    filled = [selected(R, g, p) for g in GENOTYPES for p in PASSAGES if selected(R, g, p) is not None]
    add("sec:rescue-selection", "", "filled cells", 19, len(filled), "cells", "Rescue", "selection", SEL)
    add("sec:rescue-selection", "", "filled cells within 40 colonies of the target", "15 of 19",
        f"{sum(abs(p.count - target) <= 40 for p in filled)} of {len(filled)}", "", "Rescue", "selection", SEL)
    for g, n, med, cr in (("wild_type", 149, 1200, 42), ("dbf4-1", 142, 1382, 34), ("cdc13-2", 925, 220, 49), ("dbf4-1_cdc13-2", 167, 680, 72)):
        p = selected(R, g, "5")
        add("sec:rescue-selection", "fig:rescue_selected_plates", f"P5 {NAMES[g]}: colony count", n, p.count, "colonies", "Rescue", "selection", SEL)
        add("sec:rescue-selection", "fig:rescue_selected_plates", f"P5 {NAMES[g]}: median radius", med, _n(p.median), "um", "Rescue", "selection", SEL)
        add("sec:rescue-selection", "fig:rescue_selected_plates", f"P5 {NAMES[g]}: capture ratio", cr, _pct(p.capture), "%", "Rescue", "selection", SEL)

    # ---------------- fidelity ---------------------------------------------------------------
    fs, fa = R.extra["fidelity_selected"], R.extra["fidelity_all"]
    area = lambda u: np.pi * (50.0 / u) ** 2
    add("sec:rescue-fidelity", "fig:rescue_fidelity", "colonies on the selected plates", 3450, len(fs["uncertainty"]), "colonies", "Rescue", "fidelity", SEL)
    add("sec:rescue-fidelity", "fig:rescue_fidelity", "selected plates", 19, len(filled), "plates", "Rescue", "fidelity", SEL)
    add("sec:rescue-fidelity", "fig:rescue_fidelity", "median colony area, selected plates", 156, _n(area(fs["overall"])), "px", "Rescue", "fidelity", SEL)
    add("sec:rescue-fidelity", "fig:rescue_fidelity", "median colony category, selected plates", "Good", _category(fs["overall"]), "", "Rescue", "fidelity", SEL)
    add("sec:rescue-fidelity", "fig:rescue_fidelity_full", "colonies, all plates", 25300, len(fa["uncertainty"]), "colonies", "Rescue", "fidelity", "every plate")
    add("sec:rescue-fidelity", "fig:rescue_fidelity_full", "plates, all", 121, len(R.plates), "plates", "Rescue", "fidelity", "every plate")
    add("sec:rescue-fidelity", "fig:rescue_fidelity_full", "median colony area, all plates", 76, _n(area(fa["overall"])), "px", "Rescue", "fidelity", "every plate")
    add("sec:rescue-fidelity", "fig:rescue_fidelity_full", "median colony category, all plates", "Moderate", _category(fa["overall"]), "", "Rescue", "fidelity", "every plate")
    wd = [selected(R, g, p) for g in ("wild_type", "dbf4-1") for p in PASSAGES]
    add("sec:rescue-fidelity", "", "WT and dbf4-1 median colony areas", "150 to 553", _span([p.area_px for p in wd if p]), "px", "Rescue", "fidelity", SEL)
    for passage, printed_area, printed_u in (("3", 57, 11.7), ("5", 20, 19.8)):
        p = selected(R, "cdc13-2", passage)
        add("sec:rescue-fidelity", "", f"cdc13-2 P{passage} median colony area", printed_area, _n(p.area_px), "px", "Rescue", "fidelity", SEL)
        add("sec:rescue-fidelity", "", f"cdc13-2 P{passage} uncertainty", printed_u, _n(p.uncertainty, 1), "%", "Rescue", "fidelity", SEL)
    moderate = [f"{NAMES[g]} P{p}" for g in GENOTYPES for p in PASSAGES if selected(R, g, p) and _category(selected(R, g, p).uncertainty) == "Moderate"]
    add("sec:rescue-fidelity", "fig:rescue_fidelity", "selected plates at Moderate", "cdc13-2 P3, cdc13-2 P5, double P4", ", ".join(moderate), "", "Rescue", "fidelity", SEL)
    others_p5 = [p for p in R.where(genotype="cdc13-2", passage="5", series="main") if p.index_id != selected(R, "cdc13-2", "5").index_id]
    add("sec:rescue-fidelity", "", "non-selected cdc13-2 P5 plates", 6, len(others_p5), "plates", "Rescue", "fidelity")
    add("sec:rescue-fidelity", "", "their mean median colony area", 17, _n(np.mean([p.area_px for p in others_p5])) if others_p5 else "", "px", "Rescue", "fidelity")

    # ---------------- table 14.1 -------------------------------------------------------------
    table = {("1", "wild_type"): (132, 988, 1.00, 1.00, 0.30, 59), ("1", "dbf4-1"): (160, 812, 0.82, 1.00, 0.28, 37),
             ("1", "cdc13-2"): (147, 800, 0.81, 1.00, 0.30, 35), ("1", "dbf4-1_cdc13-2"): (109, 981, 0.99, 1.00, 0.25, 31),
             ("2", "wild_type"): (208, 642, 1.00, 0.65, 0.58, 45), ("2", "dbf4-1"): (138, 830, 1.29, 1.02, 0.27, 35),
             ("2", "cdc13-2"): (130, 879, 1.37, 1.10, 0.31, 53), ("2", "dbf4-1_cdc13-2"): (144, 754, 1.17, 0.77, 0.43, 36),
             ("3", "wild_type"): (130, 1486, 1.00, 1.50, 0.27, 39), ("3", "dbf4-1"): (103, 1071, 0.72, 1.32, 0.21, 52),
             ("3", "cdc13-2"): (139, 402, 0.27, 0.50, 0.48, 39), ("3", "dbf4-1_cdc13-2"): (64, 589, 0.40, 0.60, 0.42, 74),
             ("4", "wild_type"): (203, 1160, 1.00, 1.17, 0.45, 29), ("4", "dbf4-1"): (116, 1052, 0.91, 1.30, 0.23, 68),
             ("4", "dbf4-1_cdc13-2"): (144, 436, 0.38, 0.44, 0.34, 55),
             ("5", "wild_type"): (149, 1200, 1.00, 1.21, 0.36, 42), ("5", "dbf4-1"): (142, 1382, 1.15, 1.70, 0.21, 34),
             ("5", "cdc13-2"): (925, 220, 0.18, 0.28, "<=0.16", 49), ("5", "dbf4-1_cdc13-2"): (167, 680, 0.57, 0.69, 0.43, 72)}
    for (passage, g), (n, med, rwt, rp1, cv, cr) in table.items():
        p, wt, p1 = selected(R, g, passage), selected(R, "wild_type", passage), selected(R, g, "1")
        label = f"P{passage} {NAMES[g]}"
        for column, printed_value, value, unit in (("colony count", n, p.count, "colonies"), ("median radius", med, _n(p.median), "um"),
                                                   ("ratio to wild type", f"{rwt:.2f}", f"{p.median / wt.median:.2f}", ""),
                                                   ("ratio to P1", f"{rp1:.2f}", f"{p.median / p1.median:.2f}", ""),
                                                   ("CV", cv if isinstance(cv, str) else f"{cv:.2f}", f"{p.cv:.2f}", ""),
                                                   ("capture ratio", cr, _pct(p.capture), "%")):
            add("sec:rescue-series", "tab:selected_plates", f"{label}: {column}", printed_value, value, unit, "Rescue", "selection + plate statistics", SEL)
    ratios = [selected(R, g, p).median / selected(R, g, "1").median for g in ("wild_type", "dbf4-1") for p in PASSAGES]
    add("sec:rescue-series", "", "ratio to P1 range, wild type and dbf4-1", "0.65 to 1.70", _span(ratios, 2), "", "Rescue", "plate statistics", SEL)
    p1 = [selected(R, g, "1").median for g in GENOTYPES]
    p2 = [selected(R, g, "2").median for g in GENOTYPES]
    add("sec:rescue-series", "", "P1 median range", "800 to 988", _span(p1), "um", "Rescue", "plate statistics", SEL)
    add("sec:rescue-series", "", "P2 median range", "642 to 879", _span(p2), "um", "Rescue", "plate statistics", SEL)
    add("sec:rescue-series", "", "P2 colony counts: wild type, cdc13-2, double", "208, 130, 144",
        ", ".join(str(selected(R, g, "2").count) for g in ("wild_type", "cdc13-2", "dbf4-1_cdc13-2")), "colonies", "Rescue", "selection", SEL)
    d3, d4, d5 = (selected(R, "dbf4-1_cdc13-2", p).median for p in ("3", "4", "5"))
    add("sec:rescue-series", "", "double medians P3, P4, P5", "589, 436, 680", f"{d3:.0f}, {d4:.0f}, {d5:.0f}", "um", "Rescue", "plate statistics", SEL)
    c5 = selected(R, "cdc13-2", "5")
    add("sec:rescue-series", "", "P5 double / cdc13-2 median", "3.1 (680 / 220)", f"{d5 / c5.median:.1f}", "", "Rescue", "plate statistics", SEL)
    add("sec:rescue-series", "", "cdc13-2 large-enriched P4 median (pooled)", 738, _n(np.median(np.concatenate([p.radii_um for p in big_c]))) if big_c else "", "um", "Rescue", "colony radii")
    add("sec:rescue-series", "", "cdc13-2 three-colony standard P4 median", 756, " and ".join(_n(p.median) for p in std_c), "um", "Rescue", "colony radii")
    p5_others = [selected(R, g, "5").count for g in ("wild_type", "dbf4-1", "dbf4-1_cdc13-2")]
    add("sec:rescue-series", "", "P5 colony counts of the other genotypes", "142 to 167", _span(p5_others), "colonies", "Rescue", "selection", SEL)
    c5_all = R.where(genotype="cdc13-2", passage="5", series="main")
    big = [p for p in c5_all if p.count >= 900]
    add("sec:rescue-series", "", "cdc13-2 P5 plates of 900+ colonies: colonies", "925 to 1447", _span([p.count for p in big]), "colonies", "Rescue", "plate_metrics")
    add("sec:rescue-series", "", "their capture ratios", "25 to 49", _span([p.capture for p in big], pct=True), "%", "Rescue", "plate_metrics")
    add("sec:rescue-series", "", "their growth coverage", "6 to 13", _span([p.growth for p in big], pct=True), "%", "Rescue", "plate_metrics")
    wt = sorted(R.where(genotype="wild_type", series="main"), key=lambda p: -p.count)[:2]
    add("sec:rescue-series", "", "two densest wild-type plates: colonies", "523 and 593", " and ".join(str(p.count) for p in sorted(wt, key=lambda p: p.count)), "colonies", "Rescue", "plate_metrics")
    add("sec:rescue-series", "", "two densest wild-type plates: growth coverage", "16 and 15", " and ".join(_pct(p.growth) for p in sorted(wt, key=lambda p: p.count)), "%", "Rescue", "plate_metrics")
    most = max((p.count for p in R.where(series="main") if p.levels["genotype"] != "cdc13-2"), default=0)
    add("sec:rescue-series", "", "most colonies on a plate of another genotype", "600", most, "colonies", "Rescue", "plate_metrics")

    # ---------------- dbf4-1 signature --------------------------------------------------------
    main = [p for p in R.where(series="main") if p.count >= 10]
    mean_by = lambda g, stat: [np.mean([getattr(p, stat) for p in main if p.levels["genotype"] == g and p.levels["passage"] == ps]) for ps in PASSAGES]
    add("sec:dbf4-signature", "fig:dbf4_signature", "dbf4-1 mean CV range", "0.19 to 0.27", _span(mean_by("dbf4-1", "cv"), 2), "", "Rescue", "plate_statistic: CV", ">=10 colonies")
    add("sec:dbf4-signature", "fig:dbf4_signature", "wild-type mean CV range", "0.30 to 0.54", _span(mean_by("wild_type", "cv"), 2), "", "Rescue", "plate_statistic: CV", ">=10 colonies")
    add("sec:dbf4-signature", "fig:dbf4_signature", "dbf4-1 mean skew range", "-0.06 to -0.78", _span(mean_by("dbf4-1", "skew"), 2), "", "Rescue", "plate_statistic: Skew", ">=10 colonies")
    pair = {g: np.concatenate([p.radii_um for p in R.where(genotype=g, passage="2", density="2", series="main")]) for g in ("wild_type", "dbf4-1")}
    add("sec:dbf4-signature", "fig:dbf4_signature", "P2 Med-tier colonies (wild type, dbf4-1)", "289 and 286", f"{pair['wild_type'].size} and {pair['dbf4-1'].size}", "colonies", "Rescue", "density",
        note="wild type pools three plates now that P2V3 is included")
    add("sec:dbf4-signature", "fig:dbf4_signature", "wild-type P2 density peaks", "330 and 850", ", ".join(f"{v:.0f}" for v in density_peaks(pair["wild_type"])[2]), "um", "Rescue", "density")
    add("sec:dbf4-signature", "fig:dbf4_signature", "dbf4-1 P2 density peaks", "330, 480 (minor) and upper", ", ".join(f"{v:.0f}" for v in density_peaks(pair["dbf4-1"])[2]), "um", "Rescue", "density")
    cls = R.extra["classifier"]
    keys = [k[0] if isinstance(k, tuple) else k for k in cls["data"].axes["classes"].keys]
    def hits(g, side):
        ps = [p for p in cls["plates"] if keys[p["class"]] == g]
        return f"{sum(p['assigned'] == side for p in ps)} of {len(ps)}"
    correct, total, base = cls["all"]
    pc, pt, pb = cls["pair"]
    for where, printed_values in (("text", (90, 106, "84.9")), ("caption", (91, 106, "85.8"))):
        for part, printed_value, value in zip(("correct", "total", "pct"), printed_values,
                                              (correct, total, f"{100 * correct / total:.1f}")):
            add("sec:dbf4-signature", "fig:dbf4_signature", f"accuracy all four genotypes {where} {part}", printed_value,
                value, "%" if part == "pct" else "plates", "Rescue", "shape_classifier")
    add("sec:dbf4-signature", "fig:dbf4_signature", "baseline, all four genotypes", "73.6%", f"{100 * base:.1f}%", "", "Rescue", "shape_classifier")
    for where, printed_values in (("text", (43, 51, "84.3")), ("caption", (44, 52, "84.6"))):
        for part, printed_value, value in zip(("correct", "total", "pct"), printed_values, (pc, pt, f"{100 * pc / pt:.1f}")):
            add("sec:dbf4-signature", "fig:dbf4_signature", f"accuracy wild type and dbf4-1 {where} {part}", printed_value,
                value, "%" if part == "pct" else "plates", "Rescue", "shape_classifier")
    add("sec:dbf4-signature", "fig:dbf4_signature", "baseline, wild type and dbf4-1", "54.9% (text), 53.8% (caption)", f"{100 * pb:.1f}%", "", "Rescue", "shape_classifier")
    add("sec:dbf4-signature", "", "dbf4-1 plates identified", "26 of 28", hits("dbf4-1", True), "", "Rescue", "shape_classifier")
    add("sec:dbf4-signature", "", "wild-type plates on the wild-type side", "17 of 23", hits("wild_type", False), "", "Rescue", "shape_classifier")
    add("sec:dbf4-signature", "", "double-mutant plates on the wild-type side", "27 of 30", hits("dbf4-1_cdc13-2", False), "", "Rescue", "shape_classifier")
    add("sec:dbf4-signature", "", "cdc13-2 plates on the wild-type side", "20 of 25", hits("cdc13-2", False), "", "Rescue", "shape_classifier")

    # ---------------- mixture structure ------------------------------------------------------
    d5p, c5p = selected(R, "dbf4-1_cdc13-2", "5"), selected(R, "cdc13-2", "5")
    add("sec:mixture-structure", "", "P5 double CV", "0.43", f"{d5p.cv:.2f}", "", "Rescue", "plate_statistic: CV", SEL)
    add("sec:mixture-structure", "", "P5 cdc13-2 CV", "0.16", f"{c5p.cv:.2f}", "", "Rescue", "plate_statistic: CV", SEL)
    q1, q3 = np.percentile(d5p.radii_um, [25, 75])
    lower = d5p.radii_um[d5p.radii_um >= q1 - 1.5 * (q3 - q1)].min()
    add("sec:mixture-structure", "", "P5 double lower whisker", "~160", _n(lower), "um", "Rescue", "box", SEL)
    comp = lambda g, p: selected(R, g, p).components
    wt_low = [comp("wild_type", p)[0][0] for p in PASSAGES if comp("wild_type", p) is not None and comp("wild_type", p)[0].size > 1]
    wt_up = [comp("wild_type", p)[0][-1] for p in PASSAGES if comp("wild_type", p) is not None and comp("wild_type", p)[0].size > 1]
    add("sec:mixture-structure", "", "wild-type lower components", "550 to 700", _span(wt_low), "um", "Rescue", "component_locations", SEL)
    add("sec:mixture-structure", "", "wild-type upper components", "1100 to 1500", _span(wt_up), "um", "Rescue", "component_locations", SEL)
    for g, p, printed_text in (("cdc13-2", "3", "~270"), ("dbf4-1_cdc13-2", "3", "~320")):
        add("sec:mixture-structure", "", f"{NAMES[g]} P3 low component", printed_text, _n(comp(g, p)[0][0]), "um", "Rescue", "component_locations", SEL,
            note="source FLAG: the defense deck gives ~330" if g != "cdc13-2" else "")
    add("sec:mixture-structure", "", "double P3 upper component", "~660", _n(comp("dbf4-1_cdc13-2", "3")[0][-1]), "um", "Rescue", "component_locations", SEL)
    add("sec:mixture-structure", "", "double P5 components (selected plate)", "~680 (one)", ", ".join(_n(v) for v in comp("dbf4-1_cdc13-2", "5")[0]), "um", "Rescue", "component_locations", SEL)
    add("sec:mixture-structure", "", "wild-type P5 components (selected plate)", "~700 and ~1400", ", ".join(_n(v) for v in comp("wild_type", "5")[0]), "um", "Rescue", "component_locations", SEL)
    from .figures import overlap
    ref = selected(R, "wild_type", "5")
    for g, printed_span in (("dbf4-1_cdc13-2", "0.42 to 0.77"), ("dbf4-1", "0.49 to 0.70"), ("cdc13-2", "0.00 to 0.06"), ("wild_type", "0.84")):
        ps = [p for p in R.where(genotype=g, passage="5", series="main") if p.components is not None and p.capture >= 0.25 and p is not ref]
        add("sec:mixture-structure", "fig:p5-classes", f"overlap with the wild-type P5 plate: {NAMES[g]}", printed_span, _span([overlap(p, ref) for p in ps], 2), "", "Rescue", "component_locations: overlap")
    add("sec:mixture-structure", "", "faded plates", 69, robust["faded"], "plates", "Rescue", "robustness")
    add("sec:mixture-structure", "", "median distance ratio, own selected plate", "1.18", f"{robust['own_median']:.2f}", "", "Rescue", "robustness")
    add("sec:mixture-structure", "", "median distance ratio, other selected plates", "1.39", f"{robust['other_median']:.2f}", "", "Rescue", "robustness")
    add("sec:mixture-structure", "", "faded plates closer to their own selected plate", "58 of 69", f"{robust['closer']} of {robust['faded']}", "", "Rescue", "robustness")
    by = robust["closer_by_genotype"]
    add("sec:mixture-structure", "", "by genotype: dbf4-1, cdc13-2, wild type, double", "20/21, 16/16, 9/13, 13/19",
        ", ".join(f"{by.get(g, (0, 0))[0]}/{by.get(g, (0, 0))[1]}" for g in ("dbf4-1", "cdc13-2", "wild_type", "dbf4-1_cdc13-2")), "", "Rescue", "robustness")
    lo, hi = robust["permutation_range"]
    add("sec:mixture-structure", "", "2000 reassignments: median range", "1.20 to 1.46", f"{lo:.2f} to {hi:.2f}", "", "Rescue", "robustness")
    add("sec:mixture-structure", "", "reassignments as close as the true assignment", "0", robust["permutation_as_close"], "", "Rescue", "robustness")
    add("sec:mixture-structure", "", "weighted mean component radius, faded vs selected", "r = 0.70", f"r = {robust['r_size']:.2f}", "", "Rescue", "robustness")
    same_note = ("faded plates with two components; the major (heavier) component is upper when it is the larger-median "
                 "component. The faded plate matches when its major side equals the selected plate's major side; when "
                 "the selected plate has one component, the expected side is the faded component nearest it. "
                 "One-sided binomial test against 0.5")
    add("sec:mixture-structure", "", "major component on the same side count", 26, robust["same_side"], "plates", "Rescue",
        "robustness", note=same_note)
    add("sec:mixture-structure", "", "major component on the same side total", 31, robust["two_component"], "plates", "Rescue",
        "robustness", note=same_note)
    add("sec:mixture-structure", "", "major component on the same side p", "0.0002", latex_p(robust["binomial_p"]), "", "Rescue",
        "robustness", note="LaTeX math text")
    add("sec:mixture-structure", "", "distance vs colony-count difference spearman", "0.23", f"{robust['spearman']:.2f}", "",
        "Rescue", "robustness")
    add("sec:mixture-structure", "", "distance vs colony-count difference p", "0.06", latex_p(robust["spearman_p"]), "",
        "Rescue", "robustness", note="LaTeX math text")

    # ---------------- small share ----------------------------------------------------------
    for g, printed_values in (("wild_type", (5, 21, 0, 7, 5)), ("dbf4-1", ("<=8",) * 5), ("cdc13-2", (7, 2, 59, "--", 100)),
                              ("dbf4-1_cdc13-2", (1, 19, 30, 53, 19))):
        for passage, printed_value in zip(PASSAGES, printed_values):
            plate = selected(R, g, passage)
            add("sec:small-share", "fig:small-share", f"{NAMES[g]} share below 450 um P{passage}", printed_value,
                _pct(plate.share_below()) if plate else "--", "%", "Rescue", "threshold_share (below 450, colonies)", SEL,
                note="" if plate else "no plate selected at this passage")
    sel_d4 = selected(R, "dbf4-1_cdc13-2", "4")
    others = [o for o in R.where(genotype="dbf4-1_cdc13-2", passage="4", series="main") if 100 <= o.count <= 200 and o.capture >= 0.25 and o.index_id != sel_d4.index_id]
    for k, o in enumerate(sorted(others, key=lambda o: o.count), start=1):
        printed_share, printed_count = ((25, 110), (21, 155))[k - 1] if k <= 2 else ("", "")
        add("sec:small-share", "fig:small-share", f"double P4 other plate {k} share below 450 um", printed_share, _pct(o.share_below()),
            "%", "Rescue", "threshold_share", note=f"plate {o.index_id}; ordered by colony count")
        add("sec:small-share", "fig:small-share", f"double P4 other plate {k} colonies", printed_count, o.count, "colonies",
            "Rescue", "plate_metrics", note=f"plate {o.index_id}")
    sel_c2 = selected(R, "cdc13-2", "2")
    others = [o for o in R.where(genotype="cdc13-2", passage="2", series="main") if 100 <= o.count <= 200 and o.capture >= 0.25 and o.index_id != sel_c2.index_id]
    for k, o in enumerate(sorted(others, key=lambda o: o.count), start=1):
        add("sec:small-share", "fig:small-share", f"cdc13-2 P2 other plate {k} share below 450 um", (14, 19)[k - 1] if k <= 2 else "",
            _pct(o.share_below()), "%", "Rescue", "threshold_share", note=f"plate {o.index_id}, {o.count} colonies")
        add("sec:small-share", "fig:small-share", f"cdc13-2 P2 other plate {k} colonies", "", o.count, "colonies", "Rescue",
            "plate_metrics", note=f"plate {o.index_id}")
    _rescue_details(rows, C, R, within)
    if A is not None and H is not None:
        _validation(rows, C, A, H, fidelity or {})
    _methods(rows, fidelity or {}, methods or {})
    return rows.rows


def _scale(plate) -> float:
    """µm per pixel on this plate's photo."""
    keep = plate.radii_px > 0
    return float(np.median(plate.radii_um[keep] / plate.radii_px[keep])) if keep.any() else np.nan


def _areas(plate) -> np.ndarray:
    return np.pi * plate.radii_px ** 2


def _components_text(plate) -> str:
    if plate is None or plate.components is None:
        return ""
    medians, weights = plate.components[0], plate.components[1]
    return ", ".join(f"{m:.0f} ({w:.2f})" for m, w in zip(medians, weights))


def _rescue_details(rows, C, R, within) -> None:
    """The values the rescue chapters read from the crowding work, and the values added for the revision."""
    add = rows.add
    crowd = {int(float(p.levels["dilution_level"])): p for p in C.plates.values()}
    target = R.extra["target"]
    sel = {(g, p): selected(R, g, p) for g in GENOTYPES for p in PASSAGES}
    name = lambda g, p: f"{NAMES[g]} P{p}"

    # ---- read from the crowding work (duplicated so the Rescue part stands alone)
    lab = "from crowding"
    add(lab, "", "within-state slope, log radius on log colony count", "-0.26", f"{within['fits']['Colony count'].slope:.2f}", "",
        "Crowding + Rescue", "within-state test", note="also crowding.test")
    add(lab, "", "100X plate: growth coverage", 40.1, _pct(crowd[100].growth, 1), "%", "Crowding", "plate_metrics")
    add(lab, "", "100X plate: capture ratio", 12.9, _pct(crowd[100].capture, 1), "%", "Crowding", "plate_metrics")
    add(lab, "", "capture ratio cutoff", 25, 25, "%", "Rescue", "selection", SEL, note="setting of the plate selection")
    add(lab, "", "minimum colonies per plate", 50, 50, "colonies", "Rescue", "selection", SEL, note="setting of the plate selection")

    # ---- selection
    far = [(g, p, sel[g, p].count) for g in GENOTYPES for p in PASSAGES if sel[g, p] is not None and abs(sel[g, p].count - target) > 40]
    add("sec:rescue-selection", "", "cells more than 40 colonies from the target",
        "dbf4-1 P3, wild type P4, double P3, cdc13-2 P5", ", ".join(f"{name(g, p)} ({n})" for g, p, n in far), "colonies", "Rescue",
        "selection", SEL)

    # ---- fidelity
    fs = R.extra["fidelity_selected"]
    for p in ("4", "3"):
        plate = sel["dbf4-1_cdc13-2", p]
        add("sec:rescue-fidelity", "fig:rescue_fidelity", f"double P{p}: median colony area", 121 if p == "3" else "", _n(plate.area_px), "px",
            "Rescue", "fidelity", SEL)
        add("sec:rescue-fidelity", "fig:rescue_fidelity", f"double P{p}: median uncertainty", 8.1 if p == "3" else "", _n(plate.uncertainty, 1), "%",
            "Rescue", "fidelity", SEL, note=f"category {_category(plate.uncertainty)}")
    u = np.asarray(fs["uncertainty"], float)
    add("sec:rescue-fidelity", "fig:rescue_fidelity", "colonies at Low fidelity (25 to 50%) on the selected plates", 0,
        int(np.sum((u >= 25) & (u < 50))), "colonies", "Rescue", "fidelity", SEL, note=f"Sub-pixel (over 50%): {int(np.sum(u >= 50))}")
    c5 = sel["cdc13-2", "5"]
    others = [p for p in R.where(genotype="cdc13-2", passage="5", series="main") if p.index_id != c5.index_id]
    add("sec:rescue-fidelity", "", "smallest colony area, selected cdc13-2 P5 plate", "below 5", _n(_areas(c5).min(), 1), "px", "Rescue",
        "colony radii", SEL)
    add("sec:rescue-fidelity", "", "smallest colony area, non-selected cdc13-2 P5 plates", "below 5",
        _n(min(_areas(p).min() for p in others), 1) if others else "", "px", "Rescue", "colony radii")
    add("sec:rescue-fidelity", "", "mean median uncertainty, non-selected cdc13-2 P5 plates", "",
        _n(np.mean([p.uncertainty for p in others]), 1) if others else "", "%", "Rescue", "fidelity",
        note=", ".join(f"{p.count} colonies: {p.uncertainty:.1f}%" for p in sorted(others, key=lambda p: p.count)))
    big_c = sorted(R.where(genotype="cdc13-2", passage="4", series="large_enriched"), key=lambda p: p.index_id)
    for k, p in enumerate(big_c, start=1):
        add("sec:rescue-fidelity", "", f"cdc13-2 large-enriched P4 plate {k} category", "", _category(p.uncertainty), "", "Rescue",
            "fidelity", note=f"plate {p.index_id}, {p.count} colonies")
        add("sec:rescue-fidelity", "", f"cdc13-2 large-enriched P4 plate {k} uncertainty", "", _n(p.uncertainty, 1), "%", "Rescue",
            "fidelity", note=f"plate {p.index_id}")
    gaps = []
    for g in GENOTYPES:
        for p in PASSAGES:
            plate = sel[g, p]
            if plate is not None:
                from_table = np.pi * (plate.median / _scale(plate)) ** 2
                gaps.append(abs(from_table - plate.area_px) / plate.area_px)
    add("sec:rescue-fidelity", "", "largest gap between table medians and fidelity-figure areas", "within 5",
        _n(100 * max(gaps), 1), "%", "Rescue", "selection + fidelity", SEL,
        note="area from the table median radius (µm, converted with the plate's µm per pixel) against the fidelity cell area")

    # ---- passage series
    c5_all = sorted(R.where(genotype="cdc13-2", passage="5", series="main"), key=lambda p: p.count)
    add("sec:rescue-series", "", "cdc13-2 P5 plates below the 25% capture ratio cutoff", "",
        f"{sum(p.capture < 0.25 for p in c5_all)} of {len(c5_all)}", "plates", "Rescue", "plate_metrics",
        note=", ".join(f"{p.count} colonies: {100 * p.capture:.0f}%" for p in c5_all if p.capture < 0.25))
    per100 = lambda p: 100 * p.growth / p.count * 100
    for k, p in enumerate(c5_all, start=1):
        add("sec:rescue-series", "", f"cdc13-2 P5 plate {k} growth coverage per 100 colonies", "", f"{per100(p):.2f}",
            "% per 100 colonies", "Rescue", "plate_metrics", note=f"plate {p.index_id}; growth coverage / colony count; ordered by count")
        add("sec:rescue-series", "", f"cdc13-2 P5 plate {k} colonies", "", p.count, "colonies", "Rescue", "plate_metrics",
            note=f"plate {p.index_id}")
    wt = sorted(sorted(R.where(genotype="wild_type", series="main"), key=lambda p: -p.count)[:2], key=lambda p: p.count)
    for k, p in enumerate(wt, start=1):
        add("sec:rescue-series", "", f"dense wild-type plate {k} growth coverage per 100 colonies", "", f"{per100(p):.2f}",
            "% per 100 colonies", "Rescue", "plate_metrics", note=f"plate {p.index_id}; the two densest wild-type plates")
        add("sec:rescue-series", "", f"dense wild-type plate {k} colonies", "", p.count, "colonies", "Rescue", "plate_metrics",
            note=f"plate {p.index_id}")

    # ---- dbf4-1 signature
    main = [p for p in R.where(series="main") if p.count >= 10]
    mean_skew = [np.mean([p.skew for p in main if p.levels["genotype"] == "wild_type" and p.levels["passage"] == ps]) for ps in PASSAGES]
    add("sec:dbf4-signature", "fig:dbf4_signature", "wild-type mean skew range", "", _span(mean_skew, 2), "", "Rescue",
        "plate_statistic: Skew", ">=10 colonies")
    overlap_passages = []
    for ps in PASSAGES:
        cv = {g: [p.cv for p in main if p.levels["genotype"] == g and p.levels["passage"] == ps] for g in ("wild_type", "dbf4-1")}
        if cv["wild_type"] and cv["dbf4-1"] and min(cv["wild_type"]) <= max(cv["dbf4-1"]) and min(cv["dbf4-1"]) <= max(cv["wild_type"]):
            overlap_passages.append(f"P{ps}")
    add("sec:dbf4-signature", "fig:dbf4_signature", "passages where wild-type and dbf4-1 plate CVs overlap", "",
        ", ".join(overlap_passages) or "none", "", "Rescue", "plate_statistic: CV", ">=10 colonies")

    # ---- mixture components
    lab = "sec:mixture-structure"
    wd = [(g, p, sel[g, p]) for g in ("wild_type", "dbf4-1") for p in PASSAGES if sel[g, p] is not None and sel[g, p].components is not None]
    smallest = min(wd, key=lambda t: t[2].components[0][0])
    add(lab, "", "smallest component, selected wild-type and dbf4-1 plates", 450, _n(smallest[2].components[0][0]), "um", "Rescue",
        "component_locations", SEL, note=name(smallest[0], smallest[1]))
    edges = {(g, p): 5.0 * _scale(plate) for g, p, plate in wd}     # 10% uncertainty = a 5 px radius
    add(lab, "", "radius at the 10% fidelity boundary", 451, _n(edges[smallest[0], smallest[1]]), "um", "Rescue", "fidelity", SEL,
        note=f"5 px on the {name(smallest[0], smallest[1])} plate, which holds the smallest component; across the selected "
             f"wild-type and dbf4-1 plates {min(edges.values()):.0f} to {max(edges.values()):.0f} µm (photo resolution differs)")
    lower = [(g, p, plate.components[0][0], 50.0 * _scale(plate) / plate.components[0][0]) for g, p, plate in wd
             if plate.components[0].size > 1]
    worst = max(lower, key=lambda t: t[3])
    add(lab, "", "largest uncertainty, lower wild-type and dbf4-1 components", "", _n(worst[3], 1), "%", "Rescue", "fidelity",
        SEL, note=f"{name(worst[0], worst[1])}, component at {worst[2]:.0f} µm")
    add(lab, "", "components on each selected plate", "", ", ".join(
        f"{name(g, p)} {sel[g, p].components[0].size}" for g in GENOTYPES for p in PASSAGES
        if sel[g, p] is not None and sel[g, p].components is not None), "", "Rescue", "component_locations", SEL)
    two = [sel["dbf4-1", p] for p in PASSAGES if sel["dbf4-1", p] is not None and sel["dbf4-1", p].components[0].size > 1]
    add(lab, "", "dbf4-1 lower components, selected plates", "", _span([p.components[0][0] for p in two]), "um", "Rescue",
        "component_locations", SEL, note="plates with two components")
    add(lab, "", "dbf4-1 upper components, selected plates", "", _span([p.components[0][-1] for p in two]), "um", "Rescue",
        "component_locations", SEL, note="plates with two components; " + ", ".join(
            f"P{p} single at {sel['dbf4-1', p].components[0][0]:.0f}" for p in PASSAGES
            if sel["dbf4-1", p] is not None and sel["dbf4-1", p].components[0].size == 1))
    for g in ("cdc13-2", "dbf4-1_cdc13-2"):
        add(lab, "", f"{NAMES[g]} P3 components (weight)", "", _components_text(sel[g, "3"]), "um", "Rescue", "component_locations", SEL)
    add(lab, "", "largest component, selected cdc13-2 P5 plate", "~260", _n(c5.components[0][-1]), "um", "Rescue", "component_locations", SEL)
    add(lab, "", "smallest component, non-selected cdc13-2 P5 plates", "~100",
        _n(min(p.components[0][0] for p in others if p.components is not None)), "um", "Rescue", "component_locations")
    fitted = [p for p in c5_all if p.components is not None]
    top = max(fitted, key=lambda p: p.components[0][-1])
    passing = [p for p in fitted if p.capture >= 0.25]
    add(lab, "", "largest component, all cdc13-2 P5 plates", "below 300", _n(top.components[0][-1]), "um", "Rescue",
        "component_locations", note=f"on the {top.count}-colony plate (capture ratio {100 * top.capture:.0f}%); "
        f"largest on plates passing the capture ratio cutoff: {max(p.components[0][-1] for p in passing):.0f} µm")
    add(lab, "", "components per cdc13-2 P5 plate", "1 to 4", _span([p.components[0].size for p in fitted]), "", "Rescue",
        "component_locations")
    d5 = sel["dbf4-1_cdc13-2", "5"]
    d5_all = sorted(R.where(genotype="dbf4-1_cdc13-2", passage="5", series="main"), key=lambda p: -p.count)
    d5_others = [p for p in d5_all if p.index_id != d5.index_id and p.components is not None and p.capture >= 0.25]
    add(lab, "fig:p5-classes", "components, non-selected double P5 plates", "480 to 1450",
        _span([m for p in d5_others for m in p.components[0]]), "um", "Rescue", "component_locations",
        note="plates passing the capture ratio cutoff")
    for p in d5_all:
        if p.components is None:
            continue
        medians, weights = p.components[0], p.components[1]
        major = medians[int(np.argmax(weights))]
        kind = "single" if medians.size == 1 else f"major {major:.0f}"
        about = (f"{p.count} colonies; {kind}; capture ratio {100 * p.capture:.0f}%"
                 + ("; selected" if p.index_id == d5.index_id else "")
                 + ("; below the cutoff, not in the figure" if p.capture < 0.25 else ""))
        add(lab, "fig:p5-classes", f"double P5 plate {p.index_id} colonies", "", p.count, "colonies", "Rescue", "plate_metrics", note=about)
        add(lab, "fig:p5-classes", f"double P5 plate {p.index_id} major component", "", f"{major:.0f}", "um", "Rescue",
            "component_locations", note=about)
        for c, (m, w) in enumerate(zip(medians, weights), start=1):
            add(lab, "fig:p5-classes", f"double P5 plate {p.index_id} component {c} median", "", f"{m:.0f}", "um", "Rescue",
                "component_locations", note="components ordered by median")
            add(lab, "fig:p5-classes", f"double P5 plate {p.index_id} component {c} weight", "", f"{w:.2f}", "", "Rescue",
                "component_locations")
    for g in GENOTYPES:
        shown = sorted([p for p in R.where(genotype=g, passage="5", series="main") if p.components is not None and p.capture >= 0.25],
                       key=lambda p: (p.index_id not in R.extra["chosen"].values(), p.index_id))
        add(lab, "fig:p5-classes", f"colony counts, P5 plates in the components figure: {NAMES[g]}", "",
            ", ".join(str(p.count) for p in shown), "colonies", "Rescue", "component_locations", note="selected plate first")
    elig = eligible_main(R)
    for g in GENOTYPES:
        ps = [p.cv for p in elig if p.levels["genotype"] == g and p.levels["passage"] == "5"]
        add(lab, "", f"mean CV at P5, eligible plates: {NAMES[g]}", "", f"{np.mean(ps):.2f} ({len(ps)} plates)" if ps else "", "",
            "Rescue", "plate_statistic: CV", "capture ratio >=25%, >=50 colonies")

    chosen = set(R.extra["chosen"].values())
    faded = [p for p in R.where(series="main") if p.levels["genotype"] in ("wild_type", "dbf4-1") and p.components is not None
             and p.index_id not in chosen]
    near = [p for p in faded if any(300 <= m <= 400 for m in p.components[0])]
    passing = [p for p in near if p.capture >= 0.25]
    listing = "; ".join(f"{NAMES[p.levels['genotype']]} P{p.levels['passage']} {p.count} colonies (capture ratio "
                        f"{100 * p.capture:.0f}%)" for p in sorted(near, key=lambda p: p.count))
    add(lab, "", "fewest colonies on a faded wild-type or dbf4-1 plate with a component at 300 to 400 um", 215,
        min(p.count for p in near) if near else "--", "colonies", "Rescue", "component_locations",
        note=f"no count separates the plates: {len(near)} of {len(faded)} faded plates carry such a component ({listing}), and "
             f"{sum(p.count > (min(q.count for q in near) if near else 0) for p in faded if p not in near)} plates with more "
             "colonies carry none")
    add(lab, "", "fewest colonies on such a plate passing the capture ratio cutoff", "",
        min(p.count for p in passing) if passing else "--", "colonies", "Rescue", "component_locations",
        note="" if passing else "no such plate passes the cutoff")

    # ---- small share
    add("sec:small-share", "fig:small-share", "other double P5 plates: colony counts", "", ", ".join(
        f"{p.count}" + (f" (capture ratio {100 * p.capture:.0f}%, below the cutoff)" if p.capture < 0.25 else "")
        for p in d5_all if p.index_id != d5.index_id), "colonies", "Rescue", "plate_metrics")

    # ---- fate of the double mutant: share above the lower edge of the upper wild-type component
    edge = min(sel["wild_type", p].components[0][-1] for p in PASSAGES
               if sel["wild_type", p] is not None and sel["wild_type", p].components is not None and sel["wild_type", p].components[0].size > 1)
    small_d = sorted(R.where(genotype="dbf4-1_cdc13-2", passage="4", series="small_enriched"), key=lambda p: p.median)
    add("sec:fate-double", "", "lower edge of the upper wild-type component", 1100, _n(edge), "um", "Rescue", "component_locations", SEL)
    add("sec:fate-double", "", "share above that edge on the two small-enriched double plates", "10 and 68",
        " and ".join(_pct(p.share_above(edge)) for p in small_d), "%", "Rescue", f"threshold_share (above {edge:.0f}, colonies)")

    # ---- captions
    add("captions", "fig:rescue_selected_plates", "largest colony radius, selected cdc13-2 P5 plate", "below 300",
        _n(c5.radii_um.max()), "um", "Rescue", "colony radii", SEL)


def _validation(rows, C, A, H, fidelity) -> None:
    """The numbers the validation figures show (QuantaColony Validation part)."""
    add = rows.add
    order = sorted(C.plates.values(), key=lambda p: float(p.levels["dilution_level"]))
    for p in order:
        dil = int(float(p.levels["dilution_level"]))
        lab = "validation crowding box"
        add(lab, "Crowding_Box", f"{dil}X: colonies", "", p.count, "colonies", "Crowding", "box")
        add(lab, "Crowding_Box", f"{dil}X: median radius", "", _n(p.median), "um", "Crowding", "box")
        lab = "validation crowding photos"
        add(lab, "Crowding_Photos", f"{dil}X: capture ratio", "", _pct(p.capture, 1), "%", "Crowding", "plate_metrics")
        add(lab, "Crowding_Photos", f"{dil}X: HCE", "", _n(p.hce), "cells", "Crowding", "annotation")
    for project, result in fidelity.items():
        if not result:
            continue
        overall = float(result["overall"])
        add(f"validation {project} fidelity", f"{project}_Fidelity", "median uncertainty, every colony", "", _n(overall, 1), "%",
            project, "fidelity", note=f"{len(result['uncertainty'])} colonies")
        add(f"validation {project} fidelity", f"{project}_Fidelity", "median colony area", "", _n(np.pi * (50.0 / overall) ** 2), "px",
            project, "fidelity")
        add(f"validation {project} fidelity", f"{project}_Fidelity", "median colony category", "", _category(overall), "",
            project, "fidelity")
    def plate_rows(lab, fig, project, label, p, why):
        """Colonies, median radius (one decimal) and capture ratio of one plate, or "--" with the reason."""
        values = ((p.count, _n(p.median, 1) if p.count else MISSING, _pct(p.capture, 1)) if p is not None
                  else (MISSING,) * 3)
        note = "" if p is not None else why
        if p is not None and not p.count:
            note = "no colonies, so no median"
        for what, value, unit, analysis in (("colonies", values[0], "colonies", "box"), ("median radius", values[1], "um", "box"),
                                            ("capture ratio", values[2], "%", "plate_metrics")):
            add(lab, fig, f"{label}: {what}", "", value, unit, project, analysis, note=note)

    names = A.extra["displays"]["genotype"]
    for figure in ("2C", "8D"):
        shown = [g for g in names if A.where(genotype=g, source_figure=figure)]
        for g in shown:
            for passage in A.extra["order"]["passage"]:
                found = A.where(genotype=g, passage=passage, source_figure=figure)
                plate_rows("validation anbalagan boxes", "Anbalagan_Boxes", "Anbalagan",
                           f"Figure {figure} {names.get(g, g)} passage {passage}", found[0] if found else None,
                           f"Figure {figure} shows no plate of this genotype at this passage")
    names = H.extra["displays"]["genotype"]
    for g in names:
        for passage in H.extra["order"]["passage"]:
            found = H.where(genotype=g, passage=passage)
            plate_rows("validation historical", "Historical_Boxes", "Historical", f"{names.get(g, g)} passage {passage}",
                       found[0] if found else None, "the source paper shows no plate of this genotype at this passage")


def _category(uncertainty: float) -> str:
    from ..core import stats as st
    return ("High", "Good", "Moderate", "Low", "Sub-pixel")[st.zone_of(uncertainty)] if np.isfinite(uncertainty) else ""


def _colony_coverage(model, plate) -> float:
    return float(model.extra.get("colony_coverage", {}).get(plate.index_id, np.nan))


def write(rows: list[list], root: Path) -> dict:
    """One CSV and one .tex per part, in that part's folder: {part: (csv path, tex path)}.

    The .tex defines \\val{key} (only once, so the parts can be loaded together) and one value per key."""
    out = {}
    def escape(s):
        if re.fullmatch(r"\d(\.\d+)? \\times 10\^\{-?\d+\}", s):             # a LaTeX-ready p-value
            return s
        return (s.replace("\\", r"\textbackslash{}").replace("%", r"\%").replace("µm", r"\textmu m")
                .replace("~", r"$\sim$").replace("<=", r"$\leq$").replace("_", r"\_").replace("&", r"\&")
                .replace("^", r"\textasciicircum{}").replace("#", r"\#"))
    for part, folder_name in PARTS.items():
        mine = [r for r in rows if r[1] == part]
        folder = root / folder_name / "Data"
        folder.mkdir(parents=True, exist_ok=True)
        stem = folder_name.lower()
        csv_path, tex_path = folder / f"{stem}_values.csv", folder / f"{stem}_values.tex"
        with open(csv_path, "w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(COLUMNS)
            writer.writerows(mine)
        with open(tex_path, "w", encoding="utf-8") as handle:
            handle.write(f"% Generated by QuantaColony ({folder_name}). \\val{{key}} gives the value Python computed for the row\n"
                         f"% of {csv_path.name} with that key, for example \\val{{{mine[0][0] if mine else part + '.key'}}}.\n"
                         "\\makeatletter\n\\providecommand{\\val}[1]{\\@ifundefined{qcval@#1}"
                         "{\\textbf{??#1??}}{\\@nameuse{qcval@#1}}}\n")
            for row in mine:
                handle.write(f"\\@namedef{{qcval@{row[0]}}}{{{escape(row[6])}}}% {row[4]}\n")
            handle.write("\\makeatother\n")
        out[part] = (csv_path, tex_path)
    return out


# ======================================================================================
# QuantaColony methods chapter (ch:quantacolony)
# ======================================================================================
CAPTURE_DEFINITION = (
    "The Capture Ratio is the share of a plate's growth that lies in growth pieces holding exactly one "
    "separately detected colony: growth pixels are grouped into 8-connected pieces, a colony belongs to the "
    "piece under its center, a piece counts as captured when it holds exactly one colony and that colony was "
    "not cut from a blob of touching colonies, and the captured pixels are divided by all growth pixels.")
CAPTURE_NOTES = {
    "connectivity": ("8", "pixels touching at an edge or a corner join one piece (core.growth.captured_growth)"),
    "split_blob": ("merged", "a piece holding two or more colonies is merged growth, and so is a piece whose one colony "
                   "was split from touching colonies"),
    "lawn_contact": ("captured", "a colony connected to an unmarked lawn makes the whole piece, lawn included, captured "
                     "when it is the only colony in the piece; the piece is merged once it holds a second colony"),
    "mask_closing": ("none", "pieces are labelled on the growth mask as classified: no dilation or closing before "
                     "labelling. The mask's own clean-up removes thin parts with an opening and restores their edges "
                     "within the kept growth, so it never joins two separate pieces"),
    "empty_piece": ("merged", "a growth piece holding no colony counts in the denominator only"),
}
CROWDING_TEXT = {
    "weight_formula": "w(d) = 1 / (1 + (d / r)^2)",
    "weight_text": ("Each pixel within three radii of the colony boundary carries the weight 1 / (1 + (d/r)^2), "
                    "with d its distance from the boundary and r the colony radius: 1 at the boundary, one half one "
                    "radius out, and one tenth at three radii."),
    "competitor_mask_text": ("Competitor growth is the plate's Growth Coverage mask with the focal colony's own pixels "
                             "removed, so a colony is never its own competitor."),
    "boundary_text": ("Distances are measured from the colony's traced outline where detection traced one, and from "
                      "its fitted circle otherwise; pixels inside the colony carry no weight."),
    "score_text": "The score is the weighted share of the zone that competitor growth covers, from 0 to 100.",
}


def _methods(rows, fidelity: dict, methods: dict) -> None:
    def put(section, name, value, note="", unit="", project="", analysis=""):
        value = MISSING if value is None or value == "" or (isinstance(value, float) and not np.isfinite(value)) else value
        rows.add(f"quantacolony {section}", "", name.replace("_", " "), "", value, unit, project, analysis, "", note,
                 key=f"quantacolony.{section}.{name}")

    # A: the capture ratio
    put("capture", "definition_text", CAPTURE_DEFINITION, "what core.growth computes (GROWTH_VERSION 5)")
    for name, (value, note) in CAPTURE_NOTES.items():
        put("capture", name, value, note)
    put("capture", "separable_cutoff_pct", 25, "SEPARABLE_CAPTURE_RATIO")

    # B: the growth classifier on the dilution series
    held = methods.get("heldout", [])
    recall = [h["colony_recall"] for h in held if np.isfinite(h["colony_recall"])]
    false_pos = [h["agar_false_positive"] for h in held if np.isfinite(h["agar_false_positive"])]
    put("growth", "plates", len(held), "the ten dilution-series plates")
    put("growth", "recall_min_pct", f"{100 * min(recall):.1f}" if recall else None,
        "share of withheld colony pixels classified as growth, worst plate")
    put("growth", "recall_max_pct", f"{100 * max(recall):.1f}" if recall else None, "best plate")
    put("growth", "agar_called_growth_max_pct", f"{100 * max(false_pos):.2f}" if false_pos else None,
        "share of confident agar pixels classified as growth, worst plate")
    put("growth", "folds", 3, "colonies split at random into three folds; each fold is withheld from the labels once")
    put("growth", "withheld_share_pct", f"{100 / 3:.1f}",
        "each run withholds one third of the plate's accepted colonies; every colony is withheld once")
    put("growth", "agar_truth_text",
        "Agar truth is every growable pixel more than 6 px from any accepted colony, on the agar side of the "
        "midpoint between the plate's agar and growth colors, and within 1.5 noise units of the local agar level "
        "in all three Lab channels.", "core.growth.held_out_check")
    for h in held:
        tag = slug(h["name"]) + "x"
        put("growth", f"recall_pct_{tag}", f"{100 * h['colony_recall']:.1f}", f"{h['colonies']} accepted colonies")
        put("growth", f"agar_called_growth_pct_{tag}", f"{100 * h['agar_false_positive']:.2f}")

    # C: the detection output figure (detection is unchanged; counts from the saved result)
    kinds = methods.get("output_plate", {})
    note = "saved detection (unchanged); automatic = detected, hand-added = added in review, split = cut from touching blobs"
    put("output", "plate_name", kinds.get("label"), "Anbalagan Figure 2C, wild type, 25 generations")
    put("output", "automatic", kinds.get("automatic"), note)
    put("output", "hand_added", kinds.get("manual"), note)
    put("output", "split_pieces", kinds.get("split"), note)
    put("output", "total", kinds.get("total"), "equals the plate's colony count")
    put("output", "figure_note", "Detection is unchanged, so ProcessReview.pdf is not regenerated; the caption's counts "
        "should name this plate.")

    # D: timing (not re-recorded: detection is unchanged)
    for name in ("min_s", "max_s", "median_s", "total_s", "colonies", "s_per_colony"):
        put("timing", name, None, "detection is unchanged: keep the original run's value (683 colonies)")

    # E: measurement fidelity
    put("fidelity", "panels", "A and B", "the export draws A (pooled histogram) and B (grid); the in-app "
        "analysis adds a text panel C")
    put("fidelity", "cell_text", "median uncertainty and median colony area in px, with the category",
        "the full-series grid also gives n plates")
    put("fidelity", "low_count_list", "in-app only", "the in-app panel C lists cells with fewer than 20 colonies; "
        "the exported figures do not")
    from ..core import stats as st
    for dataset, result in fidelity.items():
        if not result:
            continue
        tag = slug(dataset)
        medians, areas, counts = result["medians"], result["areas"], result["grid_counts"]
        categories = {z: 0 for z in range(5)}
        no_data = 0
        for r, row in enumerate(result["rows"]):
            for c, column in enumerate(result["columns"]):
                cell = f"{slug(str(row))}" + ("" if str(column) == "All" else f"_p{slug(str(column))}")
                value = medians[r, c]
                empty = not np.isfinite(value)
                no_data += empty
                if not empty:
                    categories[st.zone_of(value)] += 1
                why = "no colonies in this set" if empty else ""
                put(f"fidelity_{tag}", f"{cell}_area_px", None if empty else f"{areas[r, c]:.0f}", why)
                put(f"fidelity_{tag}", f"{cell}_uncertainty_pct", None if empty else f"{value:.1f}", why)
                put(f"fidelity_{tag}", f"{cell}_category", None if empty else _category(value), why)
                put(f"fidelity_{tag}", f"{cell}_colonies", int(counts[r, c]))
                put(f"fidelity_{tag}", f"{cell}_no_data", "yes" if empty else "no")
        put(f"fidelity_{tag}", "sets", medians.size)
        put(f"fidelity_{tag}", "sets_no_data", no_data)
        for z, zone in enumerate(("high", "good", "moderate", "low", "subpixel")):
            put(f"fidelity_{tag}", f"sets_{zone}", categories[z])
            put(f"fidelity_{tag}", f"colonies_{zone}_pct", f"{result['pct'][z]:.1f}")
        u = np.asarray(result["uncertainty"], float)
        put(f"fidelity_{tag}", "colonies", u.size)
        put(f"fidelity_{tag}", "smallest_radius_px", f"{50.0 / u.max():.2f}" if u.size else None)
        put(f"fidelity_{tag}", "smallest_radius_uncertainty_pct", f"{u.max():.1f}" if u.size else None)
    for name in ("est1_1_p2_radius_px", "est1_1_p2_category", "tlc1_p2_radius_px", "tlc1_p2_category"):
        put("pixel_fidelity", name, None, "detection is unchanged, so Pixel_Fidelity.pdf and its example colonies stand "
            "as drawn")

    # F: settings and calibration
    from ..core.params import DetectionParams
    defaults = DetectionParams()
    put("settings", "split_elongation", f"{defaults.split_elongation:.2f}", "split above elongation (eccentricity)")
    put("settings", "split_pinch", f"{defaults.split_pinch:.2f}", "minimum pinch, share of the blob's widest half-width")
    put("settings", "crop_px_per_mm", f"{methods['crop_px_per_mm']:.2f}" if methods.get("crop_px_per_mm") else None,
        "Anbalagan Figure 2C, 100 generations (every 2C photo at 100 generations shares this scale)")
    put("settings", "crop_dish_mm", None, "the Anbalagan photos carry the scale of the MATLAB composite; no dish "
        "diameter is stored with them")

    # G: the crowding score
    for name, text in CROWDING_TEXT.items():
        put("crowding_score", name, text, "core.crowding")
    put("crowding_score", "zone_radii", 3, "the zone reaches this many radii past the boundary")
    put("crowding_score", "box_radii", 8, "the zone is computed in a box this many radii wide")
