"""The dissertation's data figures, drawn to the house style at their printed size (view).

Every builder takes the computed models (dissertation.model) and returns a Figure. Builders place their
axes in inches, so the sizes in the file are the printed sizes: 6.0 in wide or less, labels 7 pt or more.
Panel letters follow the dissertation captions.
"""

from __future__ import annotations

import numpy as np
from matplotlib.collections import PatchCollection
from matplotlib.lines import Line2D
from matplotlib.patches import Circle, Polygon, Rectangle

from ..core import stats as st
from . import style as S
from .model import GENOTYPES, PASSAGES, SMALL, eligible_main, selected

ZONE_COLORS = ("#9BD69B", "#D6EDA0", "#FBE7A1", "#F8C9A0", "#F0A6A6")
ZONE_NAMES = ("High", "Good", "Moderate", "Low", "Sub-pixel")
OUTLINE = "#E040C8"
GRAY = "#9A9A9A"
WT_BAND = (1100.0, 1500.0)
CROWDING_COLOR, CROWDING_NAME = "#6B4C9A", "Crowding Dataset"                      # upper wild-type component band (µm)


class Sheet:
    """A figure with axes placed in inches from its top-left corner."""

    def __init__(self, height: float, width: float = S.TEXT_WIDTH):
        self.figure = S.new_figure(height, width)
        self.w, self.h = width, height

    def axes(self, x: float, top: float, width: float, height: float, **kw):
        return self.figure.add_axes((x / self.w, 1 - (top + height) / self.h, width / self.w, height / self.h), **kw)

    def text(self, x: float, top: float, text: str, **kw):
        kw.setdefault("fontsize", S.MIN_PT)
        return self.figure.text(x / self.w, 1 - top / self.h, text, **kw)

    def heading(self, x: float, top: float, letter: str, title: str):
        return self.text(x, top, f"({letter}) " + S.label(title), fontsize=S.HEAD_PT, fontweight="bold",
                         va="top", ha="left")


# ======================================================================================
# shared panels
# ======================================================================================
def photo(ax, pic: dict | None, scale_mm: float = 10.0, outline: bool = True) -> None:
    ax.set_axis_off()
    if pic is None:
        ax.text(0.5, 0.5, "no growth", ha="center", va="center", fontsize=S.MIN_PT, transform=ax.transAxes,
                color="white")
        ax.add_patch(Rectangle((0, 0), 1, 1, transform=ax.transAxes, facecolor="#111111", zorder=-1))
        return
    image = pic["image"].copy()
    image[~pic["region"]] = (image[~pic["region"]] * 0.15).astype(image.dtype)
    ax.imshow(image, interpolation="antialiased")
    if outline and pic["outlines"]:
        patches = [Polygon(o, closed=True) if kind == "polygon" else Circle(o[0], o[1]) for kind, o in pic["outlines"]]
        ax.add_collection(PatchCollection(patches, facecolor="none", edgecolor=OUTLINE, linewidth=0.35))
    rows, cols = image.shape[:2]
    bar = scale_mm * pic["px_per_mm"]
    ax.add_patch(Rectangle((cols * 0.06, rows * 0.93), bar, rows * 0.012, facecolor="white", edgecolor="none"))
    ax.set_xlim(0, cols)
    ax.set_ylim(rows, 0)


def value_rows(sheet: Sheet, x_label: float, x_center: float, top: float, rows: list, values: list) -> None:
    """Row captions at x_label (right-aligned) and the plate's values centered under its photo."""
    for k, (caption, text) in enumerate(zip(rows, values)):
        y = top + k * 0.13
        if caption is not None:
            sheet.text(x_label, y, caption, ha="right", va="top", color="#444444")
        sheet.text(x_center, y, text, ha="center", va="top")


def fmt_um(value: float) -> str:
    return f"{value:.0f} µm"


def fmt_pct(value: float) -> str:
    return f"{100 * value:.1f}%"


def fidelity_pair(sheet: Sheet, result: dict, top: float, row_labels=None, column_title: str = "Passage",
                  per_plate_n: bool = False, height_a: float = 1.55, cell_h: float = 0.36) -> float:
    """(A) pooled uncertainty histogram and (B) the per-cell grid; returns the bottom (in)."""
    uncertainty = np.asarray(result["uncertainty"], float)
    ax = sheet.axes(0.55, top + 0.42, 5.2, height_a)
    x_max = min(100.0, max(60.0, np.ceil(uncertainty.max() / 10) * 10)) if uncertainty.size else 60.0
    edges = list(st.ZONE_EDGES[:-1]) + [x_max]
    for z in range(5):
        ax.axvspan(edges[z], edges[z + 1], color=ZONE_COLORS[z], lw=0, zorder=0)
    bins = np.arange(0, x_max + 1, 1.0)
    counts, _ = np.histogram(np.minimum(uncertainty, x_max - 0.5), bins=bins)
    share = counts / max(1, counts.sum()) * 100
    ax.bar(bins[:-1] + 0.5, share, width=0.9, color="#333333", zorder=2)
    overall = float(result["overall"])
    ax.axvline(overall, color="#C0392B", lw=1.0, zorder=3)
    ax.set_xlim(0, x_max)
    ax.set_xlabel("Measurement uncertainty (% of colony radius)")
    ax.set_ylabel("Colonies (%)")
    top_axis = ax.secondary_xaxis("top")
    boundary = [5, 10, 25, 50]
    top_axis.set_xticks(boundary, [f"{np.pi * (50 / b) ** 2:.0f}" for b in boundary])
    top_axis.set_xlabel("Colony area at category boundary (px)", fontsize=S.MIN_PT)
    top_axis.tick_params(labelsize=S.MIN_PT)
    sheet.heading(0.05, top, "A", "Pooled uncertainty")
    area = np.pi * (50.0 / overall) ** 2 if overall > 0 else np.nan
    handles = [Rectangle((0, 0), 1, 1, color=c) for c in ZONE_COLORS] + [Line2D([], [], color="#C0392B", lw=1.0)]
    labels = ["High (0–5%)", "Good (5–10%)", "Moderate (10–25%)", "Low (25–50%)", "Sub-pixel (>50%)",
              f"Median colony: {overall:.1f}%, {area:.0f} px"]
    y_leg = top + 0.42 + height_a + 0.36
    sheet.figure.legend(handles, labels, loc="upper center", bbox_to_anchor=(0.5, 1 - y_leg / sheet.h), ncol=3,
                        fontsize=S.MIN_PT, frameon=False, handlelength=1.2, columnspacing=1.2)
    # (B) the grid
    top_b = y_leg + 0.42
    sheet.heading(0.05, top_b, "B", "Mean of per-plate median uncertainty" if result["per_plate"]
                  else "Median uncertainty per group")
    medians, areas = result["medians"], result["areas"]
    rows, columns = medians.shape
    names = row_labels or list(result.get("row_labels", result.get("rows", [])))
    left = 1.25 if max((len(str(n)) for n in names), default=0) < 18 else 1.6
    width = min(5.85 - left, 1.2 * columns)
    if width < 5.85 - left:                      # a narrow grid sits centered, its row labels included
        left = (S.TEXT_WIDTH - width) / 2 + (left - 0.15) / 2
    grid = sheet.axes(left, top_b + 0.55, width, cell_h * rows)
    grid.set_xlim(0, columns)
    grid.set_ylim(rows, 0)
    grid.set_axis_off()
    for c, title in enumerate(result.get("columns", [])):
        grid.annotate(str(title), (c + 0.5, 0), xytext=(0, 2), textcoords="offset points", ha="center", va="bottom",
                      fontsize=S.MIN_PT)
    if column_title:
        sheet.text(left + width / 2, top_b + 0.22, column_title, ha="center", va="top")
    for r in range(rows):
        grid.text(-0.06, r + 0.5, S.label(str(names[r])), ha="right", va="center", fontsize=S.MIN_PT)
        for c in range(columns):
            value = medians[r, c]
            if np.isfinite(value):
                zone = st.zone_of(value)
                grid.add_patch(Rectangle((c + 0.02, r + 0.04), 0.96, 0.92, facecolor=ZONE_COLORS[zone], lw=0))
                n = f", n = {int(result['plates'][r, c])}" if per_plate_n else ""
                grid.text(c + 0.5, r + 0.5, f"{value:.1f}%, {areas[r, c]:.0f} px", ha="center", va="bottom",
                          fontsize=S.MIN_PT)
                grid.annotate(ZONE_NAMES[zone] + n, (c + 0.5, r + 0.5), xytext=(0, -1.5), textcoords="offset points",
                              ha="center", va="top", fontsize=S.MIN_PT, style="italic")
            else:
                grid.add_patch(Rectangle((c + 0.02, r + 0.04), 0.96, 0.92, facecolor="#EEEEEE", lw=0))
                grid.text(c + 0.5, r + 0.5, "no data", ha="center", va="center", fontsize=S.MIN_PT, color="#777777")
    return top_b + 0.55 + cell_h * rows


def numbers_above(ax, positions, cells, first: bool) -> None:
    """Colony count (n) and median radius above each box, two rows over the axes."""
    from matplotlib.transforms import blended_transform_factory
    mark = blended_transform_factory(ax.transData, ax.transAxes)
    rows = ((13.0, lambda v: f"{len(v)}"), (3.0, lambda v: f"{np.median(v):.0f}" if len(v) else "–"))
    for x, values in zip(positions, cells):          # fixed offsets in points: rows never touch
        for rise, text in rows:
            ax.annotate(text(values), (x, 1.0), xycoords=mark, xytext=(0, rise), textcoords="offset points",
                        ha="center", va="bottom", fontsize=S.MIN_PT, annotation_clip=False)
    if first:
        for rise, caption, style in ((13.0, "n", "italic"), (3.0, "Median (µm)", "normal")):
            ax.annotate(caption, (0, 1.0), xycoords="axes fraction", xytext=(-4, rise), textcoords="offset points",
                        ha="right", va="bottom", fontsize=S.MIN_PT, style=style, annotation_clip=False)


def box(ax, values, x: float, color: str, width: float = 0.6) -> None:
    if len(values) == 0:
        return
    q1, med, q3 = np.percentile(values, [25, 50, 75])
    iqr = q3 - q1
    inside = values[(values >= q1 - 1.5 * iqr) & (values <= q3 + 1.5 * iqr)]
    lo, hi = (inside.min(), inside.max()) if inside.size else (q1, q3)
    ax.add_patch(Rectangle((x - width / 2, q1), width, q3 - q1, facecolor=color, alpha=0.45, edgecolor=color, lw=0.7))
    ax.plot([x, x], [lo, q1], color=color, lw=0.7)
    ax.plot([x, x], [q3, hi], color=color, lw=0.7)
    out = values[(values < lo) | (values > hi)]
    ax.plot(np.full(out.size, x), out, ".", color=color, ms=1.6, alpha=0.8)
    ax.plot([x - width / 2, x + width / 2], [med, med], color="#222222", lw=0.8)
    ax.plot(x, med, "o", mfc="white", mec=color, ms=2.8, mew=0.8, zorder=4)


def violin(ax, values, x: float, color: str, width: float = 0.7) -> None:
    from ..core.stats import kde
    values = np.asarray(values, float)
    if values.size < 50:
        box(ax, values, x, color, width=0.45)
        return
    logs = np.log10(values)
    grid = np.linspace(logs.min() - 0.05, logs.max() + 0.05, 160)
    h = 0.9 * min(np.std(logs), (np.percentile(logs, 75) - np.percentile(logs, 25)) / 1.34) * values.size ** -0.2
    density = kde(logs, grid, max(h, 1e-3))
    half = density / density.max() * width / 2
    ax.fill_betweenx(10 ** grid, x - half, x + half, facecolor=color, alpha=0.45, edgecolor=color, lw=0.6)
    q1, med, q3 = np.percentile(values, [25, 50, 75])
    ax.plot([x, x], [q1, q3], color="#222222", lw=1.4)
    ax.plot(x, med, "o", mfc="white", mec="#222222", ms=2.8, mew=0.7, zorder=4)


def components(ax, plates: list, x0: float, color: str, scale: float = 26.0, outline=()) -> list:
    """One column of mixture components per plate: circle area follows component weight."""
    xs = []
    for k, plate in enumerate(plates):
        x = x0 + k
        xs.append(x)
        if plate.components is None:
            continue
        medians, weights, p25, p75 = plate.components
        for m, w, a, b in zip(medians, weights, p25, p75):
            ax.plot([x, x], [a, b], color=color, lw=0.6, alpha=0.8)
            ax.scatter([x], [m], s=scale * w * 4, facecolor=color, edgecolor="black" if plate.index_id in outline else color,
                       linewidth=0.9 if plate.index_id in outline else 0.4, alpha=0.85, zorder=3)
    return xs


def overlap(a, b) -> float:
    from types import SimpleNamespace
    from ..analyses.builtin.subpopulations import ComponentLocations
    pack = lambda p: SimpleNamespace(component_medians=p.components[0], component_weights=p.components[1],
                                     component_p25=p.components[2], component_p75=p.components[3])
    return float(ComponentLocations.overlap(pack(a), pack(b)))


def genotype_legend(sheet: Sheet, keys, y_in: float, extra=()) -> None:
    handles, labels = [], []
    for key in keys:
        name, color, marker = S.genotype(key)
        handles.append(Line2D([], [], color=color, marker=marker, lw=0.9, ms=3.5))
        labels.append(name)
    for handle, text in extra:
        handles.append(handle)
        labels.append(text)
    sheet.figure.legend(handles, labels, loc="upper center", bbox_to_anchor=(0.5, 1 - y_in / sheet.h),
                        ncol=len(labels), fontsize=S.MIN_PT, frameon=False, handlelength=1.6, columnspacing=1.2)


# ======================================================================================
# Crowding Dataset
# ======================================================================================
def crowding_box(C) -> object:
    """Figure 10.1: colony radius per dilution plate."""
    sheet = Sheet(2.6)
    ax = sheet.axes(0.95, 0.42, 4.95, 1.75)
    order = sorted(C.plates.values(), key=lambda p: float(p.levels["dilution_level"]))
    cells = [p.radii_um for p in order]
    for k, values in enumerate(cells):
        box(ax, values, k + 1, "#2F6DB5")
    ax.set_xlim(0.4, len(order) + 0.6)
    ax.set_ylim(150, 2600)
    S.log_radius_axis(ax)
    ax.set_xticks(range(1, len(order) + 1), [f"{int(float(p.levels['dilution_level']))}" for p in order])
    ax.set_xlabel("Dilution factor (×)")
    S.mu_axis(ax)
    numbers_above(ax, range(1, len(order) + 1), cells, True)
    return sheet.figure


def crowding_photos(C, pictures) -> object:
    """Figure 10.2: every Crowding Dataset plate with its detected colonies, colony count, capture ratio, HCE.
    Two columns of five plates; each plate's values sit beside its photo."""
    sheet = Sheet(8.35)
    order = sorted(C.plates.values(), key=lambda p: float(p.levels["dilution_level"]))
    size, pitch = 1.4, 1.65
    for k, plate in enumerate(order):
        col, row = k // 5, k % 5
        x, top = 0.1 + col * 3.0, 0.05 + row * pitch
        sheet.text(x + size / 2, top, f"Dilution {int(float(plate.levels['dilution_level']))}×", ha="center", va="top")
        photo(sheet.axes(x, top + 0.17, size, size), pictures.get(("crowding", plate.index_id)))
        lines = [("Colonies", f"{plate.count}"), ("Capture ratio", fmt_pct(plate.capture)),
                 ("HCE", f"{plate.hce:,.0f}")]
        for j, (caption, value) in enumerate(lines):
            y = top + 0.17 + size / 2 - 0.2 + j * 0.15
            sheet.text(x + size + 0.12, y, caption, ha="left", va="top", color="#444444")
            sheet.text(x + size + 1.35, y, value, ha="right", va="top")
    return sheet.figure


def foreground_overlay(pic, growth) -> np.ndarray:
    """The growth mask in red over the grayscale plate, colony outlines in blue: an RGB array (PNG)."""
    from PIL import Image, ImageDraw
    gray = np.asarray(Image.fromarray(pic["image"]).convert("L"), float)
    rgb = np.stack([gray] * 3, -1)
    rgb[~pic["region"]] *= 0.3
    mask = np.asarray(Image.fromarray(growth.astype(np.uint8) * 255).resize(gray.shape[::-1], Image.NEAREST)) > 0
    rgb[mask] = 0.35 * rgb[mask] + 0.65 * np.array([225, 40, 40])
    out = Image.fromarray(rgb.clip(0, 255).astype(np.uint8))
    draw = ImageDraw.Draw(out)
    for kind, o in pic["outlines"]:
        if kind == "polygon":
            draw.line([tuple(p) for p in o] + [tuple(o[0])], fill=(40, 90, 230), width=2)
        else:
            (cx, cy), r = o
            draw.ellipse((cx - r, cy - r, cx + r, cy + r), outline=(40, 90, 230), width=2)
    return np.asarray(out)


def representative(C, R, pictures) -> object:
    """Figure (ch. crowding control): two Crowding Dataset plates and two Rescue Dataset plates."""
    sheet = Sheet(2.75)
    crowd = {int(float(p.levels["dilution_level"])): p for p in C.plates.values()}
    plates = [("A", "crowding", crowd[500], "500×"), ("A", "crowding", crowd[16000], "16000×"),
              ("B", "rescue", selected(R, "wild_type", "1"), "Wild type P1"),
              ("B", "rescue", selected(R, "cdc13-2", "3"), "cdc13-2 P3")]
    size = 1.08
    sheet.heading(0.05, 0.05, "A", "Crowding Dataset")
    sheet.heading(3.18, 0.05, "B", "Rescue Dataset")
    for k, (_, project, plate, title) in enumerate(plates):
        x = 0.95 + k * 1.2 + (0.18 if k >= 2 else 0)
        sheet.text(x + size / 2, 0.30, S.label(title), ha="center", va="top")
        photo(sheet.axes(x, 0.44, size, size), pictures.get((project, plate.index_id)))
        value_rows(sheet, 0.88 if k == 0 else x - 0.1, x + size / 2, 0.44 + size + 0.06,
                   ["Colonies", "Median radius", "HCE"] if k == 0 else [None] * 3,
                   [f"{plate.count}", fmt_um(plate.median), f"{plate.hce:,.0f}"])
    return sheet.figure


def within_state(result) -> object:
    """Within-state fits of the four candidate predictors, in the layout of the original MATLAB figure: a
    centered bold title over each panel, the fit statistics boxed in the upper left, a grid, the slope -1/3
    reference in A and B, one filled circle per plate (A to C) and one open circle per colony (D), colored by
    genotype with the Crowding Dataset in its own color, and one legend row beneath."""
    sheet = Sheet(5.05)
    fits = result["fits"]
    plate_group = _within_groups(result.get("plate_states", []))
    colony_group = _within_groups(result.get("colony_states", []))
    spec = [("A", "HCE", "HCE (centered, log)", 1.0, True), ("B", "Colony count", "Colony count (centered, log)", 1.0, True),
            ("C", "Growth coverage", "Growth coverage (centered, linear)", 100.0, False),
            ("D", "Crowding score", "Crowding score (centered, linear)", 100.0, False)]
    for k, (letter, name, xlabel, unit, reference) in enumerate(spec):
        col, row = k % 2, k // 2
        x, top = 0.62 + col * 2.82, 0.2 + row * 2.45
        ax = sheet.axes(x, top, 2.33, 1.72)
        fit = fits.get(name)
        if fit is None:
            continue
        sheet.text(x + 2.33 / 2, top - 0.04, f"({letter}) {name}", ha="center", va="bottom", fontweight="bold",
                   fontsize=S.HEAD_PT)
        ax.grid(True, color="#D9D9D9", lw=0.4, zorder=0)
        ax.axhline(0, color="#9A9A9A", lw=0.5, zorder=1)
        ax.axvline(0, color="#9A9A9A", lw=0.5, zorder=1)
        xs = fit.x * unit
        groups = colony_group if fit.level == "colony" else plate_group
        for key, color in WITHIN_COLORS.items():
            rows = groups == key
            if not rows.any():
                continue
            if fit.level == "colony":
                ax.scatter(xs[rows], fit.y[rows], s=2.2, facecolors="none", edgecolors=color, linewidths=0.3, zorder=2,
                           rasterized=False)
            else:
                ax.scatter(xs[rows], fit.y[rows], s=11, c=color, edgecolors="none", zorder=3)
        slope = fit.slope / unit
        line = np.array([np.nanmin(xs), np.nanmax(xs)])
        ax.plot(line, slope * line, color="#262626", lw=1.3, zorder=4)
        if reference:
            ax.axline((0, 0), slope=-1 / 3, color=WITHIN_COLORS["cdc13-2"], lw=0.9, ls="--", zorder=3)
        ax.set_xlim(*_pad(xs))
        ax.set_ylim(*_pad(fit.y))
        n_states = len(set((result.get("colony_states") if fit.level == "colony" else result.get("plate_states")) or []))
        first = f"slope = {slope:.3f}" + (" (ref −0.333)" if reference else "")
        ax.text(0.03, 0.97, f"{first}\nR² = {fit.r2:.3f}, n = {fit.n}, states = {n_states}".replace("-", "−"),
                transform=ax.transAxes, ha="left", va="top", fontsize=S.MIN_PT, zorder=6, linespacing=1.3,
                bbox={"facecolor": "white", "edgecolor": "#262626", "linewidth": 0.6, "pad": 2.5})
        for side in ("top", "right"):
            ax.spines[side].set_visible(True)
        ax.set_xlabel(xlabel)
        ax.set_ylabel("radius (centered, log)" if fit.level == "colony" else "median radius (centered, log)")
    handles = [Line2D([], [], marker="o", color=c, lw=0, ms=4) for c in WITHIN_COLORS.values()]
    names = [S.genotype(k)[0] if k != "Crowding" else "Wild type, Crowding Dataset" for k in WITHIN_COLORS]
    sheet.figure.legend(handles, names, loc="upper center", bbox_to_anchor=(0.5, 1 - 4.82 / sheet.h), ncol=5,
                        fontsize=S.MIN_PT, frameon=False, columnspacing=1.4, handletextpad=0.3)
    return sheet.figure


WITHIN_COLORS = {"wild_type": "#0072BD", "dbf4-1": "#77AC30", "cdc13-2": "#D95319", "dbf4-1_cdc13-2": "#7E2F8E",
                 "Crowding": "#1A9E8F"}           # the original figure's MATLAB colors


def _within_groups(states) -> np.ndarray:
    """Genotype key of each state ('wild_type P2' -> 'wild_type'); the Crowding Dataset is its own group."""
    return np.array(["Crowding" if st == "Crowding" else st.rsplit(" P", 1)[0] for st in states])


def _pad(values, share=0.05) -> tuple:
    values = np.asarray(values, float)
    values = values[np.isfinite(values)]
    lo, hi = float(values.min()), float(values.max())
    pad = (hi - lo) * share or 0.1
    return lo - pad, hi + pad

def selected_p5(R, pictures) -> object:
    sheet = Sheet(1.8)
    size = 1.1
    for k, g in enumerate(GENOTYPES):
        plate = selected(R, g, "5")
        x = 0.95 + k * 1.25
        sheet.text(x + size / 2, 0.05, S.genotype(g)[0], ha="center", va="top")
        photo(sheet.axes(x, 0.2, size, size), pictures.get(("rescue", plate.index_id)) if plate else None)
        if plate:
            value_rows(sheet, 0.88 if k == 0 else x - 0.1, x + size / 2, 0.2 + size + 0.06,
                       ["Colonies", "Median radius", "Capture ratio"] if k == 0 else [None] * 3,
                       [f"{plate.count}", fmt_um(plate.median), fmt_pct(plate.capture)])
    return sheet.figure


def bimodality(R, pictures) -> object:
    """Two colony classes at passage 3: photos with an example of each class, and each plate's density."""
    from .model import density_peaks
    sheet = Sheet(4.4)
    for k, g in enumerate(("cdc13-2", "dbf4-1_cdc13-2")):
        plate = selected(R, g, "3")
        x = 0.6 + k * 2.75
        sheet.text(x + 1.05, 0.05, S.genotype(g)[0], ha="center", va="top")
        pic = pictures.get(("rescue", plate.index_id))
        ax = sheet.axes(x + 0.05, 0.2, 2.0, 2.0)
        photo(ax, pic)
        grid, density, peaks = density_peaks(plate.radii_um)
        if pic is not None and len(peaks) >= 2:
            px_per_um = pic["px_per_mm"] / 1000.0
            for peak, dash in ((max(peaks), (0, (1.5, 1.2))), (min(peaks), "solid")):
                i = int(np.argmin(np.abs(plate.radii_um - peak)))
                cx, cy = pic["centers"][i]
                ax.add_patch(Circle((cx, cy), max(6.0, pic["radii"][i] * 2.2), fill=False, edgecolor="white", lw=1.0, ls=dash))
        ad = sheet.axes(x + 0.3, 2.55, 1.85, 1.25)
        ad.plot(grid, density, color=S.genotype(g)[1], lw=1.0)
        for peak in peaks:
            ad.axvline(peak, color="#555555", lw=0.5, ls=":", ymax=0.84)
            ad.text(peak, density.max() * 1.1, f"{peak:.0f}", ha="center", va="bottom", fontsize=S.MIN_PT,
                    bbox={"facecolor": "white", "edgecolor": "none", "pad": 0.5})
        ad.set_xscale("log")
        ad.set_xlim(100, 3000)
        S.log_radius_axis(ad, "x", ticks=(100, 300, 1000, 3000))
        ad.set_xlabel("Colony radius (µm)")
        ad.set_ylabel("Density")
        ad.set_ylim(0, density.max() * 1.3)
    return sheet.figure


def enrichment(R, pictures) -> object:
    """Selective enrichment at P4: (A) photos, (B) colony radius per plate."""
    sheet = Sheet(6.35)
    sheet.heading(0.05, 0.05, "A", "Enrichment plates")
    arms = (("small_enriched", "Small-enriched"), ("large_enriched", "Large-enriched"))
    size = 1.45
    for c, g in enumerate(("cdc13-2", "dbf4-1_cdc13-2")):
        sheet.text(1.55 + c * 2.3 + size / 2, 0.3, S.genotype(g)[0], ha="center", va="top")
        for r, (series, title) in enumerate(arms):
            plates = [p for p in R.where(genotype=g, passage="4", series=series)]
            plate = max(plates, key=lambda p: p.count) if plates else None
            top = 0.45 + r * (size + 0.12)
            if c == 0:
                sheet.text(1.4, top + size / 2, title, ha="right", va="center")
            photo(sheet.axes(1.55 + c * 2.3, top, size, size),
                  pictures.get(("rescue", plate.index_id)) if plate is not None and plate.count else None)
    sheet.heading(0.05, 3.62, "B", "Colony radius per plate")
    ax = sheet.axes(0.95, 4.2, 4.9, 1.5)
    groups = []
    for g in ("cdc13-2", "dbf4-1_cdc13-2"):
        for series in ("large_enriched", "small_enriched"):
            groups += [(g, series, p) for p in sorted(R.where(genotype=g, passage="4", series=series), key=lambda p: p.index_id)]
    groups.append(None)
    for g in ("cdc13-2", "dbf4-1_cdc13-2"):
        groups += [(g, "main", p) for p in sorted(R.where(genotype=g, passage="4", series="main"), key=lambda p: p.index_id)]
    ticks, labels, cells, positions = [], [], [], []
    for k, item in enumerate(groups):
        if item is None:
            continue
        g, series, plate = item
        x = k + 1
        color = S.genotype(g)[1]
        if plate.radii_um.size:
            violin(ax, plate.radii_um, x, color)
        else:
            ax.text(x, 200, "×", ha="center", va="center", fontsize=S.BASE_PT)
        positions.append(x)
        cells.append(plate.radii_um)
        star = "*" if "140" in plate.plate_mm else ""
        short = {"large_enriched": "Large", "small_enriched": "Small", "main": "Std"}[series]
        ticks.append(x)
        labels.append(f"{short}{star}")
    ax.set_xlim(0.3, len(groups) + 0.7)
    ax.set_ylim(80, 4000)
    S.log_radius_axis(ax, ticks=(100, 200, 300, 500, 1000, 2000, 3000))
    ax.set_xticks(ticks, labels, rotation=0)
    S.mu_axis(ax)
    numbers_above(ax, positions, cells, True)
    genotype_legend(sheet, ("cdc13-2", "dbf4-1_cdc13-2"), 6.08)
    return sheet.figure


def selected_boxes(R) -> object:
    """Colony radius across passages on the selected plates, one panel per genotype."""
    sheet = Sheet(4.9)
    for k, g in enumerate(GENOTYPES):
        col, row = k % 2, k // 2
        x, top = 0.95 + col * 2.75, 0.05 + row * 2.45
        name, color, _ = S.genotype(g)
        sheet.text(x + 1.1, top, name, ha="center", va="top", color=color)
        top += 0.5
        ax = sheet.axes(x, top, 2.2, 1.45)
        cells, xs = [], []
        for p, passage in enumerate(PASSAGES):
            plate = selected(R, g, passage)
            values = plate.radii_um if plate else np.zeros(0)
            box(ax, values, p + 1, color)
            cells.append(values)
            xs.append(p + 1)
        ax.set_xlim(0.4, 5.6)
        ax.set_ylim(150, 2800)
        S.log_radius_axis(ax, ticks=(200, 300, 500, 1000, 2000))
        ax.set_xticks(xs, [f"P{p}" for p in PASSAGES])
        ax.set_xlabel("Passage")
        if col == 0:
            S.mu_axis(ax)
        numbers_above(ax, xs, cells, col == 0)
    return sheet.figure


def dbf4_signature(R) -> object:
    from .model import density_peaks
    sheet = Sheet(5.3)
    pair = ("wild_type", "dbf4-1")
    main = [p for p in R.where(series="main") if p.count >= 10]
    for k, (letter, title, stat) in enumerate((("A", "CV across passages", "cv"), ("B", "Skew across passages", "skew"))):
        x = 0.6 + k * 2.85
        sheet.heading(x - 0.55, 0.05, letter, title)
        ax = sheet.axes(x, 0.35, 2.3, 1.55)
        for j, g in enumerate(pair):
            name, color, marker = S.genotype(g)
            means = []
            for p, passage in enumerate(PASSAGES):
                values = [getattr(pl, stat) for pl in main if pl.levels["genotype"] == g and pl.levels["passage"] == passage]
                jitter = (j - 0.5) * 0.18
                ax.plot(np.full(len(values), p + 1 + jitter), values, marker, color=color, ms=2.6, alpha=0.75, lw=0)
                means.append(np.mean(values) if values else np.nan)
            ax.plot(np.arange(1, 6), means, "-", color=color, lw=1.0)
        ax.set_xticks(range(1, 6), [f"P{p}" for p in PASSAGES])
        ax.set_xlabel("Passage")
        ax.set_ylabel("CV of colony radius" if stat == "cv" else "Skew of colony radius")
        if stat == "skew":
            ax.axhline(0, color="#BBBBBB", lw=0.5, zorder=0)
    sheet.heading(0.05, 2.4, "C", "Density at P2, pooled replicates")
    ax = sheet.axes(0.6, 2.7, 2.3, 1.55)
    for g in pair:
        radii = np.concatenate([p.radii_um for p in R.where(genotype=g, passage="2", density="2", series="main")])
        grid, density, _ = density_peaks(radii)
        ax.plot(grid, density, color=S.genotype(g)[1], lw=1.0)
    ax.set_xscale("log")
    ax.set_xlim(150, 3000)
    S.log_radius_axis(ax, "x", ticks=(200, 300, 500, 1000, 2000))
    ax.set_xlabel("Colony radius (µm)")
    ax.set_ylabel("Density")
    sheet.heading(2.9, 2.4, "D", "dbf4-1 classifier")
    ax = sheet.axes(3.45, 2.7, 2.3, 1.55)
    result = R.extra["classifier"]
    data = result["data"]
    classes = data.axes["classes"]
    keys = [k[0] if isinstance(k, tuple) else k for k in classes.keys]
    for p in result["plates"]:
        g = keys[p["class"]]
        _, color, marker = S.genotype(g)
        ax.plot(p["cv"], p["skew"], marker, color=color, ms=2.6, alpha=0.8, lw=0)
    centroids = result.get("centroids", [])
    cv = np.array([p["cv"] for p in result["plates"]])
    sk = np.array([p["skew"] for p in result["plates"]])
    if len(centroids) == 2 and cv.size:
        center, scale = np.array([cv.mean(), sk.mean()]), np.array([cv.std() or 1.0, sk.std() or 1.0])
        z1, z2 = [(np.array(c) - center) / scale for c in centroids]
        mid, normal = (z1 + z2) / 2, z2 - z1                  # boundary: points equidistant from the centroids
        xs = np.linspace(cv.min() - 0.02, cv.max() + 0.02, 50)
        zx = (xs - center[0]) / scale[0]
        zy = mid[1] - normal[0] * (zx - mid[0]) / normal[1] if normal[1] else np.full_like(zx, np.nan)
        ax.plot(xs, zy * scale[1] + center[1], "--", color="#222222", lw=0.7)
        ax.set_ylim(sk.min() - 0.2, sk.max() + 0.2)
    for (cx, cy), g in zip(centroids, pair):
        ax.plot(cx, cy, "*", ms=8, mfc=S.genotype(g)[1], mec="black", mew=0.6, zorder=5)
    ax.set_xlabel("CV of colony radius")
    ax.set_ylabel("Skew of colony radius")
    genotype_legend(sheet, GENOTYPES, 4.85, extra=[(Line2D([], [], marker="*", lw=0, ms=7, mfc="white", mec="black"),
                                                   "Centroid (D)"), (Line2D([], [], color="#222222", ls="--", lw=0.7),
                                                                     "Boundary (D)")])
    return sheet.figure


def p5_components(R, height: float = 2.9, letter: str | None = None, top: float = 0.0, sheet: Sheet | None = None):
    own = sheet is None
    sheet = sheet or Sheet(height)
    plates = {g: sorted([p for p in R.where(genotype=g, passage="5", series="main") if p.components is not None
                         and p.capture >= 0.25], key=lambda p: (p.index_id not in R.extra["chosen"].values(), p.index_id))
              for g in GENOTYPES}
    reference = selected(R, "wild_type", "5")
    if letter:
        sheet.heading(0.05, top, letter, "P5 mixture components")
        top += 0.25
    ax = sheet.axes(0.9, top + 0.1, 4.95, height - 1.05 - (0.25 if letter else 0))
    x = 1
    centers = []
    chosen = set(R.extra["chosen"].values())
    for g in GENOTYPES:
        xs = components(ax, plates[g], x, S.genotype(g)[1], outline=chosen)
        for xi, plate in zip(xs, plates[g]):
            ax.text(xi, -0.02, f"{plate.count}", transform=ax.get_xaxis_transform(), ha="center", va="top",
                    fontsize=S.MIN_PT, rotation=90)
        centers.append((np.mean(xs) if xs else x, g, plates[g]))
        x += len(plates[g]) + 1
    if reference is not None and reference.components is not None:
        for m in reference.components[0]:
            ax.axhline(m, color=S.genotype("wild_type")[1], lw=0.6, ls="--", zorder=0)
    ax.set_xlim(0, x - 1)
    ax.set_ylim(70, 3000)
    S.log_radius_axis(ax, ticks=(100, 200, 300, 500, 1000, 2000))
    S.mu_axis(ax)
    ax.text(-0.01, -0.02, "Colonies", transform=ax.transAxes, ha="right", va="top", fontsize=S.MIN_PT, color="#444444")
    ax.set_xticks([])
    ax.spines["bottom"].set_visible(False)
    for cx, g, ps in centers:
        values = [overlap(p, reference) for p in ps if p is not reference and reference is not None]
        span = (f"{min(values):.2f}" if len(values) == 1 else f"{min(values):.2f}–{max(values):.2f}") if values else "–"
        ax.text(cx, -0.2, S.genotype(g)[0], transform=ax.get_xaxis_transform(), ha="center", va="top",
                fontsize=S.MIN_PT)
        ax.text(cx, -0.33, f"Overlap {span}", transform=ax.get_xaxis_transform(), ha="center", va="top",
                fontsize=S.MIN_PT, color="#444444")
    return sheet.figure if own else None


def mixture_summary(R, selected_only: bool = False) -> object:
    """Mixture components of every main-series plate on one shared axis, drawn by the subpopulation figure
    (stats.subpopfig.plot_subpopulations): one cluster per genotype and passage, selected plates opaque, the
    other plates faded, the trajectory through the selected plates, and the legend panel in the left margin.
    Landscape: 8.5 in wide, for a sidewaysfigure page."""
    from types import SimpleNamespace
    import matplotlib.pyplot as plt
    from ..stats.subpopfig.figure import ComponentStyle, FigureText, plot_subpopulations
    from ..stats.subpopfig.workbook import Entry, Labels, Levels

    def build_fits():
        chosen = set(R.extra["chosen"].values())
        entries = []
        for gi, g in enumerate(GENOTYPES):
            for passage in PASSAGES:
                for p in R.where(genotype=g, passage=passage, series="main"):
                    if p.components is None:
                        continue
                    medians, weights, p25, p75 = (np.asarray(v, float) for v in p.components)
                    order = np.argsort(medians)
                    entries.append(Entry(
                        entry_id=f"index {p.index_id}", nominal=g, nominal_display=S.genotype(g)[0],
                        ordinal=float(passage), ordinal_display=f"P{passage}", sort_key=float(p.count),
                        selected=p.index_id in chosen, measurements=p.radii_um, n_rows=int(p.radii_um.size),
                        nominal_idx=gi, n_components=int(medians.size), component_medians=medians[order],
                        component_weights=weights[order], component_p25=p25[order], component_p75=p75[order]))
        levels = Levels(nominal=list(GENOTYPES), nominal_display=[S.genotype(g)[0] for g in GENOTYPES],
                        ordinal=np.array([float(p) for p in PASSAGES]), ordinal_display=[f"P{p}" for p in PASSAGES])
        labels = Labels(unit="Plates", nominal="Genotype", ordinal="Passage", measurement="radius (µm)",
                        sort_key="Colonies")
        return SimpleNamespace(entries=entries, levels=levels, labels=labels)

    width, height = S.LANDSCAPE
    height = 5.2
    legend_w, left = 1.1, 1.8                      # inches: legend panel, then the axes
    style = ComponentStyle(
        sel_whisker_width=1.1, other_whisker_width=0.7, size_base=2.0, size_scale=34.0,
        traj_min_width=0.5, traj_max_width=1.8, cluster_gap=1.5, gutter_frac=0.16,
        axes_position=(left / width, 0.04, (width - left - 0.05) / width, 0.94),
        legend_position=(0.0, 0.04, legend_w / width, 0.94),
        legend_font_size=S.MIN_PT, legend_header_size=S.HEAD_PT, legend_row_step=0.042, legend_header_gap=0.02,
        legend_glyph_x=0.1, legend_line_x=(0.02, 0.2), legend_text_x=0.25, legend_whisker_half=0.012,
        font_rc={}, show_title=False, ylabel_font_size=S.BASE_PT, tick_font_size=S.MIN_PT,
        ordinal_font_size=S.MIN_PT, nominal_font_size=S.BASE_PT, bracket_width=1.0, label_math=True,
        marker_edge_width=0.35)
    colors = np.array([matplotlib_rgb(S.genotype(g)[1]) for g in GENOTYPES])
    text = FigureText(y_label="Component median radius (µm)", unit_header="Plates", selected="Selected plate",
                      other="Other plates", weight_header="Component weight", trajectory_header="Trajectory",
                      consecutive="Next passage", gap="Missing passage")
    import contextlib, io
    with contextlib.redirect_stdout(io.StringIO()):
        drawn = plot_subpopulations(build_fits(), figsize=(width, height), dpi=300, colors=colors, text=text,
                                    style=style, y_limits=(60, 4000), verbose=False, selected_only=selected_only)
    plt.close(drawn.figure)
    return drawn.figure


def matplotlib_rgb(color) -> tuple:
    from matplotlib.colors import to_rgb
    return to_rgb(color)


def _pair_by_rank(a, b):
    a, b = np.sort(a), np.sort(b)
    if a.size == b.size:
        return list(zip(a, b))
    small, large = (a, b) if a.size < b.size else (b, a)
    pairs = [(s, l) for s in small for l in large] if small.size == 1 else list(zip(small, large[-small.size:]))
    return pairs if a.size <= b.size else [(l, s) for s, l in pairs]


def small_share(R, genotypes=GENOTYPES, sheet=None, top=0.0, letter=None, height=2.3):
    own = sheet is None
    sheet = sheet or Sheet(height)
    if letter:
        sheet.heading(0.05, top, letter, "Share of colonies below 450 µm")
        top += 0.25
    width = (5.15 - 0.25 * (len(genotypes) - 1)) / len(genotypes)
    for k, g in enumerate(genotypes):
        x = 0.7 + k * (width + 0.25)
        ax = sheet.axes(x, top + 0.2, width, height - 0.85 - (0.25 if letter else 0))
        name, color, marker = S.genotype(g)
        ax.set_title(name, fontsize=S.MIN_PT, color=color, pad=7)
        xs, ys = [], []
        for p, passage in enumerate(PASSAGES):
            plate = selected(R, g, passage)
            others = [o for o in R.where(genotype=g, passage=passage, series="main")
                      if 100 <= o.count <= 200 and o.capture >= 0.25 and (plate is None or o.index_id != plate.index_id)]
            ax.plot([p + 1] * len(others), [o.share_below() for o in others], marker, mfc="none", mec=color, ms=3.2, lw=0)
            if plate is not None:
                xs.append(p + 1)
                ys.append(plate.share_below())
        ax.plot(xs, ys, marker + "-", color=color, ms=3.2, lw=0.9)
        if g == "cdc13-2":
            big = R.where(genotype=g, passage="4", series="large_enriched")
            if big:
                ax.plot([4] * len(big), [b.share_below() for b in big], "D", color=GRAY, ms=3)
            gap = [(x0, y0) for x0, y0 in zip(xs, ys) if x0 in (3, 5)]
            if len(gap) == 2:
                ax.plot([gap[0][0], gap[1][0]], [gap[0][1], gap[1][1]], ":", color=color, lw=0.9)
        ax.set_ylim(-0.03, 1.05)
        ax.set_xlim(0.5, 5.5)
        ax.set_xticks(range(1, 6), [f"P{p}" for p in PASSAGES])
        if k == 0:
            ax.set_ylabel("Share below 450 µm")
        else:
            ax.set_yticklabels([])
    if own:
        handles = [Line2D([], [], color="#555555", marker="o", lw=0.9, ms=3), Line2D([], [], color="#555555", marker="o",
                   mfc="none", lw=0, ms=3), Line2D([], [], color=GRAY, marker="D", lw=0, ms=3)]
        sheet.figure.legend(handles, ["Selected plate", "Other plates, 100 to 200 colonies", "Large-enriched (excluded)"],
                            loc="lower center", bbox_to_anchor=(0.5, 0.0), ncol=3, fontsize=S.MIN_PT, frameon=False)
        return sheet.figure
    return None


def rate_only(R) -> object:
    """Panels (B) and (C) of the rate-only figure; panel (A) is a schematic drawn in TikZ."""
    sheet = Sheet(2.4)
    sheet.heading(0.05, 0.05, "B", "Colonies founded from small colonies")
    ax = sheet.axes(0.7, 0.4, 1.9, 1.45)
    for k, g in enumerate(("cdc13-2", "dbf4-1_cdc13-2")):
        counts = [p.count for p in R.where(genotype=g, passage="4", series="small_enriched")]
        _, color, marker = S.genotype(g)
        ax.bar(k, np.mean(counts) if counts else 0, color=color, alpha=0.45, width=0.6)
        ax.plot([k] * len(counts), counts, marker, color=color, ms=3.5)
    ax.axhline(0, color="#222222", lw=0.8, ls="--", zorder=5)
    ax.set_ylim(-6, None)                        # room below zero, so the prediction line clears the axis
    ax.spines["bottom"].set_position(("data", -6))
    ax.set_xticks([0, 1], [S.genotype("cdc13-2")[0], S.genotype("dbf4-1_cdc13-2")[0]])
    ax.set_ylabel("Colonies founded")
    sheet.heading(2.95, 0.05, "C", "Share below 450 µm")
    ax = sheet.axes(3.6, 0.4, 2.2, 1.45)
    for g in ("cdc13-2", "dbf4-1_cdc13-2"):
        _, color, marker = S.genotype(g)
        xs, ys = [], []
        for p, passage in enumerate(PASSAGES):
            plate = selected(R, g, passage)
            if plate is not None:
                xs.append(p + 1)
                ys.append(plate.share_below())
        ax.plot(xs, ys, marker + "-", color=color, ms=3.2, lw=0.9)
    ax.set_xticks(range(1, 6), [f"P{p}" for p in PASSAGES])
    ax.set_ylim(-0.03, 1.05)
    ax.set_ylabel("Share below 450 µm")
    genotype_legend(sheet, ("cdc13-2", "dbf4-1_cdc13-2"), 2.12,
                    extra=[(Line2D([], [], color="#222222", ls="--", lw=0.8), "Rate-only prediction (B)")])
    return sheet.figure


def readouts(R) -> object:
    """(A) small-enriched P4 plates, (C) the double-mutant share at P4 and P5 (top row); (B) every P5 plate's
    mixture components (bottom row)."""
    sheet = Sheet(5.2)
    sheet.heading(0.05, 0.05, "A", "Small-enriched P4 plates")
    ax = sheet.axes(0.95, 0.4, 2.0, 1.45)
    ax.axhspan(*WT_BAND, color=S.genotype("wild_type")[1], alpha=0.15, lw=0)
    double = sorted(R.where(genotype="dbf4-1_cdc13-2", passage="4", series="small_enriched"), key=lambda p: p.index_id)
    for k, p in enumerate(double):
        violin(ax, p.radii_um, k + 1, S.genotype("dbf4-1_cdc13-2")[1])
    ax.text(len(double) + 1, 200, "×", ha="center", va="center", fontsize=S.BASE_PT, color=S.genotype("cdc13-2")[1])
    ax.set_xlim(0.4, len(double) + 1.6)
    ax.set_ylim(150, 4000)
    S.log_radius_axis(ax, ticks=(200, 300, 500, 1000, 2000, 3000))
    ax.set_xticks(list(range(1, len(double) + 2)), [f"{p.count}" for p in double] + ["0"])
    ax.set_xlabel("Colonies founded per plate")
    S.mu_axis(ax)
    sheet.heading(3.25, 0.05, "C", "Share below 450 µm")
    ax = sheet.axes(4.05, 0.4, 1.8, 1.45)
    for g in ("wild_type", "dbf4-1_cdc13-2"):
        _, color, marker = S.genotype(g)
        picks = [selected(R, g, p) for p in ("4", "5")]
        ax.plot([1, 2], [p.share_below() for p in picks], marker + "-", color=color, ms=3, lw=0.9)
        if g == "dbf4-1_cdc13-2":
            others = [o for o in R.where(genotype=g, passage="4", series="main")
                      if 100 <= o.count <= 200 and o.capture >= 0.25 and o.index_id != picks[0].index_id]
            ax.plot([1] * len(others), [o.share_below() for o in others], marker, mfc="none", mec=color, ms=3, lw=0)
            ax.plot([1, 2], [picks[0].share_below()] * 2, "--", color="#555555", lw=0.7)
    ax.set_xticks([1, 2], ["P4", "P5"])
    ax.set_xlim(0.6, 2.4)
    ax.set_ylim(-0.03, 0.8)
    ax.set_ylabel("Share below 450 µm")
    p5_components(R, height=2.85, letter="B", top=2.35, sheet=sheet)
    genotype_legend(sheet, GENOTYPES, 5.0, extra=[(Rectangle((0, 0), 1, 1, color=S.genotype("wild_type")[1], alpha=0.15),
                                                   "Upper wild-type component (A)"),
                                                  (Line2D([], [], color="#555555", ls="--", lw=0.7), "Delay prediction (C)")])
    return sheet.figure


class _Inset:
    """A Sheet view shifted right, so a panel builder can draw into part of a figure."""

    def __init__(self, sheet: Sheet, x0: float, width: float):
        self.sheet, self.x0, self.width = sheet, x0, width
        self.figure, self.h, self.w = sheet.figure, sheet.h, sheet.w

    def axes(self, x, top, width, height, **kw):
        return self.sheet.axes(self.x0 + x * self.width / 6.0, top, width * self.width / 6.0, height, **kw)

    def heading(self, x, top, letter, title):
        return self.sheet.heading(self.x0 + x, top, letter, title)

    def text(self, x, top, text, **kw):
        return self.sheet.text(self.x0 + x * self.width / 6.0, top, text, **kw)


# ======================================================================================
# Anbalagan and the historical plates
# ======================================================================================
def photo_matrix(model, project: str, pictures, rows, columns, scale_mm=5.0, size=1.6, headings=None):
    """rows: [(row label, {column key: Plate})]; columns: [(key, title)]."""
    sheet_h = sum(size + 0.85 + (0.25 if headings else 0) for _ in rows) - 0.15
    sheet = Sheet(min(sheet_h, S.TEXT_HEIGHT))
    top = 0.05
    for r, (row_label, plates) in enumerate(rows):
        if headings:
            sheet.heading(0.05, top, headings[r][0], headings[r][1])
            top += 0.25
        for c, (key, title) in enumerate(columns):
            x = 1.6 + c * (size + 0.4)
            plate = plates.get(key)
            if isinstance(plate, tuple):                    # (plate, its own column title)
                plate, title = plate
            sheet.text(x + size / 2, top, title, ha="center", va="top")
            photo(sheet.axes(x, top + 0.15, size, size), pictures.get((project, plate.index_id)) if plate else None,
                  scale_mm=scale_mm)
            if c == 0 and row_label:
                sheet.text(1.5, top + 0.15 + size / 2, S.label(row_label), ha="right", va="center")
            if plate is not None:
                value_rows(sheet, 1.5 if c == 0 else x - 0.1, x + size / 2, top + 0.2 + size,
                           ["Colonies", "Median radius", "Capture ratio"] if c == 0 else [None] * 3,
                           [f"{plate.count}", fmt_um(plate.median) if plate.count else "–", fmt_pct(plate.capture)])
        top += size + 0.85
    return sheet.figure


def statistic_panels(A) -> object:
    """Figure 10.7: colony count (A, B) and median radius (C, D) by lineage across streaks."""
    sheet = Sheet(4.55)
    shown = {"Wild_Type": ("#2E9A4B", "o"), "rif1": ("#222222", "s"), "cdc132": ("#E3871C", "o"), "est2": ("#C0392B", "D")}
    names = A.extra["displays"]["genotype"]
    passages = A.extra["order"]["passage"]
    generations = {p: 25 * (i + 1) for i, p in enumerate(passages)}
    panels = [("A", "Wild type and rif1Δ, count", ("Wild_Type", "rif1"), "count"),
              ("B", "Single mutants, count", ("cdc132", "est2"), "count"),
              ("C", "Wild type and rif1Δ, size", ("Wild_Type", "rif1"), "median"),
              ("D", "Single mutants, size", ("cdc132", "est2"), "median")]
    for k, (letter, title, genes, what) in enumerate(panels):
        col, row = k % 2, k // 2
        x, top = 0.65 + col * 2.8, 0.3 + row * 2.1
        sheet.heading(x - 0.6, top - 0.25, letter, title)
        ax = sheet.axes(x, top, 2.3, 1.4)
        band = [getattr(p, what) if what == "count" else p.median for p in A.where(genotype="Wild_Type") if p.count >= (0 if what == "count" else 3)]
        if band:
            ax.axhspan(min(band), max(band), color="#2E9A4B", alpha=0.15, lw=0)
        if "cdc132" in genes:
            for figure in ("2C", "8D"):
                wt = sorted(A.where(genotype="Wild_Type", source_figure=figure), key=lambda p: passages.index(p.levels["passage"]))
                ax.plot([generations[p.levels["passage"]] for p in wt], [_stat(p, what) for p in wt], "o",
                        ls="-" if figure == "2C" else "--", color=GRAY, ms=2.6, lw=0.8)
        for g in genes:
            color, marker = shown[g]
            for figure in ("2C", "8D"):
                ps = sorted(A.where(genotype=g, source_figure=figure), key=lambda p: passages.index(p.levels["passage"]))
                if not ps:
                    continue
                ax.plot([generations[p.levels["passage"]] for p in ps], [_stat(p, what) for p in ps], marker,
                        ls="-" if figure == "2C" else "--", color=color, ms=2.8, lw=0.9)
        ax.set_xticks([25, 50, 75, 100])
        ax.set_xlabel("Generations")
        ax.set_ylabel("Colony count" if what == "count" else "Median colony radius (µm)")
    handles = [Line2D([], [], color=shown[g][0], marker=shown[g][1], lw=0.9, ms=3) for g in shown]
    labels = [S.label(names.get(g, g)) for g in shown]
    handles += [Line2D([], [], color=GRAY, marker="o", lw=0.8, ms=3), Line2D([], [], color="#222222", lw=0.8),
                Line2D([], [], color="#222222", lw=0.8, ls="--"), Rectangle((0, 0), 1, 1, color="#2E9A4B", alpha=0.15)]
    labels += ["Wild type (B, D)", "Fig. 2 lineage", "Fig. 8 lineage", "Wild-type range"]
    sheet.figure.legend(handles, labels, loc="upper center", bbox_to_anchor=(0.5, 1 - 4.17 / sheet.h), ncol=4,
                        fontsize=S.MIN_PT, frameon=False, handlelength=1.6, columnspacing=1.0)
    return sheet.figure


def _stat(plate, what):
    if what == "count":
        return plate.count
    return plate.median if plate.count >= 3 else np.nan


def anbalagan_boxes(A) -> object:
    sheet = Sheet(4.3)
    names = A.extra["displays"]["genotype"]
    passages = A.extra["order"]["passage"]
    palette = {"Wild_Type": "#2F6DB5", "rif1": "#8E44AD", "cdc132": "#2E9A4B", "rif1_cdc132": "#C0392B",
               "est2": "#2E9A4B", "rif1_est2": "#C0392B"}
    for k, (figure, letter, genes) in enumerate((("2C", "A", ("Wild_Type", "rif1", "cdc132", "rif1_cdc132")),
                                                  ("8D", "B", ("Wild_Type", "est2", "rif1", "rif1_est2")))):
        top = 0.05 + k * 2.1
        sheet.heading(0.05, top, letter, f"Anbalagan Figure {figure}")
        ax = sheet.axes(0.95, top + 0.75, 4.9, 1.05)
        x, cells, xs, ticks = 1, [], [], []
        for g in genes:
            start = x
            for passage in passages:
                ps = A.where(genotype=g, passage=passage, source_figure=figure)
                values = ps[0].radii_um if ps else np.zeros(0)
                box(ax, values, x, palette[g], width=0.62)
                cells.append(values)
                xs.append(x)
                ticks.append(str(25 * (passages.index(passage) + 1)))
                x += 1
            ax.text((start + x - 1) / 2, 1.3, S.label(names.get(g, g)), transform=ax.get_xaxis_transform(),
                    ha="center", va="bottom", fontsize=S.MIN_PT, color=palette[g])
            x += 1
        ax.set_xlim(0.3, x - 0.7)
        ax.set_ylim(150, 1400)
        S.log_radius_axis(ax, ticks=(200, 300, 500, 700, 1000))
        ax.set_xticks(xs, ticks)
        ax.set_xlabel("Generations")
        S.mu_axis(ax)
        numbers_above(ax, xs, cells, True)
    return sheet.figure


def historical_boxes(H) -> object:
    sheet = Sheet(2.7)
    names = H.extra["displays"]["genotype"]
    passages = H.extra["order"]["passage"]
    ax = sheet.axes(0.95, 0.75, 4.9, 1.5)
    x, cells, xs, ticks = 1, [], [], []
    for g, color in (("est41", "#D2569C"), ("est11", "#2F6DB5")):
        start = x
        for passage in passages:
            ps = H.where(genotype=g, passage=passage)
            values = ps[0].radii_um if ps else np.zeros(0)
            box(ax, values, x, color)
            cells.append(values)
            xs.append(x)
            ticks.append(passage)
            x += 1
        ax.text((start + x - 1) / 2, 1.33, S.label(names.get(g, g)), transform=ax.get_xaxis_transform(), ha="center",
                va="bottom", fontsize=S.MIN_PT, color=color)
        x += 1
    ax.set_xlim(0.3, x - 0.7)
    ax.set_ylim(200, 2000)
    S.log_radius_axis(ax, ticks=(300, 500, 700, 1000, 1500))
    ax.set_xticks(xs, ticks)
    ax.set_xlabel("Passage")
    S.mu_axis(ax)
    numbers_above(ax, xs, cells, True)
    return sheet.figure


def transposed(result: dict) -> dict:
    """The fidelity result with rows and columns swapped (a long row of cells becomes a column)."""
    out = dict(result)
    for key in ("medians", "areas", "plates", "grid_counts"):
        if key in result and hasattr(result[key], "T"):
            out[key] = result[key].T
    out["rows"], out["columns"] = result.get("columns", ()), result.get("rows", ())
    return out


def fidelity_figure(result, row_labels=None, per_plate_n=False, cell_h=0.36, column_title="Passage") -> object:
    columns = result["medians"].shape[1]
    if row_labels is None and columns > 5 and result["medians"].shape[0] < columns:   # cells too narrow side by side
        result, column_title = transposed(result), ""
    rows = result["medians"].shape[0]
    height = 0.42 + 1.55 + 0.36 + 0.42 + 0.55 + cell_h * rows + 0.1
    sheet = Sheet(min(height, S.TEXT_HEIGHT))
    fidelity_pair(sheet, result, 0.05, row_labels=row_labels, per_plate_n=per_plate_n, cell_h=cell_h,
                  column_title=column_title)
    return sheet.figure
