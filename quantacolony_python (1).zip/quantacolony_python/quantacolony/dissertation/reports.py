"""Dataset reports: the MATLAB overview PDFs (generateOverviewPDF in LeanFinalAnalysis.m), in the
dissertation page format (stats.print_pages).

Each report opens with the measurement fidelity page, then the grid pages, then the box plot pages, then the
dataset's own figures, as in MATLAB:

    Selected mode   one cell per index (nominal columns x ordinal rows, at most 4 x 5 cells per page), five
                    page types in turn: original source images, source images with colony overlays, density
                    histograms, kernel density estimates (peak and mean marked, with their coordinates) and
                    LogNormal mixture fits (histogram backing, the summed mixture in black, each component in
                    its dominance-rank color). A dataset with one nominal level wraps its ordinal sequence
                    through the grid (MATLAB's reflow layout). One box plot page per chunk of at most four
                    nominal levels, with each box's colony count and median radius in a band above it.
    Full mode       every index (genotype x passage) gets the five page types with all of its plates, standard
                    plates first; each genotype ends with a box plot page of every plate.

Every cell carries a stat block beneath it. Image pages: colony count and capture ratio, plus replicate, HCE
and plate diameter where they vary between plates; distribution pages: median radius and the q1 to q3 range.
A field with one value on every plate moves to a footnote. Histograms, KDEs and mixtures share one log-radius
axis and one density scale across the report, and densities are per unit of ln(radius), as in MATLAB.

Flags over a box: a dagger marks a plate seeded from enriched colonies, a double dagger a 140 mm plate.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from . import style as S

N_BINS, X_PAD_LOG, HEADROOM = 30, 0.15, 1.5
HIST_ALPHA, HIST_BACKING = 0.6, 0.15
COMPONENT_COLORS = ("#33A64D", "#F28C1A", "#D93333")          # dominance rank 1, 2, 3 and beyond
MAX_COLUMNS, MAX_ROWS = 4, 5
BOX_TICKS = (100, 250, 500, 750, 1000, 1500, 2500)
NEUTRAL = "#4066A6"
PAGE_TYPES = ("Original Source Images", "Source Images with Colony Overlays", "Density Histograms",
              "Kernel Density Estimates", "LogNormal Mixture Fits")
DAGGER, DOUBLE_DAGGER = "†", "‡"


@dataclass
class Column:
    key: str
    label: str
    color: str


@dataclass
class Grid:
    """One block of a selected report: ordinal rows by nominal columns, one plate (or None) per cell."""
    title: str
    columns: list
    rows: list                                     # [(key, label)]
    cells: dict                                    # (row key, column key) -> Plate or None
    reflow: bool = False                           # one nominal level: the ordinal sequence wraps


@dataclass
class Report:
    name: str
    mode: str                                      # 'Selected' or 'Full'
    fidelity: object                               # a fidelity result, or None
    grids: list = field(default_factory=list)      # Selected
    indices: list = field(default_factory=list)    # Full: [(column, row label, [plates])]
    ordinal_title: str = "Passage"
    extra: list = field(default_factory=list)      # zero-argument builders of the dataset's own figures
    fidelity_rows: list | None = None


# ======================================================================================
# shared scaling (MATLAB computeGlobalScaling)
# ======================================================================================
@dataclass
class Scaling:
    extent: tuple
    edges: np.ndarray
    fine: np.ndarray
    y_max: float


def _kde_ln(radii):
    from ..analyses.builtin.distributions import log_kde
    grid, density, _ = log_kde(np.asarray(radii, float))
    return grid, density / np.log(10)                         # per ln unit, as MATLAB's eval_x_log


def _hist_ln(radii, edges):
    counts, _ = np.histogram(np.log(radii), bins=np.log(edges))
    width = np.diff(np.log(edges))
    return counts / max(len(radii), 1) / width


def _mixture_ln(plate, fine):
    """(components, sum): each component a normal in ln radius, sigma from its quartiles, scaled by weight;
    components ordered by weight, heaviest first."""
    if plate.components is None or not len(plate.components[0]):
        return [], None
    medians, weights, p25, p75 = (np.asarray(v, float) for v in plate.components)
    order = np.argsort(-weights)
    x = np.log(fine)
    curves = []
    for k in order:
        sigma = max((np.log(max(p75[k], 1e-9)) - np.log(max(p25[k], 1e-9))) / 1.349, 0.02)
        curves.append(weights[k] * np.exp(-0.5 * ((x - np.log(medians[k])) / sigma) ** 2) / (sigma * np.sqrt(2 * np.pi)))
    return curves, np.sum(curves, axis=0)


def scaling_for(plates) -> Scaling:
    """MODEL: one log-radius extent, 30 log bins and one density maximum for every plate (terminal)."""
    lo, hi = np.inf, -np.inf
    for p in plates:
        if p.radii_um.size >= 3:
            grid, _ = _kde_ln(p.radii_um)
            lo, hi = min(lo, np.log(grid.min())), max(hi, np.log(grid.max()))
    if not np.isfinite(lo):
        lo, hi = np.log(10), np.log(2000)
    lo, hi = lo - X_PAD_LOG, hi + X_PAD_LOG
    edges = np.exp(np.linspace(lo, hi, N_BINS + 1))
    fine = np.exp(np.linspace(lo, hi, 400))
    top = 0.0
    for p in plates:
        if p.radii_um.size >= 3:
            top = max(top, _kde_ln(p.radii_um)[1].max(), _hist_ln(p.radii_um, edges).max())
            curves, total = _mixture_ln(p, fine)
            if total is not None:
                top = max(top, total.max())
    return Scaling((float(np.exp(lo)), float(np.exp(hi))), edges, fine, top * HEADROOM if top else 1.0)


# ======================================================================================
# stat blocks
# ======================================================================================
def _image_fields(plate) -> dict:
    return {"Colonies": f"{plate.count}", "Capture ratio": f"{100 * plate.capture:.1f}%" if np.isfinite(plate.capture) else "–",
            "Replicate": plate.levels.get("replicate", "") or "", "HCE": f"{plate.hce:,.0f}" if np.isfinite(plate.hce) else "",
            "Plate": plate.plate_mm or ""}


def _distribution_fields(plate) -> dict:
    if plate.radii_um.size:
        q1, q3 = np.percentile(plate.radii_um, [25, 75])
        return {"Median radius": f"{plate.median:.0f} µm", "Q1 to Q3": f"{q1:.0f} to {q3:.0f} µm"}
    return {"Median radius": "–", "Q1 to Q3": "–"}


def stat_rows(plates, kind: str) -> tuple[list, list]:
    """MODEL: (rows printed in every cell, footnotes): colony count always prints; a field missing on every plate
    is dropped; a field with one value everywhere becomes a footnote (terminal)."""
    getter = _image_fields if kind == "image" else _distribution_fields
    values = [getter(p) for p in plates if p is not None]
    if not values:
        return [], []
    rows, notes = [], []
    for name in values[0]:
        seen = [v[name] for v in values if v[name] not in ("", "–")]
        if name in ("Colonies", "Median radius", "Q1 to Q3", "Capture ratio"):
            rows.append(name)
        elif not seen:
            continue
        elif len(set(seen)) == 1:
            notes.append(f"{name}: {seen[0]}" + (" (where recorded)" if len(seen) < len(values) else ""))
        else:
            rows.append(name)
    return rows, notes


# ======================================================================================
# cell renderers (MATLAB renderCell*)
# ======================================================================================
def _photo(ax, pic, overlay: bool) -> None:
    from matplotlib.patches import Circle
    ax.set_axis_off()
    if pic is None:
        return
    gray = np.asarray(pic["image"][..., :3], float) @ np.array([0.299, 0.587, 0.114])
    ax.imshow(gray, cmap="gray", vmin=0, vmax=255, interpolation="bilinear")
    if overlay:
        for kind, o in pic["outlines"]:
            if kind == "polygon":
                ax.plot(o[:, 0], o[:, 1], "-", color="#FF00FF", lw=0.35)
            else:
                (cx, cy), r = o
                ax.add_patch(Circle((cx, cy), r, fill=False, edgecolor="#FF0000", lw=0.35))


def _distribution_axes(ax, scaling: Scaling, left: bool, bottom: bool) -> None:
    ax.set_xscale("log")
    ax.set_xlim(*scaling.extent)
    ax.set_ylim(0, scaling.y_max)
    S.log_radius_axis(ax, "x", ticks=tuple(t for t in (100, 300, 1000, 3000) if scaling.extent[0] <= t <= scaling.extent[1]))
    ax.tick_params(labelsize=S.MIN_PT, length=2)
    ax.yaxis.set_major_locator(__import__("matplotlib.ticker", fromlist=["MaxNLocator"]).MaxNLocator(3))
    if not left:
        ax.set_yticklabels([])
    if not bottom:
        ax.set_xticklabels([])
    ax.set_xlabel("")


def _histogram(ax, plate, color, scaling, alpha=HIST_ALPHA):
    if plate.radii_um.size:
        density = _hist_ln(plate.radii_um, scaling.edges)
        ax.bar(scaling.edges[:-1], density, width=np.diff(scaling.edges), align="edge", color=color, alpha=alpha,
               edgecolor="none")


def _kde(ax, plate, color, scaling):
    if plate.radii_um.size < 3:
        return
    grid, density = _kde_ln(plate.radii_um)
    ax.plot(grid, density, color=color, lw=1.0)
    dark = tuple(0.4 * np.array(__import__("matplotlib.colors", fromlist=["to_rgb"]).to_rgb(color)))
    peak = float(grid[int(np.argmax(density))])
    mean = float(np.mean(plate.radii_um))
    mean_y = float(np.interp(mean, grid, density)) if grid.min() <= mean <= grid.max() else 0.0
    ax.plot([peak], [density.max()], "o", ms=3, color=color, mec=dark, mew=0.5)
    ax.plot([mean], [mean_y], "D", ms=3, color=color, mec=dark, mew=0.5)
    for k, text in enumerate((f"Mean: ({mean:.0f}, {mean_y:.2f})", f"Peak: ({peak:.0f}, {density.max():.2f})")):
        ax.annotate(text, (0.5, 1.0), xycoords="axes fraction", xytext=(0, -1 - 8.5 * k), textcoords="offset points",
                    ha="center", va="top", fontsize=S.MIN_PT, color=dark)


def _mixture(ax, plate, color, scaling):
    _histogram(ax, plate, color, scaling, alpha=HIST_BACKING)
    curves, total = _mixture_ln(plate, scaling.fine)
    if total is None:
        return
    ax.plot(scaling.fine, total, color="black", lw=0.9)
    for k, curve in enumerate(curves):
        ax.plot(scaling.fine, curve, color=COMPONENT_COLORS[min(k, 2)], lw=0.7)


RENDER = {2: _histogram, 3: _kde, 4: _mixture}


# ======================================================================================
# grid pages
# ======================================================================================
def _grid_page(page_type: int, title: str, cells: list, n_rows: int, n_columns: int, scaling: Scaling,
               pictures: dict, project: str, column_heads=None, row_heads=None):
    """VIEW: one grid page. cells: [(row, column, plate or None, color, cell header)] (terminal)."""
    from matplotlib.figure import Figure
    width, height = 6.0, 8.12
    figure = Figure(figsize=(width, height), facecolor="white")
    figure.text(0.0, 1.0, title, ha="left", va="top", fontsize=S.HEAD_PT, fontweight="bold")
    image = page_type < 2
    rows_named, notes = stat_rows([c[2] for c in cells], "image" if image else "distribution")
    lead = 0.95                                            # left: row heads and stat row names
    top = 0.42 + (0.18 if column_heads else 0.0)
    cell_w = (width - lead) / n_columns
    stat_h = 0.13 * len(rows_named)
    cell_h = (height - top - 0.25) / n_rows
    below = 0.06 if image else 0.24                      # room under the plot: tick labels on distribution pages
    plot_h = min(cell_h - 0.12 - below - stat_h - 0.06, (cell_w - 0.1) if image else 1.2)
    plot_w = plot_h if image else cell_w - 0.2
    if column_heads:
        for c, (text, color) in enumerate(column_heads):
            figure.text((lead + (c + 0.5) * cell_w) / width, 1 - 0.47 / height, S.label(text), ha="center", va="top",
                        fontsize=S.BASE_PT, fontweight="bold", color=color)
    for r in range(n_rows):
        y_top = top + r * cell_h
        if row_heads and r < len(row_heads):
            figure.text(0.02 / width, 1 - (y_top + 0.12 + plot_h / 2) / height, row_heads[r], rotation=90,
                        ha="left", va="center", fontsize=S.BASE_PT, fontweight="bold")
        if any(cell[0] == r and cell[2] is not None for cell in cells):
            for k, name in enumerate(rows_named):
                figure.text((lead - 0.06) / width, 1 - (y_top + 0.12 + plot_h + below + k * 0.13) / height,
                            name, ha="right", va="top", fontsize=S.MIN_PT, color="#666666")
    for r, c, plate, color, header in cells:
        x0 = lead + c * cell_w + (cell_w - plot_w) / 2 + (0.05 if not image else 0)
        y_top = top + r * cell_h
        if header:
            figure.text((lead + (c + 0.5) * cell_w) / width, 1 - y_top / height, S.label(header), ha="center",
                        va="top", fontsize=S.MIN_PT, color="#222222")
        ax = figure.add_axes((x0 / width, 1 - (y_top + 0.12 + plot_h) / height, (plot_w - (0.1 if not image else 0)) / width,
                              plot_h / height))
        if plate is None:
            ax.set_axis_off()
            ax.text(0.5, 0.5, "no plate", ha="center", va="center", fontsize=S.MIN_PT, color="#888888",
                    transform=ax.transAxes)
            continue
        if image:
            _photo(ax, pictures.get((project, plate.index_id)), overlay=page_type == 1)
        else:
            RENDER[page_type](ax, plate, color, scaling)
            _distribution_axes(ax, scaling, left=c == 0, bottom=True)
        values = (_image_fields if image else _distribution_fields)(plate)
        for k, name in enumerate(rows_named):
            figure.text((lead + (c + 0.5) * cell_w) / width,
                        1 - (y_top + 0.12 + plot_h + below + k * 0.13) / height,
                        values.get(name) or "–", ha="center", va="top", fontsize=S.MIN_PT)
    if not image:
        figure.text(0.5, 0.0, "Colony radius (µm)    ·    density per unit ln(radius)", ha="center", va="bottom",
                    fontsize=S.MIN_PT, color="#444444")
    if notes:
        figure.text(1.0, 0.0 if image else 0.03, "   ".join(notes), ha="right", va="bottom", fontsize=S.MIN_PT,
                    color="#444444")
    return figure


def selected_grid_pages(report: Report, scaling: Scaling, pictures: dict, project: str) -> list:
    """VIEW SUB-CONTROLLER: every grid page of a selected report, page type outermost, then block, then
    pagination chunks (at most 4 columns x 5 rows)."""
    pages = []
    for page_type, type_title in enumerate(PAGE_TYPES):
        for grid in report.grids:
            if grid.reflow:                                         # one nominal: the sequence wraps
                column = grid.columns[0]
                sequence = [(label, grid.cells.get((key, column.key))) for key, label in grid.rows]
                per_page = MAX_COLUMNS * MAX_ROWS
                for start in range(0, len(sequence), per_page):
                    chunk = sequence[start:start + per_page]
                    n_rows = min(MAX_ROWS, int(np.ceil(len(chunk) / MAX_COLUMNS)))
                    cells = [(k % n_rows, k // n_rows, plate, column.color, label)
                             for k, (label, plate) in enumerate(chunk)]
                    title = f"{report.name}: {type_title}" + (f" · {grid.title}" if grid.title else "")
                    pages.append(_grid_page(page_type, title, cells, n_rows, min(MAX_COLUMNS, int(np.ceil(len(chunk) / n_rows))),
                                            scaling, pictures, project))
                continue
            for c0 in range(0, len(grid.columns), MAX_COLUMNS):
                columns = grid.columns[c0:c0 + MAX_COLUMNS]
                for r0 in range(0, len(grid.rows), MAX_ROWS):
                    rows = grid.rows[r0:r0 + MAX_ROWS]
                    cells = [(r, c, grid.cells.get((rk, col.key)), col.color, "")
                             for r, (rk, _) in enumerate(rows) for c, col in enumerate(columns)]
                    title = f"{report.name}: {type_title}" + (f" · {grid.title}" if grid.title else "")
                    pages.append(_grid_page(page_type, title, cells, len(rows), len(columns), scaling, pictures, project,
                                            column_heads=[(col.label, col.color) for col in columns],
                                            row_heads=[label for _, label in rows]))
    return pages


def full_index_pages(report: Report, scaling: Scaling, pictures: dict, project: str) -> list:
    """VIEW SUB-CONTROLLER: full mode: each index gets the five page types with all of its plates (standard
    plates first); a genotype's indices are followed by its box plot page."""
    pages = []
    for column in _unique_columns(report.indices):
        for col, row_label, plates in [i for i in report.indices if i[0].key == column.key]:
            per_page = MAX_COLUMNS * MAX_ROWS
            for page_type, type_title in enumerate(PAGE_TYPES):
                for start in range(0, len(plates), per_page):
                    chunk = plates[start:start + per_page]
                    n_rows = int(np.ceil(len(chunk) / MAX_COLUMNS))
                    cells = [(k // MAX_COLUMNS, k % MAX_COLUMNS, p, col.color, _plate_header(p)) for k, p in enumerate(chunk)]
                    pages.append(_grid_page(page_type, f"{report.name}: {type_title} · {col.label} {row_label}", cells,
                                            max(n_rows, 1), MAX_COLUMNS, scaling, pictures, project))
        pages.append(box_page(f"{report.name}: Colony Radius Distributions · {column.label}",
                              [(f"{row_label}", [(p, column.color) for p in plates])
                               for col, row_label, plates in report.indices if col.key == column.key],
                              scaling, per_plate=True))
    return pages


def _unique_columns(indices) -> list:
    seen, out = set(), []
    for col, _, _ in indices:
        if col.key not in seen:
            seen.add(col.key)
            out.append(col)
    return out


def _plate_header(plate) -> str:
    series = plate.levels.get("series", "")
    names = {"main": "Standard", "small_enriched": "Small-colony enriched", "large_enriched": "Large-colony enriched"}
    parts = [names.get(series, series.replace("_", " ").capitalize()) if series else ""]
    if plate.levels.get("replicate"):
        parts.append(f"replicate {plate.levels['replicate']}")
    return ", ".join(p for p in parts if p)


def _flags(plate) -> str:
    marks = ""
    if "enriched" in plate.levels.get("series", ""):
        marks += DAGGER
    if str(plate.plate_mm).startswith("140"):
        marks += DOUBLE_DAGGER
    return marks


# ======================================================================================
# box plot pages (MATLAB renderSelectedBoxPlotPage / buildGenotypeBoxPlotPage)
# ======================================================================================
def box_page(title: str, groups: list, scaling: Scaling, per_plate: bool = False):
    """VIEW: boxes on a log radius axis grouped with gaps, colony count and median in a band above each box,
    group names above the band, flags over flagged boxes, and the flag key (terminal).

    groups: [(group label, [(plate or None, color)])]."""
    from matplotlib.figure import Figure
    from . import figures as F
    figure = Figure(figsize=(8.5, 5.62), facecolor="white")
    figure.text(0.0, 1.0, title, ha="left", va="top", fontsize=S.HEAD_PT, fontweight="bold")
    ax = figure.add_axes((0.9 / 8.5, 0.75 / 5.62, 7.5 / 8.5, 3.65 / 5.62))
    x, xs, cells, ticks, labels, heads, flagged = 1, [], [], [], [], [], []
    for label, members in groups:
        start = x
        for plate, color in members:
            values = plate.radii_um if plate is not None else np.zeros(0)
            F.box(ax, values, x, color)
            xs.append(x)
            cells.append(values)
            ticks.append(x)
            labels.append(_plate_header(plate).replace("Standard, ", "").replace("replicate ", "R") if per_plate and plate
                          else label)
            if plate is not None and _flags(plate):
                flagged.append((x, _flags(plate)))
            x += 1
        heads.append(((start + x - 1) / 2, label))
        x += 1
    ax.set_xlim(0.3, x - 0.7)
    ax.set_yscale("log")
    ax.set_ylim(*scaling.extent)
    S.log_radius_axis(ax, ticks=tuple(t for t in BOX_TICKS if scaling.extent[0] <= t <= scaling.extent[1]))
    S.mu_axis(ax)
    ax.set_xticks(ticks, labels if per_plate else [""] * len(ticks), rotation=90 if per_plate else 0, fontsize=S.MIN_PT)
    F.numbers_above(ax, xs, cells, True)
    from matplotlib.transforms import blended_transform_factory
    mark = blended_transform_factory(ax.transData, ax.transAxes)
    for center, label in heads:
        ax.annotate(S.label(label), (center, 1.0), xycoords=mark, xytext=(0, 24), textcoords="offset points",
                    ha="center", va="bottom", fontsize=S.MIN_PT, fontweight="bold", annotation_clip=False)
    for xi, marks in flagged:
        ax.annotate(marks, (xi, 0.97), xycoords=mark, ha="center", va="top", fontsize=S.BASE_PT)
    if flagged:
        figure.text(0.0, 0.0, f"{DAGGER} seeded from enriched colonies   {DOUBLE_DAGGER} 140 mm plate", ha="left",
                    va="bottom", fontsize=S.MIN_PT, color="#444444")
    return figure


def selected_box_pages(report: Report, scaling: Scaling) -> list:
    pages = []
    for grid in report.grids:
        for c0 in range(0, len(grid.columns), MAX_COLUMNS):
            columns = grid.columns[c0:c0 + MAX_COLUMNS]
            groups = [(col.label if not grid.reflow else "", [(grid.cells.get((rk, col.key)), col.color) for rk, _ in grid.rows])
                      for col in columns]
            title = f"{report.name}: Colony Radius Distributions" + (f" · {grid.title}" if grid.title else "")
            figure = box_page(title, groups, scaling)
            ax = figure.axes[0]
            positions = [x for x in ax.get_xticks()]
            row_labels = [label for _, label in grid.rows] * len(columns)
            ax.set_xticks(positions, row_labels[:len(positions)], fontsize=S.MIN_PT, rotation=90 if grid.reflow else 0)
            ax.set_xlabel(report.ordinal_title)
            pages.append(figure)
    return pages


# ======================================================================================
# the report
# ======================================================================================
def build_pages(report: Report, pictures: dict, project: str) -> list:
    """VIEW SUB-CONTROLLER: every page of one report, in MATLAB's order."""
    from . import figures as F
    plates = ([p for g in report.grids for p in g.cells.values() if p is not None]
              or [p for _, _, ps in report.indices for p in ps])
    scaling = scaling_for(plates)
    pages = []
    if report.fidelity is not None:
        pages.append(F.fidelity_figure(report.fidelity, row_labels=report.fidelity_rows,
                                       per_plate_n=bool(report.fidelity.get("per_plate"))))
    if report.mode == "Selected":
        pages += selected_grid_pages(report, scaling, pictures, project)
        pages += selected_box_pages(report, scaling)
    else:
        pages += full_index_pages(report, scaling, pictures, project)
    for builder in report.extra:
        made = builder()
        pages += made if isinstance(made, list) else [made]
    return pages


def write_report(report: Report, pictures: dict, project: str, path) -> list:
    """CONTROLLER: draw, check and write one report; returns the page checks."""
    from ..stats import print_pages as P
    import datetime
    stamp = datetime.date.today().isoformat()
    checks, pdf_pages = [], []
    with S.house():
        pages = build_pages(report, pictures, project)
        for k, page in enumerate(pages, start=1):
            P.italicize(page)
            P.raise_small_text(page)
            P.fit_to_page(page)
            checks.append(P.check_page(page, f"{report.name} page {k}"))
            footer = f"{report.name} Overview ({report.mode}) · page {k} of {len(pages)} · QuantaColony · {stamp}"
            pdf_pages.append(P.compose(P.to_pdf_page(page), P.to_pdf_page(P.footer_figure(page.get_figwidth(), footer)),
                                       P.landscape(page)))
    P.write_pages(pdf_pages, path)
    return checks


# ======================================================================================
# the four datasets (the generateOverviewPDF calls of LeanFinalAnalysis.m)
# ======================================================================================
def reports(C, R, A, H, within, fidelity: dict) -> list:
    """MODEL: (report, project key, folder) for every MATLAB overview: Crowding, Historical, Anbalagan (by figure,
    with the lineage figure), Rescue Selected and Rescue Full (each with the five Rescue figures)."""
    from . import figures as F
    from .model import GENOTYPES, PASSAGES, selected
    out = []
    crowd = sorted(C.plates.values(), key=lambda p: float(p.levels["dilution_level"]))
    column = Column("all", "", NEUTRAL)
    grid = Grid("", [column], [(p.index_id, f"{int(float(p.levels['dilution_level']))}×") for p in crowd],
                {(p.index_id, "all"): p for p in crowd}, reflow=True)
    out.append((Report("Crowding", "Selected", fidelity.get("Crowding"), [grid], ordinal_title="Dilution factor",
                       fidelity_rows=[f"{str(r).rstrip('Xx')}×" for r in fidelity["Crowding"]["rows"]] if fidelity.get("Crowding") else None),
                "crowding", "Crowding"))

    names = H.extra["displays"]["genotype"]
    passages = H.extra["order"]["passage"]
    palette = ("#2F6DB5", "#E3871C", "#2E9A4B", "#D2569C", "#8E44AD", "#8C564B")
    columns = [Column(g, names.get(g, g), palette[k % len(palette)]) for k, g in enumerate(names)]
    cells = {(p, g): next(iter(H.where(genotype=g, passage=p)), None) for g in names for p in passages}
    out.append((Report("Historical", "Selected", fidelity.get("Historical"),
                       [Grid("", columns, [(p, f"P{p}") for p in passages], cells)]), "historical", "QuantaColony_Validation"))

    names = A.extra["displays"]["genotype"]
    passages = A.extra["order"]["passage"]
    generations = {p: f"{25 * (i + 1)} gen." for i, p in enumerate(passages)}
    colors = {"Wild_Type": "#2F6DB5", "rif1": "#8E44AD", "cdc132": "#2E9A4B", "rif1_cdc132": "#C0392B",
              "est2": "#2E9A4B", "rif1_est2": "#C0392B"}
    grids = []
    for figure in ("2C", "8D"):
        shown = [g for g in names if A.where(genotype=g, source_figure=figure)]
        grids.append(Grid(f"Figure {figure}", [Column(g, names.get(g, g), colors.get(g, NEUTRAL)) for g in shown],
                          [(p, generations[p]) for p in passages],
                          {(p, g): next(iter(A.where(genotype=g, passage=p, source_figure=figure)), None)
                           for g in shown for p in passages}))
    out.append((Report("Anbalagan", "Selected", fidelity.get("Anbalagan"), grids, ordinal_title="Generations",
                       extra=[lambda: F.statistic_panels(A)]), "anbalagan", "QuantaColony_Validation"))

    rescue_extra = [lambda: F.mixture_summary(R), lambda: F.mixture_summary(R, selected_only=True),
                    lambda: F.within_state(within), lambda: F.selected_boxes(R), lambda: F.dbf4_signature(R)]
    columns = [Column(g, S.genotype(g)[0], S.genotype(g)[1]) for g in GENOTYPES]
    cells = {(p, g): selected(R, g, p) for g in GENOTYPES for p in PASSAGES}
    out.append((Report("Rescue", "Selected", R.extra.get("fidelity_selected"),
                       [Grid("", columns, [(p, f"P{p}") for p in PASSAGES], cells)], extra=rescue_extra),
                "rescue", "Rescue"))
    series_rank = {"main": 0}
    indices = []
    for g in GENOTYPES:
        for p in PASSAGES:
            plates = sorted(R.where(genotype=g, passage=p), key=lambda q: (series_rank.get(q.levels.get("series", ""), 1),
                                                                           q.levels.get("series", ""), q.index_id))
            if plates:
                indices.append((Column(g, S.genotype(g)[0], S.genotype(g)[1]), f"P{p}", plates))
    out.append((Report("Rescue", "Full", R.extra.get("fidelity_all"), indices=indices, extra=rescue_extra), "rescue", "Rescue"))
    return out
