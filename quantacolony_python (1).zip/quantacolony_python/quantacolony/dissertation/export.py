"""Export every dissertation data figure and every quoted value (controller).

    export_dissertation(folder, library_manager, theme, progress) runs each project's analyses on a
    private copy, draws every data figure to the house style and writes three folders:

        Crowding/Data                  the crowding chapter's figures, crowding_values.csv and .tex
        Rescue/Data                    the rescue chapters' figures, rescue_values.csv and .tex
        Rescue/Schematics              the TikZ schematics, copied as supplied (dissertation/schematics)
        QuantaColony_Validation/Data   every other figure, quantacolony_validation_values.csv and .tex

Figures are vector PDFs (photographs PNG at 300 dpi). Each figure is checked (size against the page,
smallest label, labels past the edges or over each other, embedded fonts); the checks come back in the
result, and any figure that fails is listed under "problems".
"""

from __future__ import annotations

import csv
from pathlib import Path

import numpy as np

from . import figures as F
from . import style as S
from . import values as V
from .model import (GENOTYPES, PASSAGES, collect_plates, crowding_scores, fit_components, picture, rescue,
                    robustness_plates, selected, within_state_plates)

SCHEMATICS = Path(__file__).parent / "schematics"
CROWDING = {"Representative_Plates", "Part 2 Crowding Dataset 500X photo", "Within_State_Predictors"}
RESCUE = {"Colony_Type_Bimodality", "Enrichment_P4", "Rescue_Selected_Plates", "Rescue_Fidelity_Selected",
          "Rescue_Fidelity_Full", "Rescue_Selected_Boxplot", "Rescue_dbf4_Signature", "Rescue_P5_Components",
          "Mixture_Summary", "Rescue_Small_Share", "Rescue_Rate_Only_BC", "Rescue_Readouts"}


def folder_of(name: str) -> str:
    """The part folder a figure belongs to; anything outside the crowding and rescue chapters is validation."""
    return "Crowding" if name in CROWDING else "Rescue" if name in RESCUE else "QuantaColony_Validation"


FIGURES = (  # file name, dissertation label
    ("Representative_Plates", "fig:representative_plates"), ("Part 2 Crowding Dataset 500X photo", "fig:foreground_overlay"),
    ("Within_State_Predictors", "fig:within_state_predictors"), ("Colony_Type_Bimodality", "fig:bimodality"),
    ("Enrichment_P4", "fig:enrichment_p4"), ("Rescue_Selected_Plates", "fig:rescue_selected_plates"),
    ("Rescue_Fidelity_Selected", "fig:rescue_fidelity"), ("Rescue_Fidelity_Full", "fig:rescue_fidelity_full"),
    ("Rescue_Selected_Boxplot", "fig:part3_selected_dataset_page6"), ("Rescue_dbf4_Signature", "fig:dbf4_signature"),
    ("Rescue_P5_Components", "fig:p5-classes"), ("Mixture_Summary", "fig:mixture_summary"),
    ("Rescue_Small_Share", "fig:small-share"), ("Rescue_Rate_Only_BC", "fig:rate-only (B, C)"),
    ("Rescue_Readouts", "fig:readouts"), ("Crowding_Box", "Figure 10.1"), ("Crowding_Photos", "Figure 10.2"),
    ("Crowding_Fidelity", "Figure 10.3"), ("Anbalagan_Photos", "Figure 10.4"), ("Anbalagan_Fidelity", "Figure 10.5"),
    ("Historical_Photos", "Figure 10.6"), ("Anbalagan_Lineages", "Figure 10.7"), ("Anbalagan_Boxes", "Figure 10.8"),
    ("Historical_Boxes", "Figure 10.9"), ("Historical_Fidelity", "Figure 8.7"),
)


LANDSCAPE_FIGURES = {"Mixture_Summary.pdf"}         # set in a sidewaysfigure: the page turned, 8.5 x 6.0 in


def _fits_page(row) -> bool:
    width, height = (S.LANDSCAPE if row["file"] in LANDSCAPE_FIGURES else (S.TEXT_WIDTH, S.TEXT_HEIGHT))
    return float(row["width_in"]) <= width + 1e-6 and float(row["height_in"]) <= height + 1e-6


REPORTS_ONLY = "reports"


def export_dissertation(folder: Path, library_manager, theme, progress=lambda step, total, text: True,
                        what: str = "all") -> dict:
    """what: 'all' (figures, values, schematics and the dataset reports) or REPORTS_ONLY (the five dataset
    report PDFs). Both prepare the same data; the reports draw on every project."""
    from .session import DissertationProjects
    folder = Path(folder)
    reports_only = what == REPORTS_ONLY
    steps = 14 + (0 if reports_only else len(FIGURES))
    step = 0

    def tick(text):
        nonlocal step
        step += 1
        if progress(step, steps, text) is False:
            raise InterruptedError("Export stopped")

    projects = DissertationProjects(library_manager, theme)
    try:
        return _export_body(folder, projects, tick, steps, reports_only)
    finally:
        projects.close()


def _export_body(folder, projects, tick, steps, reports_only=False):
    """The export with the private project copies open (export_dissertation deletes them afterwards)."""
    pictures = {}
    # --- Crowding Dataset
    tick("Crowding Dataset: plates and crowding scores")
    session = projects.session("crowding")
    C = collect_plates(session)
    crowd_scores = crowding_scores(session)
    for p in C.plates.values():
        pictures[("crowding", p.index_id)] = picture(session, p.index_id)
    fit_components(C, [p for p in C.plates.values() if p.radii_um.size >= 10])
    crowd500 = next(p for p in C.plates.values() if int(float(p.levels["dilution_level"])) == 500)
    from ..core.growth import growth_mask
    packet = session.manager.checkout_image(crowd500.index_id)
    growth500 = growth_mask(packet.record.image, packet.record.mask, packet.saved.colonies).growth
    overlay_pic = picture(session, crowd500.index_id, width_px=int(4.2 * S.PHOTO_DPI))
    _, crowding_fidelity = session.view("fidelity", slots={"dilution_level": "rows"}, options={"cell": "colonies"})
    tick("Crowding Dataset: growth classifier check (withheld colonies)")
    from ..core.growth import held_out_check
    methods = {"heldout": []}
    for p in sorted(C.plates.values(), key=lambda p: float(p.levels["dilution_level"])) if not reports_only else ():
        packet = session.manager.checkout_image(p.index_id)
        check = held_out_check(packet.record.image, packet.record.mask, packet.saved.colonies, folds=3)
        methods["heldout"].append({"name": str(int(float(p.levels["dilution_level"]))), "colonies": len(packet.saved.colonies),
                                   **{k: float(v) for k, v in check.items()}})
    session.close()
    # --- Rescue Dataset
    tick("Rescue Dataset: selection, fidelity, classifier and mixture fits")
    session = projects.session("rescue")
    R = rescue(session)
    tick("Rescue Dataset: crowding scores and photos")
    rescue_scores = crowding_scores(session)
    wanted = {selected(R, g, p).index_id for g in GENOTYPES for p in PASSAGES if selected(R, g, p) is not None}
    wanted |= {p.index_id for p in R.where(passage="4", series=("small_enriched", "large_enriched"))}
    for index_id in wanted:
        pictures[("rescue", index_id)] = picture(session, index_id)
    report_pictures = {}                                 # every plate, small, for the dataset reports
    for p in R.plates.values():
        report_pictures[("rescue", p.index_id)] = picture(session, p.index_id, width_px=360)
    fit_components(R, [p for p in R.plates.values() if p.radii_um.size >= 10])
    session.close()
    # --- Anbalagan and historical plates
    tick("Anbalagan et al. plates")
    session = projects.session("anbalagan")
    A = collect_plates(session)
    _, anbalagan_fidelity = session.view("fidelity", slots={"genotype": "rows", "source_figure": "rows", "passage": "columns"},
                                         options={"cell": "colonies"})
    for p in A.where(source_figure="2C", passage=(A.extra["order"]["passage"][0], A.extra["order"]["passage"][-1])):
        pictures[("anbalagan", p.index_id)] = picture(session, p.index_id)
    for p in A.plates.values():
        report_pictures[("anbalagan", p.index_id)] = picture(session, p.index_id, width_px=360)
    fit_components(A, [p for p in A.plates.values() if p.radii_um.size >= 10])
    from ..core.colony_set import KIND_MANUAL, KIND_SPLIT
    first = A.where(genotype="Wild_Type", source_figure="2C", passage=A.extra["order"]["passage"][0])
    last = A.where(genotype="Wild_Type", source_figure="2C", passage=A.extra["order"]["passage"][-1])
    if first:                                     # the detection output figure's plate: colony kinds of its saved result
        packet = session.manager.checkout_image(first[0].index_id)
        kinds = list(packet.saved.colonies.kinds)
        methods["output_plate"] = {"label": first[0].name, "total": len(kinds), "manual": kinds.count(KIND_MANUAL),
                                   "split": kinds.count(KIND_SPLIT),
                                   "automatic": len(kinds) - kinds.count(KIND_MANUAL) - kinds.count(KIND_SPLIT)}
    if last:
        methods["crop_px_per_mm"] = session.manager.checkout_image(last[0].index_id).record.px_per_mm
    session.close()
    tick("Historical est plates")
    session = projects.session("historical")
    H = collect_plates(session)
    _, historical_fidelity = session.view("fidelity", slots={"genotype": "rows", "passage": "columns"},
                                          options={"cell": "colonies"})
    for p in H.where(genotype=("est11", "tlc1")):
        pictures[("historical", p.index_id)] = picture(session, p.index_id)
    for p in H.plates.values():
        report_pictures[("historical", p.index_id)] = picture(session, p.index_id, width_px=360)
    fit_components(H, [p for p in H.plates.values() if p.radii_um.size >= 10])
    session.close()
    report_pictures.update({k: v for k, v in pictures.items() if k[0] == "crowding"})
    # --- cross-project statistics
    tick("Within-state test and robustness statistics")
    from ..core import robustness, within_state
    scores = {("Crowding", k): v for k, v in crowd_scores.items()}
    scores.update({("Rescue", k): v for k, v in rescue_scores.items()})
    within = within_state.run(within_state_plates(C, R, scores))
    robust = robustness.run(robustness_plates(R))
    # --- figures
    report = []
    with S.house():
        builders = _builders(C, R, A, H, within, pictures, crowding_fidelity, anbalagan_fidelity, historical_fidelity,
                             overlay_pic, growth500)
        for name, label in (() if reports_only else FIGURES):
            tick(f"Drawing {name}")
            out = folder / folder_of(name) / "Data"
            out.mkdir(parents=True, exist_ok=True)
            built = builders[name]()
            if isinstance(built, np.ndarray):                         # a photograph: PNG at 300 dpi
                from PIL import Image
                path = out / f"{name}.png"
                Image.fromarray(built).save(path, dpi=(S.PHOTO_DPI, S.PHOTO_DPI))
                report.append({"file": path.name, "label": label, "orientation": "portrait",
                               "width_in": built.shape[1] / S.PHOTO_DPI,
                               "height_in": built.shape[0] / S.PHOTO_DPI, "min_pt": "", "texts": 0, "outside": "", "overlaps": "",
                               "fonts": "", "all_embedded": "", "dpi": S.PHOTO_DPI})
                continue
            checked = S.check(built)
            path = out / f"{name}.pdf"
            built.savefig(path, format="pdf", dpi=S.PHOTO_DPI)
            fonts = S.pdf_fonts(path)
            report.append({"file": path.name, "label": label,
                           "orientation": "landscape" if path.name in LANDSCAPE_FIGURES else "portrait",
                           "width_in": round(checked["width_in"], 3),
                           "height_in": round(checked["height_in"], 3), "min_pt": round(checked["min_pt"], 2),
                           "texts": checked["texts"], "outside": " | ".join(checked["outside"]), "overlaps": " | ".join(checked["overlaps"]),
                           "fonts": " ".join(sorted({f for f, _ in fonts})), "all_embedded": all(e for _, e in fonts),
                           "dpi": S.PHOTO_DPI})
    rows, written = [], {}
    if not reports_only:
        tick("Writing the values")
        rows = V.build(C, R, within, robust, A, H, {"Crowding": crowding_fidelity, "Anbalagan": anbalagan_fidelity,
                                                    "Historical": historical_fidelity}, methods)
        written = V.write(rows, folder)
    from . import reports as REP
    report_checks = []
    for spec, project, part_folder in REP.reports(C, R, A, H, within, {"Crowding": crowding_fidelity,
                                                                         "Anbalagan": anbalagan_fidelity,
                                                                         "Historical": historical_fidelity}):
        tick(f"Report: {spec.name} Overview ({spec.mode})")
        target = folder / part_folder / "Reports"
        target.mkdir(parents=True, exist_ok=True)
        checks = REP.write_report(spec, report_pictures, project, target / f"{spec.name}_Overview_{spec.mode}.pdf")
        report_checks += checks
    import shutil
    for part in (() if reports_only else SCHEMATICS.iterdir()):   # the schematics as supplied, one folder per part
        if part.is_dir():
            shutil.copytree(part, folder / part.name / "Schematics", dirs_exist_ok=True)
    tick("Done")
    problems = [r["file"] for r in report if (r["min_pt"] != "" and r["min_pt"] < S.MIN_PT - 1e-6) or r["outside"] or r["overlaps"]
                or r["all_embedded"] is False or not _fits_page(r)]
    problems += [c.title for c in report_checks if not c.passed]
    changed = V.COLUMNS.index("changed")
    reports_written = sorted(str(p.relative_to(folder)) for p in folder.glob("*/Reports/*.pdf"))
    return {"folder": folder, "figures": len(report), "values": len(rows), "changed": sum(r[changed] == "yes" for r in rows),
            "written": written, "report": report, "problems": problems, "reports": reports_written}


def _builders(C, R, A, H, within, pictures, crowding_fidelity, anbalagan_fidelity, historical_fidelity, overlay_pic, growth500):
    names_a = A.extra["displays"]
    passages_a = A.extra["order"]["passage"]
    first, last = passages_a[0], passages_a[-1]
    gen = {p: f"{25 * (i + 1)} generations" for i, p in enumerate(passages_a)}
    anb_rows = [(names_a["genotype"].get(g, g), {p: next(iter(A.where(genotype=g, source_figure="2C", passage=p)), None)
                                                 for p in (first, last)}) for g in ("Wild_Type", "cdc132")]
    names_h = H.extra["displays"]["genotype"]
    pass_h = H.extra["order"]["passage"]
    hist_rows = []
    for g, shown in (("est11", (pass_h[0], pass_h[-1])), ("tlc1", (pass_h[0], pass_h[2]))):
        hist_rows.append(("", {k: (next(iter(H.where(genotype=g, passage=p)), None), f"Passage {p}")
                               for k, p in zip(("a", "b"), shown)}))
    anb_labels = [f"{names_a['genotype'].get(r.split(' · ')[0], r)}" for r in anbalagan_fidelity["rows"]]
    return {
        "Representative_Plates": lambda: F.representative(C, R, pictures),
        "Part 2 Crowding Dataset 500X photo": lambda: F.foreground_overlay(overlay_pic, growth500),
        "Within_State_Predictors": lambda: F.within_state(within),
        "Colony_Type_Bimodality": lambda: F.bimodality(R, pictures),
        "Enrichment_P4": lambda: F.enrichment(R, pictures),
        "Rescue_Selected_Plates": lambda: F.selected_p5(R, pictures),
        "Rescue_Fidelity_Selected": lambda: F.fidelity_figure(R.extra["fidelity_selected"]),
        "Rescue_Fidelity_Full": lambda: F.fidelity_figure(R.extra["fidelity_all"], per_plate_n=True),
        "Rescue_Selected_Boxplot": lambda: F.selected_boxes(R),
        "Rescue_dbf4_Signature": lambda: F.dbf4_signature(R),
        "Rescue_P5_Components": lambda: F.p5_components(R),
        "Mixture_Summary": lambda: F.mixture_summary(R),
        "Rescue_Small_Share": lambda: F.small_share(R),
        "Rescue_Rate_Only_BC": lambda: F.rate_only(R),
        "Rescue_Readouts": lambda: F.readouts(R),
        "Crowding_Box": lambda: F.crowding_box(C),
        "Crowding_Photos": lambda: F.crowding_photos(C, pictures),
        "Crowding_Fidelity": lambda: F.fidelity_figure(crowding_fidelity, row_labels=[f"{str(r).rstrip('Xx')}×" for r in crowding_fidelity["rows"]],
                                                    column_title=""),
        "Anbalagan_Photos": lambda: F.photo_matrix(A, "anbalagan", pictures, anb_rows, [(first, gen[first]), (last, gen[last])]),
        "Anbalagan_Fidelity": lambda: F.fidelity_figure(anbalagan_fidelity),
        "Historical_Photos": lambda: F.photo_matrix(H, "historical", pictures, hist_rows, [("a", "First passage"), ("b", "Last passage")],
                                                    headings=[("A", f"Retained for size analysis: {names_h.get('est11', 'est1-1')}"),
                                                              ("B", f"Excluded from size analysis: {names_h.get('tlc1', 'tlc1Δ')}")]),
        "Anbalagan_Lineages": lambda: F.statistic_panels(A),
        "Anbalagan_Boxes": lambda: F.anbalagan_boxes(A),
        "Historical_Boxes": lambda: F.historical_boxes(H),
        "Historical_Fidelity": lambda: F.fidelity_figure(historical_fidelity),
    }
