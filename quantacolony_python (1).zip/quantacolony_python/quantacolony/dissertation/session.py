"""Stats sessions on private copies of the dissertation projects (model access for the export).

Each project is copied into a temporary library (the newest copy in the user's library when there is one,
the bundled file otherwise), so running the dissertation's analyses never changes the user's own Stats
choices. A StatsSession drives the same StatsController the Stats screen uses, without showing it, so
every value the export reports is the value the tutorial shows.

    DissertationProjects   opens one project at a time: projects.session(name) -> StatsSession
    StatsSession.view(...) sets the analysis and every choice of a figure, computes, returns (data, result)
"""

from __future__ import annotations

import tempfile
from pathlib import Path

from ..core.selection import LEAST_DEVIATION
from ..data import DataManager, Settings, create_library
from ..data.tutorial_project import DISSERTATION_FILES

SELECTION = dict(selection=True, matched=("genotype", "passage"), window=(50, None), target=LEAST_DEVIATION)


class StatsSession:
    """One project's Stats, driven by a figure's choices."""

    def __init__(self, manager: DataManager, theme, name: str):
        from PySide6.QtWidgets import QApplication
        from ..gui.launch import open_stats
        self.manager, self.name = manager, name
        self.window, self.stats = open_stats(manager, theme)
        self.app = QApplication.instance()
        self.variables = {v.name: v for v in self.stats.variables}

    # ----- choices --------------------------------------------------------------------------
    def view(self, analysis: str, slots: dict | None = None, levels: dict | None = None, options: dict | None = None,
             measure: str = "", selection: dict | None = None, leave_out: bool = False, by_hand: tuple = (),
             color_by: str = ""):
        """Apply every choice of one view and compute it: (AnalysisData, result).

        slots: {variable: slot} (every other variable pooled); levels: {variable: used level values} (every
        other variable shows every level); selection: SELECTION-like dict or None for every plate; by_hand:
        photo-name prefixes left out by hand."""
        s = self.stats
        s.choose_analysis(analysis)
        for name in self.variables:
            s.set_slot(name, (slots or {}).get(name, ""))
        for name, variable in self.variables.items():
            s.show_all_levels(name)
            used = (levels or {}).get(name)
            if used:
                for value in variable.values:
                    if value not in used:
                        s.toggle_level(name, value)
        s.set_scheme("raw")
        s.set_color_by(color_by)
        for index_id in list(s.by_hand):
            s.toggle_by_hand(index_id)
        for index_id in s.indices.index_ids:
            if by_hand and any(s.plate_name(int(index_id)).startswith(p) for p in by_hand):
                s.toggle_by_hand(int(index_id))
        if selection:
            s.set_plate_selection(True)
            s.window.close_selection()
            for name in self.variables:
                if (name in s.choice.matched) != (name in selection["matched"]):
                    s.toggle_matched(name)
            s.set_count_window(*selection["window"])
            s.set_target(selection["target"])
        else:
            s.set_plate_selection(False)
            s.set_leave_out(leave_out)
        for key, value in (options or {}).items():
            s.set_option(key, str(value))
        if measure:
            s.set_measure(measure)
        s.refresh()
        for _ in range(500):
            s.wait_for_compute(3_600_000)
            self.app.processEvents()
            if s._worker is None:
                break
        if s.result is None or s.data is None:
            raise RuntimeError(f"{self.name}: {analysis} did not compute")
        return s.data, s.result

    def table(self, analysis_result=None) -> list[dict]:
        return self.stats.current.table(self.stats.result if analysis_result is None else analysis_result)

    def selection(self):
        return self.stats.selection()[0]

    def plate_name(self, index_id: int) -> str:
        return self.stats.plate_name(int(index_id))

    def close(self) -> None:
        try:
            self.stats._save_preferences = lambda *a, **k: None      # nothing to keep: a private copy
            self.window.close()
            self.window.deleteLater()
        finally:
            self.manager.close()


class DissertationProjects:
    """Private copies of the dissertation projects, opened one at a time."""

    def __init__(self, library_manager: DataManager | None, theme):
        self.theme = theme
        self.folder = Path(tempfile.mkdtemp(prefix="qc_dissertation_"))
        import shutil
        import weakref
        self._cleanup = weakref.finalize(self, shutil.rmtree, str(self.folder), True)   # removed with this object
        self.manager = DataManager(Settings(folder=self.folder / "settings"), create_library(self.folder / "Library"))
        self.sources = {}
        for name, bundled in DISSERTATION_FILES.items():
            source = Path(bundled)
            if library_manager is not None:
                copies = [e for e in library_manager.list_projects() if e.tutorial_name == name]
                if copies:
                    newest = max(copies, key=lambda e: e.tutorial_version)
                    source = library_manager.export_project_file(newest.project_id, self.folder / f"{name}.qcproj")
            self.sources[name] = source
        self.ids = {name: self.manager.import_project_file(path) for name, path in self.sources.items()}

    def close(self) -> None:
        """Close the open copy and delete every private copy (about 450 MB)."""
        if self.manager.is_open:
            self.manager.close()
        self._cleanup()

    def session(self, name: str) -> StatsSession:
        if self.manager.is_open:
            self.manager.close()
        self.manager.open_project(self.ids[name])
        return StatsSession(self.manager, self.theme, name)
