"""House style for the dissertation figures (view helpers), and the checks a figure must pass.

Page (UCR): text block 6.0 in x 8.5 in; every figure is drawn at its printed size, so the sizes in the
file are the printed sizes. Type: Latin Modern Roman (bundled, embedded), no label below 7 pt, gene and
allele names in italics, a real µ. Layout: no title inside a figure, panel headings '(A) Short title'
bold and left-aligned, legends in a row beneath the plot.
"""

from __future__ import annotations

import re
from contextlib import contextmanager
from pathlib import Path

import numpy as np

TEXT_WIDTH = 6.0                                 # in
TEXT_HEIGHT = 8.5
LANDSCAPE = (8.5, 6.0)                         # a sidewaysfigure page: the text block turned                                # in
MIN_PT = 7.0
BASE_PT = 8.0
HEAD_PT = 8.5
PHOTO_DPI = 300
FONT_DIR = Path(__file__).resolve().parent.parent / "assets" / "fonts" / "lm"
FAMILY = "Latin Modern Roman"

# genotype colors, markers and line styles: color is never the only cue (markers differ in grayscale)
RESCUE = {"wild_type": ("Wild type", "#2F6DB5", "o"), "dbf4-1": ("dbf4-1", "#E3871C", "s"),
          "cdc13-2": ("cdc13-2", "#2E9A4B", "^"), "dbf4-1_cdc13-2": ("dbf4-1 cdc13-2", "#D2569C", "D")}
GENE = re.compile(r"^[a-zA-Z]{3,4}\d+(-\d+)?Δ?,?$|^[a-z]{3,4}\d*Δ,?$")


def register_fonts() -> None:
    """The bundled Latin Modern Roman 10 (TrueType outlines, GUST Font License), and no other Latin Modern
    Roman, so every computer embeds the same faces."""
    from matplotlib import font_manager
    manager = font_manager.fontManager
    ours = {str(p) for p in FONT_DIR.glob("*.ttf")}
    manager.ttflist = [f for f in manager.ttflist if f.name != FAMILY or f.fname in ours]
    known = {f.fname for f in manager.ttflist}
    for path in sorted(ours - known):
        manager.addfont(path)
    font_manager._get_font.cache_clear() if hasattr(font_manager, "_get_font") else None


@contextmanager
def house():
    """rcParams for every dissertation figure."""
    import matplotlib as mpl
    register_fonts()
    settings = {
        "font.family": FAMILY, "font.size": BASE_PT, "axes.labelsize": BASE_PT, "axes.titlesize": HEAD_PT,
        "xtick.labelsize": MIN_PT, "ytick.labelsize": MIN_PT, "legend.fontsize": MIN_PT,
        "legend.title_fontsize": MIN_PT, "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none",
        "mathtext.fontset": "custom", "mathtext.rm": FAMILY, "mathtext.it": f"{FAMILY}:italic",
        "mathtext.bf": f"{FAMILY}:bold", "mathtext.default": "regular", "mathtext.fallback": None, "axes.linewidth": 0.6,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6, "xtick.minor.width": 0.4, "ytick.minor.width": 0.4,
        "xtick.major.size": 2.5, "ytick.major.size": 2.5, "lines.linewidth": 0.9, "lines.markersize": 3.5,
        "axes.spines.top": False, "axes.spines.right": False, "axes.unicode_minus": True,
        "figure.dpi": 100, "savefig.dpi": PHOTO_DPI, "image.interpolation": "antialiased",
        "axes.titlepad": 4, "legend.frameon": False, "axes.edgecolor": "#333333",
    }
    with mpl.rc_context(settings):
        yield


def italic(word: str) -> str:
    """One gene or allele name as italic mathtext (hyphen kept as a hyphen, Δ as Delta)."""
    word = word.replace("-", "‐")
    trail = "," if word.endswith(",") else ""
    word = word.rstrip(",").replace("Δ", r"}\Delta\mathit{")
    return rf"$\mathit{{{word}}}${trail}"


def label(text: str) -> str:
    """Display text with every gene or allele name in italics."""
    if not text:
        return text
    text = text.replace("-Δ", "Δ").replace("‐Δ", "Δ").replace("Wild Type", "Wild type")
    return " ".join(italic(w) if GENE.match(w.replace("‐", "-")) else w for w in text.split(" "))


def genotype(key: str) -> tuple[str, str, str]:
    """(label, color, marker) of a rescue genotype."""
    name, color, marker = RESCUE.get(key, (key, "#555555", "o"))
    return label(name), color, marker


def new_figure(height: float, width: float = TEXT_WIDTH):
    from matplotlib.figure import Figure
    if width > TEXT_WIDTH + 1e-6 or height > TEXT_HEIGHT + 1e-6:
        raise ValueError(f"figure {width} x {height} in exceeds the 6.0 x 8.5 in text block")
    return Figure(figsize=(width, height), facecolor="white")


def heading(ax, letter: str, title: str, x: float = 0.0) -> None:
    """'(A) Short title', bold, left-aligned over the panel (gene names in italics)."""
    ax.set_title(f"({letter}) " + label(title), loc="left", fontsize=HEAD_PT, fontweight="bold",
                 x=x, ha="left", pad=4)


def legend_below(figure, handles, labels, y: float = 0.0, ncol: int | None = None) -> None:
    figure.legend(handles, labels, loc="lower center", bbox_to_anchor=(0.5, y), ncol=ncol or len(labels),
                  frameon=False, fontsize=MIN_PT, handlelength=1.6, columnspacing=1.4, handletextpad=0.5)


def mu_axis(ax, which: str = "y", text: str = "Colony radius (µm)") -> None:
    (ax.set_ylabel if which == "y" else ax.set_xlabel)(text)


def log_radius_axis(ax, which: str = "y", ticks=(100, 200, 300, 500, 700, 1000, 1500, 2000, 3000)) -> None:
    from matplotlib.ticker import FixedLocator, NullFormatter, NullLocator
    axis = ax.yaxis if which == "y" else ax.xaxis
    (ax.set_yscale if which == "y" else ax.set_xscale)("log")
    low, high = (ax.get_ylim() if which == "y" else ax.get_xlim())
    shown = [t for t in ticks if low <= t <= high] or list(ticks)
    axis.set_major_locator(FixedLocator(shown))
    axis.set_major_formatter(__import__("matplotlib.ticker", fromlist=["FixedFormatter"]).FixedFormatter([f"{t:g}" for t in shown]))
    axis.set_minor_locator(NullLocator())
    axis.set_minor_formatter(NullFormatter())


# ----- checks ---------------------------------------------------------------------------------
def check(figure) -> dict:
    """Smallest text size, any text past the figure's edges, and any title inside the figure."""
    from matplotlib.text import Text
    renderer = figure.canvas.get_renderer() if hasattr(figure.canvas, "get_renderer") else figure._get_renderer()
    figure.draw_without_rendering()
    width, height = figure.bbox.width, figure.bbox.height
    sizes, outside, boxes = [], [], []
    hidden = set()                                     # tick labels outside the view limits are never drawn
    for ax in figure.axes:
        for axis in (ax.xaxis, ax.yaxis):
            drawn = {id(t) for t in axis._update_ticks()} if ax.axison else set()
            for tick in axis.get_major_ticks() + axis.get_minor_ticks():
                if id(tick) not in drawn:
                    hidden.update((id(tick.label1), id(tick.label2)))
    for text in figure.findobj(Text):
        if id(text) in hidden or not text.get_visible() or not text.get_text().strip():
            continue
        sizes.append(float(text.get_fontsize()))
        box = text.get_window_extent(renderer)
        boxes.append((text.get_text()[:30], box))
        if box.x0 < -0.5 or box.y0 < -0.5 or box.x1 > width + 0.5 or box.y1 > height + 0.5:
            outside.append(text.get_text()[:40])
    overlaps = []                                      # any two drawn texts sharing more than a sliver
    for i, (a, ba) in enumerate(boxes):
        for b, bb in boxes[i + 1:]:
            w = min(ba.x1, bb.x1) - max(ba.x0, bb.x0)
            h = min(ba.y1, bb.y1) - max(ba.y0, bb.y0)
            if w > 0.5 and h > 0.5:
                overlaps.append(f"{a} / {b}")
    return {"min_pt": min(sizes) if sizes else float("nan"), "texts": len(sizes), "outside": outside,
            "overlaps": overlaps,
            "width_in": figure.get_figwidth(), "height_in": figure.get_figheight(),
            "suptitle": bool(getattr(figure, "_suptitle", None) and figure._suptitle.get_text())}


def pdf_fonts(path: Path) -> list[tuple[str, bool]]:
    """(font name, embedded) for every font in a PDF, read with pdffonts when it is installed, else pypdf."""
    import shutil
    import subprocess
    if shutil.which("pdffonts"):
        out = subprocess.run(["pdffonts", str(path)], capture_output=True, text=True).stdout.splitlines()[2:]
        return [(line.split()[0], line.split()[-5] == "yes") for line in out if line.strip()]
    try:
        from pypdf import PdfReader
    except ImportError:
        return []
    fonts = []
    for page in PdfReader(str(path)).pages:
        resources = page.get("/Resources") or {}
        for font in (resources.get("/Font") or {}).values():
            font = font.get_object()
            descriptor = font.get("/FontDescriptor")
            if descriptor is None and "/DescendantFonts" in font:
                descriptor = font["/DescendantFonts"][0].get_object().get("/FontDescriptor")
            descriptor = descriptor.get_object() if descriptor is not None else {}
            embedded = any(k in descriptor for k in ("/FontFile", "/FontFile2", "/FontFile3"))
            fonts.append((str(font.get("/BaseFont", "?")).lstrip("/"), embedded))
    return fonts


def downsample(image: np.ndarray, width_in: float) -> np.ndarray:
    """A photo reduced to PHOTO_DPI at its printed width (never enlarged)."""
    from PIL import Image
    target = int(round(width_in * PHOTO_DPI))
    if image.shape[1] <= target:
        return image
    scale = target / image.shape[1]
    pic = Image.fromarray(image)
    return np.asarray(pic.resize((target, max(1, int(round(image.shape[0] * scale)))), Image.LANCZOS))
