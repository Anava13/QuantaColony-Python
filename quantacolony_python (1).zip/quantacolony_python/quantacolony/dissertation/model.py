"""Everything the dissertation figures and values need, computed once per project (model).

Plate-level values come from the per-plate table Stats uses (core.stats.IndexTable); colony radii from its
colony table; the plate selection, measurement fidelity and the shape classifier from the Stats analyses
themselves (StatsSession.view); mixture components from the same LogNormal fits the mixture analyses use
and keep in the project.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..analyses.builtin.distributions import log_kde, peaks_of
from ..core import stats as st
from .session import SELECTION

GENOTYPES = ("wild_type", "dbf4-1", "cdc13-2", "dbf4-1_cdc13-2")
PASSAGES = ("1", "2", "3", "4", "5")
SMALL = 450.0                                    # µm: the small-colony cutoff of the rescue chapters


@dataclass
class Plate:
    index_id: int
    levels: dict
    name: str                                    # original photo file
    count: int
    median: float                                # µm
    capture: float                               # fraction
    growth: float                                # fraction
    hce: float
    radii_um: np.ndarray
    radii_px: np.ndarray
    plate_mm: str = ""                           # plate size annotation ('140 mm' marks a star)
    components: tuple | None = None              # (medians, weights, p25, p75)

    @property
    def cv(self) -> float:
        return float(np.std(self.radii_um, ddof=1) / np.mean(self.radii_um)) if self.radii_um.size > 1 else np.nan

    @property
    def skew(self) -> float:
        return float(st.summary_values(self.radii_um)["Skew"]) if self.radii_um.size > 2 else np.nan

    def share_below(self, cutoff: float = SMALL) -> float:
        return float(np.mean(self.radii_um < cutoff)) if self.radii_um.size else np.nan

    def share_above(self, cutoff: float) -> float:
        return float(np.mean(self.radii_um > cutoff)) if self.radii_um.size else np.nan

    @property
    def area_px(self) -> float:
        return float(np.pi * np.median(self.radii_px) ** 2) if self.radii_px.size else np.nan

    @property
    def uncertainty(self) -> float:
        """Median per-colony uncertainty, % (half a pixel over the radius)."""
        return float(np.median(50.0 / self.radii_px)) if self.radii_px.size else np.nan


@dataclass
class ProjectModel:
    name: str
    plates: dict = field(default_factory=dict)  # index id -> Plate
    extra: dict = field(default_factory=dict)

    def where(self, **levels) -> list[Plate]:
        return [p for p in self.plates.values()
                if all(p.levels.get(k) in (v if isinstance(v, (tuple, list, set)) else (v,)) for k, v in levels.items())]


def collect_plates(session) -> ProjectModel:
    """Every detected plate of a project with its measures and radii."""
    s = session.stats
    indices, colonies = s.indices, s.colonies
    meta = (session.manager._file.setting("source_metadata") or {}).get("plates", {})
    model = ProjectModel(session.name)
    model.extra["displays"] = {v.name: dict(zip(v.values, v.displays)) for v in s.variables}
    model.extra["order"] = {v.name: list(v.values) for v in s.variables}
    measures = indices.measures
    if "colony_coverage" in measures:
        model.extra["colony_coverage"] = {int(i): float(v) for i, v in zip(indices.index_ids, measures["colony_coverage"])}
    for row, index_id in enumerate(indices.index_ids):
        index_id = int(index_id)
        keep = colonies.index_ids == index_id
        annotations = (s.plate_info or {}).get(index_id, {}).get("annotations", {})
        size = next((str(v) for k, v in annotations.items() if "size" in str(k).lower()), "")
        hce = measures.get("annotation:hce")
        model.plates[index_id] = Plate(
            index_id, {name: str(values[row]) for name, values in indices.levels.items()},
            str(meta.get(str(index_id), {}).get("original_file", session.plate_name(index_id))),
            int(measures["colony_count"][row]), float(measures["median_radius_um"][row]),
            float(measures["capture_ratio"][row]) if "capture_ratio" in measures else np.nan,
            float(measures["growth_coverage"][row]) if "growth_coverage" in measures else np.nan,
            float(hce[row]) if hce is not None else np.nan,
            np.asarray(colonies.radius_um[keep], float), np.asarray(colonies.radius_px[keep], float), size)
    return model


def fit_components(model: ProjectModel, plates=None) -> None:
    """LogNormal mixture components of each plate (the fits Stats keeps and saves)."""
    from ..analyses.builtin.subpopulations import SHARED_FITS
    from ..stats.subpopfig.fitting import fit_one
    for plate in (plates if plates is not None else model.plates.values()):
        if plate.components is None and plate.radii_um.size:
            _, stats = fit_one(plate.radii_um, SHARED_FITS)
            plate.components = (np.asarray(stats.median), np.asarray(stats.weight), np.asarray(stats.p25),
                                np.asarray(stats.p75))


def density_peaks(radii: np.ndarray) -> tuple:
    grid, density, _ = log_kde(np.asarray(radii, float))
    return grid, density, peaks_of(grid, density)


# ======================================================================================
# Rescue
# ======================================================================================
def rescue(session) -> ProjectModel:
    model = collect_plates(session)
    main = {"series": ("main",)}
    session.view("plate_metrics", slots={"passage": "x", "genotype": "groups"}, levels=main,
                 options={"view": "table"}, measure="colony_count", selection=SELECTION, color_by="genotype")
    selection = session.selection()
    chosen = {}
    for group in selection.groups:
        if group.chosen is not None:
            genotype, passage = group.key
            chosen[(genotype, passage)] = int(group.chosen.index_id)
    model.extra.update(selection=selection, chosen=chosen, target=selection.target,
                       target_rule=selection.target_rule, eligible=selection.eligible)
    # fidelity: the selected plates, and every plate (mean of plate medians)
    _, fidelity_selected = session.view("fidelity", slots={"genotype": "rows", "passage": "columns"},
                                        levels=main, options={"cell": "colonies"}, selection=SELECTION)
    _, fidelity_all = session.view("fidelity", slots={"genotype": "rows", "passage": "columns"},
                                   options={"cell": "plates"})
    model.extra.update(fidelity_selected=fidelity_selected, fidelity_all=fidelity_all)
    # the dbf4-1 classifier (every main-series plate with at least 10 colonies)
    _, classifier = session.view("shape_classifier", slots={"genotype": "classes"}, levels=main,
                                 options={"target": "dbf4-1", "reference": "wild_type"})
    model.extra["classifier"] = classifier
    # mixture components of every main-series plate in the separable range, and the P5 plates
    main_plates = [p for p in model.where(series="main") if p.radii_um.size >= 10]
    fit_components(model, main_plates)
    enrich = model.where(passage="4", series=("large_enriched", "small_enriched"))
    fit_components(model, [p for p in enrich if p.radii_um.size >= 10])
    return model


def selected(model: ProjectModel, genotype: str, passage: str) -> Plate | None:
    index_id = model.extra["chosen"].get((genotype, passage))
    return model.plates.get(index_id) if index_id is not None else None


def eligible_main(model: ProjectModel, minimum: int = 50) -> list[Plate]:
    """Main-series plates in the separable range with enough colonies for the size analyses."""
    return [p for p in model.where(series="main") if p.capture >= 0.25 and p.count >= minimum]


def robustness_plates(model: ProjectModel):
    from ..core.robustness import PlateComponents
    chosen = set(model.extra["chosen"].values())
    out = []
    for p in model.where(series="main"):
        if p.components is None or p.capture < 0.25 or p.count < 10:
            continue
        cell = (p.levels["genotype"], p.levels["passage"])
        out.append(PlateComponents(p.index_id, cell, p.levels["genotype"], p.count, p.components[0],
                                   p.components[1], p.index_id in chosen))
    return out


def within_state_plates(crowding: ProjectModel, rescue_model: ProjectModel, crowding_scores: dict) -> list:
    """Plates of the within-state test: the Crowding Dataset as one state, each Rescue genotype and passage
    (main series) as another; crowding_scores: (project, index id) -> per-colony scores."""
    from ..core.within_state import Plate as TestPlate
    out = []
    for project, model in (("Crowding", crowding), ("Rescue", rescue_model)):
        plates = model.plates.values() if project == "Crowding" else model.where(series="main")
        for p in plates:
            state = "Crowding" if project == "Crowding" else f"{p.levels['genotype']} P{p.levels['passage']}"
            scores = crowding_scores.get((project, p.index_id), np.zeros(0))
            out.append(TestPlate(project, state, p.name, p.hce, p.count, p.growth, p.capture, p.median,
                                 p.radii_um, scores))
    return out


def crowding_scores(session) -> dict:
    """index id -> each colony's crowding score, in colony-table order (derived results kept in the project)."""
    out = {}
    s = session.stats
    for index_id in s.indices.index_ids:
        table = session.manager.request_derived("colony_crowding", int(index_id))
        rows = [r if isinstance(r, dict) else dict(zip(table.columns, r)) for r in table.rows]
        by_id = {int(r["colony_id"]): (np.nan if r["crowding_score"] is None else float(r["crowding_score"]))
                 for r in rows}
        measured = session.manager.request_derived("colony_measurements", int(index_id))
        ids = [int((r if isinstance(r, dict) else dict(zip(measured.columns, r)))["colony_id"]) for r in measured.rows]
        out[int(index_id)] = np.array([by_id.get(i, np.nan) for i in ids])
    return out


def picture(session, index_id: int, width_px: int = 640) -> dict:
    """A plate photo reduced for print (about 300 dpi at up to 2 in wide), its region mask, and its colony
    outlines and scale in the reduced photo's pixels."""
    from PIL import Image
    image, mask, colonies, px_per_mm = session.stats.plate_picture(int(index_id))
    scale = min(1.0, width_px / image.shape[1])
    size = (max(1, int(round(image.shape[1] * scale))), max(1, int(round(image.shape[0] * scale))))
    small = np.asarray(Image.fromarray(image[..., :3]).resize(size, Image.LANCZOS))
    region = np.asarray(Image.fromarray(mask.astype(np.uint8) * 255).resize(size, Image.NEAREST)) > 0
    outlines = []
    for i in range(len(colonies)):
        outline = colonies.boundaries[i]
        if outline is not None and len(outline) > 2:
            outlines.append(("polygon", np.asarray(outline, float) * scale))
        else:
            outlines.append(("circle", (np.asarray(colonies.centers[i], float) * scale,
                                        float(colonies.radii[i]) * scale)))
    return {"image": small, "region": region, "outlines": outlines, "px_per_mm": float(px_per_mm) * scale,
            "centers": np.asarray(colonies.centers, float) * scale, "radii": np.asarray(colonies.radii, float) * scale}
