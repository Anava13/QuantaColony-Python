"""Benchmark report from a project recorded in developer mode (developer command).

    uv run python -m quantacolony.benchmark "D:\\Projects\\Synthetic.qcproj" --truth truth.csv
    uv run python -m quantacolony.benchmark Synthetic.qcproj --truth truth.csv --idle 60 --out report

Accuracy. Each detected index is scored at three tiers against a reference:
    automatic   detection at settings estimated from the image (project defaults for the rest),
                before any person acted: the developer table dev_initial_detection
    tuned       the last whole-image detection, after any settings changes (the stored baseline)
    corrected   the final colonies, after deletions and additions
The reference is the ground truth when --truth is given. Without it the corrected colonies are
the reference, and only the automatic and tuned tiers are scored.

Ground truth: a CSV with one row per colony and the columns
    photo       file name of the photo, as added to the project
    x, y        colony center in photo pixels (0-based; x is the column, y the row)
    radius_px   colony radius in photo pixels
Colonies are assigned to an index when their center lies inside the index's region.

Matching follows core/scoring.py: a detected colony matches a reference colony when its center
lies within --tolerance x the reference radius; pairs are taken closest first. Size error is
(detected radius - reference radius) / reference radius over matched pairs.

Time. Each finished image session (dev_detection_sessions) is divided into gaps between
consecutive events. A gap counts as
    away     the program window was inactive (another program had focus)
    idle     the gap is longer than the idle cutoff (--idle, seconds)
    active   otherwise, credited to the mode the gap started in
Tuning time is active time in Modify Global Parameters; correction time is active time in the
four editing modes. Compute time is the time detection itself took (whole image and regions).
Cropping time is divided the same way, counting time between visits to a photo as away.

The project file is copied into a temporary library and read there; the file is never changed.
"""

from __future__ import annotations

import argparse
import csv
import json
import statistics
import sys
import tempfile
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from .core.colony_set import ColonySet
from .core.scoring import MATCH_TOLERANCE, Score, match
from .data import DataManager, ProjectError, Settings, create_library

DEFAULT_IDLE_S = 60.0
FIRST_MODE = "ModifyGlobalParameters"
TUNING_MODES = {"ModifyGlobalParameters"}
TIERS = ("automatic", "tuned", "corrected")


# =====================================================================
# model: time
# =====================================================================
@dataclass
class SessionTime:
    duration_ms: int = 0
    active_ms: int = 0
    idle_ms: int = 0
    away_ms: int = 0
    by_mode: dict = field(default_factory=dict)


def divide_time(events: list[dict], duration_ms: int, idle_ms: float, first_mode: str | None = FIRST_MODE
                ) -> SessionTime:
    """Split a session into active, idle and away time; active time by mode (see the module text).
    'left' and 'opened' events (Cropping) mark time away from the photo."""
    result = SessionTime(duration_ms=duration_ms)
    mode, present, previous = first_mode, True, 0
    for event in [*events, {"t_ms": duration_ms, "kind": "end", "data": {}}]:
        gap = max(0, int(event["t_ms"]) - previous)
        if gap:
            if not present:
                result.away_ms += gap
            elif gap > idle_ms:
                result.idle_ms += gap
            else:
                result.active_ms += gap
                if mode is not None:
                    result.by_mode[mode] = result.by_mode.get(mode, 0) + gap
        kind, data = event["kind"], event["data"]
        if kind == "mode":
            mode = data.get("mode", mode)
        elif kind == "focus":
            present = bool(data.get("active", True))
        elif kind == "left":
            present = False
        elif kind == "opened":
            present = True
        previous = max(previous, int(event["t_ms"]))
    return result


def session_row(session: dict, events: list[dict], edit_log: list[dict], idle_ms: float, label: str,
                initial: dict | None) -> dict:
    """One row of the image-session table."""
    time = divide_time(events, session["duration_ms"], idle_ms)
    tuning = sum(ms for mode, ms in time.by_mode.items() if mode in TUNING_MODES)
    compute = sum(e["data"].get("compute_ms", 0.0) for e in events
                  if e["kind"] in ("detection", "region_preview") and e["data"].get("trigger") != "initial")
    kinds = Counter(e["kind"] for e in events)
    gross = Counter()
    for e in events:
        if e["kind"] == "edit":
            gross[e["data"]["kind"]] += int(e["data"]["count"])
    net = Counter()
    for edit in edit_log:
        if edit["revision"] == session["revision"]:
            net[edit["kind"]] += int(edit["count"])
    return {"index": label, "index_id": session["index_id"], "revision": session["revision"],
            "start_source": session["start_source"], "duration_s": _s(time.duration_ms),
            "active_s": _s(time.active_ms), "idle_s": _s(time.idle_ms), "away_s": _s(time.away_ms),
            "tuning_s": _s(tuning), "correction_s": _s(time.active_ms - tuning),
            **{f"mode_{mode}_s": _s(ms) for mode, ms in sorted(time.by_mode.items())},
            "compute_s": _s(compute), "initial_compute_s": _s(initial["compute_ms"]) if initial else "",
            "detection_runs": sum(1 for e in events if e["kind"] == "detection" and e["data"].get("trigger") != "initial"),
            "region_previews": kinds["region_preview"], "edits_made": kinds["edit"], "undos": kinds["undo"],
            "redos": kinds["redo"], "deleted_gross": gross["Deletion"], "added_gross": gross["Addition"],
            "deleted_net": net["Deletion"], "added_net": net["Addition"],
            "corrections_net": net["Deletion"] + net["Addition"], "region_px": session["region_px"],
            "image_px": session["image_rows"] * session["image_cols"]}


def crop_row(session: dict, events: list[dict], idle_ms: float, photo_name: str) -> dict:
    time = divide_time(events, session["duration_ms"], idle_ms, first_mode=None)
    kinds = Counter(e["kind"] for e in events)
    return {"photo": photo_name, "photo_id": session["photo_id"], "visits": session["visits"],
            "sections": session["section_count"], "layout": session["layout_kind"],
            "duration_s": _s(time.duration_ms), "active_s": _s(time.active_ms), "idle_s": _s(time.idle_ms),
            "away_s": _s(time.away_ms), "layout_edits": kinds["layout"], "rotations": kinds["rotate"],
            "fits": kinds["fit"], "count_changes": kinds["count"], "picks": kinds["pick"]}


def _s(ms) -> float:
    return round(float(ms) / 1000.0, 3)


# =====================================================================
# model: accuracy
# =====================================================================
@dataclass(frozen=True)
class TierScore:
    score: Score
    radius_errors: tuple[float, ...]          # (detected - reference) / reference, one per matched pair


def score_tier(detected: ColonySet, reference: ColonySet, tolerance: float) -> TierScore:
    pairs = match(detected, reference, tolerance)
    errors = tuple(float((detected.radii[i] - reference.radii[j]) / reference.radii[j])
                   for i, j in pairs if reference.radii[j] > 0)
    return TierScore(Score(len(reference), len(detected), len(pairs)), errors)


def read_truth(path: Path) -> dict[str, np.ndarray]:
    """{photo file name: (n, 3) array of x, y, radius_px}."""
    rows: dict[str, list] = defaultdict(list)
    with open(path, newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        missing = {"photo", "x", "y", "radius_px"} - set(reader.fieldnames or [])
        if missing:
            raise ValueError(f"{path.name} needs the columns photo, x, y, radius_px (missing: {', '.join(sorted(missing))})")
        for row in reader:
            rows[row["photo"].strip()].append((float(row["x"]), float(row["y"]), float(row["radius_px"])))
    return {name: np.asarray(values, dtype=float).reshape(-1, 3) for name, values in rows.items()}


def truth_in_region(truth: np.ndarray, origin: tuple[int, int], mask: np.ndarray) -> ColonySet:
    """Ground-truth colonies whose centers lie inside the region, in crop pixels."""
    if not len(truth):
        return ColonySet.empty()
    centers = truth[:, :2] - np.array(origin, dtype=float)
    cols, rows = np.rint(centers[:, 0]).astype(int), np.rint(centers[:, 1]).astype(int)
    inside = (rows >= 0) & (rows < mask.shape[0]) & (cols >= 0) & (cols < mask.shape[1])
    inside[inside] = mask[rows[inside], cols[inside]]
    return ColonySet.from_columns(centers[inside], truth[inside, 2])


def accuracy_rows(label: str, index_id: int, scores: dict[str, TierScore], reference: str) -> list[dict]:
    rows = []
    for tier, result in scores.items():
        s, errors = result.score, np.asarray(result.radius_errors)
        rows.append({"index": label, "index_id": index_id, "tier": tier, "reference": reference,
                     "reference_colonies": s.reference, "detected": s.detected, "matched": s.matched,
                     "missed": s.missed, "extra": s.extra, "corrections": s.corrections,
                     "precision": _r(s.precision), "recall": _r(s.recall), "f1": _r(s.f1),
                     "radius_error_median": _r(np.median(errors)) if errors.size else "",
                     "radius_error_abs_median": _r(np.median(np.abs(errors))) if errors.size else ""})
    return rows


def _r(value) -> float | str:
    value = float(value)
    return "" if np.isnan(value) else round(value, 4)


# =====================================================================
# model: reading a project
# =====================================================================
@dataclass
class Report:
    accuracy: list[dict] = field(default_factory=list)
    pooled: dict[str, TierScore] = field(default_factory=dict)
    sessions: list[dict] = field(default_factory=list)
    cropping: list[dict] = field(default_factory=list)
    environments: list[dict] = field(default_factory=list)
    reference: str = "corrected"
    notes: list[str] = field(default_factory=list)


def build_report(manager: DataManager, truth: dict[str, np.ndarray] | None, idle_s: float,
                 tolerance: float = MATCH_TOLERANCE) -> Report:
    """Accuracy and time for the open project."""
    report = Report(reference="ground truth" if truth is not None else "corrected")
    records = manager.developer_records()
    info = manager.project_info()
    labels = {i.index_id: " · ".join(lv.display for lv in i.labels) for i in info.indices}
    names = {p.photo_id: p.file_name for p in manager.crop_packet().photos}
    sessions = records.detection_sessions()
    first_initial: dict[int, dict] = {}
    for session in sessions:
        if session["index_id"] not in first_initial:
            initial = records.initial_detection(session["session_id"])
            if initial is not None:
                first_initial[session["index_id"]] = initial
    if not sessions:
        report.notes.append("No developer records: the project was not opened in developer mode "
                            "(quantacolony --developer), so the automatic tier and the time tables are empty.")
    if truth is not None:
        unknown = sorted(set(truth) - set(names.values()))
        if unknown:
            report.notes.append(f"Ground truth names photos the project does not have: {', '.join(unknown[:5])}")

    pooled_scores: dict[str, list[TierScore]] = defaultdict(list)
    for index in info.indices:
        if not index.revision or not index.has_region:
            continue
        packet = manager.checkout_image(index.index_id)
        origin = manager.crop_origin(index.index_id)
        saved = packet.saved
        tiers: dict[str, ColonySet] = {}
        initial = first_initial.get(index.index_id)
        if initial is not None:
            tiers["automatic"] = ColonySet.from_columns(initial["centers"] - np.array(origin, dtype=float),
                                                        initial["radii"])
        tiers["tuned"] = saved.baseline
        if truth is not None:
            tiers["corrected"] = saved.colonies
            photo_name = names[manager.index_photo(index.index_id)]
            reference = truth_in_region(truth.get(photo_name, np.empty((0, 3))), origin, packet.record.mask)
        else:
            reference = saved.colonies
        scores = {tier: score_tier(colonies, reference, tolerance) for tier, colonies in tiers.items()}
        for tier, result in scores.items():
            pooled_scores[tier].append(result)
        report.accuracy += accuracy_rows(labels[index.index_id], index.index_id, scores, report.reference)
    for tier in TIERS:
        if pooled_scores.get(tier):
            results = pooled_scores[tier]
            report.pooled[tier] = TierScore(sum((r.score for r in results), Score(0, 0, 0)),
                                            tuple(e for r in results for e in r.radius_errors))

    idle_ms = 1000.0 * idle_s
    for session in sessions:
        events = records.detection_events(session["session_id"])
        report.sessions.append(session_row(session, events, manager.edit_log(session["index_id"]), idle_ms,
                                           labels.get(session["index_id"], str(session["index_id"])),
                                           records.initial_detection(session["session_id"])))
    for session in records.crop_sessions():
        events = records.crop_events(session["crop_session_id"])
        report.cropping.append(crop_row(session, events, idle_ms, names.get(session["photo_id"], "")))
    report.environments = records.environments()
    return report


def report_for_file(path: Path, truth_path: Path | None, idle_s: float,
                    tolerance: float = MATCH_TOLERANCE) -> Report:
    """build_report on a copy of a project file (the file itself is never changed)."""
    truth = read_truth(truth_path) if truth_path is not None else None
    with tempfile.TemporaryDirectory() as folder:
        manager = DataManager(Settings(folder=Path(folder) / "settings"))
        manager.use_library(create_library(Path(folder) / "Library"))
        manager.open_project(manager.import_project_file(Path(path)))
        try:
            return build_report(manager, truth, idle_s, tolerance)
        finally:
            manager.close()


# =====================================================================
# view: tables and summary
# =====================================================================
def write_csv(rows: list[dict], path: Path) -> None:
    columns: list[str] = []
    for row in rows:
        columns += [key for key in row if key not in columns]
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, restval="")
        writer.writeheader()
        writer.writerows(rows)


def summary_text(report: Report, idle_s: float) -> str:
    lines = [f"Reference: {report.reference}", ""]
    if report.pooled:
        lines.append(f"{'tier':<11}{'reference':>10}{'detected':>10}{'matched':>9}{'missed':>8}{'extra':>7}"
                     f"{'precision':>11}{'recall':>8}{'F1':>7}{'|radius err|':>14}")
        for tier in TIERS:
            if tier not in report.pooled:
                continue
            s, errors = report.pooled[tier].score, np.abs(report.pooled[tier].radius_errors)
            radius = f"{np.median(errors):.1%}" if errors.size else "-"
            lines.append(f"{tier:<11}{s.reference:>10}{s.detected:>10}{s.matched:>9}{s.missed:>8}{s.extra:>7}"
                         f"{s.precision:>11.3f}{s.recall:>8.3f}{s.f1:>7.3f}{radius:>14}")
        lines.append("")
    if report.sessions:
        def median(key):
            return statistics.median(float(row[key]) for row in report.sessions)
        total = sum(float(row["active_s"]) for row in report.sessions)
        lines += [f"Image sessions: {len(report.sessions)} (idle cutoff {idle_s:g} s)",
                  f"  active time per image, median: {median('active_s'):.1f} s "
                  f"(tuning {median('tuning_s'):.1f} s, correction {median('correction_s'):.1f} s)",
                  f"  detection compute per image, median: {median('compute_s'):.2f} s",
                  f"  net corrections per image, median: {median('corrections_net'):g}",
                  f"  active time, all images: {total / 60:.1f} min", ""]
    if report.cropping:
        crop_total = sum(float(row["active_s"]) for row in report.cropping)
        crop_median = statistics.median(float(row["active_s"]) for row in report.cropping)
        lines += [f"Photos cropped: {len(report.cropping)}",
                  f"  active time per photo, median: {crop_median:.1f} s; all photos: {crop_total / 60:.1f} min", ""]
    lines += report.notes
    return "\n".join(lines).rstrip() + "\n"


def write_report(report: Report, folder: Path, idle_s: float) -> str:
    folder.mkdir(parents=True, exist_ok=True)
    write_csv(report.accuracy, folder / "accuracy.csv")
    write_csv(report.sessions, folder / "image_sessions.csv")
    write_csv(report.cropping, folder / "cropping.csv")
    (folder / "environment.json").write_text(json.dumps(report.environments, indent=2), encoding="utf-8")
    text = summary_text(report, idle_s)
    (folder / "summary.txt").write_text(text, encoding="utf-8")
    return text


# =====================================================================
# controller
# =====================================================================
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Accuracy and time report for a project recorded in developer mode.")
    parser.add_argument("project", type=Path)
    parser.add_argument("--truth", type=Path, help="ground-truth CSV: photo, x, y, radius_px (photo pixels)")
    parser.add_argument("--idle", type=float, default=DEFAULT_IDLE_S, help="idle cutoff in seconds (default 60)")
    parser.add_argument("--tolerance", type=float, default=MATCH_TOLERANCE,
                        help="match when centers lie within this many reference radii (default 0.5)")
    parser.add_argument("--out", type=Path, help="report folder (default: '<project> benchmark' next to the file)")
    args = parser.parse_args(argv)
    folder = args.out or args.project.with_name(f"{args.project.stem} benchmark")
    try:
        report = report_for_file(args.project, args.truth, args.idle, args.tolerance)
    except (OSError, ValueError, ProjectError) as error:
        print(error, file=sys.stderr)
        return 1
    print(write_report(report, folder, args.idle))
    print(f"Tables written to {folder}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
