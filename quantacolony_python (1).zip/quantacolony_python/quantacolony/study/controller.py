"""User study controller: form, concepts, the practice plate with its tutorial, four plates, the results zip.

    StudyController             the flow; owns the participant's DataManager and the master window
    StudyDetectionController    Colony Detection with the order locked: no index board, no previous or
                                next, no way back to a project page, no "Estimate every new image" switch
                                (every plate starts from its own estimate); after the last plate, the
                                study's finish replaces the usual Stats / project question

Every plate's actions and times are recorded by Colony Detection's own recorder (core/benchmark.py).
The study adds stage times (form sent, concepts read, practice saved, finished) and the tutorial steps
skipped to the study record (project.stamp).
"""

from __future__ import annotations

import secrets
from pathlib import Path

import numpy as np
from PIL import Image
from PySide6.QtCore import QObject, QPoint, QPointF, QRect, Qt, QTimer, QUrl
from PySide6.QtGui import QBrush, QColor, QDesktopServices, QPen
from PySide6.QtWidgets import QGraphicsEllipseItem

from ..data import ProjectError
from ..gui.controller import ColonyDetectionController, session_from_packet
from ..gui.dialogs import QUESTION, WARNING, notify, show_message
from ..gui.main_window import ColonyDetectionWindow
from ..gui.shell import Shell
from ..gui.tutorial import Spotlight
from . import model as sm
from . import project as sp
from .views import ConceptsView, FinishView, FormView, TutorialPanel, WaitView

POLL_MS = 400                         # tutorial checks, twice a second or so
RING_COLOR = "#FF3DFF"


class StudyDetectionController(ColonyDetectionController):
    """Colony Detection for the study. on_done is called once every plate is saved."""

    on_done = None

    def _setup_navigation(self) -> None:
        super()._setup_navigation()
        w = self.window
        w.back_button.setVisible(False)
        w.prev_button.setVisible(False)
        w.next_button.setVisible(False)
        w.image_picker.setEnabled(False)
        w.start_row.setVisible(False)
        w.start_row.setVisible = lambda *_: None         # the window shows it again on every mode change

    def _show_position(self) -> None:
        super()._show_position()
        self.window.set_navigation(False, False)

    def all_indices_detected(self, count: int) -> None:
        self.notifyuser("AllDetected")
        if self.on_done is not None:
            QTimer.singleShot(0, self.on_done)


class StudyController(QObject):
    def __init__(self, app, theme, bundle: sm.Bundle, root: Path, results: Path | None = None):
        super().__init__()
        self.app, self.theme, self.bundle, self.root = app, theme, bundle, Path(root)
        self.results = results                         # folder for the zip (None: the Desktop)
        self.participant = sm.Participant()
        self.manager = None
        self.detection = None
        self.panel = None
        self.spotlight = None
        self.ring = None
        self.passed: set[str] = set()
        self.skipped: list[str] = []
        self.practice_done = False
        self.finished_path = None
        self.labels = np.asarray(Image.open(bundle.labels_path())).astype(int)
        self.shell = Shell(theme)
        self.shell.setWindowTitle("QuantaColony study")
        self.shell.closing.connect(self._closing)
        self.timer = QTimer(self)
        self.timer.setInterval(POLL_MS)
        self.timer.timeout.connect(self.check_tutorial)
        self.view = None
        self.show_form()

    # ----- screens ------------------------------------------------------------------
    def _set_view(self, view) -> None:
        previous = self.view
        self.view = view
        self.shell.set_main(view)
        if not self.shell.isVisible():
            self.shell.fit_to_screen()
            self.shell.show()
        if previous is not None:
            previous.setParent(None)
            previous.deleteLater()

    def show_form(self) -> None:
        form = FormView(self.theme, sm.QUESTIONS)
        form.nameEdited.connect(self.set_name)
        form.answerChosen.connect(self.set_answer)
        form.startRequested.connect(self.start)
        self._set_view(form)
        self._refresh_form()

    def _refresh_form(self) -> None:
        self.view.set_state(self.participant.answers, self.participant.problems())

    def set_name(self, text: str) -> None:
        self.participant.name = text
        self._refresh_form()

    def set_answer(self, key: str, text: str) -> None:
        self.participant.answers[key] = text
        self._refresh_form()

    def start(self) -> None:
        """Make the participant's project (a few seconds), then show the concepts."""
        if self.participant.problems():
            return
        self._set_view(WaitView(self.theme, "Preparing the plates…"))
        self.app.processEvents()
        seed = secrets.randbits(32)
        order = list(self.bundle.order) or sm.presentation_order([p.name for p in self.bundle.scored], seed)
        try:
            self.manager = sp.open_manager(sp.work_folder(self.root))
            sp.create_project(self.manager, self.bundle, self.participant, order, seed)
        except (ProjectError, OSError) as error:
            notify(self.shell, WARNING, "The study could not start", str(error))
            self.show_form()
            return
        view = ConceptsView(self.theme, sm.GOAL, self.bundle.concepts, self.bundle.folder / "concepts")
        view.startRequested.connect(self.start_practice)
        self._set_view(view)

    def start_practice(self) -> None:
        sp.stamp(self.manager, "concepts_read")
        index_id = self.manager.first_index_for_detection()
        packet = self.manager.checkout_image(index_id)
        record = packet.record
        window = ColonyDetectionWindow(self.theme, record.nominal_display, record.ordinal_display)
        window.setWindowTitle("QuantaColony study · Colony Detection")
        self.detection = StudyDetectionController(session_from_packet(packet), window, self.manager)
        self.detection.on_done = self.finish
        self._set_view(window)
        self.panel = TutorialPanel(self.theme)
        self.panel.showRequested.connect(self.show_anchor)
        self.panel.nextRequested.connect(self.pass_step)
        self.panel.skipRequested.connect(self.skip_step)
        self.shell.show_tutorial(self.panel)
        self.spotlight = Spotlight(window, RING_COLOR)
        self.spotlight.hide()
        self._draw_ring()
        self.timer.start()
        self.check_tutorial()

    # ----- the tutorial ---------------------------------------------------------------
    def _plate(self) -> str:
        labels = self.detection.session.record.labels
        return next((label.value for label in labels), "")

    def _practice_saved(self) -> bool:
        info = self.manager.project_info()
        return any(i.revision for i in info.indices if any(lb.value == sm.PRACTICE for lb in i.labels))

    def _target_met(self) -> bool:
        target = self.bundle.target
        if target is None or self._plate() != sm.PRACTICE:
            return False
        x0, y0 = self._offset()
        return sm.target_resolved(self.detection.session.colonies.translated(x0, y0), self.labels, target)

    def _offset(self) -> tuple[int, int]:
        return sp.crop_offset(self.bundle.practice, self.labels.shape)

    def facts(self) -> sm.Facts:
        recorder = self.detection.recorder
        events = recorder.log.events if recorder is not None else []
        return sm.facts_from_events(events, self._plate(), self._target_met(), self._practice_saved())

    def check_tutorial(self) -> None:
        if self.detection is None or self.panel is None:
            return
        if self.practice_done:
            self._show_reminder()
            return
        facts = self.facts()
        if facts.practice_saved:
            self.practice_done = True
            sp.stamp(self.manager, "practice_saved", tutorial_skipped=list(self.skipped))
            self._clear_ring()
            self.spotlight.hide()
            self._show_reminder()
            return
        step = sm.current_step(facts, self.passed)
        if step >= len(sm.STEPS):
            step = len(sm.STEPS) - 1
        s = sm.STEPS[step]
        self.panel.show_step(step + 1, len(sm.STEPS), s.title, s.text, s.task, s.met(facts))

    def _show_reminder(self) -> None:
        order = self.manager.study_record().get("order", []) if self.manager else []
        plate = self._plate()
        number = order.index(plate) + 1 if plate in order else 0
        self.panel.show_reminder(number, len(order), sm.GOAL)

    def _step(self) -> sm.Step:
        index = sm.current_step(self.facts(), self.passed)
        return sm.STEPS[min(index, len(sm.STEPS) - 1)]

    def pass_step(self) -> None:
        self.passed.add(self._step().key)
        self.check_tutorial()

    def skip_step(self) -> None:
        step = self._step()
        if step.key == "finish":
            return
        self.passed.add(step.key)
        self.skipped.append(step.key)
        self.check_tutorial()

    def anchor(self, name: str):
        """The control a step points at."""
        w = self.detection.window
        return {"settings": w.sense_row, "split": w.split_switch, "undo": w.undo_button, "finish": w.finish_button,
                "delete": w.mode_buttons.get("DeleteIndividualColonies"),
                "add": w.mode_buttons.get("AddIndividualColonies"), "ring": w.canvas}.get(name)

    def show_anchor(self) -> None:
        step = self._step()
        if step.anchor == "ring":
            self._zoom_to_ring()
        widget = self.anchor(step.anchor)
        if widget is None or not widget.isVisible():
            return
        host = self.detection.window
        top_left = widget.mapTo(host, QPoint(0, 0))
        self.spotlight.show_at(QRect(top_left, widget.size()), strong=True)
        QTimer.singleShot(3000, self.spotlight.hide)

    def _draw_ring(self) -> None:
        target = self.bundle.target
        if target is None:
            return
        x0, y0 = self._offset()
        cx, cy, r = target.center[0] - x0, target.center[1] - y0, target.radius
        self.ring = QGraphicsEllipseItem(cx - r, cy - r, 2 * r, 2 * r)
        pen = QPen(QColor(RING_COLOR), 3)
        pen.setCosmetic(True)
        pen.setStyle(Qt.DashLine)
        self.ring.setPen(pen)
        self.ring.setBrush(QBrush(Qt.NoBrush))
        self.ring.setZValue(50)
        self.detection.window.canvas.add_preview_item(self.ring)

    def _clear_ring(self) -> None:
        if self.ring is not None:
            try:
                self.detection.window.canvas.remove_preview_item(self.ring)
            except RuntimeError:
                pass
            self.ring = None

    def _zoom_to_ring(self) -> None:
        if self.ring is None:
            return
        canvas = self.detection.window.canvas
        canvas.reset_axes_view()
        canvas.centerOn(self.ring.rect().center())
        canvas.zoom_at(QPointF(canvas.viewport().rect().center()), 4.0)

    # ----- the end --------------------------------------------------------------------
    def finish(self, complete: bool = True) -> None:
        """Every plate is saved (or the participant stopped): write the zip and say where it is."""
        if self.manager is None or self.finished_path is not None:
            return
        self.timer.stop()
        if self.detection is not None:
            self.detection.window.set_close_guard(None)
        try:
            path = sp.write_results(self.manager, self.participant, self.results)
        except OSError as error:
            notify(self.shell, WARNING, "The results file could not be written", str(error))
            return
        self.finished_path = path
        self.manager = None
        self.shell.hide_tutorial()
        view = FinishView(self.theme, str(path), complete)
        view.openRequested.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(path.parent))))
        view.closeRequested.connect(self.shell.close)
        self.detection = None
        self._set_view(view)

    def _closing(self, event) -> None:
        """Closing the window mid-study asks first, then saves what is measured so far."""
        if self.manager is None:
            event.accept()
            self.app.quit()
            return
        answer = show_message(self.shell, QUESTION, "Stop the study?",
                              "The plates you finished are saved in a results file to send. Plates not finished "
                              "are left out.", [("stay", "Keep going"), ("stop", "Stop and save")], default="stay")
        if answer != "stop":
            event.ignore()
            return
        event.ignore()
        QTimer.singleShot(0, lambda: self.finish(complete=False))
