"""User study views (light palette). Each shows what the controller passes it and reports clicks as signals.

    FormView        name and the four questions, then Start
    WaitView        one line while the participant's project is made
    ConceptsView    what to measure: the goal and the concept figures, then Start the practice plate
    TutorialPanel   beside Colony Detection: the tutorial's step, its task and its check on the practice
                    plate; afterwards the goal and the plate count
    FinishView      where the results file is, and what to do with it
"""

from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QLineEdit, QScrollArea, QVBoxLayout, QWidget

from ..gui.light import LightSegmented, clear_layout, light_button, light_label, wordmark
from ..theme.stylesheet import build_light_stylesheet
from ..theme.tokens import get_quanta_colony_style

L = get_quanta_colony_style().light
PAGE_WIDTH = 760


def light_page(theme, title: str) -> tuple[QWidget, QVBoxLayout]:
    """A scrolling light page with the wordmark and a title; returns (page, column for its content)."""
    page = QWidget(objectName="LightWindow")
    page.setStyleSheet(build_light_stylesheet(theme.style.light, theme.ui_family, theme.brand_family))
    page.setWindowTitle(f"QuantaColony study · {title}")
    outer = QVBoxLayout(page)
    outer.setContentsMargins(0, 0, 0, 0)
    scroll = QScrollArea()
    scroll.setWidgetResizable(True)
    scroll.setFrameShape(QFrame.NoFrame)
    outer.addWidget(scroll)
    holder = QWidget()
    row = QHBoxLayout(holder)
    row.addStretch(1)
    body = QWidget()
    body.setMaximumWidth(PAGE_WIDTH)
    row.addWidget(body, 100)
    row.addStretch(1)
    scroll.setWidget(holder)
    column = QVBoxLayout(body)
    column.setContentsMargins(24, 28, 24, 28)
    column.setSpacing(14)
    mark = QLabel()
    mark.setPixmap(wordmark(theme, "QuantaColony study", 18))
    column.addWidget(mark)
    column.addWidget(light_label(title, "title"))
    return page, column


class FormView(QWidget):
    nameEdited = Signal(str)
    answerChosen = Signal(str, str)          # question key, chosen text
    startRequested = Signal()

    def __init__(self, theme, questions):
        super().__init__()
        self.questions = questions
        page, column = light_page(theme, "Before you start")
        self.setWindowTitle(page.windowTitle())
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(page)
        column.addWidget(light_label(
            "This study tests whether different people measure the same colonies the same way with QuantaColony. "
            "It takes about 20 to 40 minutes: a short guide, one practice plate, then four plates. The program keeps "
            "your measurements and how long each step took, and saves them in one file at the end.", "body",
            wrap=True))
        column.addWidget(light_label("Your name", "field"))
        self.name_edit = QLineEdit()
        self.name_edit.setObjectName("study-name")
        self.name_edit.setPlaceholderText("Any name that tells you apart from other participants")
        self.name_edit.setMaximumWidth(420)
        self.name_edit.textEdited.connect(self.nameEdited.emit)
        column.addWidget(self.name_edit)
        self.rows = {}
        for key, question, _ in questions:
            column.addWidget(light_label(question, "field"))
            holder = QWidget()
            line = QHBoxLayout(holder)
            line.setContentsMargins(0, 0, 0, 0)
            column.addWidget(holder, 0, Qt.AlignLeft)
            self.rows[key] = line
        self.problem = light_label("", "small", wrap=True)
        column.addWidget(self.problem)
        self.start_button = light_button("Start", "primary")
        self.start_button.setObjectName("study-start")
        self.start_button.clicked.connect(self.startRequested.emit)
        column.addWidget(self.start_button, 0, Qt.AlignLeft)
        column.addStretch(1)

    def set_state(self, answers: dict, problems: list[str]) -> None:
        for key, _, choices in self.questions:
            clear_layout(self.rows[key])
            self.rows[key].addWidget(LightSegmented(
                [(text, answers.get(key) == text, lambda k=key, t=text: self.answerChosen.emit(k, t))
                 for text in choices], height=30))
        self.problem.setText(" ".join(problems))
        self.start_button.setEnabled(not problems)


class WaitView(QWidget):
    def __init__(self, theme, text: str):
        super().__init__()
        page, column = light_page(theme, "One moment")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(page)
        column.addWidget(light_label(text, "body", wrap=True))
        column.addStretch(1)


class ConceptsView(QWidget):
    startRequested = Signal()

    def __init__(self, theme, goal: str, concepts, folder):
        super().__init__()
        page, column = light_page(theme, "What to measure")
        self.setWindowTitle(page.windowTitle())
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(page)
        column.addWidget(light_label(goal, "body", wrap=True))
        for concept in concepts:
            column.addSpacing(8)
            column.addWidget(light_label(concept.title, "field"))
            picture = QLabel()
            pixmap = QPixmap(str(folder / concept.file))
            picture.setPixmap(pixmap.scaledToWidth(min(pixmap.width(), PAGE_WIDTH - 48), Qt.SmoothTransformation))
            column.addWidget(picture)
            heads = QHBoxLayout()
            for text in ("The photo", "Wrong (red)", "Right (green)"):
                heads.addWidget(light_label(text, "small"), 1)
            column.addLayout(heads)
            column.addWidget(light_label(concept.caption, "body", wrap=True))
        column.addSpacing(8)
        column.addWidget(light_label("Next, a practice plate with a guide beside it shows where each tool is.", "body",
                                     wrap=True))
        start = light_button("Start the practice plate", "primary")
        start.setObjectName("study-concepts-done")
        start.clicked.connect(self.startRequested.emit)
        column.addWidget(start, 0, Qt.AlignLeft)
        column.addStretch(1)


class TutorialPanel(QFrame):
    """The guide beside Colony Detection."""

    showRequested = Signal()                 # point at the step's control
    skipRequested = Signal()                 # pass a step without meeting it (recorded)
    nextRequested = Signal()                 # pass a reading step

    def __init__(self, theme):
        super().__init__(objectName="LightWindow")
        self.setStyleSheet(build_light_stylesheet(theme.style.light, theme.ui_family, theme.brand_family))
        self.setMinimumWidth(320)
        self.setMaximumWidth(380)
        column = QVBoxLayout(self)
        column.setContentsMargins(18, 18, 18, 18)
        column.setSpacing(10)
        self.progress = light_label("", "small")
        self.title = light_label("", "title")
        self.title.setWordWrap(True)
        self.text = light_label("", "body", wrap=True)
        self.task = light_label("", "body", wrap=True)
        self.task.setObjectName("study-task")
        for widget in (self.progress, self.title, self.text, self.task):
            column.addWidget(widget)
        buttons = QHBoxLayout()
        self.show_button = light_button("Show me", None)
        self.next_button = light_button("Next", "primary")
        self.skip_button = light_button("Skip this step", "link")
        for widget in (self.show_button, self.next_button, self.skip_button):
            buttons.addWidget(widget)
        buttons.addStretch(1)
        column.addLayout(buttons)
        column.addStretch(1)
        self.show_button.clicked.connect(self.showRequested.emit)
        self.next_button.clicked.connect(self.nextRequested.emit)
        self.skip_button.clicked.connect(self.skipRequested.emit)

    def wanted_width(self) -> int:
        return 360

    def show_step(self, number: int, total: int, title: str, text: str, task: str, done: bool) -> None:
        self.progress.setText(f"Practice · step {number} of {total}")
        self.title.setText(title)
        self.text.setText(text)
        mark = "✓ " if done else "→ "
        self.task.setText(mark + task if task else "")
        self.task.setStyleSheet(f"color: {L.accent_text if done else L.text}; font-weight: 600;")
        self.show_button.setVisible(bool(task))
        self.next_button.setVisible(not task)
        self.skip_button.setVisible(bool(task) and not done)

    def show_reminder(self, plate: int, total: int, goal: str) -> None:
        self.progress.setText(f"Plate {plate} of {total}" if plate else "")
        self.title.setText("Measure every colony")
        self.text.setText(goal + "\n\nPress Finish image when the outlines match the colonies. The next plate "
                                 "opens on its own.")
        self.task.setText("")
        for widget in (self.show_button, self.next_button, self.skip_button):
            widget.setVisible(False)


class FinishView(QWidget):
    openRequested = Signal()
    closeRequested = Signal()

    def __init__(self, theme, path: str, complete: bool):
        super().__init__()
        page, column = light_page(theme, "Thank you" if complete else "Study stopped")
        self.setWindowTitle(page.windowTitle())
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(page)
        lead = ("Every plate is measured. Your results are saved in this file:" if complete else
                "The plates measured so far are saved in this file:")
        column.addWidget(light_label(lead, "body", wrap=True))
        where = light_label(path, "field", wrap=True)
        where.setObjectName("study-results-path")
        where.setTextInteractionFlags(Qt.TextSelectableByMouse)
        column.addWidget(where)
        column.addWidget(light_label("Send this file to the person who gave you the study. It holds your "
                                     "measurements, the times of each step and your answers to the first page.",
                                     "body", wrap=True))
        buttons = QHBoxLayout()
        show = light_button("Show the file", "primary")
        close = light_button("Close", None)
        show.clicked.connect(self.openRequested.emit)
        close.clicked.connect(self.closeRequested.emit)
        buttons.addWidget(show)
        buttons.addWidget(close)
        buttons.addStretch(1)
        column.addLayout(buttons)
        column.addStretch(1)
