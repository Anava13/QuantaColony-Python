"""Entry point of the user study: quantacolony-study, or python -m quantacolony.study.

    uv run quantacolony-study                       the study, working files under ~/QuantaColony Study
    uv run quantacolony-study --results D:\\Out      write the results zip there (default: the Desktop)

Each session works in a folder of its own under the working folder (project, library, settings), so
a second participant on the same computer never sees the first one's files. The results zip is the
only file to send.
"""

from __future__ import annotations

import argparse
import sys
import traceback
from pathlib import Path

from PySide6.QtWidgets import QApplication

from ..gui.dialogs import ERROR, notify
from ..theme import apply_theme
from ..theme.icons import app_icon
from .controller import StudyController
from .model import load_bundle

BUNDLE = Path(__file__).resolve().parent / "bundle"
WORK = Path.home() / "QuantaColony Study"


def main() -> int:
    parser = argparse.ArgumentParser(description="QuantaColony user study")
    parser.add_argument("--work", default=str(WORK), help="folder for each session's working files")
    parser.add_argument("--results", default=None, help="folder for the results zip (default: the Desktop)")
    args = parser.parse_args()
    app = QApplication(sys.argv[:1])
    app.setApplicationName("QuantaColony study")
    app.setWindowIcon(app_icon())
    try:
        controller = StudyController(app, apply_theme(app), load_bundle(BUNDLE), Path(args.work),
                                     Path(args.results) if args.results else None)
    except Exception:                               # started from a shortcut: no console to show it
        notify(None, ERROR, "The study could not start", traceback.format_exc())
        return 1
    app.controller = controller                     # kept alive while the window is open
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
